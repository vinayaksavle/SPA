import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/_layout/header/header.component';
import { AppMatModule } from './modules/app-mat.module';
import { MatTableModule, MatIconModule } from '@angular/material';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { LayoutComponent } from './components/_layout/layout/layout.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    LayoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    AppMatModule,
    MatTableModule,
    MatIconModule,
    DragDropModule,
  ],
  providers: [{ provide: LocationStrategy, useClass: HashLocationStrategy }],
  entryComponents: [LayoutComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
