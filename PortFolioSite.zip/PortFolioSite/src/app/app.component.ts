import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { filter } from 'rxjs/operators';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  title = 'PortFolioSite';

  constructor(private router: Router) {
    this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(() => {
      const showMenu = sessionStorage.getItem('showMenu');
      if (showMenu === 'false') {
        document.querySelector('.section__sidenav').classList.add('show');
        document.querySelector('.section__main').classList.add('full');
      } else if (showMenu === 'true') {
        const sideNav = document.querySelector('.section__sidenav');
        const sectionMain = document.querySelector('.section__main');
        if (!isNullOrUndefined(sideNav)) {
          sideNav.classList.remove('show');
        }
        if (!isNullOrUndefined(sectionMain)) {
          sectionMain.classList.remove('full');
        }
      }
    });
  }

  ngOnInit() {
    sessionStorage.setItem('showMenu', 'true');
  }
}
