import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit {
    showMenu: string = 'true';

    constructor() { }

    ngOnInit(): void {

    }

    toggleLeftNav() {
        this.showMenu = sessionStorage.getItem('showMenu');
        if (this.showMenu === 'true') {
            sessionStorage.setItem('showMenu', 'false');
            document.querySelector('.section__sidenav').classList.add('show');
            document.querySelector('.section__main').classList.add('full');
        } else if (this.showMenu === 'false') {
            sessionStorage.setItem('showMenu', 'true');
            document.querySelector('.section__sidenav').classList.remove('show');
            document.querySelector('.section__main').classList.remove('full');
        }
    }
}