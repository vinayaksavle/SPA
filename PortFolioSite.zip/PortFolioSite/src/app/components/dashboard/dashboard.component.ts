import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.css'],
    host: { 'class': 'section__main' }
})
export class DashboardComponent implements OnInit {
    ngOnInit(): void { }
}