import { OnInit, Component } from '@angular/core';
import { isNullOrUndefined } from 'util';

@Component({
    selector: 'sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.css'],
    host: { 'class': 'section__sidenav' }
})

export class SidebarComponent implements OnInit {
    urlMenu = "dashboard";

    constructor() { }

    ngOnInit(): void { }

    showSubMenu(val: string): void {
        if (!isNullOrUndefined(val) && val.length > 0 && !isNullOrUndefined(document.getElementById(val))) {
            document.getElementById(val).style.left = '0';
        }
    }

    hideSubMenu(val: string): void {
        if (!isNullOrUndefined(val) && val.length > 0 && !isNullOrUndefined(document.getElementById(val))) {
            document.getElementById(val).style.left = '-150px';
        }
    }

}