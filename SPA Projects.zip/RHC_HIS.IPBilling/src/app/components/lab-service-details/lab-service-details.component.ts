import { Component, OnInit, ViewChild, HostBinding } from '@angular/core';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatTableDataSource, MatSort, MatDialogRef } from '@angular/material';
import { isNullOrUndefined } from 'util';
import { ParseDate } from 'shared-utility';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { messageConstant } from 'src/app/constants/messageConstants';
import { BillDropdownComponent } from 'bill-dropdown';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';

@Component({
  selector: 'app-lab-service-details',
  templateUrl: './lab-service-details.component.html',
  styleUrls: ['./lab-service-details.component.css'],
  host: { 'class': 'section__main' },
})
export class LabServiceDetailsComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('billDropdown') billDropdownComponent: BillDropdownComponent;
  @ViewChild('patDetails') patDetailComp: PatientDetailsComponent;
  isPopup: boolean = false;
  regNo: string;
  labServiceForm: FormGroup
  labPrintData: any = {};
  searchObj: any = {};
  public displayedColumnsList: string[] = ['DepartmentCode', 'ServiceCode', 'ServiceGroupName', 'Quantity', 'ServiceCost', 'ServiceAmount', 'ServiceDate'];
  public labDetails = new MatTableDataSource();
  public total: any = 0.00;
  hiddenItems: any = ['FinalButton', 'InterimButton', 'DoctorButton', 'ApprovedAmount',
    'TPA', 'DischDateTime', 'InsCompanyName'];
  permissions: any = [];
  canPrint: boolean;
  constructor(
    private httpService: HttpService,
    private loader: LoaderService,
    public fb: FormBuilder,
    private commonService: CommonService,
    public dialogRef: MatDialogRef<LabServiceDetailsComponent>) {
    //#region permission
    this.permissions = JSON.parse(localStorage.getItem('Permission'));

    if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
      // Print Permissons set
      this.canPrint = this.permissions.includes('4006P') ? true : false;
    }
    //#endregion
  }

  @HostBinding('class.full') get valid() { return this.isPopup; }

  ngOnInit() {
    this.initForm();
  }



  ngAfterViewInit(): void {
    if (this.isPopup && this.commonService.isValidStringValue(this.regNo)) {
      this.patDetailComp.setPatientDetailByRegNo(this.regNo, true);
      setTimeout(() => {
        this.onSubmit();
      }, 5000);

    }
  }

  initForm() {
    this.labServiceForm = this.fb.group({
      EnableDates: [false],
      RegNo: [''],
      FolioNo: [''],
      FromDate: [new Date()],
      ToDate: [new Date()],
      DeptCode: [''],
      BillNo: [''],
      FolioNumberForBill: [''],
      BillDate: [''],
      DonorCheck: [false],
      RateWiseCheck: [true],
      DetailsDatesCheck: [false],
      LoadBackUpCheck: [false]
    });
  }

  public get f() {
    return this.labServiceForm.controls;
  }

  setPatientDetail(patient: any, patDetails?: any, date?, dept?) {

    if (!this.commonService.isValidStringValue(patient.RegNo)) {
      this.clearSearch(date, patDetails, dept)
      return;
    }
    this.createSeacrhObj(patient);
    // After selecting patient from Patient Enquiry clear previous lab details
    this.labDetails = new MatTableDataSource([]);
    this.f.BillNo.setValue('');
    this.f.BillDate.setValue('');
    this.f.FolioNumberForBill.setValue('');
    this.billDropdownComponent.regNo = this.f.RegNo.value;
    this.billDropdownComponent.GetBills();

    this.labPrintData.RegNo = this.f.RegNo.value;
    this.labPrintData.PatientName = patient.Title + " " + patient.PatientName;
    this.labPrintData.DischargeDate = patient.DischargeDate;
  }

  getFormFieldValue(event, component) {
    if (component === 'Date') {
      this.f.FromDate.setValue(new Date(event.FromDate.value));
      this.f.ToDate.setValue(new Date(event.ToDate.value));
    } else if (component === 'Dept') {
      this.f.DeptCode.setValue(event.DepartmentCode)
    }
  }

  clearSearch(date, patientDetails, dept) {
    date.FromDate.setValue(new Date());
    date.ToDate.setValue(new Date());
    patientDetails.patientForm.reset();
    dept.clearLookupSearch();
    this.billDropdownComponent.billList = [];
    this.initForm();
    this.searchObj = {};
    this.labDetails = new MatTableDataSource();
    this.total = 0.00;
  }

  onSubmit(date?) {
    if (!this.validateForm(date)) {
      return;
    }
    this.createSeacrhObj();
    this.loader.spin.next(true);
    this.labDetails = new MatTableDataSource();
    this.httpService.Post(urlConstant.LabServiceDetails.GetDepartmentWiseServiceDetails(), this.searchObj).subscribe(response => {
      if (response && response.Data.length > 0) {
        this.labDetails = new MatTableDataSource(response.Data);
        this.labDetails.sort = this.sort;
        this.total = response.Data.filter(s => this.commonService.isValidStringValue(s.ServiceAmount)).map(item => item.ServiceAmount).reduce((prev, next) => parseFloat(prev) + parseFloat(next));
        this.labPrintData.TotalAmount = this.total;
      }
      else {
        this.labDetails = new MatTableDataSource();
      }
      this.loader.spin.next(false);
    });
    this.loader.spin.next(false);
  }

  validateForm(date?) {
    if (!this.commonService.isValidStringValue(this.f.RegNo.value)) {
      this.commonService.openSnackBar(messageConstant.AllowToGo.RegNoRequired,
        messageConstant.invalidMessages.OK);
      return false;
    }
    // if (!this.commonService.isValidStringValue(date.FromDate.value)) {
    //   this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidFromDate,
    //     messageConstant.invalidMessages.OK);
    //   return false;
    // }
    // if (!this.commonService.isValidStringValue(date.ToDate.value)) {
    //   this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidToDate,
    //     messageConstant.invalidMessages.OK);
    //   return false;
    // }
    // if (new ParseDate().transform(date.FromDate.value) > new ParseDate().transform(new Date())) {
    //   this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidFromDate,
    //     messageConstant.invalidMessages.OK);
    //   return false;
    // }
    // if (new ParseDate().transform(date.ToDate.value) > new ParseDate().transform(new Date())) {
    //   this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidToDate,
    //     messageConstant.invalidMessages.OK);
    //   return false;
    // }
    return true;
  }

  createSeacrhObj(patientObj?: any) {
    if (!isNullOrUndefined(patientObj) && patientObj !== '') {
      this.f.RegNo.setValue(patientObj.RegNo);
      this.f.FolioNo.setValue(patientObj.FolioNo);
      this.searchObj.RegNo = this.f.RegNo.value;
      this.searchObj.FolioNo = this.f.FolioNo.value;
    }

    this.searchObj.BillNo = this.f.BillNo.value;
    if (this.f.EnableDates.value) {
      this.searchObj.ServiceFromDate = new ParseDate().transform(this.f.FromDate.value);
      this.searchObj.ServiceToDate = new ParseDate().transform(this.f.ToDate.value);
    }
    else {
      this.searchObj.ServiceFromDate = '';
      this.searchObj.ServiceToDate = '';
    }
    this.searchObj.DepartmentCode = this.f.DeptCode.value;
    this.searchObj.CheckDonor = this.f.DonorCheck.value;
    this.searchObj.LoadBackUpData = this.f.LoadBackUpCheck.value;
    this.searchObj.DetailsDatesCheck = this.f.DetailsDatesCheck.value;
  }

  printLabServices() {
    this.labPrintData.DetailsDatesCheck = this.f.DetailsDatesCheck.value;
    let printData = this.labPrintData;
    let labServices: any = this.labDetails.data;
    printData.LabServiceList = labServices;
    this.httpService.Post(urlConstant.Billing.GetLabServicePrint(), printData).subscribe(response => {
      if (this.commonService.isValidStringValue(response))
        this.httpService.openFile(response);
    });
  }

  setBillDetail(bill: any) {
    this.f.BillNo.setValue(bill.IpBillNo);
    this.f.BillDate.setValue(bill.BillDate);
    this.f.FolioNumberForBill.setValue(bill.FolioNo);
  }


  closeDialog() {
    this.dialogRef.close();
  }

  setFolio(folioNo: string) {
    this.f.FolioNo.setValue(folioNo);
    this.searchObj.FolioNo = this.f.FolioNo.value;
  }
}
