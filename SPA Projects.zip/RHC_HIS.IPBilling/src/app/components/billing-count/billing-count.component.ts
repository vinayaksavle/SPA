import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';

@Component({
    selector: "app-billing-count",
    templateUrl: "./billing-count.component.html",
    styleUrls: ["./billing-count.component.css"],
    host: { class: "section__main" },
})

export class BillingCountComponent implements OnInit {
    totalJeevaCount: number = 0;
    totalProMedikCount: number = 0;
    billingCountForm: FormGroup;
    billingCountDtls: MatTableDataSource<any> = new MatTableDataSource();;
    displayedColumns = ["PCatDesc", "Jeeva", "ProMedik"];

    constructor(private fb: FormBuilder, private commonService: CommonService,
        private httpService: HttpService, private loader: LoaderService) { }

    ngOnInit() {
        this.initializeForm();
        this.getBillingCount();
    }

    initializeForm() {
        this.billingCountForm = this.fb.group({
            FromDate: [new Date(), Validators.required],
            ToDate: [new Date(), Validators.required]
        })
    }

    get f() {
        return this.billingCountForm.controls;
    }

    // sets from date and to date from library element
    setDate(event) {
        if (!isNullOrUndefined(event)) {
            this.f.FromDate.setValue(new Date(event.FromDate.value).toLocaleDateString());
            this.f.ToDate.setValue(new Date(event.ToDate.value).toLocaleDateString());
        }
    }

    // Author - Vinayak Savale
    getBillingCount() {
        this.loader.spin.next(true);
        const inputParams = this.billingCountForm.getRawValue();
        this.httpService.Post(urlConstant.Billing.GetBillingCount(), inputParams).subscribe(response => {
            if (response.Status === 200) {
                this.billingCountDtls = new MatTableDataSource(response.Data);
                this.totalJeevaCount = response.Data.map(x => parseFloat(x.Jeeva != null ? x.Jeeva : 0)).reduce((prev, curr) => prev + curr, 0);
                this.totalProMedikCount = response.Data.map(x => parseFloat((x.ProMedik != null ? x.ProMedik : 0))).reduce((prev, curr) => prev + curr, 0);
            }
            else {
                this.billingCountDtls = new MatTableDataSource([]);
                this.totalJeevaCount = 0;
                this.totalProMedikCount = 0;
            }
            this.loader.spin.next(false);
        })
    }

    exportToExcel() {
        this.loader.spin.next(true);
        const inputParams = this.billingCountForm.getRawValue();
        this.httpService.Post(urlConstant.Billing.GetNewSystemBillDtls(), inputParams).subscribe(response => {
            if (response && !isNullOrUndefined(response.Data)
                && response.Status === 200) {
                this.httpService.exportToExcel(response.Data);
            }
            this.loader.spin.next(false);
        })
    }
}