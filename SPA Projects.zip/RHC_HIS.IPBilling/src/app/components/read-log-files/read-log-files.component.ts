import { Component, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { urlConstant } from 'src/app/constants/urlConstants';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
  selector: 'app-read-log-files',
  templateUrl: './read-log-files.component.html',
  styleUrls: ['./read-log-files.component.css'],
  host: { 'class': 'section__main' }
})
export class ReadLogFilesComponent implements OnInit {

  fileContent: any = [];
  maxDate: any = new Date();
  LogFileName=new FormControl('',Validators.required);
  logFileList=[];
  constructor(private _httpService: HttpService,private _loader:LoaderService) {
    
  }

  ngOnInit() {
    this._httpService.Get(urlConstant.ReadLogFiles.GetLogFileNames).subscribe(
      res=>{
        this._loader.spin.next(true);
        if(res.Status==200 && res.Data.length>0){
          this.logFileList=res.Data;
          this._loader.spin.next(false);
        } else{
          this._loader.spin.next(false);
        }

      });
  }
  readLogFile(){
    this._httpService.Get(urlConstant.ReadLogFiles.ReadFile(this.LogFileName.value)).subscribe(
      res=>{
        this._loader.spin.next(true);
        if(res.Status==200){
          this.fileContent=res.Data;
          this._loader.spin.next(false);
        } else{
          this._loader.spin.next(false);
        }
      });
  }

  
  }


