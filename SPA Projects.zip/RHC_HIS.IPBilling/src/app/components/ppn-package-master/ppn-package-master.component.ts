import { Component, OnInit, ViewChild } from '@angular/core';
import 'rxjs/add/operator/filter';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { MatSort, MatTableDataSource, MatDialog } from '@angular/material';
import { PackageMasterListModel } from 'src/app/models/ppn-package-master.model';
import { PreviousPackagesComponent } from '../previous-packages/previous-packages.component';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
  selector: 'app-ppn-package-master',
  templateUrl: './ppn-package-master.component.html',
  styleUrls: ['./ppn-package-master.component.css'],
  host: { 'class': 'section__main' }
})

export class PPNPackageMaterComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  selectedRowData: any;
  selectedRowIndex: number = -1;
  action: string = "S"; // Default action is save
  packageMasterForm: FormGroup;
  packageMasterList: MatTableDataSource<PackageMasterListModel> = new MatTableDataSource();
  displayedColumns = ["PackageCode", "PackageName", "GeneralWardAmount", "Amount",
    "PrivateRoomAmount", "NHGeneralWardAmount", "NHSemiPvtAmount", "NHPvtRoomAmount"];

  constructor(
    private fb: FormBuilder,
    private commonService: CommonService,
    private dialog: MatDialog,
    private httpService: HttpService,
    private loader: LoaderService) {
  }

  ngOnInit() {
    this.initializeform();
    this.getCGHSPackageMasterList();
  }

  // Initialiaze form
  initializeform() {
    this.packageMasterForm = this.fb.group({
      PackageCode: ["", Validators.required],
      PackageName: ["", Validators.required],
      GeneralWardAmount: ["", Validators.required],
      Amount: ["", Validators.required],
      PrivateRoomAmount: ["", Validators.required],
      NHGeneralWardAmount: ["", Validators.required],
      NHSemiPvtAmount: ["", Validators.required],
      NHPvtRoomAmount: ["", Validators.required],
    });
  }

  // get package master controls
  get f() {
    return this.packageMasterForm.controls;
  }

  // To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }

  // Author - Vinayak Savale
  // Get CGHS Package Master List
  getCGHSPackageMasterList() {
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.Billing.GetCGHSPackageMasterList()).subscribe(response => {
      this.packageMasterList = new MatTableDataSource(response.Data);
      this.packageMasterList.sort = this.sort;
      this.loader.spin.next(false);
    });


  }

  // Open Previous Package dialog box
  openPreviousPackages() {
    const dialogRef = this.dialog.open(PreviousPackagesComponent, {
      maxHeight: '600px',
      disableClose: true
    });

    dialogRef.componentInstance.isPopup = true;
  }

  // Author - Vinayak Savale
  // Update Package Master
  updatePackageMaster() {
    this.loader.spin.next(true);

    this.packageMasterForm.patchValue({
      PackageCode: this.selectedRowData.PackageCode, PackageName: this.selectedRowData.PackageName, GeneralWardAmount: this.selectedRowData.GeneralWardAmount, Amount: this.selectedRowData.Amount, PrivateRoomAmount: this.selectedRowData.PrivateRoomAmount, NHGeneralWardAmount: this.selectedRowData.NHGeneralWardAmount, NHSemiPvtAmount: this.selectedRowData.NHSemiPvtAmount, NHPvtRoomAmount: this.selectedRowData.NHPvtRoomAmount
    });

    this.f.PackageCode.disable();
    this.action = "U";
    this.loader.spin.next(false);
  }

  // Author - Vinayak Savale
  // Save or Update Package Master based on the action value
  savePPNPackageMaster() {
    if (!this.validateForm()) return;

    const packageMasterInput = this.packageMasterForm.getRawValue();

    // if action is "S" that means save package master
    if (this.action === "S") {
      this.commonService.confirmAction("Save Package Master", "Do you want to save ?").subscribe(response => {
        if (response) {
          this.loader.spin.next(true);
          this.httpService.Post(urlConstant.Billing.SavePackageMaster(), packageMasterInput).subscribe(response => {
            if (response.Status === 200) {
              this.commonService.displayPromptMessage("Save Package Master", "Package master saved successfully").subscribe(response => {
                this.loader.spin.next(false);
                window.location.reload();
              });
            } else{
              this.commonService.displayPromptMessage("Save Package Master", "Unable to save , Duplicate Package Code or Name!");
                this.loader.spin.next(false);
                window.location.reload();
            }
          });
        }
      });
    }
    // if action is U that means update package master
    else {
      this.commonService.confirmAction("Update Package Master", "Do you want to update package master ?").subscribe(response => {
        if (response) {
          this.httpService.Post(urlConstant.Billing.UpdatePackageMaster(), packageMasterInput).subscribe(response => {
            if (response.Status === 200) {
              this.commonService.displayPromptMessage("Update Package Master", "Package master updated successfully").subscribe(response => {
                window.location.reload();
              });
            }
          });
        }
      });
    }
  }

  // validate before inserting or updating form value.
  validateForm(): boolean {

    if (!this.commonService.isValidStringValue(this.f.PackageCode.value)) {
      this.commonService.openSnackBar("Please enter PPN code", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.PackageName.value)) {
      this.commonService.openSnackBar("Please enter Procedure name", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.GeneralWardAmount.value)) {
      this.commonService.openSnackBar("Please enter General Ward Rate", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.Amount.value)) {
      this.commonService.openSnackBar("Please enter Semi Pvt Rate", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.PrivateRoomAmount.value)) {
      this.commonService.openSnackBar("Please enter Pvt Room Rate", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.NHGeneralWardAmount.value)) {
      this.commonService.openSnackBar("Please enter NH General Ward Rate", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.NHSemiPvtAmount.value)) {
      this.commonService.openSnackBar("Please enter NH Semi Pvt Rate", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.NHPvtRoomAmount.value)) {
      this.commonService.openSnackBar("Please enter NH Pvt Room Rate", "Ok");
      return false;
    }

    return true;
  }

  // reset form values
  resetForm() {
    this.packageMasterForm.reset();
    this.f.PackageCode.enable();
    this.action = "S";
  }

  // filters the table 
  public filterList = (value: string) => {
    this.packageMasterList.filter = value.trim().toLocaleLowerCase();
  }
}