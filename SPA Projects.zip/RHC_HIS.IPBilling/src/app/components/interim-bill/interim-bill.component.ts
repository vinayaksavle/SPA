import { Component, OnInit, ViewChild } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { FormBuilder, FormGroup } from "@angular/forms";
import { HttpService } from "src/app/services/http.service";
import { LoaderService } from "src/app/services/loader.service";
import { ServiceBillModel } from "src/app/models/service-bill.model";
import { urlConstant } from "src/app/constants/urlConstants";
import { isNullOrUndefined } from "util";
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material';
import { PreviousBillsComponent } from '../previous-bills/previous-bills.component';

@Component({
  selector: "app-interim-bill",
  templateUrl: "./interim-bill.component.html",
  styleUrls: ["./interim-bill.component.css"],
  host: { class: "section__main" },
})

export class InterimBillComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  //Flag to decide between interim and final billing
  billTypeFlag: string = "IN";
  isFromFinal: boolean = false;
  newBillForm: FormGroup;
  serviceListDetails: MatTableDataSource<ServiceBillModel> = new MatTableDataSource();
  patientDetails: any;
  ipBillNo: string;
  regNo: string;
  totalBill: string;
  categoryCode: string;
  bedCategoryCode: string;
  previousBill: string;
  netAmt: string;
  doctBill: string;
  totalDepositAmount: string;
  folioNo: string;
  voucherNo: string;
  billDate: string;
  billTime: string;
  userId: string;
  errorList: any;

  displayedColumns = [
    "DepartmentCode",
    "ServiceCode",
    "ServiceName",
    "Amount",
    "Qty",
    "ServiceCategory",
    "DoctCode",
    "ChrgDesc",
  ];

  constructor(
    private fb: FormBuilder,
    private httpService: HttpService,
    private loader: LoaderService,
    private dialog: MatDialog,
    private router: Router,
    private activateRoute: ActivatedRoute
  ) { }

  //  constructor(private router: Router,private activateRoute : ActivatedRoute) { }

  ngOnInit() {

    this.activateRoute
      .queryParams
      .subscribe(params => {
        // Defaults to 0 if no query param provided.
        //this.page = +params['serviceId'] || 0;
        console.log(params.source);
        if (params.source == 'final-bill') {
          this.isFromFinal = true
          this.billTypeFlag = 'FN';
        }
      });

    this.initializeForm();
    this.serviceListDetails.sort = this.sort;
  }

  //Function to return interim bill form controls
  get f() {
    return this.newBillForm.controls;
  }

  //Initialize form
  initializeForm() {
    this.newBillForm = this.fb.group({
      BillNo: "",
      RegNo: "",
      FolioNo: "",
      CategoryCode: "",
      BedCategoryCode: ""
    });

    this.viewBillDetails();
  }

  // Author - Vinayak Savale
  // Get Patient Details from patient-detail.component
  getPatientDetail(patient: any) {
    this.patientDetails = patient;
    console.log('Reg No from Patient Details :' + patient.RegNo);
    this.regNo = patient.RegNo;
    this.folioNo = patient.FolioNo;
    this.categoryCode = isNullOrUndefined(patient.CategoryCode) ? "" : patient.CategoryCode;
    this.bedCategoryCode = isNullOrUndefined(patient.BedCategoryCode) ? "" : patient.BedCategoryCode;
    this.getServiceDetails();
  }

  // Author - Vinayak Savale
  // On validate bill no fetch service details
  getServiceDetails() {
    if (this.newBillForm.invalid) {
      return;
    }

    const newBillInput = this.getNewBillInput();
    this.loader.spin.next(true);

    this.httpService
      .Post(urlConstant.Billing.GetServiceList(), newBillInput)
      .subscribe(
        (response: any) => {
          if (
            response &&
            !isNullOrUndefined(response) &&
            response.Data.BillingServiceList.length > 0 &&
            response.Status === 200
          ) {
            console.log('Response ' + response);
            if (response.Data.BillingInfoList != null) {
              this.regNo = response.Data.BillingInfoList[0].RegNo;
              console.log('RegNo: ' + this.regNo);
              this.totalBill = response.Data.BillingInfoList[0].BillTotal;
              console.log('Total Bill: ' + this.totalBill);
              this.previousBill = response.Data.BillingInfoList[0].PreviousBills;
              this.netAmt = response.Data.BillingInfoList[0].NetAmt;
              this.doctBill = response.Data.BillingInfoList[0].DoctBill;
              this.folioNo = response.Data.BillingInfoList[0].FolioNo;
              this.voucherNo = response.Data.BillingInfoList[0].VoucherNo;
              this.billDate = response.Data.BillingInfoList[0].BillDate;
              this.billTime = response.Data.BillingInfoList[0].BillTime;
              this.userId = response.Data.BillingInfoList[0].UserId;
            }

            this.totalDepositAmount = response.Data.TotalDepositAmount;
            console.log('Total Deposit Amt ' + this.totalDepositAmount);

            this.serviceListDetails = new MatTableDataSource(response.Data.BillingServiceList);
            console.log('Service Details ' + response.Data.BillingServiceList);
            const serviceList = response.Data.BillingServiceList;
            //For interim billing service details
            if (this.billTypeFlag === "IN") {
              this.serviceListDetails = new MatTableDataSource(serviceList);
            }
            //For final billing other than doctor fees and for doctor fees  
            else if (this.billTypeFlag === "FN") {
              const servListOtherThanDoct = response.Data.OtherThanDocFeeServList;
              const servListForDoct = response.Data.BillDocFeeServList;
              //Using spread operator combined json response
              const finalBillServDtls = [...serviceList, ...servListOtherThanDoct, ...servListForDoct];
              const distinctServDtls = finalBillServDtls.filter((val, ind, arr) => arr.findIndex(d => d.DepartmentCode === val.DepartmentCode) === ind);
              this.serviceListDetails = new MatTableDataSource(distinctServDtls);
            }
            else {
              this.serviceListDetails = new MatTableDataSource([]);
              this.loader.spin.next(false);
            }
            this.serviceListDetails.sort = this.sort;
            this.loader.spin.next(false);
          } else if (response && response.Status === 400) {
            this.serviceListDetails = new MatTableDataSource([]);
            this.errorList = response.Data.BillingServiceList;
            this.loader.spin.next(false);
          } else {
            this.serviceListDetails = new MatTableDataSource([]);
            this.loader.spin.next(false);
          }
        },
        (error) => {
          this.serviceListDetails = new MatTableDataSource([]);
          this.loader.spin.next(false);
          console.log("Error : " + error);
        }
      );
  }

  //Input to fetch service details
  getNewBillInput() {
    return {
      IpBillNo: this.f.BillNo.value,
      RegNo: this.regNo,
      BillTotal: this.totalBill,
      CategoryCode: this.categoryCode,
      BedCategoryCode: this.bedCategoryCode,
      //PfNo: this.patientDetails.PfundNo,
      ServiceCost: this.totalBill,//check once whether value is correct
      ServiceAmt: this.totalBill,//check once whether value is correct
      FolioNo: this.folioNo,
      VoucherNo: this.voucherNo,
      ServDate: this.billDate,
      BookDate: this.billDate,
      BookTime: this.billTime,
      UserId: this.userId,
      BillTypeFlag: this.billTypeFlag
    };
  }

  /// Author -  Vinayak Savale
  /// Save new bill
  saveNewBill() {
    if (this.newBillForm.invalid)
      return;

    const newBillInput = this.getNewBillInput();
    this.loader.spin.next(true);
    this.httpService.Post(urlConstant.Billing.SaveBill(), newBillInput).subscribe(response => {
      console.log('Response for Save ' + response.Data);
    },
      (error) => {
        console.log('Error in save' + error);
      });
    this.loader.spin.next(false);
  }

  //navigation view details
  viewBillDetails() {
    this.activateRoute.queryParams.subscribe(params => {
      if (this.activateRoute.snapshot.queryParams['IpBillNo']) {
        this.ipBillNo = params['IpBillNo'];
        this.loader.spin.next(true);
        this.setViewData(this.ipBillNo);
        this.getServiceDetails();
        this.loader.spin.next(false);
      }
    });
  }

  //set ipbillno to fetch service details
  setViewData(ipBillNo: string) {
    this.newBillForm.patchValue({
      "BillNo": ipBillNo
    });

    this.newBillForm.disable();
  }

  /// Author -  Vinayak Savale
  /// On click of previous bill button it will open Previous Bill dialog box
  openPreviousBills() {
    const dialogRef = this.dialog.open(PreviousBillsComponent, {
      width: '90%',
      maxWidth: '1024px',
      maxHeight: '600px',
      disableClose: true
    });

    dialogRef.componentInstance.isPopup = true;
    dialogRef.componentInstance.regNo = this.regNo;
    dialogRef.componentInstance.folioNo = this.folioNo;
  }

  alldeptInput($event) {

  }

  summaryInput($event) {

  }
}
