import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MatTableDataSource, MatDialog, MatSort } from '@angular/material';
import { messageConstant } from 'src/app/constants/messageConstants';
import { ParseDate } from 'shared-utility';
import { urlConstant } from 'src/app/constants/urlConstants';
import { isNullOrUndefined } from 'util';
import { PatientEnquiryComponent } from 'patient-enquiry';
import { AdmissionNumberLookupComponent } from 'admission-number-lookup';
import { Router, NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-package-collection',
  templateUrl: './package-collection.component.html',
  styleUrls: ['./package-collection.component.css'],
  host: { 'class': 'section__main' }
})
export class PackageCollectionComponent implements OnInit {
  @ViewChild('admissionNumberLookup') admissionNumberLookup: AdmissionNumberLookupComponent;
  @ViewChild(MatSort) sort: MatSort;
  pkgCollectionListForm: FormGroup;
  pkgCollectionList: MatTableDataSource<any> = new MatTableDataSource([]);
  displayedColumnsList: string[] = ['SerialNo', 'PackageNo', 'PackageDate', 'RegNo', 'PatientName','FolioNo','BedNo', 'Status'];
  highLightRow: number;
  rowDetails: any;
  isCancelDisabled: boolean = true;
  isDisplayDisabled: boolean = true;
  constructor(public fb: FormBuilder, private commonService: CommonService, private httpService: HttpService,
    private loader: LoaderService,public dialog: MatDialog,private router:Router) { }

  ngOnInit() {
    this.initForm();
  }
 // initialize the form
 initForm() {
  this.pkgCollectionListForm = this.fb.group({
    RegNo: [{ value: '', disabled: true }],
    PatientName: [''],
    FromDate: new Date(),
    ToDate: new Date(),
  });
  this.highLightRow = -1;
}
// the function returns the form controls to access in both files.
public get f() {
  return this.pkgCollectionListForm.controls;
}

// sets patient details on event emit
setPatientDetail(patient: any, patDetails?: any,date?) {
  if (!this.commonService.isValidStringValue(patient.AdmissionNo)) {
    this.resetForm(patDetails,date);
    return;
  }
  this.pkgCollectionListForm.patchValue({
    "RegNo": patient.AdmissionNo, "PatientName": patient.PatientName
  });
}

// set from date and to date
getSetDate(event) {
  this.f.FromDate.setValue(new Date(event.FromDate.value));
  this.f.ToDate.setValue(new Date(event.ToDate.value)); 
}
// open patient help
openPatientHelp(patDetail) {
  const dialogRef = this.dialog.open(PatientEnquiryComponent, {
    disableClose: true,
    maxHeight: '800px',

  });

  dialogRef.componentInstance.isPopup = true;

  dialogRef.afterClosed().subscribe(dialogResult => {

    if (!isNullOrUndefined(dialogResult)) {
      this.f.RegNo.setValue(dialogResult.AdmissionNumber);
      this.f.PatientName.setValue(dialogResult.PatientName);
      patDetail.myControl.setValue(`(${(dialogResult.AdmissionNumber)}) ${dialogResult.PatientName}`);
    }
  });
}

// validation of form
validateForm(date): boolean { 
  if(new ParseDate().transform(date.FromDate.value) > new ParseDate().transform(new Date())) {
    this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidFromDate,
      messageConstant.invalidMessages.OK);
    return false;
  }
  if(new ParseDate().transform(date.ToDate.value) > new ParseDate().transform(new Date())) {
    this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidToDate,
      messageConstant.invalidMessages.OK);
    return false;
  }
  if(new ParseDate().transform(date.FromDate.value) > new ParseDate().transform(date.ToDate.value)) {
    this.commonService.openSnackBar(messageConstant.DoctorDetailsService.GreaterToDate,
      messageConstant.invalidMessages.OK);
    return false;
  }
  return true;
}

// get package colllection list
GetPkgCollectionList(date){
  if (!this.validateForm(date)) return;
  this.loader.spin.next(true);
        this.httpService.Get(urlConstant.PackageCollection.GetPackageCollectionList(new ParseDate().transform(this.f.FromDate.value), new ParseDate().transform(this.f.ToDate.value), this.f.RegNo.value))
          .subscribe(response => {
            if (response && response.Data.length > 0) {
              this.loader.spin.next(false);
              this.pkgCollectionList = new MatTableDataSource(response.Data);
              this.pkgCollectionList.sort = this.sort;
              
            } else {
              this.loader.spin.next(false);
              this.pkgCollectionList = new MatTableDataSource([]);
            }
          });

}

// Highlight row from grid.
setActiveServiceRow(index: number, item: any) {
  this.rowDetails = item;
  if (this.highLightRow === index) {
    this.isCancelDisabled=true;
    this.isDisplayDisabled=true;
    this.highLightRow = -1;
  } else {
    if(this.rowDetails.Status=='C' || this.rowDetails.Status=='B'){
    this.isCancelDisabled=true;
    } else{
    this.isCancelDisabled=false;
  }
    this.isDisplayDisabled=false;
    this.highLightRow = index;
  }
}

// reset form
resetForm(patientDetail,date) {
  date.FromDate.setValue(new Date());
  date.ToDate.setValue(new Date());
  this.pkgCollectionList = new MatTableDataSource([]);
  this.initForm();
  patientDetail.myControl.setValue('');
}


displayPackage(){
  const navigationExtras: NavigationExtras = {
    queryParams: {
      'PackageSerialNo': this.rowDetails.PackageNo,
    }
  };
this.router.navigate(['billing/package/new-package'],navigationExtras);

}
cancelPackage() {
  const navigationExtras: NavigationExtras = {
    queryParams: {
      'PackageSerialNo': this.rowDetails.PackageNo,
      'IsCancelled':true
    }
  };
this.router.navigate(['billing/package/new-package'],navigationExtras);
}
exportToExcel() {
  
}
}
