import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef, MatTableDataSource, MatDialog } from '@angular/material';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { pipe } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-exchange-rate-master',
  templateUrl: './exchange-rate-master.component.html',
  styleUrls: ['./exchange-rate-master.component.css'],
  host: { 'class': 'section__main' }
})

export class ExchangeRateMasterComponent {

  exchangeRateForm: FormGroup;
  selectedRowData: any;
  selectedRowIndex: number = -1;
  action: string = "S"; // Default action is save
  exchangeRateList: MatTableDataSource<any> = new MatTableDataSource();
  displayedColumnsList: string[] = ["Sr No", "CountryName", "CurrencyName", "Rate", "Symbol", "Status","UpdatedOn","UpdatedBy", "Action"];
  countryList: any;

  constructor(
    private fb: FormBuilder,
    private commonService: CommonService,
    private httpService: HttpService,
    private loader: LoaderService
  ) { }

  ngOnInit() {
    this.initializeForm();
    this.initializeCountryLookup();
    this.getExchangeRateList();
  }

  initializeCountryLookup() {
    const waitTime = pipe(debounceTime(200));
    const distinct = pipe(distinctUntilChanged());
    this.f.CountryName.valueChanges
      .pipe(waitTime)
      .pipe(distinct)
      .pipe(
        switchMap(text =>
          !isNullOrUndefined(text) && text.toString().trim() !== ''
            ? this.httpService.Get(urlConstant.Billing.GetCountryLookup(text))
            : []
        )
      )
      .subscribe(result => {
        if (result.Status === 200) {
          this.countryList = result.Data;
        } else {
          return;
        }
      });
  }

  // clears lookup search
  clearLookupSearch() {
    this.f.CountryName.setValue("");
    this.countryList = [];
  }

  //Initialize form
  initializeForm() {
    this.exchangeRateForm = this.fb.group({
      Id: [''],
      CountryName: [''],
      CurrencyName: [''],
      Rate: [''],
      Symbol: [''],
      Status: [true],
      UserId: [localStorage.getItem("UserName")]
    });
  }

  get f() {
    return this.exchangeRateForm.controls;
  }

  //To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }

  // Get exchange rate list
  getExchangeRateList() {
    this.httpService.Get(urlConstant.Billing.GetAllRate()).subscribe(response => {
      this.exchangeRateList = new MatTableDataSource(response.Data);
    })
  }

  saveExchangeRate() {
    //console.log(this.f.CountryName.value);
    if (!this.validateForm()) return;

    const rateInput = this.exchangeRateForm.getRawValue();

    // if action is "S" that means save exchange rate master
    if (this.action === "S") {
      this.commonService.confirmAction("Add Exchange Rate Master", "Do you want to submit new exchange rate ?").subscribe(response => {
        if (response) {
          this.httpService.Post(urlConstant.Billing.SaveExchangeRate(), rateInput).subscribe(response => {
            if (response.Status === 200) {
              this.commonService.displayPromptMessage("Add Exchange Rate Master", "Exchange Rate saved successfully").subscribe(response => {
                window.location.reload();
              });
            }
          });
        }
      });
    }
    // if action is U that means update exchange rate master
    else {
      this.commonService.confirmAction("Update Exchange Rate Master", `Do you want to update exchange rate for ${rateInput.CountryName} ?`).subscribe(response => {
        if (response) {
          this.httpService.Post(urlConstant.Billing.EditExchangeRate(), rateInput).subscribe(response => {
            if (response.Status === 200) {
              this.commonService.displayPromptMessage("Update Exchange Rate Master", "Exchange Rate Master updated successfully").subscribe(response => {
                window.location.reload();
              });
            }
          });
        }
      });
    }
  }

  validateForm() {

    const duplicateCountry = this.exchangeRateList.data.some(x => x.CountryName.trim().toLowerCase() === this.f.CountryName.value.trim().toLowerCase());

    if (duplicateCountry && this.action === "S") {
      this.commonService.displayPromptMessage("Add Exchange Rate Master", `Exchange rate already added for the country ${this.f.CountryName.value}.`);
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.CurrencyName.value)) {
      this.commonService.openSnackBar("Please enter currency name.", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.Rate.value)) {
      this.commonService.openSnackBar("Please enter currency rate.", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.Symbol.value)) {
      this.commonService.openSnackBar("Please enter symbol for the country.", "Ok");
      return false;
    }

    return true;
  }

  // Edit exchange rate list
  editExchangeRate(rowdetails: any) {
    this.loader.spin.next(true);

    this.exchangeRateForm.patchValue({
      Id: rowdetails.Id,
      CountryName: rowdetails.CountryName,
      CurrencyName: rowdetails.CurrencyName,
      Rate: rowdetails.Rate,
      Symbol: rowdetails.Symbol,
      Status: rowdetails.Status
    });

    this.f.CountryName.disable();
    this.action = "U";
    this.loader.spin.next(false);
  }

  // Deletes exchange rate
  deleteExchangeRate(rowdetails: any) {

    this.commonService.confirmAction("Delete Exchange Rate Master", `Do you want to delete exchange rate for ${rowdetails.CountryName} ?`).subscribe(response => {
      if (response) {
        this.httpService.Post(urlConstant.Billing.DeleteExchangeRate(), rowdetails).subscribe(response => {
          if (response.Status === 200) {
            this.commonService.displayPromptMessage("Delete Exchange Rate Master", "Exchange Rate deleted successfully").subscribe(response => {
              window.location.reload();
            });
          }
        });
      }
    });
  }

  // reset form values
  resetForm() {
    this.exchangeRateForm.reset();
    this.f.CountryName.enable();
    this.action = "S";
  }

}
