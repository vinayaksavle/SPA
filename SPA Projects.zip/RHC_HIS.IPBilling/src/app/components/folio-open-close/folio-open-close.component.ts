import { Component, OnInit, ViewChild } from '@angular/core';
import 'rxjs/add/operator/filter';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-folio-open-close',
  templateUrl: './folio-open-close.component.html',
  styleUrls: ['./folio-open-close.component.css'],
  host: { 'class': 'section__main' }
})
export class FolioOpenCloseComponent implements OnInit {

  folioOpenCloseForm: FormGroup;
  @ViewChild('patientDetailComponent') patDetailsComp;
  folioLogObj: any;
  responsibleObj: {};
  permissions: any=[];
  canSaveFolio: boolean;

  constructor(private fb: FormBuilder, private commonService: CommonService,
    private httpService: HttpService, private loader: LoaderService,
    private dataTransferService: DataTranferService) {
       //#region permission
    this.permissions = JSON.parse(localStorage.getItem('Permission'));
    
    if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
      // Save Folio Permissons set
      this.canSaveFolio =  this.permissions.includes('407') ? true :false;
    }
    //#endregion
  }

  ngOnInit(): void {
    // Setted the flag to get all folio (open & close).
    this.patDetailsComp.getAllFolios = true;
    this.initForm();
  }

  // Function to get selected folio No status and set the current status checkBox.
  //  getFolioStatus(event){
  //   if(this.patDetailsComp.FolioList!=null && this.patDetailsComp.FolioList.length>0){
  //     let folioNo=event;
  //     this.patDetailsComp.FolioList.forEach(element => {
  //       if(element.Value==folioNo){
  //           if(this.commonService.isValidStringValue(element.Status) && element.Status=='O'){
  //               this.f.Current.setValue(element.Status);
  //           }
  //       }          
  //     });
  //   }
  //  }

  initForm() {
    this.folioOpenCloseForm = this.fb.group({
      RegNo: [],
      Current: [{ value: '', disabled: true }],
      Present: [''],
      Responsible: ['']
    });
  }

  public get f() {
    return this.folioOpenCloseForm.controls;
  }

  getPatientDetails(event) {
    this.f.RegNo.setValue(event.RegNo);
    this.f.Responsible.setValue(event.Responsible);
    if (this.patDetailsComp.FolioList.length > 0) {
      if (this.patDetailsComp.FolioList[0].Status != "O" && this.patDetailsComp.FolioList[0].Status.trim().length != 0)
        this.f.Current.setValue('C');
      else
        this.f.Current.setValue('O');
    }
  }

  onSave() {
    if (!this.commonService.isValidStringValue(this.f.RegNo.value)) {
      this.commonService.openSnackBar("Enter Registration Number", "Ok");
      return;
    }
    if (!this.commonService.isValidStringValue(this.f.Present.value)) {
      this.commonService.openSnackBar("Folio Opening Or Closing Should Be Selected", "Ok");
      return;
    }
    else {
      this.folioLogObj = {
        RegNo: this.f.RegNo.value,
        Status: this.f.Present.value,
        UserId: this.dataTransferService.GetUserName()
      }
      this.commonService.confirmAction("Folio Open/Close", "Do You Want to Save?").subscribe(confirmation => {
        if (confirmation) {
          this.loader.spin.next(true);
          this.httpService.Post(urlConstant.Masters.FolioOpenClose.SaveFolioLog, this.folioLogObj).subscribe(response => {
            if (response.Status == 200 && response.Data) {
              this.commonService.displayPromptMessage("Folio Open/Close", "Folio Log Saved Succesfully");
              this.clearSearch();
              this.loader.spin.next(false);
            }
            else {
              this.loader.spin.next(false);
            }
            this.loader.spin.next(false);
          });
        }
        else {
          return;
        }
      });
    }
  }

  // Function to save responsible for settlement
  saveResponsible() {
    if (!this.commonService.isValidStringValue(this.f.RegNo.value)) {
      this.commonService.openSnackBar("Invalid RegNo", "Ok");
      return;
    }
    else if (!this.commonService.isValidStringValue(this.f.Responsible.value)) {
      this.commonService.openSnackBar("Please enter Responsible for settlement", "OK");
      return;
    }
    else {
      this.responsibleObj = {
        RegNo: this.f.RegNo.value,
        Responsible: this.f.Responsible.value
      }
      this.loader.spin.next(true);
      this.httpService.Post(urlConstant.Masters.FolioOpenClose.SaveResponsible, this.responsibleObj).subscribe(res => {
        if (res.Status == 200 && res.Data) {
          this.commonService.displayPromptMessage("Folio Open/Close", "Responsible saved succesfully");
          this.f.Responsible.setValue("");
          this.loader.spin.next(false);
        } else {
          this.commonService.displayPromptMessage("Folio Open/Close", "Responsible Unable to Save");
          this.loader.spin.next(false);
        }
        this.loader.spin.next(false);
      });
    }
  }

  clearSearch() {
    this.initForm();
    this.patDetailsComp.patientForm.reset();
  }

}