import { Component, OnInit, ViewChild, Input, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { isNullOrUndefined } from 'util';
import { MatTableDataSource } from '@angular/material';
import { FromDateToDateComponent } from 'from-date-to-date';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
    selector: 'app-package-report',
    templateUrl: './package-report.component.html',
    styleUrls: ['./package-report.component.css'],
    host: { 'class': 'section__main' },
})

export class PackageReportComponent implements OnInit {
    @ViewChild('fromDateToDate') fromDateToDate: FromDateToDateComponent;
    totalAmount: any = 0.0;
    packageReportForm: FormGroup;
    packageReportList: MatTableDataSource<any> = new MatTableDataSource([]);
    filterdisplayedColumnsList: any = ["FolioNo", "PackageName", 'DepartmentCode', 'ServiceCode', 'ServiceName', 'ServiceAmount', 'ServiceDate', 'PostType', 'Remarks'];

    constructor(private fb: FormBuilder,
        private httpService: HttpService,
        private loader: LoaderService) {
    }

    ngOnInit() {
        this.initializeForm();
        this.getPackageReportList();
    }

    // Initialize form
    initializeForm() {
        this.packageReportForm = this.fb.group({
            DateChecker: [true],
            FromDate: [new Date(), Validators.required],
            ToDate: [new Date(), Validators.required],
            RegNo: [""],
            PatientName: [""],
        });
    }

    get f() {
        return this.packageReportForm.controls;
    }

    setPatientFormValue(patient: any) {
        this.f.RegNo.setValue(patient.AdmissionNo);
        this.f.PatientName.setValue(patient.PatientName);
    }

    enableDate() {
        if (this.f.DateChecker.value) {
            this.fromDateToDate.FromDate.enable();
            this.fromDateToDate.ToDate.enable();
        }
        else {
            this.fromDateToDate.FromDate.disable();
            this.fromDateToDate.ToDate.disable();
        }
    }

    // sets from date and to date from library element
    setDate(event) {
        if (!isNullOrUndefined(event)) {
            this.f.FromDate.setValue(new Date(event.FromDate.value).toLocaleDateString());
            this.f.ToDate.setValue(new Date(event.ToDate.value).toLocaleDateString());
        }
    }

    getPackageReportList() {
        const inputParam = this.packageReportForm.getRawValue();
        this.httpService.Post(urlConstant.PackagePosting.GetPackageReportList(), inputParam).subscribe(response => {
            if (response.Status === 200 && response.Data.length > 0) {
                this.packageReportList = new MatTableDataSource(response.Data);
                this.totalAmount = this.packageReportList.data.map((d) => parseFloat(d.ServiceAmount)).reduce((prev, curr) => prev + curr, 0).toFixed(2);
            }
            else {
                this.packageReportList = new MatTableDataSource([]);
                this.totalAmount = "0.00";
            }
        })
    }

    exportToExcel() {
        const inputParam = this.packageReportForm.getRawValue();
        this.loader.spin.next(true);
        this.httpService.Post(urlConstant.PackagePosting.GetBillListExportPath(), inputParam).subscribe(response => {

            if (response && !isNullOrUndefined(response.Data)
                && response.Status === 200) {
                this.httpService.exportToExcel(response.Data);
            }
            this.loader.spin.next(false);
        });
    }

}
