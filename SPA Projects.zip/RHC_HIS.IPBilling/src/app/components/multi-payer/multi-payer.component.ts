import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MatSort, MatTableDataSource } from '@angular/material';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { ParseDBDateToDOBPipe } from 'shared-utility/lib/pipes/parse-dbDate-to-dob.pipe';
import { LoaderService } from 'src/app/services/loader.service';
import { ParseDate } from 'shared-utility';
import { FormControl } from '@angular/forms';
import { isNullOrUndefined } from 'util';

@Component({
    selector: 'app-multi-payer',
    templateUrl: './multi-payer.component.html',

})


export class MultiPayerComponent implements OnInit, AfterViewInit {

    displayedColumns: string[] = ['SNo', 'PayerType', 'PayerName', 'ApprovedAmount', 'Remarks'];
    multiPayerDetails: MatTableDataSource<any> = new MatTableDataSource([]);
    @ViewChild(MatSort) sort: MatSort;

    regNo: string = ""; // passed from new bill component while invoking this component in popup
    billNetAmount: string = "0.00"; // passed from new bill component while invoking this component in popup

    // below values to be calculated after api call is successfull
    totalCount: number = 0;
    totalApprovedAmount: number = 0;
    paientResponsibility: number = 0;

    constructor(private http: HttpService, private loader: LoaderService,
        private dialogRef: MatDialogRef<MultiPayerComponent>, private commonService: CommonService) { }


    ngOnInit(): void {

    }

    ngAfterViewInit(): void {
        this.billNetAmount = this.commonService.isValidStringValue(this.billNetAmount) ? this.billNetAmount : "0.00";
        this.getMultiPayerDetails();
    }

    getMultiPayerDetails() {
        if (this.commonService.isValidStringValue(this.regNo)) {
            // write api call here
            this.loader.spin.next(true);
            this.http.Get(urlConstant.Billing.GetMultiPayerDetails(this.regNo)).subscribe(res => {
                if (res.Status == 200 && res.Data.length > 0) {
                    this.multiPayerDetails = new MatTableDataSource(res.Data);
                    this.multiPayerDetails.sort = this.sort;
                    this.totalApprovedAmount=this.multiPayerDetails.data[0].TotalApprovedAmount;
                    this.paientResponsibility=Number(this.billNetAmount) - this.totalApprovedAmount;
                    this.loader.spin.next(false);
                } else {
                    this.loader.spin.next(false);
                }
            }, (err) => {
                console.log(err);
                this.loader.spin.next(false);
            });
        }
    }

    closePopup() {
        this.dialogRef.close()
    }

}