import { Component, OnInit, ViewChild } from '@angular/core';
import 'rxjs/add/operator/filter';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { ActivatedRoute, Router } from '@angular/router';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';
import { LoaderService } from 'src/app/services/loader.service';
import { MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-new-package',
  templateUrl: './new-package.component.html',
  styleUrls: ['./new-package.component.css'],
  host: { 'class': 'section__main' }
})

export class NewPackageCollection implements OnInit {
  displayedColumns = [
    "SerialNo",
    "Department",
    "Actuals",
    "PackageAmount",
    "DifferenceAmount",
    "Service",
    "PostServiceType",
    "ServiceSlNo",
  ];
  saveButtonStatus = true;
  cancelButtonStatus = true;

  packgeListDetails = new MatTableDataSource();
  newPackageForm: FormGroup;
  @ViewChild('patDetails') patDetails: PatientDetailsComponent;
  patientdata: any;
  packMasterDetails: any;
  cancelPackObj: any = {};
  newPackageObj: any;
  constructor(private fb: FormBuilder, private commonService: CommonService,
    private httpService: HttpService, public route: ActivatedRoute, private router: Router, private loader: LoaderService) {
  }
  ngOnInit(): void {
    this.initForm();

    // for display
    if (this.route.snapshot.queryParams['PackageSerialNo']) {
      this.loader.spin.next(true);
      this.httpService.Get(urlConstant.PackageCollection.getPatientPakageDetails(this.route.snapshot.queryParams['PackageSerialNo'])).subscribe(res => {
        if (res.Status === 200 && res.Data.length > 0) {
          this.patientdata = res.Data;
          this.setPackageData();
        }
        else {
          return;
        }

      });
      this.loader.spin.next(false);
    }
  }


  initForm() {
    this.newPackageForm = this.fb.group({
      RegNo: [{ value: '' }],
      FolioNo: [{ value: '' }],
      PackageNo: [''],
      PackageDate: [new Date()],
      PackageTime: [(new Date().getHours() + ':' + new Date().getMinutes() + ':' + new Date().getSeconds()).toString()],
      UserId: [localStorage.getItem('UserName') ? localStorage.getItem('UserName') : ''],
      PackageCode: [''],
      PackageName: [''],
      PackageCost: [''],
      VoucherNo: [''],
      Remarks: [''],
    });
    this.packgeListDetails = new MatTableDataSource();
    this.patDetails.initForm();
  }
  public get f() {
    return this.newPackageForm.controls;
  }
  patientDetailEmitter(patientComp) {
    this.newPackageForm.patchValue({
      RegNo: patientComp.patientForm.controls['RegNo'].value,
      FolioNo: patientComp.patientForm.controls['FolioNo'].value
    })
    // To check whether package is already done for patient.
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.PackageCollection.IsPackageDone(this.f.RegNo.value, this.f.FolioNo.value)).subscribe(response => {
      if (response.Status == 200 && response.Data) {
        if (response.Data > 0) {
          this.commonService.displayPromptMessage('New Package', 'Package is already done for this patient');
          this.initForm();
          this.loader.spin.next(false);
        }
        else {
          this.loader.spin.next(false);
          return;
        }
      }
      else {
        this.loader.spin.next(false);
        return;
      }
    });
  }

  // To check whether package is already done for patient.
  IsPackageDone(): boolean {
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.PackageCollection.IsPackageDone(this.f.RegNo.value, this.f.FolioNo.value)).subscribe(response => {
      if (response.Status == 200 && response.Data) {
        if (response.Data > 0) {
          this.commonService.displayPromptMessage('New Package', 'Package is already done for this patient');
          return true;
        }
        else {
          return false;
        }
      }
      else {
        return false;
      }
    });
    this.loader.spin.next(false);
    return false;
  }

  // Set Package Details for View Package
  setPackageData() {
    this.patDetails.patientForm.controls['RegNo'].setValue(this.patientdata[0].RegNo);
    this.patDetails.setPatientDetailByRegNo(this.patDetails.patientForm.controls['RegNo'].value);

    this.newPackageForm.patchValue({
      RegNo: this.patDetails.patientForm.controls['RegNo'].value,
      FolioNo: this.patDetails.patientForm.controls['FolioNo'].value,
      PackageNo: this.patientdata[0].PackageSerialNo,
      PackageCode: this.patientdata[0].PackageCode,
      PackageDate: this.patientdata[0].PackageDate,
      PackageCost: this.patientdata[0].PackageAmount,
      UserId: this.patientdata[0].UserId,
      Remarks: this.patientdata[0].Remarks
    })

    let packageTime: string = this.patientdata[0].PackageTime.trim();
    this.f.PackageTime.setValue(packageTime.substring(0, 2) + ':' + packageTime.substring(2, 4) + ':' + packageTime.substring(4, 6));

    // Get Master Details
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.PackageCollection.GetPackageMasterDetails(this.f.PackageCode.value)).subscribe(response => {
      if (response.Status == 200 && response.Data.length > 0) {
        this.packMasterDetails = response.Data;
      }
    });
    this.loader.spin.next(false);

    if (this.commonService.isValidStringValue(this.packMasterDetails)) {
      this.f.PackageName.setValue(this.packMasterDetails[0].PackageName);
    }

    // Get Service Details for Table Binding
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.PackageCollection.GetPackageServiceDetails(this.f.PackageNo.value)).subscribe(response => {
      if (response.Status == 200 && response.Data.length > 0) {
        this.packgeListDetails = new MatTableDataSource(response.Data);
      }
    })
    this.loader.spin.next(false);

    this.patDetails.patientForm.disable();
    this.newPackageForm.disable();
    if (this.route.snapshot.queryParams['PackageSerialNo'] && this.route.snapshot.queryParams['IsCancelled']) {
      this.f.Remarks.enable();
    }

  }
  
  // Method to cancel Package
  cancelPackage() {
    this.cancelPackObj.PackageSerialNo = this.f.PackageNo.value;
    this.cancelPackObj.Remarks = this.f.Remarks.value;
    if (this.commonService.isValidStringValue(this.f.FolioNo.value)) {
      this.cancelPackObj.FolioNo = this.f.FolioNo.value;
    }
    else {
      this.cancelPackObj.FolioNo = '01';
    }

    this.cancelPackObj.RegNo = this.f.RegNo.value;

    this.httpService.Post(urlConstant.PackageCollection.CancelPackageAPI, this.cancelPackObj).subscribe(response => {
      if (response.Status == 200 && response.Data.length > 0) {
        this.commonService.displayPromptMessage("Package Cancel", "Package Cancelled Sucessfully");
        this.initForm();
        this.router.navigate(['/billing/package']);
      }
    });
  }
  //Get Package details on type of package Code
  GetPackDetails() {
    // Get Master Details
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.PackageCollection.GetPackageMasterDetails(this.f.PackageCode.value)).subscribe(response => {
      if (response.Status == 200 && response.Data.length > 0) {
        this.packMasterDetails = response.Data[0];
        this.f.PackageName.setValue(this.packMasterDetails.PackageName);
        this.loader.spin.next(false);
      }
      else {
        this.loader.spin.next(false);
      }
    });

  }
  // Save
  savePackage() {
    if (this.route.snapshot.queryParams['PackageSerialNo'] && this.route.snapshot.queryParams['IsCancelled']) {
      this.cancelPackage();
    }
    if (!this.commonService.isValidStringValue(this.f.RegNo.value) || !this.commonService.isValidStringValue(this.f.PackageCode.value)) {
      this.commonService.displayPromptMessage("New Package Collection", "Invalid RegNo or Package Code");
    }

    //need to create object for posting after clear with the service details method
    this.createNewPackObj();
    this.httpService.Post(urlConstant.PackageCollection.CreateNewPackApi, this.newPackageObj).subscribe(response => {
      if (response.Status == 200 && response.Data.length > 0) {
        console.log(response.Data);
      }

    })

  }
  createNewPackObj() {
    throw new Error("Method not implemented.");
  }
  closePackage() {
    this.router.navigate(['/billing/package']);

  }
  cancelClick() {

  }

}

