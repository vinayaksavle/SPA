import { Component, OnInit, ViewChild, AfterViewInit, ElementRef, HostListener } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { HttpService } from "src/app/services/http.service";
import { LoaderService } from "src/app/services/loader.service";
import { ServiceBillModel } from "src/app/models/service-bill.model";
import { urlConstant } from "src/app/constants/urlConstants";
import { isNullOrUndefined } from "util";
import hotkeys from 'hotkeys-js';
import { Router, ActivatedRoute } from '@angular/router';
import { MatButton, MatDialog, MatInput, MatSelect } from '@angular/material';
import { PreviousBillsComponent } from '../previous-bills/previous-bills.component';
import { CommonService } from 'src/app/services/common.service';
import { patientCategoryConstant } from 'src/app/constants/patientCategoryConstants';
import { formatDate, Time } from '@angular/common';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';
import { SummaryBillComponent } from '../summary-bill/summary-bill.component';
import { AllDepartmentComponent } from '../all-department/all-department.component';
import { PrinterService } from 'src/app/services/print.service';
import { messageConstant } from 'src/app/constants/messageConstants';
import { pipe } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { DoctorDetailsListComponent } from '../doctor-details-list/doctor-details-list.component';
import { LabServiceDetailsComponent } from '../lab-service-details/lab-service-details.component';
import { DrugDetailsListComponent } from '../drug-details-list/drug-details-list.component';
import { OtDetailsListComponent } from '../ot-details-list/ot-details-list.component';
import { AllowToGoComponent } from '../allow-to-go/allow-to-go.component';
import { DiscountServiceComponent } from "../discount-service/discount-service.component";
import { MultiPayerComponent } from "../multi-payer/multi-payer.component";

@Component({
  selector: 'app-new-bill',
  templateUrl: './new-bill.component.html',
  styleUrls: ['./new-bill.component.css'],
  host: { class: "section__main" },
})

export class NewBillComponent implements OnInit, AfterViewInit {
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('patientDetailComponent') patientDetailComponent: PatientDetailsComponent;
  @ViewChild('VoucherNo') VoucherNo: ElementRef;
  @ViewChild('saveButton') saveButton: ElementRef;
  @ViewChild('DeptCode') DeptCode: MatSelect;
  @ViewChild('Disch') Disch: MatSelect;

  //Flag to decide between interim and final billing
  billTypeFlag: string;
  isFromFinal: boolean = false;
  newBillForm: FormGroup;
  reqApprDetails: any[];
  serviceListDetails: MatTableDataSource<ServiceBillModel> = new MatTableDataSource();
  billedServiceDetails: MatTableDataSource<ServiceBillModel> = new MatTableDataSource();
  patientStatus: { value: String, viewValue: String, DBValue: string }[];
  patientDetails: any;
  ipBillNo: string;
  regNo: string;
  categoryCode: string;
  bedCategoryCode: string;
  folioNo: string;
  voucherNo: string;
  billDate: string = this.commonService.convertDateToString();
  billTime: string = this.commonService.getCurrentTime();
  fDate: Date = new Date();
  fTime: number = this.fDate.getTime();
  userId: string;
  dischStatus: string;
  diagnosis: string;
  idcnNo: string;
  errorList: any;
  rate: any = {};
  symbol: string;
  rateUpdatedDate: string;
  summaryBillList: any = [];
  currencyList: any = [];
  currentDate = new Date();
  hiddenItems: any = ['DischDateTime', 'InsCompanyName', 'DoctorButton',];
  disabledItems: any = ['BedCategory'];
  servicePopupHeight: string = "700px";
  savePopupOpened: any;
  displayTPADiscount: boolean = false;
  isTPADiscountAllowed: boolean = false;

  displayedColumns = [
    "DepartmentCode",
    "ServiceCode",
    "Amount",
    "Qty",
    "ServiceCategory",
    "DoctCode",
    "PackCode",
    "Servslno",
    "NoTax",
  ];
  sub: any;
  billType: string;
  action: string;
  isNew: boolean = false;
  isReqApprDisabled: boolean = true;
  isSaveDisabled: boolean = false;
  billData: any = {};
  departmentList: any;
  billAmount: string = "0.00";
  reserveAmount: string = "0.00";
  activateApproval: any;
  permissions: any = [];
  canPrintIPF: boolean;
  minDate: any;

  @HostListener('document:keydown', ['$event']) onKeydownHandler(event: KeyboardEvent) {

    // redirect to final bill
    if (event.ctrlKey && (event.key === "f" || event.key === "F")) {
      event.preventDefault();
      this.patientDetailComponent.openFinalBill();
    }

    // redirect to interim bill
    if (event.ctrlKey && (event.key === "i" || event.key === "I") && !event.shiftKey) {
      event.preventDefault();
      this.patientDetailComponent.openInterimBill();
    }

    // redirect to patient folio
    if (event.altKey && (event.key === "f" || event.key === "F")) {
      event.preventDefault();
      this.patientDetailComponent.openPatientFolio();
    }

    // print bill
    if (event.altKey && (event.key === "p" || event.key === "P") && !this.isNew) {
      event.preventDefault();
      this.printBill();
    }

    // save bill
    if (event.ctrlKey && (event.key === "s" || event.key === "S") && this.isNew) {
      event.preventDefault();
      this.saveNewBill();
    }

    // Doctor details
    if (event.ctrlKey && (event.key === "d" || event.key === "D")) {
      event.preventDefault();
      this.openDoctorDetail();
    }

    // Lab details
    if (event.ctrlKey && (event.key === "l" || event.key === "L")) {
      event.preventDefault();
      this.openLabDetail();
    }

    // Drug details
    if (event.ctrlKey && (event.key === "m" || event.key === "M")) {
      event.preventDefault();
      this.openPharmaDetail();
    }

    // OT Drug details
    if (event.ctrlKey && (event.key === "o" || event.key === "O")) {
      event.preventDefault();
      this.openOTDrugs();
    }
  }

  constructor(
    private fb: FormBuilder,
    private httpService: HttpService,
    private loader: LoaderService,
    private commonService: CommonService,
    private dialog: MatDialog,
    private router: Router,
    private activateRoute: ActivatedRoute,
    private printerService: PrinterService
  ) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
    //#region permission
    this.permissions = JSON.parse(localStorage.getItem('Permission'));

    if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
      // Print Permissons set
      this.canPrintIPF = this.permissions.includes('4002P') ? true : false;
      this.isTPADiscountAllowed = this.permissions.includes('4014');
    }
    //#endregion

  }


  ngAfterViewInit(): void {



    if (!this.isNew) {
      this.patientDetailComponent.setPatientDetailByRegNo(this.f.RegNo.value);
      this.f.FolioNo.setValue(this.folioNo);
      this.hiddenItems.push("EnquiryButton");
    }
    else {
      if (!isNullOrUndefined(this.f.RegNo.value) && !isNullOrUndefined(this.folioNo)) {
        this.patientDetailComponent.setPatientDetailByRegNo(this.f.RegNo.value, false);
        this.f.FolioNo.setValue(this.folioNo);
      }
    }
  }


  ngOnInit() {

    this.initializeForm();
    this.setRouteParameters();
    this.serviceListDetails.sort = this.sort;
    this.patientStatus = patientCategoryConstant.getPatientStatus();
    //this.initHotKeys();
  }


  //Initialize form
  initializeForm() {
    this.newBillForm = this.fb.group({
      BillNo: [""],
      RegNo: [""],
      PatientName: [""],
      FolioNo: [""],
      CategoryCode: [""],
      BedCategoryCode: [""],
      BillType: [""],
      CloseFolio: false,
      IsAllDepartment: false,
      IsSummary: false,
      BillDate: [""],
      BillTime: [""],
      DischStat: [""],
      SummaryBill: [""],
      BillTotal: [""],
      PreviousBill: [""],
      RcvdRfndAmt: [""],
      NetAmt: [""],
      CnaAmount: [""],
      DoctBill: [""],
      TotalDepositAmount: [""],
      VoucherNo: [""],
      PrintCharges: ["D"],
      UserId: [localStorage.getItem("UserName")],
      Action: [""],
      DoctCode: [""],
      CompanyCode: [""],
      IdcnNo: [""],
      Diagnosis: ['', Validators.maxLength(35)],
      DepartmentCode: [""],
      DischargeDate: [new Date()],
      DischargeTime: [this.commonService.getCurrentTime()],
      ExchangeRate: [""],
      Phone: [""],
      DiscountType: [""],
      DiscountAmount: [""],
      ApprovedAmount: [""],
    });
  }

  //initialize hot keys for redirection through keys
  initHotKeys() {
    let refThis = this;

    // redirect to final bill
    hotkeys("ctrl+f", function (event) {
      event.preventDefault();
      refThis.router.navigateByUrl('billing/new-bill/FN');
    });

    // redirect ti interim bill
    hotkeys("ctrl+i", function (event) {
      event.preventDefault();
      refThis.router.navigateByUrl('billing/new-bill/IN');
    });

    // redirect to patient folio
    hotkeys("ctrl+l", function (event) {
      event.preventDefault();
      refThis.router.navigateByUrl('billing/patient-folio');
    });


    // redirect to patient folio
    hotkeys("alt+p", function (event) {
      if (!refThis.isNew) {
        event.preventDefault();
        refThis.printBill();
      }
    });

  }

  //Function to return interim bill form controls
  get f() {
    return this.newBillForm.controls;
  }

  // set focus on discharge status on tab keypress
  setFocusDischStatus() {
    setTimeout(() => {
      this.Disch.focus();
    }, 100);
  }

  // set focus on voucher no on tab keypress
  setFocusVoucherNo() {
    setTimeout(() => {
      this.VoucherNo.nativeElement.focus();
    }, 100);
  }
  // set focus on voucher no on tab keypress
  setSaveButtonFocus() {
    setTimeout(() => {
      document.getElementById("saveButton").focus()
    }, 100);
  }

  // on change event for exchange rate
  changeExchangeRate(event: any) {
    this.rate = event.value.Rate;
    this.symbol = event.value.Symbol;
    this.rateUpdatedDate = event.value.UpdatedOn;
    this.rateUpdatedDate = event.value.UpdatedOn;
  }

  //sets route details from route
  setRouteParameters() {
    this.action = this.commonService.capitalizeFirstLetter(this.router.url.split("/")[2].split("-")[0]);
    this.isNew = this.action.toLowerCase() === "new" ? true : false;
    this.sub = this.activateRoute.params.subscribe(params => {
      let billTypeFlag = params['billType'];
      let ipBillNo = params['billNumber'];
      this.folioNo = params['folioNo'];
      this.f.BillType.setValue(billTypeFlag);
      this.f.BillNo.setValue(ipBillNo);
      this.f.RegNo.setValue(params['regNo']);
      if (billTypeFlag === "IN") {
        this.billType = "Interim";
        this.billTypeFlag = "IN";
        this.isFromFinal = false;
      }
      else if (billTypeFlag === "FN") {
        this.billType = "Final";
        this.billTypeFlag = "FN";
        this.isFromFinal = true
        this.GetCostCent();
      }
    });

    this.newBillForm.disable();
    this.getSummaryBills();
    this.getExchangeRates();
    if (this.isNew) {
      this.f.SummaryBill.enable();
    }
    else {
      this.f.IsSummary.disable();
      this.f.IsAllDepartment.enable();
    }
  }


  // Author - Vinayak Savale
  // Get Patient Details from patient-detail.component
  getPatientDetail(patient: any) {


    if (this.commonService.isValidStringValue(patient.RegNo)) {

      /// added folio no and changed code to display message only rather than clearing the field 
      if (this.isNew && patient.PatientCategoryCode === "03" && !this.commonService.isValidStringValue(patient.CompanyCode) && patient.FolioNo === "01") {
        this.commonService.displayPromptMessage("New Bill", "Credit company not selected for patient. Deposit will be applied on the bill.");
      }


      if (this.isFromFinal && this.isNew) {

        this.httpService.Get(urlConstant.Billing.GetPatientStatus(patient.RegNo))
          .subscribe(res => {
            if (this.commonService.isValidStringValue(res.Data)) {
              this.setPatientDetails(patient);
            }
            else {
              this.f.RegNo.setValue(patient.RegNo);
              this.commonService.displayPromptMessage("Final Billing", "File not cleared from pharmacy");
            }
          });

      } else {
        this.setPatientDetails(patient);
      }

    }
    else {
      this.clearFormField();
    }
  }

  setPatientDetails(patient: any) {
    this.patientDetails = patient;
    this.billAmount = patient.BillAmount;
    this.reserveAmount = patient.ReserveAmount
    this.f.Phone.setValue(patient.MobileNo);
    this.f.RegNo.setValue(patient.RegNo);
    this.f.PatientName.setValue(patient.PatientName);
    this.f.CategoryCode.setValue(patient.PatientCategoryCode);
    this.f.BedCategoryCode.setValue(patient.BedCategory);
    this.f.DoctCode.setValue(patient.TreatingDoctorCode);
    this.f.CompanyCode.setValue(patient.CompanyCode);
    this.f.ApprovedAmount.setValue(patient.ApproveAmount);
    if (this.isNew && ["13", "20"].indexOf(patient.PatientCategoryCode.trim()) > -1) {
      // FOR MEDICLAIM PATIENT ALLOW TO CLOSE FOLIO AT FINAL INTERIM BILL
      this.f.CloseFolio.enable();
    }
    if (!this.commonService.isValidStringValue(this.folioNo)) {
      this.folioNo = patient.FolioNo;
      this.f.FolioNo.setValue(patient.FolioNo);
    }

    // Added on 29 April 2021
    if (!isNullOrUndefined(patient.Ruby)) {

      this.currentDate = this.commonService.convertStringToDate(patient.Ruby.RubyDate);
      this.f.DischargeDate.setValue(this.currentDate);

    }
    this.minDate = this.commonService.convertStringToDate(patient.AdmitDate);
    this.savePopupOpened = null; //  moved here on 10 May 2020
    this.getServiceDetails(patient);
  }


  // Author - Vinayak Savale
  // On validate bill no fetch service details
  getServiceDetails(patient: any = {}) {

    const newBillInput = this.getNewBillInput();
    this.loader.spin.next(true);

    this.httpService.Post(urlConstant.Billing.GetServiceList(), newBillInput)
      .subscribe((response: any) => {
        if (response && response.Status === 200) {

          let firstBillService = response.Data;
          this.billData = firstBillService;
          if (this.commonService.isValidStringValue(patient.RegNo)) {
            this.setPatientData(patient);
          }

          this.regNo = firstBillService.RegNo;
          this.folioNo = firstBillService.FolioNo;
          this.patientDetailComponent.setPatientFolioNo(this.folioNo);
          this.f.VoucherNo.setValue(firstBillService.VoucherNo);
          if (this.commonService.isValidStringValue(firstBillService.BillDate)) this.billDate = firstBillService.BillDate;
          if (this.commonService.isValidStringValue(firstBillService.BillTime)) this.billTime = firstBillService.BillTime;
          this.userId = firstBillService.UserId;
          this.diagnosis = firstBillService.Diagnosis;
          this.dischStatus = firstBillService.DischStat;
          this.f.DischStat.setValue(firstBillService.DischStat);
          this.idcnNo = firstBillService.DUserId + firstBillService.DuTime;
          this.f.BillTotal.setValue(firstBillService.Total);
          this.f.DoctBill.setValue(firstBillService.DoctorBills);
          this.f.PreviousBill.setValue(firstBillService.PreviousBills);
          this.f.RcvdRfndAmt.setValue(firstBillService.RcvdRfndAmt);
          this.f.TotalDepositAmount.setValue(firstBillService.TotalDepositAmount);
          this.f.NetAmt.setValue(firstBillService.NetAmt);
          this.f.CnaAmount.setValue(firstBillService.CnaAmount);
          this.f.DiscountAmount.setValue(firstBillService.DiscountAmount);

          this.f.SummaryBill.setValue(firstBillService.SummaryBill);

          this.f.DepartmentCode.setValue(firstBillService.GDeptNo);


          this.f.Diagnosis.setValue(firstBillService.Diagnosis);
          this.f.IdcnNo.setValue(firstBillService.IdcnNo);
          this.displayTPADiscount = firstBillService.ActivateTPADisc;
          if (this.commonService.isValidStringValue(firstBillService.DischargeDate))
            this.f.DischargeDate.setValue(firstBillService.DischargeDate);
          if (this.commonService.isValidStringValue(firstBillService.DischTime)) this.f.DischargeTime.setValue(firstBillService.DischTime);

          const serviceList = firstBillService.BillingServiceList;
          //For interim billing service details
          if (this.billTypeFlag === "IN") {
            this.serviceListDetails = new MatTableDataSource(serviceList);
            setTimeout(() => {
              this.VoucherNo.nativeElement.focus();
            }, 100);
          }
          //For final billing other than doctor fees and for doctor fees
          else if (this.billTypeFlag === "FN") {
            // Focus when press tab after regNo
            this.DeptCode.focus();
            this.activateApproval = response.Data.ActivateApproval;
            if (this.isNew && response.Data.ActivateApproval) {
              if (response.Data.ReqApprDetails && response.Data.ReqApprDetails.length > 0) {
                this.reqApprDetails = response.Data.ReqApprDetails;
                if (this.reqApprDetails[0].ApprStatus.trim() === "APPROVED") {
                  // When Approver has approved request enable Save button
                  this.isReqApprDisabled = true;
                  this.isSaveDisabled = false;
                  // Focus when press tab after regNo
                  this.DeptCode.focus();
                }
                else if (this.reqApprDetails[0].ApprStatus.trim() === "NEW") {
                  // When Request for Approval has been send and not Approved yet
                  this.isReqApprDisabled = true;
                  this.isSaveDisabled = true;
                  this.commonService.displayPromptMessage("Request For Approval", "For Final Bill Creation, Request has not been approved yet.")
                }
              }
              else {
                // When Request has not been send for Approval
                this.reqApprDetails = [];
                this.isReqApprDisabled = false;
                this.isSaveDisabled = true;
                this.commonService.displayPromptMessage("Request For Approval", "For final bill creation, Please send request for approval.");
              }

            }



            this.billedServiceDetails = new MatTableDataSource(response.Data.BilledServices);
            const servListOtherThanDoct = response.Data.OtherThanDocFeeServList;
            const servListForDoct = response.Data.BillDocFeeServList;
            //Using spread operator combined json response
            let finalBillServDtls = [...serviceList, ...servListOtherThanDoct, ...servListForDoct];
            finalBillServDtls = finalBillServDtls.filter(s => !isNullOrUndefined(s));

            const distinctServDtls = finalBillServDtls.filter((val, ind, arr) => arr.findIndex(d => d.DepartmentCode === val.DepartmentCode) === ind);
            // this.serviceListDetails = new MatTableDataSource(finalBillServDtls); /// commented by aditya on 24 aug 2020
            this.serviceListDetails = new MatTableDataSource(serviceList);
          }
          else {
            this.serviceListDetails = new MatTableDataSource([]);
            this.billedServiceDetails = new MatTableDataSource([]);
            this.loader.spin.next(false);
          }
          this.serviceListDetails.sort = this.sort;
          this.loader.spin.next(false);
          if (this.isNew) {
            this.f.VoucherNo.enable();
            this.f.IdcnNo.enable();
            this.f.DepartmentCode.enable();

          }
          else {

            this.f.UserId.setValue(firstBillService.UserId);
          }

          this.f.DiscountType.setValue(firstBillService.DiscountType);
          if (!this.commonService.isValidStringValue(this.f.DiscountType.value) && this.isNew) {
            this.f.DiscountType.enable();
          }

          this.f.PrintCharges.enable();
          this.f.DischargeDate.enable();
          this.f.Diagnosis.enable();
          this.f.DischStat.enable();
          this.f.ExchangeRate.enable();

        } else if (response && response.Status === 400) {
          this.serviceListDetails = new MatTableDataSource([]);
          this.billedServiceDetails = new MatTableDataSource([]);
          this.errorList = response.Data.BillingServiceList;
          this.loader.spin.next(false);
        } else {
          this.serviceListDetails = new MatTableDataSource([]);
          this.billedServiceDetails = new MatTableDataSource([]);
          this.loader.spin.next(false);
        }
      },
        (error) => {
          this.serviceListDetails = new MatTableDataSource([]);
          this.billedServiceDetails = new MatTableDataSource([]);
          this.loader.spin.next(false);
        }
      );
  }

  setPatientData(patient: any) {
    this.billData["Title"] = patient.Title;
    this.billData["PatientName"] = patient.PatientName;
    this.billData["BedCategory"] = patient.BedCategoryName;
    this.billData["BedNo"] = patient.BedNo;
    this.billData["AdmissionDate"] = patient.AdmitDate;
    this.billData["InsCompanyName"] = patient.InsCompanyName;
    this.billData["Address"] = patient.Address;
    this.billData["DoctorName"] = patient.DoctorName;
    this.billData["PatientCategory"] = patient.PatientCategory;
    this.billData["ReferralDoctor"] = patient.ReferralDoctor;
    this.billData["Phone"] = patient.MobileNo;
    this.billData["CategoryCode"] = patient.PatientCategoryCode;
    this.billData["ReferralDoctor"] = patient.ReferralDoctorName;
    if (!isNullOrUndefined(patient.CompanyName)) {
      this.billData["CompanyCode"] = patient.CompanyName.split(" ")[0];
    }
    this.billData["BillType"] = this.f.BillType.value;
    this.billData["InsCompName"] = patient.InsCompName;
    this.billData["InsCompCode"] = patient.InsCompCode;
    this.billData["Phone"] = patient.MobileNo;
  }

  //Input to fetch service details
  getNewBillInput() {
    return {
      IpBillNo: this.f.BillNo.value,
      RegNo: this.f.RegNo.value,
      BillTotal: this.f.BillTotal.value,
      CategoryCode: this.f.CategoryCode.value,
      CompanyCode: this.f.CompanyCode.value,
      BedCategoryCode: this.bedCategoryCode,
      //PfNo: this.patientDetails.PfundNo,
      ServiceCost: this.f.BillTotal.value,//check once whether value is correct
      ServiceAmt: this.f.BillTotal.value,//check once whether value is correct
      FolioNo: this.folioNo,
      VoucherNo: this.voucherNo,
      ServDate: this.billDate,
      BookDate: this.billDate,
      BookTime: this.billTime,
      FDate: this.fDate,
      FTime: this.fTime,
      UserId: this.userId,
      BillTypeFlag: this.billTypeFlag,
      IsNew: this.isNew,
      BillAmount: this.billAmount,
      ReserveAmount: this.reserveAmount,
      DiscountType: (this.isTPADiscountAllowed && this.isFromFinal && this.isNew && this.displayTPADiscount) ? this.f.DiscountType.value : '',
      ApprovedAmount: this.f.ApprovedAmount.value,
    };
  }

  // Author - Vinayak Savale
  // Sends request for Approval
  sendReqForApproval() {

    if (!this.validateBeforeReqForApproval()) return;

    this.commonService.inputConfirmAction("Request For Approval", "Are you sure you want to send request for approval ?", "PATIENT DISCHARGE").subscribe(response => {
      if (response.Status) {
        let regApprovalInput = this.getRegApprovalInput();
        regApprovalInput.ReqRemarks = response.Remarks;
        this.httpService.Post(urlConstant.Billing.SendApprovalRequest(), regApprovalInput).subscribe(response => {
          if (response.Data === true) {
            this.commonService.displayPromptMessage("Request For Approval", "Request sent for Approval successfully.").subscribe(response => {
              //this.redirectToReqApprDashboard();
              this.redirectToList();
            })
          }
        })
      }
    })


  }


  /// Author -  Vinayak Savale
  /// Save new bill
  saveNewBill() {
    if (!this.validateForm()) return;


    if (!isNullOrUndefined(this.savePopupOpened))
      return;
    else
      this.savePopupOpened = this.commonService.confirmAction("Save Bill", "Are you sure you want to save this bill ?")


    this.savePopupOpened.subscribe(response => {

      if (response) {

        this.httpService.Get(urlConstant.Billing.ValidateDuplicateBill(this.f.RegNo.value, this.f.FolioNo.value,
          (parseFloat(this.f.BillTotal.value) + parseFloat(this.f.DoctBill.value)).toFixed(2)))
          .subscribe(res => {

            if (this.commonService.isValidStringValue(res.Data)) {
              this.commonService.displayPromptMessage("Save Bill",
                "Bill (" + res.Data + ") for " + this.f.PatientName.value + " with same amount has already been saved for today.Please re enter the Admission Number")
                .subscribe(confirmRes => {
                  // Changed after discussion with Prakash Sir on 13 April 2021. removed yes and no option with just a simple message
                  // this.savePopupOpened = null;
                  // if (!confirmRes)
                  //   this.executeSaveAPI();
                  // else
                  // this.clearServices(true);
                  window.location.reload();
                });
            }
            else {

              this.executeSaveAPI();
            }
          });

      }
      else {
        this.savePopupOpened = null;
      }
    });
  }




  executeSaveAPI() {
    this.loader.spin.next(true);
    this.f.Action.setValue(this.isNew ? "N" : "C");

    let newBillInput = this.newBillForm.getRawValue();
    let dischargeDate = this.f.DischargeDate.value;
    newBillInput.DischargeDate = typeof (dischargeDate) === "string" && dischargeDate.length === 8
      ? dischargeDate : this.commonService.convertDateToString(new Date(this.f.DischargeDate.value));
    newBillInput.BillingServiceList = this.serviceListDetails.data;
    // Final Bill Request/Approval details
    newBillInput.ReqApprDetails = this.reqApprDetails;
    newBillInput.DiscountType = (this.isTPADiscountAllowed && this.isFromFinal && this.isNew && this.displayTPADiscount) ? this.f.DiscountType.value : '',
      this.httpService.Post(urlConstant.Billing.SaveBill(), newBillInput).subscribe(response => {
        if (response.Status === 200) {

          if (!this.commonService.isValidStringValue(response.Data)) {
            this.commonService.displayPromptMessage("New bill", "Unable to generate bill. Please try after some time!").subscribe();
            this.loader.spin.next(false);
            return;
          }


          this.f.BillNo.setValue(response.Data);
          this.billData["IpBillNo"] = response.Data;
          this.billData["BillTotal"] = this.f.BillTotal.value;
          this.billData.RegNo = this.f.RegNo.value;

          // Re-Assigning printBill values to billData in case clicked on 'No' when ask for print bill.
          this.billData["PrintType"] = this.billType;
          this.billData["BillTotal"] = (parseFloat(this.f.BillTotal.value) + parseFloat(this.f.DoctBill.value)).toFixed(2);
          this.billData["BillType"] = this.f.CloseFolio.value ? "IFB" : this.billTypeFlag;

          if (this.isNew) {
            this.billData["DischStat"] = this.f.DischStat.value;
            this.billData["DischargeDate"] = this.commonService.convertDateToString(new Date(this.f.DischargeDate.value));
          }

          // Exchange rates
          this.billData["Rate"] = this.rate.Rate;
          this.billData["Symbol"] = this.rate.Symbol;
          this.billData["RateUpdatedDate"] = this.rate.UpdatedOn;
          this.billData["CurrencyName"] = this.rate.CurrencyName;

          // Show Diagnosis after save while printing
          if (isNullOrUndefined(this.billData.Diagnosis))
            this.billData["Diagnosis"] = this.f.Diagnosis.value;

          // Show Prepared By after save while printing
          if (isNullOrUndefined(this.billData.UserId))
            this.billData["UserId"] = localStorage.getItem("UserName");

          this.commonService.confirmAction("New Bill", "Bill saved successfully. Do you want to print?")
            .subscribe(confirmation => {
              if (confirmation) {
                this.printBill(true);
              }
              else {
                this.conditionalConfirmations();
              }

            });
        }
        this.loader.spin.next(false);
      });
  }

  // Author - Vinayak Savale
  // After saving final bill it will ask for print then whether need to create summary bill on save or print or close it will ask for ATG. On ATG save it will redirect and On ATG close it will stay on same page.
  conditionalConfirmations(redirect: boolean = true) {
    // if user click on 'No' should ask for summary bill pop-up

    if (this.isNew) {
      this.commonService.confirmAction("Summary Bill", "Do you want to create summary bill for this ?").subscribe(response => {
        if (response) {
          this.summaryInput().subscribe(sumresponse => {
            // on save or close or print it will ask for ATG pop up.
            this.openATGPopup();
          });
        }
        else {
          this.openATGPopup();
        }
      })
    }
    else if (redirect) {
      localStorage.removeItem("BillListParam");
      this.redirectToList();
    }

  }


  openATGPopup() {
    if (this.billTypeFlag === "FN" || (this.billTypeFlag === "IN" && this.f.CloseFolio.value)) {
      this.openATG().subscribe(atgresponse => {
        this.clearServices();
      });
    }
    else {
      this.clearServices();
    }
  }

  validateForm() {

    if (this.serviceListDetails.data.length === 0) {
      this.commonService.openSnackBar(`Please add services first to create a bill`, "Ok");
      return false;
    }


    if (!this.commonService.isValidStringValue(this.f.VoucherNo.value)) {
      this.commonService.openSnackBar(`Please enter voucher number`, "Ok");
      this.VoucherNo.nativeElement.focus();
      return false;
    }

    if (this.f.VoucherNo.value.length > 2) {
      this.commonService.openSnackBar(`Voucher number cannot be greater than 2`, "Ok");
      return false;
    }

    if (this.isFromFinal) {
      if (!this.commonService.isValidStringValue(this.f.DepartmentCode.value)) {
        this.commonService.openSnackBar(`Please select a valid department`, "Ok");
        this.DeptCode.focus();
        return false;
      }

      if (!this.commonService.isValidStringValue(this.f.DischStat.value)) {
        this.commonService.openSnackBar(`Please select a valid discharge status`, "Ok");
        this.Disch.focus();
        return false;
      }


      if (this.commonService.isValidStringValue(this.f.IdcnNo.value) && this.f.IdcnNo.value.length > 14) {
        this.commonService.openSnackBar(`Idc No cannot be greater than 14 characters`, "Ok");
        return false;
      }

      if (this.commonService.isValidStringValue(this.f.Diagnosis.value) && this.f.Diagnosis.value.length > 35) {
        this.commonService.openSnackBar(`Diagnosis cannot be greater than 35 characters`, "Ok");
        return false;
      }

      if (this.f.DischargeDate.value < this.commonService.convertStringToDate(this.patientDetails.AdmitDate)) {
        this.commonService.openSnackBar(`Discharge date cannot be smaller than admit date`, "Ok");
        return false;
      }
    }

    return true;
  }

  validateBeforeReqForApproval() {
    if (!this.commonService.isValidStringValue(this.f.RegNo.value)) {
      this.commonService.openSnackBar(`Please enter admission number first`, "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.FolioNo.value)) {
      this.commonService.openSnackBar(`Please enter folio number first`, "Ok");
      return false;
    }

    return true;
  }

  /// Author -  Vinayak Savale
  /// On click of previous bill button it will open Previous Bill dialog box
  openPreviousBills() {
    const dialogRef = this.dialog.open(PreviousBillsComponent, {
      maxHeight: '700px',
      disableClose: true
    });

    dialogRef.componentInstance.isPopup = true;
    dialogRef.componentInstance.folioNo = this.f.FolioNo.value;
    dialogRef.componentInstance.regNo = this.f.RegNo.value;
  }

  /// Author -  Vinayak Savale
  // gets summary bills from master and displays data in dropdown
  getSummaryBills() {
    this.httpService.Get(urlConstant.Billing.GetSummaryBills())
      .subscribe(response => {
        this.summaryBillList = response.Data;
      });
  }

  // Author - Vinayak Savale
  // To get exchange rates currency list
  getExchangeRates() {

    const waitTime = pipe(debounceTime(200));
    const distinct = pipe(distinctUntilChanged());
    this.f.ExchangeRate.valueChanges
      .pipe(waitTime)
      .pipe(distinct)
      .pipe(
        switchMap(text =>
          !isNullOrUndefined(text) && text.toString().trim() !== ''
            ? this.httpService.Get(urlConstant.Billing.GetExchangeRates(text))
            : []
        )
      )
      .subscribe(result => {
        if (result.Status === 200) {
          this.currencyList = result.Data;
        } else {
          return;
        }
      });
  }

  // set exchange rate value on the basis of selection.
  setExchangeRateValue(details: any) {
    this.rate = details;
  }

  // clears exchange rate lookup search
  clearLookupSearch() {
    this.f.ExchangeRate.setValue("");
    this.currencyList = [];
    this.rate = { Rate: 1, Symbol: "" };
    this.symbol = "";
  }

  /// Author -  Vinayak Savale
  /// on click of summary check box
  summaryInput() {
    const dialogRef = this.dialog.open(SummaryBillComponent, {
      maxHeight: '700px',
      disableClose: true
    });

    dialogRef.componentInstance.isPopup = true;
    dialogRef.componentInstance.ipBillNo = this.f.BillNo.value;
    dialogRef.componentInstance.folioNo = this.folioNo;
    dialogRef.componentInstance.regNo = this.f.RegNo.value;
    dialogRef.componentInstance.billTypeFlag = this.billTypeFlag;
    dialogRef.componentInstance.billAmount = (parseFloat(this.f.BillTotal.value) + parseFloat(this.f.DoctBill.value)).toFixed(2);
    dialogRef.componentInstance.billPrintData = this.billData;

    return dialogRef.afterClosed();
  }

  /// Author -  Vinayak Savale
  /// on click of All Department /IPF checkbox
  alldeptInput(event: any) {
    const dialogRef = this.dialog.open(AllDepartmentComponent, {
      maxHeight: '700px',
      disableClose: true
    });

    dialogRef.componentInstance.isPopup = true;
    dialogRef.componentInstance.ipBillNo = this.f.BillNo.value;
    dialogRef.componentInstance.folioNo = this.f.FolioNo.value;
    dialogRef.componentInstance.regNo = this.f.RegNo.value;
    dialogRef.componentInstance.billTypeFlag = this.billTypeFlag;
    dialogRef.componentInstance.billPrintData = this.billData;
  }

  //on click of display button it will redirect to bill list.
  redirectToList() {
    this.router.navigate(['billing/bill-list', this.billTypeFlag.trim()]);
  }

  redirectToReqApprDashboard() {
    this.router.navigate(['billing/request-approval-dashboard']);
  }

  // reset form
  resetForm() {
    this.commonService.confirmAction(messageConstant.invalidMessages.HeaderForReset, messageConstant.invalidMessages.ResetMessage).subscribe(
      response => {
        if (response) {
          this.clearFormField();

        }
      }
    );
  }

  clearFormField() {
    this.clearServices(false);
    this.newBillForm.reset();

    this.patientDetailComponent.clearPatientLookup();
    this.f.UserId.setValue(localStorage.getItem("UserName"));
    this.setRouteParameters();
  }


  clearServices(reload: boolean = true) {
    this.serviceListDetails = new MatTableDataSource<ServiceBillModel>([]);
    this.billedServiceDetails = new MatTableDataSource<ServiceBillModel>([]);
    if (reload) {
      this.patientDetailComponent.setPatientDetailByRegNo(this.f.RegNo.value, false);
    }
    else {
      this.f.DischargeTime.setValue(this.commonService.getCurrentTime());
      this.f.DischargeTime.setValue(new Date());
      this.savePopupOpened = null; //  moved here on 10 May 2020
    }
    this.f.DiscountType.setValue('');
  }

  setFolio(folioNo: string) {
    if (this.isNew && this.commonService.isValidStringValue(this.folioNo)
      && this.folioNo !== folioNo) {
      this.folioNo = folioNo;
      this.f.FolioNo.setValue(folioNo);
      this.patientDetails.FolioNo = folioNo;
      this.getServiceDetails(this.patientDetails);
    }
  }

  printBill(redirect: boolean = false, isDetail: boolean = false) {
    this.loader.spin.next(true);
    if (["09", "11"].indexOf(this.f.CategoryCode.value) > -1) {
      this.loader.spin.next(false);
      this.commonService.displayPromptMessage("Bill Print", "Print Bill Using IPF Option").subscribe(resp => {
        this.conditionalConfirmations(redirect)
      });
    }
    else {
      let printData = this.billData;
      printData["PrintType"] = this.billType;
      printData["BillTotal"] = (parseFloat(this.f.BillTotal.value) + parseFloat(this.f.DoctBill.value)).toFixed(2);
      printData["BillType"] = this.f.CloseFolio.value ? "IFB" : this.billTypeFlag;
      printData["IsDetail"] = isDetail;

      if (this.isNew) {
        printData["DischStat"] = this.f.DischStat.value;
        printData["DischargeDate"] = this.commonService.convertDateToString(new Date(this.f.DischargeDate.value));
      }

      // Exchange rates
      printData["Rate"] = this.rate.Rate;
      printData["Symbol"] = this.rate.Symbol;
      printData["RateUpdatedDate"] = this.rate.UpdatedOn;
      printData["CurrencyName"] = this.rate.CurrencyName;

      // Show Diagnosis after save while printing
      if (isNullOrUndefined(this.billData.Diagnosis))
        printData["Diagnosis"] = this.f.Diagnosis.value;

      // Show Prepared By after save while printing
      if (isNullOrUndefined(this.billData.UserId))
        printData["UserId"] = localStorage.getItem("UserName");

      // let services = printData.BillingServiceList;
      let services: any = this.serviceListDetails.data;

      if (isDetail) {
        services = [...this.serviceListDetails.data, ...this.billedServiceDetails.data];
      }

      for (let i = 0; i < services.length; i++) {
        services[i].Service = (this.commonService.isValidStringValue(services[i].DoctCode) && this.f.PrintCharges.value === 'P')
          ? "PROFESSIONAL CHARGES" : services[i].ServiceName;
        services[i].Quantity = services[i].Qty;
        services[i].ServiceAmount = services[i].Amount;
      }

      printData.BillingServiceList = services;

      this.httpService.Post(urlConstant.Billing.GetPrint(), printData).subscribe(response => {
        this.loader.spin.next(false);
        if (this.commonService.isValidStringValue(response))
          this.httpService.openFile(response);
        this.conditionalConfirmations(redirect);
      });
    }
  }

  openATG() {
    const dialogRef = this.dialog.open(AllowToGoComponent, {
      maxHeight: '650px',
      disableClose: true,
      minWidth: '88vw',
    });

    dialogRef.componentInstance.isPopup = true;
    dialogRef.componentInstance.regNo = this.f.RegNo.value;
    dialogRef.componentInstance.status = this.f.DischStat.value;
    dialogRef.componentInstance.dischStatus = this.patientStatus.filter(s => s.value === this.f.DischStat.value)[0].DBValue;

    return dialogRef.afterClosed();

  }


  printDeposit() {
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.Billing.GetDeposits(this.f.RegNo.value)).subscribe(response => {
      let printData = response.Data;
      printData["PrintType"] = "Deposit";
      if (printData.length > 0) {
        printData[0]["PatientName"] = this.billData["PatientName"];
        this.httpService.Post(urlConstant.Billing.GetDepositPrint(), printData).subscribe(response => {
          this.loader.spin.next(false);
          if (this.commonService.isValidStringValue(response))
            this.httpService.openFile(response);
        });
      }
      else {
        this.loader.spin.next(false);
        this.commonService.displayPromptMessage("Deposit Print", "No deposit data present for print").subscribe();
      }
    });
  }

  saveDiagnosis() {
    if (this.f.Diagnosis.value.length > 35) {
      this.commonService.openSnackBar("Diagnosis length cannot be greater than 35", "Ok");
      return;
    }


    this.commonService.confirmAction("Diagnosis Updation Confirmation", "Do you want to change Diagnosis Y/N?")
      .subscribe(confirmResponse => {
        if (confirmResponse) {
          let formValue = this.newBillForm.getRawValue();

          formValue.IpBillNo = this.f.BillNo.value;
          let dischargeDate = this.f.DischargeDate.value;
          formValue.DischargeDate = typeof (dischargeDate) === "string" && dischargeDate.length === 8
            ? dischargeDate : this.commonService.convertDateToString(new Date(this.f.DischargeDate.value));
          this.httpService.Post(urlConstant.Billing.SaveDiagnosis(), formValue)
            .subscribe(response => {
              if (response.Status === 200) {
                this.commonService.openSnackBar("Diagnosis updated successfully", "ok");
                this.billData["Diagnosis"] = this.f.Diagnosis.value;
                this.billData["DischStat"] = this.f.DischStat.value;
                this.billData["DischargeDate"] = formValue.DischargeDate;

              }
            });
        }
      })

  }

  // gets cost cent master data
  GetCostCent() {
    this.httpService.Get(urlConstant.Masters.GetCostCent())
      .subscribe(response => {
        if (response.Status === 200)
          this.departmentList = response.Data;
      });
  }

  getRegApprovalInput() {
    return {
      RegNo: this.f.RegNo.value,
      FolioNo: this.f.FolioNo.value,
      PatName: this.f.PatientName.value,
      ReqBy: this.f.UserId.value,
      ApprovalAmount: (parseFloat(this.f.BillTotal.value) + parseFloat(this.f.DoctBill.value)),
      ReqRemarks: ""
    };
  }


  openDoctorDetail() {
    const dialogRef = this.dialog.open(DoctorDetailsListComponent, {
      maxHeight: this.servicePopupHeight,
      disableClose: true,
      minWidth: '88vw',
    });

    dialogRef.componentInstance.isPopup = true;
    dialogRef.componentInstance.regNo = this.f.RegNo.value;

    dialogRef.afterClosed().subscribe();

  }


  openLabDetail() {
    const dialogRef = this.dialog.open(LabServiceDetailsComponent, {
      maxHeight: this.servicePopupHeight,
      disableClose: true,
      minWidth: '88vw',
    });

    dialogRef.componentInstance.isPopup = true;
    dialogRef.componentInstance.regNo = this.f.RegNo.value;

    dialogRef.afterClosed().subscribe();
  }
  openPharmaDetail() {
    const dialogRef = this.dialog.open(DrugDetailsListComponent, {
      maxHeight: this.servicePopupHeight,
      disableClose: true,
      minWidth: '88vw',
    });

    dialogRef.componentInstance.isPopup = true;
    dialogRef.componentInstance.regNo = this.f.RegNo.value;

    dialogRef.afterClosed().subscribe();
  }
  openOTDrugs() {
    const dialogRef = this.dialog.open(OtDetailsListComponent, {
      maxHeight: this.servicePopupHeight,
      disableClose: true,
      minWidth: '88vw',
    });

    dialogRef.componentInstance.isPopup = true;
    dialogRef.componentInstance.regNo = this.f.RegNo.value;

    dialogRef.afterClosed().subscribe();
  }

  getServiceDetailsOnChange() {
    this.getServiceDetails(this.patientDetails);

  }


  getDiscountServices() {
    const dialogRef = this.dialog.open(DiscountServiceComponent, {
      maxHeight: this.servicePopupHeight,
      disableClose: true,
      minWidth: '64vw',
    });

    dialogRef.componentInstance.regNo = this.f.RegNo.value;
    dialogRef.componentInstance.billNo = this.f.BillNo.value;

    dialogRef.afterClosed().subscribe();
  }


  openMultiPayer() {
    const dialogRef = this.dialog.open(MultiPayerComponent, {
      maxHeight: this.servicePopupHeight,
      disableClose: true,
      minWidth: '34vw',
    });

    dialogRef.componentInstance.regNo = this.commonService.isValidStringValue(this.f.RegNo.value) ? this.f.RegNo.value : '';
    dialogRef.componentInstance.billNetAmount = this.f.NetAmt.value;

    dialogRef.afterClosed().subscribe();
  }

}
