import { Component, OnInit, ViewChild, OnDestroy } from "@angular/core";
import { MatSort } from "@angular/material/sort";
import { MatTableDataSource } from "@angular/material/table";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { HttpService } from "src/app/services/http.service";
import { urlConstant } from "../../constants/urlConstants";
import { isNullOrUndefined } from "util";
import { patientCategoryConstant } from "src/app/constants/patientCategoryConstants";
import { BillListModel } from "src/app/models/bill-list.model";
import { LoaderService } from "src/app/services/loader.service";
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { MatDialog } from '@angular/material';
import { PatientEnquiryComponent } from 'patient-enquiry';
import { AdmissionNumberLookupComponent } from 'admission-number-lookup';
import { CommonService } from 'src/app/services/common.service';
import { FromDateToDateComponent } from 'from-date-to-date';
import { RegnoTabFieldComponent } from 'regno-tab-field';
import { EligibleFinalbillPatientsComponent } from '../eligible-finalbill-patients/eligible-finalbill-patients';
import { PatientSourceMultiselectLookupComponent } from "patient-source-multiselect-lookup";

@Component({
  selector: "app-bill-list",
  templateUrl: "./bill-list.component.html",
  styleUrls: ["./bill-list.component.css"],
  host: { class: "section__main" },
})
export class BillListComponent implements OnInit, OnDestroy {
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('fromDateToDate') fromDateToDate: FromDateToDateComponent;
  // @ViewChild('patientSourceDropdown') patientSourceDropdown: PatientSourceDropdownComponent;
  @ViewChild('patientmultiselect') patientmultiselect: PatientSourceMultiselectLookupComponent;
  @ViewChild('regNoTabfield') regNoTabfield: RegnoTabFieldComponent;
  billTypeFlag: string;
  billListForm: FormGroup;
  maxDate = new Date();
  selectedRowData: any;
  selectedRowIndex: number = -1;
  floatLabel = "always";
  highLightRow: number;
  categoryList: { value: string; viewValue: string }[];
  errorList: any;

  totalBillAmount: any = 0.0;
  currentUrl = ''
  billType: string = "";
  billListDetails: MatTableDataSource<BillListModel> = new MatTableDataSource();
  displayedColumns = ["IpBillNo", "BillDate", "RegNo", "PatName", "FolioNo", "BillAmt", "BillStat", "BedNo", "Summary", "PatientCategory"];
  sub: any;
  // permissions
  permissions: any[];
  canCreateBill: boolean;
  canViewBill: boolean;
  //variables
  constructor(
    private fb: FormBuilder, private commonService: CommonService,
    private httpService: HttpService, public dialog: MatDialog,
    private loader: LoaderService, private router: Router, private route: ActivatedRoute) {
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;

  }

  ngOnInit() {
    this.initializeForm();
    this.sub = this.route.params.subscribe(params => {
      let billTypeFlag = params['billType'];
      this.f.BillTypeFlag.setValue(billTypeFlag);
      if (billTypeFlag === "IN") {
        this.billType = "Interim";
        this.billTypeFlag = "IN";
        this.displayedColumns = this.displayedColumns.filter(d => d !== "Approved");
      }
      else if (billTypeFlag === "FN") {
        this.billType = "Final";
        this.billTypeFlag = "FN";
        // Removed as per the issue RHHIS-3214
        //Bhushan T  
        //this.displayedColumns.push("Approved");
      }
    });

    this.billListDetails = new MatTableDataSource([]);
    this.billListDetails.sort = this.sort;
    this.getBillList();

    //#region permission
    this.permissions = JSON.parse(localStorage.getItem('Permission'));

    if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
      // Bill Permissons set
      this.canCreateBill = this.permissions.includes('4002N') || this.permissions.includes('4003N') ? true : false;
      this.canViewBill = this.permissions.includes('4003N') || this.permissions.includes('4003V') ? true : false;
    }
    //#endregion
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }

  //Function to return bill list form controls
  get f() {
    return this.billListForm.controls;
  }

  //Initialize form
  initializeForm() {
    this.billListForm = this.fb.group({
      DateChecker: [true],
      FromDate: [new Date(), Validators.required],
      ToDate: [new Date(), Validators.required],
      Category: [""],
      SummaryBills: false,
      RegNo: [""],
      PatientName: [""],
      BillTypeFlag: [""]
    });


  }

  enableDate() {
    if (this.f.DateChecker.value) {
      this.fromDateToDate.FromDate.enable();
      this.fromDateToDate.ToDate.enable();
    }
    else {
      this.fromDateToDate.FromDate.disable();
      this.fromDateToDate.ToDate.disable();
    }
  }

  /// Author -  Vinayak Savale
  //on click of show button get billing list
  getBillList() {
    this.selectedRowData = {};

    let billIndex = localStorage.getItem("SelectedBillIndex");
    if (isNullOrUndefined(billIndex)) {
      this.selectedRowIndex = -1;
    }
    else {
      this.selectedRowIndex = parseInt(billIndex);
      localStorage.removeItem("SelectedBillIndex");
    }


    let billparam = JSON.parse(localStorage.getItem("BillListParam"));
    if (!isNullOrUndefined(billparam)) {
      // flag check if user navigate from view interim to final bill list vice versa
      if (billparam.BillTypeFlag != this.billTypeFlag)
        // if click of interim to final bill or vice versa
        localStorage.removeItem("BillListParam");
      else {
        // on click of back setting form values from localstorage
        this.billListForm.patchValue({
          'DateChecker': billparam.DateChecker, 'FromDate': billparam.FromDate, 'ToDate': billparam.ToDate, 'Category': billparam.Category, 'SummaryBills': billparam.SummaryBills, 'RegNo': billparam.RegNo, 'PatientName': billparam.PatientName, 'BillTypeFlag': billparam.BillTypeFlag
        });
        this.fromDateToDate.FromDate.setValue(new Date(billparam.FromDate));
        this.fromDateToDate.ToDate.setValue(new Date(billparam.ToDate));
        //this.patientSourceDropdown.myControl.setValue(billparam.Category);
        this.patientmultiselect.PatientSourceControl.setValue(billparam.Category.split(","));
        // Enable/Disable on the basis of DateChecker value
        this.enableDate();
        // after click on back setting admission number and patient name in input field
        if (billparam.RegNo != "")
          this.regNoTabfield.setValues(billparam.RegNo, billparam.PatientName);
        localStorage.removeItem("BillListParam");
      }
    }
    // on selection of 'All' from dropdown, setting Category form value directly.
    // this.f.Category.setValue(this.patientSourceDropdown.myControl.value);
    const categories = this.commonService.isValidStringValue(this.patientmultiselect.PatientSourceControl.value) ? (this.patientmultiselect.PatientSourceControl.value.includes(",") ? this.patientmultiselect.PatientSourceControl.value : this.patientmultiselect.PatientSourceControl.value.join(",")) : "";

    this.f.Category.setValue(categories);
    const billListInput = this.getBillListInput();
    this.loader.spin.next(true);

    this.httpService.Post(urlConstant.Billing.GetBillList(), billListInput).subscribe((response: any) => {
      if (!isNullOrUndefined(response) && response.Data.length > 0
        && response.Status === 200) {
        this.billListDetails = new MatTableDataSource(response.Data);
        this.billListDetails.sort = this.sort;
        this.totalBillAmount = this.billListDetails.data.filter((d) => d.IpBillNo).map((d) => parseFloat(d.BillAmt)).reduce((prev, curr) => prev + curr, 0).toFixed(2);

        this.loader.spin.next(false);
      } else if (response && response.Status === 400) {
        this.billListDetails = new MatTableDataSource([]);
        this.totalBillAmount = "0.00";
        this.errorList = response.Data;
        // this.f.Category.setValue("");
        this.loader.spin.next(false);
      } else {
        this.billListDetails = new MatTableDataSource([]);
        this.totalBillAmount = "0.00";
        // this.f.Category.setValue("");
        this.loader.spin.next(false);
      }
    },
      (error) => {
        this.billListDetails = new MatTableDataSource([]);
        this.totalBillAmount = "0.00";
        this.loader.spin.next(false);
      }
    );
  }

  setLocalStorageValue() {
    localStorage.setItem("BillListParam", JSON.stringify(this.billListForm.getRawValue()));
  }

  //form input model
  getBillListInput() {

    if (!(this.commonService.isValidStringValue(this.f.RegNo.value)
      && this.commonService.isValidStringValue(this.f.PatientName.value)) && !this.f.DateChecker.value) {
      this.commonService.openSnackBar("Date filter cannot be removed without valid admission number", "Ok");
      this.f.DateChecker.setValue(true);
      this.enableDate();
    }


    return {
      DateChecker: this.f.DateChecker.value,
      FromDate: this.validateDate(this.f.FromDate.value),
      ToDate: this.validateDate(this.f.ToDate.value),
      Category: this.f.Category.value,
      SummaryBills: this.f.SummaryBills.value,
      RegNo: this.f.RegNo.value,
      PatientName: this.f.PatientName.value,
      BillTypeFlag: this.billTypeFlag,
    };
  }

  //to validate date
  validateDate(date: any) {
    if (isNullOrUndefined(date._isAMomentObject)) {
      return date;
    } else {
      return new Date(date._i.year, date._i.month, date._i.date).toLocaleDateString();
    }
  }

  //To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }


  }

  // clear form inputs
  clearSearch() {
    this.initializeForm();
    this.billListDetails = new MatTableDataSource([]);
    localStorage.removeItem("BillListParam");
    localStorage.removeItem("SelectedBillIndex");
    window.location.reload();
  }

  redirectToNewBill() {
    this.setLocalStorageValue();
    this.router.navigate(['billing/new-bill', this.billTypeFlag.trim()]);
  }

  /// Author -  Vinayak Savale
  // on click of display button it will redirect to bill service details.
  redirectToView() {

    if (this.selectedRowIndex === -1 || isNullOrUndefined(this.selectedRowIndex)) {
      this.commonService.openSnackBar("Please select a record first !", "Ok");
      return;
    }

    const ipBillNo = this.selectedRowData.IpBillNo.trim();

    if (!this.commonService.isValidStringValue(ipBillNo)) {
      this.commonService.openSnackBar("Invalid bill number selected !", "Ok");
      return;
    }

    this.setLocalStorageValue();
    this.router.navigate(['billing/view-bill', this.billTypeFlag.trim(), this.selectedRowData.RegNo.trim(), ipBillNo, this.selectedRowData.FolioNo.trim()]);
    localStorage.setItem("SelectedBillIndex", this.selectedRowIndex.toString());
  }

  // sets from date and to date from library element
  setDate(event) {
    if (!isNullOrUndefined(event)) {
      this.f.FromDate.setValue(new Date(event.FromDate.value).toLocaleDateString());
      this.f.ToDate.setValue(new Date(event.ToDate.value).toLocaleDateString());
    }
  }


  // sets patient category in form
  setPatientCategory(category) {
    if (!isNullOrUndefined(category.Code))
      this.f.Category.setValue(category.Code);
    else
      this.f.Category.setValue("");
  }

  // sets registration number 
  setPatientFormValue(patient) {
    //console.log(patient);
    this.f.RegNo.setValue(patient.AdmissionNo);
    this.f.PatientName.setValue(patient.PatientName);
  }


  // open patient help
  openPatientHelp() {
    const dialogRef = this.dialog.open(PatientEnquiryComponent, {
      disableClose: true,
      maxHeight: '800px',

    });

    dialogRef.componentInstance.isPopup = true;

    dialogRef.afterClosed().subscribe(dialogResult => {

      if (!isNullOrUndefined(dialogResult)) {
        this.f.RegNo.setValue(dialogResult.AdmissionNumber);
        this.f.PatientName.setValue(dialogResult.PatientName);
        this.regNoTabfield.setValues(dialogResult.AdmissionNumber, dialogResult.PatientName);
      }
    });
  }

  //export to excel
  exportToExcel() {

    const billListInput = this.getBillListInput();
    this.loader.spin.next(true);
    this.httpService
      .Post(urlConstant.Billing.GetBillListExportPath(), billListInput)
      .subscribe(response => {

        if (response && !isNullOrUndefined(response.Data)
          && response.Status === 200) {
          this.httpService.exportToExcel(response.Data);

        }
        this.loader.spin.next(false);
      });
  }

  getIRDABillPrint(isSummary: boolean = false, isDeposit: boolean = false) {

    let regNo = "";

    if (this.selectedRowIndex == -1) {
      regNo = this.f.RegNo.value;
    }
    else {
      regNo = this.selectedRowData.RegNo;
    }

    if (!this.commonService.isValidStringValue(regNo)) {
      this.commonService.openSnackBar('Please select a row or registration number for details', 'OK');
      return;
    }
    this.loader.spin.next(true);
    this.httpService.Get(isSummary ? urlConstant.Billing.GetIRDADetailPrint(regNo) : urlConstant.Billing.GetIRDABillPrint(regNo, isDeposit)).subscribe(response => {
      if (this.commonService.isValidStringValue(response))
        this.httpService.openFile(response);
      this.loader.spin.next(false);
    });

  }

  // Display patients which are eligible for Final Bill.
  openEligibleForFinalBill() {
    const dialogRef = this.dialog.open(EligibleFinalbillPatientsComponent, {
      maxHeight: '700px',
      disableClose: true
    });

    dialogRef.componentInstance.isPopup = true;
  }
}
