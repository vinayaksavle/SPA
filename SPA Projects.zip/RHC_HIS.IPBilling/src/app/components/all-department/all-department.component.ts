import { Component, OnInit, ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import { MatDialogRef, MatSort, MatTableDataSource } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AllDepartmentModel } from 'src/app/models/all-department.model';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';
import { PrinterService } from 'src/app/services/print.service';
import { CommonService } from 'src/app/services/common.service';

@Component({
  selector: 'app-all-department',
  templateUrl: './all-department.component.html',
  styleUrls: ['./all-department.component.css']
})
export class AllDepartmentComponent implements OnInit, AfterViewInit {
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('patientDetailComponent') patientDetailComponent: PatientDetailsComponent;
  depSummaryForm: FormGroup;
  isPopup: boolean = false;
  hiddenItems: any = ['FinalButton', 'InterimButton', 'DoctorButton', 'ApprovedAmount',
    'TPA', 'DischDateTime', 'RoomNo', 'CompanyName', 'EnquiryButton',
    , 'AdmitDateTime', 'FolioButton'];

  isNew: boolean = false;
  regNo: string;
  folioNo: string;
  ipBillNo: string;
  totalBillAmount: any = "0.00";
  billTypeFlag: string;
  TotalAmt = "0.00";
  Deposit = "0.00";
  BalanceDue = "0.00";

  displayedColumnsList: string[] = ['DepartmentCode', 'ServiceName', 'Billed', 'UnBilled', 'Total'];
  services: MatTableDataSource<AllDepartmentModel> = new MatTableDataSource();
  billPrintData: any;
  constructor(private http: HttpService, private loader: LoaderService,
    private dialogRef: MatDialogRef<AllDepartmentComponent>, private fb: FormBuilder
    , private printerService: PrinterService, private commonService: CommonService) { }


  ngAfterViewInit(): void {
    this.isNew = true;
    this.patientDetailComponent.setPatientDetailByRegNo(this.regNo, true);

    this.initializeForm();
    this.depSummaryForm.disable();
  }

  ngOnInit() {

  }

  initializeForm() {
    this.depSummaryForm = this.fb.group({
      RegNo: this.regNo,
      IpBillNo: this.ipBillNo,
      FolioNo: this.folioNo,
      BillType: this.billTypeFlag,
      TotalAmt: ["0.00"],
      Deposit: ["0.00"],
      BalanceDue: ["0.00"]
    });
  }

  getDepartmentSummary() {
    const depSummaryInput = this.getDepSummaryInput();
    this.loader.spin.next(true);

    this.http.Post(urlConstant.Billing.GetDepartmentSummary(), depSummaryInput).subscribe((response: any) => {
      if (response && response.Status === 200) {
        this.services = new MatTableDataSource(response.Data.DeptSummary);
        this.TotalAmt = response.Data.TotalAmt;
        this.Deposit = response.Data.DepositAmt;
        this.BalanceDue = response.Data.BalanceDue;
        setTimeout(() => {
          this.patientDetailComponent.setPatientFolioNo(this.folioNo);
          this.loader.spin.next(false);
          this.isNew = false;
        }, 500);
      }
      this.loader.spin.next(false);
    });
  }

  getDepSummaryInput() {
    return {
      IpBillNo: this.ipBillNo,
      RegNo: this.regNo,
      FolioNo: this.folioNo,
      BillTypeFlag: this.billTypeFlag
    }
  }

  //close dialog box
  closeDialog() {
    this.dialogRef.close();
  }

  //print document
  print() {

    let printData = this.billPrintData;

    printData["PrintType"] = "AllDepartmentSummary";
    printData["RegNo"] = this.regNo;
    let allDeptServices = [];
    printData["BillingServiceList"] = this.services.data.forEach(element => {
      allDeptServices.push({ 'ServiceName': element.ServiceName, 'Amount': element.Billed });
    });

    printData["BillingServiceList"] = allDeptServices;
    printData["BillTotal"] = this.TotalAmt;
    printData["NetAmt"] = this.TotalAmt;
    printData["ADBalance"] = this.BalanceDue;
    printData["ADDeposit"] = this.Deposit;


    this.http.Post(urlConstant.Billing.GetPrint(), printData).subscribe(response => {
      this.http.openFile(response);
    });
  }


  getPatientDetail(patient: any) {

    if (this.commonService.isValidStringValue(patient.RegNo)) {

      if (this.regNo !== patient.RegNo) {
        this.folioNo = patient.FolioNo;
      }
      this.regNo = patient.RegNo;
      this.getDepartmentSummary();
    }
    else {
      this.resetForm();
    }

  }

  setFolio(folioNo: string) {
    if (this.folioNo !== folioNo && !this.isNew) {
      this.folioNo = folioNo;
      this.getDepartmentSummary();
    }
  }


  resetForm() {

    this.regNo = '';
    this.folioNo = '';
    this.ipBillNo = '';
    this.totalBillAmount = "0.00";
    this.TotalAmt = "0.00";
    this.Deposit = "0.00";
    this.BalanceDue = "0.00";
    this.services = new MatTableDataSource();
  }

}
