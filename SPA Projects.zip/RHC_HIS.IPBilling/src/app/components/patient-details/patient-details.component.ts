import { Component, OnInit, Output, EventEmitter, ViewChild, Input, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { isNullOrUndefined } from 'util';
import { MatDialog } from '@angular/material';
import { AdmissionNumberLookupComponent } from 'admission-number-lookup';

import { PatientEnquiryComponent } from 'src/app/components/patient-enquiry/patient-enquiry.component';
import { PatientFolioComponent } from 'src/app/components/patient-folio/patient-folio.component';
import { Router } from '@angular/router';
import { PatientSourceDropdownComponent } from 'patient-source-dropdown';

@Component({
  selector: 'app-patient-details',
  templateUrl: './patient-details.component.html',
  styleUrls: ['./patient-details.component.css'],
})
export class PatientDetailsComponent implements OnInit, AfterViewInit {

  //Declarations start
  patientForm: FormGroup;
  bedCategoryList: any[] = [];
  FolioList: any[] = [];
  billDetailsList: any[] = [];
  //declare event emitters
  @Output() patientEmitter = new EventEmitter<any>();
  @Output() bedCategoryEmmitter = new EventEmitter<any>();
  @Output() folioEmmitter = new EventEmitter<any>();
  @Output() categoryEmmitter = new EventEmitter<any>();
  @Output() activateDoctorList = new EventEmitter<any>();

  @Input() hideItems = [];
  @Input() disabledItems = [];
  @Input() disableValidations: boolean = false;
  @Input() getAllFolios: boolean = false;
  @Input() title: string = "Patient Details";
  @Input() billType: string = "";
  @Input() displayHeader: boolean = true;
  @Input() hideBorder: boolean = false;
  @Input() displayAllFolio: boolean = false;
  @Input() enableCategoryDropdown: boolean = false;
  @Input() width: string = '100';


  admmissionDateTime: string = "";
  blockFolioEmit: boolean = false


  @ViewChild('admissionNumberLookup') admissionNumberLookup: AdmissionNumberLookupComponent;
  @ViewChild('sourceList') sourceList: PatientSourceDropdownComponent;
  percentages: any;
  ruby: any;
  fromPatHelp: boolean = false;

  constructor(private fb: FormBuilder, private commonService: CommonService,
    private dataService: DataTranferService, private httpService: HttpService,
    public dialog: MatDialog, private router: Router) {
  }
  ngAfterViewInit(): void {
    this.sourceList.myControl.disable()
    this.setFocus();
    this.getPatientDataByLS();
    if (this.dataService.checkAccessRights('4013') && this.enableCategoryDropdown) this.sourceList.myControl.enable();


  }

  ngOnInit() {
    this.initForm();
    this.getInitData();
    
  }

  // initialize form 
  initForm() {
    this.patientForm = this.fb.group({
      RegNo: ['', Validators.required],
      Title: [''],
      PatientName: [{ value: '', disabled: true }],
      BedNo: [{ value: '', disabled: this.checkDisablity('BedNo') }],
      RoomNo: [{ value: '', disabled: true }],
      FolioNo: [{ value: '', disabled: this.checkDisablity('FolioNo') }],
      CompanyName: [{ value: '', disabled: true }],
      AdmitDate: [{ value: '', disabled: true }],
      AdmitTime: [{ value: '', disabled: true }],
      ApproveAmount: [{ value: '', disabled: true }],
      TPA: [{ value: '', disabled: true }],
      PatientCategory: [{ value: '', disabled: true }],
      PatientCategoryCode: [{ value: '', disabled: true }],
      CategorySource: [{ value: '', disabled: true }],
      BedCategory: [{ value: '', disabled: this.checkDisablity('BedCategory') }],
      DischargeDate: [{ value: '', disabled: true }],
      DischargeTime: [{ value: '', disabled: true }],
      PreviousBillNo: [{ value: '', disabled: true }],
      PreviousBillDate: [{ value: '', disabled: true }],
      BillNo: [{ value: '', disabled: true }],
      BillDate: [{ value: '', disabled: true }],
      FolioNumberForBill: [{ value: '', disabled: true }],
      InsCompanyName: [{ value: '', disabled: true }],
      InsCompCode: [{ value: '', disabled: true }],
      Address: [{ value: '', disabled: true }],
      Responsible: [{ value: '' }],
      Tstatus: [{ value: '' }],
      RefComp: [{ value: '' }],
      ReferredCompany: [{ value: '' }],
      PatCategory: [{ value: '' }],
      Status: [{ value: '' }]
    });
  }

  //sets patient category in form
  setPatientCategory(category) {
   
    if (!isNullOrUndefined(category.Code)) {
      this.f.PatientCategory.setValue(category.Code + " " + category.Name);
      this.f.PatCategory.setValue(category.Code);
      this.f.CategorySource.setValue(category.PatientCatSrc);
    }
    else {
      this.f.PatientCategory.setValue("");
      this.f.PatCategory.setValue("");
      this.f.CategorySource.setValue("");
    }

    this.categoryEmmitter.emit(category);
  }



  // gets patient form controls
  get f() {
    return this.patientForm.controls;
  }

  //get inital data for dropdown and select
  getInitData() {
  this.f.RegNo.disable(); 
  this.f.BedNo.disable(); 
    this.httpService.Get(urlConstant.Patient.GetPatientInit()).subscribe(response => {
      this.bedCategoryList = response.Data.BillCategories;
      this.percentages = response.Data.Percentages;
      this.ruby = response.Data.Ruby;
      this.f.RegNo.enable(); 
      this.f.BedNo.enable(); 
    });
  }


  // Gets patient details
  getPatientDetails(searchBy: string = 'RegNo') {

    let regNo = this.f.RegNo.value;
    let bedNo = this.f.BedNo.value;

    if (searchBy === 'RegNo' && !this.commonService.isValidStringValue(regNo)) {
      return;
    }

    if (searchBy === 'BedNo' && !this.commonService.isValidStringValue(bedNo)) {
      return;
    }

    if (searchBy === 'RegNo' && regNo.length < 7) {
      this.commonService.openSnackBar("Admission number must be 7 digits long", "Ok");
      return;
    }



    let searchObj = { AdmissionNo: regNo, FetchType: 'T', BedNo: '', PatientType: "" };

    if (searchBy === 'BedNo') {
      searchObj = { AdmissionNo: '', FetchType: 'T', BedNo: bedNo, PatientType: "A" };
    }

    this.httpService.Post(urlConstant.Patient.GetPatient(), searchObj)
      .subscribe(response => {
        let patient = response.Data[0];
        this.getPatientFolio(patient);

      });
  }


  //gets patient folio detail
  getPatientFolio(patient: any) {
    if (isNullOrUndefined(patient) && !this.disableValidations) {
      this.commonService.displayPromptMessage("Patient details", "Patient is invalid or is discharged");
      this.f.RegNo.setValue('');
      this.f.BedNo.setValue('');
      return;
    }
    if (this.commonService.isValidStringValue(patient.AdmissionNo))
      // this.admissionNumberLookup.myControl.setValue(`(${patient.AdmissionNo}) ${patient.PatientName}`);
      //Get folio details, as there can be multile folios for same patient hence seperate api call
      this.httpService.Get(urlConstant.Patient.GetPatientFolioNumber(patient.AdmissionNo, this.getAllFolios)).subscribe(response => {
        this.FolioList = response.Data;
        if (this.displayAllFolio) this.FolioList.splice(0, 0, { Value: "All", Status: "O" });


        if (isNullOrUndefined(this.FolioList) || this.FolioList.length === 0) {
          this.commonService.displayPromptMessage("Patient details",
            "Patient has no active folio.Service posting cannot be continued").subscribe();
          this.clearPatientLookup();
          return;
        }

        this.setPatientDetail(patient);


      });
  }


  setPatientFormValue(patient: any) {
    this.getPatientFolio(patient);
  }

  // Set patient detail
  setPatientDetail(patient: any) {

    if (!this.commonService.isValidStringValue(patient.AdmissionNo)) {
      this.patientForm.reset();
      this.patientEmitter.emit({});
      return;
    }

    let folioNo = this.FolioList.length > 0 ? this.FolioList[0].Value : '';
    // folioNo = this.displayAllFolio ? 'A' : folioNo;

    let companyName = this.commonService.isValidStringValue(patient.CompanyCode) ? patient.CompanyCode + " " + patient.CompanyName : "";
    this.patientForm.patchValue({
      "RegNo": patient.AdmissionNo, "Title": patient.Title, "PatientName": patient.PatientName, "BedNo": patient.BedNo,
      "RoomNo": patient.WardNo, "FolioNo": folioNo, "CompanyName": companyName,
      "AdmitDate": patient.AdmissionDate, "AdmitTime": patient.AdmissionTime, "ApproveAmount": patient.ApproveAmount,
      "TPA": patient.TPA, "PatientCategory": (patient.PatientCatCode + " " + patient.PatientCategory),
      "BedCategory": patient.CategoryCode, "DischargeDate": patient.DischargeDate, "DischargeTime": patient.DischargeTime,
      "PatientCategoryCode": patient.PatientCatCode, "CategorySource": patient.PatientCatSrc,
      "BillNo": patient.BillNo, "BillDate": patient.BillDate, "FolioNumberForBill": patient.FolioNumberForBill,
      "InsCompanyName": (patient.InsCompCode + " " + patient.InsCompName), "InsCompCode": patient.InsCompCode, "Address": patient.Address,
      "Responsible": patient.Responsible,
      "Tstatus": patient.Tstatus, "RefComp": patient.RefComp, "ReferredCompany": patient.ReferredCompany, "Status": patient.Status
    });

    this.sourceList.myControl.setValue(patient.PatientCatCode);

    // disable patient category dropdown if permission is not present - Added Newly, not existing in JEEVA 
    if (!this.dataService.checkAccessRights('4013')) this.sourceList.myControl.disable();


    let patientData = this.patientForm.getRawValue();
    patientData.DoctorName = patient.TreatingDoctorName;
    patientData.MobileNo = patient.MobileNo;
    patientData.Percentages = this.percentages;
    patientData.ReserveAmount = patient.ReserveAmount;
    patientData.BillAmount = patient.BillAmount;
    patientData.Pexpdate = patient.Pexpdate;
    patientData.CompanyCode = patient.CompanyCode;
    patientData.FolioNo = patientData.FolioNo === 'All' ? '' : patientData.FolioNo;
    patientData.Ruby = this.ruby;

    setTimeout(() => {
      if (patient.CategoryCode != null && patient.CategoryCode !== '') {
        patientData.BedCategoryName = this.bedCategoryList.filter(b => b.CategoryCode === patient.CategoryCode)[0].Name;
        patientData.ReferralDoctorName = patient.ReferralDoctorName;
      }
      this.patientEmitter.emit(patientData);

    }, 500);

    this.billDetailsList = [];
  }

  //Get mediclaim details, as this applied for only mediclaim hence seperate api call
  getMediclaimDetail(patient: any) {
    this.httpService.Get(urlConstant.Patient.GetPatientFolioNumber(this.f.RegNo.value, this.getAllFolios))
      .subscribe(response => {
        patient.ApproveAmount = response.Data[0].BaseApprovedAmount;
        patient.TPA = response.Data[0].CompanyName;
        this.setPatientDetail(patient);
      });
  }


  // emits folio number on change
  emitFolio(event: any) {
    if (!event.isUserInput)
      return;

    let folioNo = event.source.value;
    folioNo = (folioNo === 'All' ? '' : folioNo);
    this.folioEmmitter.emit(folioNo);
  }

  // emits bedCategory on change
  emitBedCategory(event: any) {
    if (!event.isUserInput)
      return;

    this.bedCategoryEmmitter.emit(event.source.value);

  }


  // vaidate key press
  validateKey(event) {
    if (event.key === "Backspace"
      && this.commonService.isValidStringValue(this.f.PatientName.value)) {
      this.clearPatientLookup();
      this.patientEmitter.emit({});
    }
  }


  // open patient help
  openPatientHelp() {
    const dialogRef = this.dialog.open(PatientEnquiryComponent, {
      disableClose: true,
      maxHeight: '600px',

    });

    dialogRef.componentInstance.isPopup = true;

    dialogRef.afterClosed().subscribe(dialogResult => {

      if (!isNullOrUndefined(dialogResult)) {
        this.f.RegNo.setValue(dialogResult.AdmissionNumber);
        this.getPatientDetails('RegNo');
      }
    });
    this.fromPatHelp = true;
  }


  //open patient folio
  openPatientFolio() {
    const dialogRef = this.dialog.open(PatientFolioComponent, {
      maxHeight: '650px',
      disableClose: true,
      minWidth: '88vw',
    });

    dialogRef.componentInstance.isPopup = true;
    dialogRef.componentInstance.regNo = this.f.RegNo.value;

    dialogRef.afterClosed().subscribe();
  }

  //open patient folio
  openDoctorDetail() {
    this.activateDoctorList.emit(this.f.RegNo.value);
  }


  //clear patient lookup
  clearPatientLookup() {
    this.patientForm.reset();
    this.sourceList.myControl.setValue("");
  }



  checkVisibility(itemName: string) {
    return !(this.hideItems.indexOf(itemName) > -1);
  }


  checkDisablity(itemName: string) {
    return (this.disabledItems.indexOf(itemName) > -1);
  }

  // use this for setting patient details from other components

  setPatientDetailByRegNo(regNo: string, disableActiveControls: boolean = true) {
    this.f.RegNo.setValue(regNo);
    
    this.getPatientDetails();
    if (disableActiveControls) this.patientForm.disable();
  }


  // set patient folio no  by external component
  setPatientFolioNo(folioNo: string) {
    if (this.commonService.isValidStringValue(folioNo))
      this.f.FolioNo.setValue(folioNo);
  }

  setFocus() {
    document.getElementById("regNoField").focus();
  }
  // Added the click events as per feedback point
  // Bhushan T
  // Date:- 9 Nov 2020
  openFinalBill() {
    this.setLocalStorageRegNo();
    this.router.navigateByUrl('billing/new-bill/FN');
  }

  openInterimBill() {
    this.setLocalStorageRegNo();
    this.router.navigateByUrl('billing/new-bill/IN');
  }

  setLocalStorageRegNo() {
    if (this.commonService.isValidStringValue(this.f.RegNo.value)) {
      localStorage.setItem("SPRegNo", this.f.RegNo.value);
    }
  }

  getPatientDataByLS() {
    let regNo = localStorage.getItem("SPRegNo");

    if (!this.commonService.isValidStringValue(regNo)) {
      regNo = localStorage.getItem("BillingRegNo");
    }

    if (this.commonService.isValidStringValue(regNo)) {
      this.setPatientDetailByRegNo(regNo, false);
      localStorage.removeItem("SPRegNo");
      localStorage.removeItem("BillingRegNo");
    }
  }
}
