import { Component, OnInit, ViewChild } from '@angular/core';
import 'rxjs/add/operator/filter';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-new-cghs-drug',
  templateUrl: './new-cghs-drug.component.html',
  styleUrls: ['./new-cghs-drug.component.css'],
  host: { 'class': 'section__main' }
})
export class NewCGHSDrugComponent implements OnInit {
  minTime: string = "00:00";

  drugDetailsList: MatTableDataSource<any> = new MatTableDataSource([]);
  CGHSAdjustmentForm: FormGroup;
  @ViewChild('patientDetailComponent') patDetailsComp;
  displayedColumns = ["Action", "ItemCode", "ItemName", "DrugQuantity", "SellingPrice", "SellingAmount", "ExpiryDate"]
  searchObj: {};
  DrugList: any[];
  list: any[] = [];
  data: any;
  rowDetails: any;
  selectedIndexRow: any;
  constructor(private fb: FormBuilder, private commonService: CommonService, public loader: LoaderService,
    private dataService: DataTranferService, private httpService: HttpService) {
  }

  ngOnInit(): void {
    this.initializeForm();
  }



  onSubmit() {
    const input = this.getCGHSInput();
    this.httpService.Post(urlConstant.DrugServiceDetails.SavePatientCghsDrugDetails, input)
      .subscribe(response => {
        let patient = response.Data[0];
        console.log("patient", patient);
      });
  }
  get f() {
    return this.CGHSAdjustmentForm.controls;
  }

  initializeForm() {
    this.CGHSAdjustmentForm = this.fb.group({
      RegNo: [],
      PatientCategoryCode: [],
      BedCategoryCode: [],
      FolioNo: [],
      CompanyCode: [],
      DrugDate: [{ value: new Date(), disabled: true }],
      DrugTime: [{ value: this.getCurrentTime(), disabled: true }],
      DrugNo: [],
      checkExpiryDate: [false],
      ChargeCode: [{ value: '17', disabled: true }],
      ServiceCode: [{ value: '99999', disabled: true }],
      DrugTotal: [],
      UserId: [],
      VoucherNo: [],
      ItemCode: [],
      ItemName: [{ value: '', disabled: true }],
      DrugQuantity: [''],
      SellingPrice: [],
      SellingAmount: [],
      ExpiryDate: [{ value: '', disabled: true }],
      BatchNo: [{ value: '', disabled: true }],
    });
  }

  getCurrentTime() {
    let currentDate = new Date();
    let currentHours = currentDate.getHours();
    let currentMinutes = currentDate.getMinutes();
    return (currentHours < 10 ? ('0' + currentHours) : currentHours) + ':' + (currentMinutes < 10 ? ('0' + currentMinutes) : currentMinutes);
  }

  getPatientDetails(event) {
    console.log("event", event);
    this.f.RegNo.setValue(event.RegNo);
    this.f.BedCategoryCode.setValue(event.BedNo);
    this.f.PatientCategoryCode.setValue(event.CategoryCode);
    this.f.FolioNo.setValue(event.FolioNo);
  }

  getCGHSInput() {
    return {
      RegNo: this.f.RegNo.value,
      // DrugDate :
      // DrugTime 
      PatientCategoryCode: this.f.PatientCategoryCode.value,
      //BedCategoryCode: this.f.BedCategoryCode.value,
      // ChargeCode 
      // ServiceCode 
      // DrugTotal 
      FolioNo: this.f.FolioNo.value,
      // UserId 
      // VoucherNo 
      // CompanyCode
      DrugList: this.drugDetailsList.data
    }
  }
  addDrugDetails() {
    this.DrugList = [
      {
        ItemCode: this.f.ItemCode.value,
        ItemName: this.f.ItemName.value,
        DrugQuantity: this.f.DrugQuantity.value,
        Sellinantity: this.f.DrugQuantity.value,
        SellingPrice: this.f.SellingPrice.value,
        SellingAmount: this.f.SellingAmount.value,
        ExpiryDate: this.f.ExpiryDate.value,
        BatchNo: this.f.BatchNo.value,
      }
    ]

    for (var i = 0; i < this.DrugList.length; i++) {
      this.list.push(this.DrugList[i]);
    }

    this.drugDetailsList = new MatTableDataSource(this.list);
  }

  setDrugDetails(drugdata) {
    console.log("drugData", drugdata)
    if (drugdata) {
      this.f.ItemName.setValue(drugdata.ItemName);
      this.f.BatchNo.setValue(drugdata.BatchNo);
      this.f.ExpiryDate.setValue(drugdata.ExpiryDate);
      this.f.SellingAmount.setValue(drugdata.SellingAmount);
      this.f.SellingPrice.setValue(drugdata.SellingPrice);
      this.f.DrugQuantity.setValue(drugdata.DrugQuantity);
    }
  }

  getItemDetails() {
    let itemCode = this.f.ItemCode.value;
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.DrugServiceDetails.GetItemDetailsByCode(itemCode))
      .subscribe(response => {
        if (response.Status == 200 && response.Data.length > 0) {
          let drugData = response.Data[0];
          this.setDrugDetails(drugData);
          this.loader.spin.next(false);
        }
        else {
          this.loader.spin.next(false);
          return;
        }
      });
  }

  highlightSelectedRow(index: any, rowDetails: any) {
    this.rowDetails = rowDetails;
    if (this.selectedIndexRow == index) {
      this.selectedIndexRow = -1;
    }
    else {
      this.selectedIndexRow = index;
    }
  }

  removeDrugRow(index) {
    this.list.splice(index, 1);
    this.drugDetailsList = new MatTableDataSource(this.list);
  }

  clearSearch() {
    this.initializeForm();
    this.patDetailsComp.patientForm.reset();
  }

  checkExpiryDate(checkValue) {
    if (checkValue)
      this.f.ExpiryDate.enable();
    else
      this.f.ExpiryDate.disable();
  }
}