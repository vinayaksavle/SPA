
import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatDialogRef, MatTableDataSource, MatSort } from '@angular/material';
import { HttpService } from 'src/app/services/http.service';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { isNullOrUndefined, isNumber } from 'util';
import { urlConstant } from 'src/app/constants/urlConstants';

@Component({
  selector: 'app-ppn-package-help-modal',
  templateUrl: './ppn-package-help-modal.component.html',
  styleUrls: ['./ppn-package-help-modal.component.css']
})
export class PPNPackageHelpComponent implements OnInit, AfterViewInit {
  packageName: string;
  PPNPackageForm: FormGroup;
  displayedColumnsList = ["PackageCode", "PackageName"];
  packageList: any;
  constructor(public dialogRef: MatDialogRef<any>,
    private fb: FormBuilder, public http: HttpService, public common: CommonService) {
    this.packageList = new MatTableDataSource();

  }
  ngAfterViewInit(): void {
    if (this.common.isValidStringValue(this.packageName)) {
      this.PPNPackageForm.controls["PPNItem"].setValue(this.packageName);
      this.SearchPPN();
    }

  }

  ngOnInit() {
    this.initForm()
  }

  initForm() {
    this.PPNPackageForm = this.fb.group({
      PPNItem: ['']
    })
  }

  //close dialog box
  SearchPPN() {
    console.log(this.PPNPackageForm.value);
    this.http.Get(urlConstant.Billing.GetPPNPackage(this.PPNPackageForm.value.PPNItem))
      .subscribe(response => {
        console.log(response);
        if (response.Status === 200) {
          this.packageList = new MatTableDataSource(response.Data)
        }
        else {
          this.packageList = new MatTableDataSource([]);
        }

      });
  }

  //close dialog box
  clearForm() {
    this.PPNPackageForm.reset();
  }

  //close dialog box
  closeDialog() {
    this.dialogRef.close(true);
  }

 
  // double click event of row 
  doubleClick(event, rowData) {
    this.dialogRef.close({ data: rowData });

  }
}