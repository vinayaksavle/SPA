/// <reference types="dwt"/>

import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-document-scan-dialog',
  templateUrl: './document-scan-dialog.component.html',
  styleUrls: ['./document-scan-dialog.component.css']
})
export class DocumentScanDialogComponent implements OnInit {

  constructor(public dialogRef: MatDialogRef<DocumentScanDialogComponent>, @Inject(MAT_DIALOG_DATA) public imageData: any) {
    dialogRef.disableClose = true;
   }
  DWObject:WebTwain;
  ngOnInit() {
      Dynamsoft.WebTwainEnv.Load();
      Dynamsoft.WebTwainEnv.RegisterEvent("OnWebTwainReady",() => { this.DWObject = Dynamsoft.WebTwainEnv.GetWebTwain('dwtcontrolContainer');});

    
  }
  AcquireImage() :void {
     if(this.DWObject.SelectSource()){
       this.DWObject.OpenSource();
       this.DWObject.AcquireImage({}, () => {
        this.DWObject.CloseSource();         
        this.DWObject.SelectedImagesCount = 1;
        this.DWObject.SetSelectedImageIndex(0,0);
        this.DWObject.GetSelectedImagesSize(EnumDWT_ImageType.IT_JPG);
        this.imageData = this.DWObject.SaveSelectedImagesToBase64Binary();
      }, () => this.DWObject.CloseSource());
     }
  }
  closeDialog(): void {
    this.dialogRef.close();
  }

}
