import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { messageConstant } from 'src/app/constants/messageConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';
import { MatTableDataSource } from '@angular/material';
import { pipe } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { FromDateToDateComponent } from 'from-date-to-date';
import { Services } from '@angular/core/src/view';


@Component({
  selector: 'app-package-posting',
  templateUrl: './package-posting.component.html',
  styleUrls: ['./package-posting.component.css'],
  host: { 'class': 'section__main' },
})
export class PackagePostingComponent implements OnInit {
  @ViewChild('fromDateToDate') fromDateToDate: FromDateToDateComponent;
  PackageFormArray: FormArray;
  packageControl = new FormControl();
  packagePostingForm: FormGroup;
  minTime: string = "00:00";
  isSaveDisabled: boolean = false;
  isSearchDisabled: boolean = false;
  packageServiceDtls: MatTableDataSource<any> = new MatTableDataSource();
  filterPackageList: MatTableDataSource<any> = new MatTableDataSource();
  summaryData: MatTableDataSource<any> = new MatTableDataSource();
  packageServiceName = 'Service Name';
  displayedColumnsList: any = ['Component', 'DepartmentCode', 'ServiceName', 'Amount', 'Package Amount', 'Diff Amount', 'Remarks'];
  filterdisplayedColumnsList: any = ['Dept Code', 'Service Code', 'Service Name', 'Service Amount', 'Post Service Date', 'Remarks']
  packageList: any = [];
  packageData: any = {};
  pkgInput: any = {};
  total: any = 0;
  totalActual: any = 0;
  totalPackageAmount: any = 0;
  totalDifference: any = 0;

  hiddenItems: any = ['FinalButton', 'InterimButton', 'DoctorButton', 'ApprovedAmount',
    'TPA', 'DischDateTime', 'InsCompanyName', 'Address'];

  // @ViewChild('lookup') packageLookup: ElementRef;
  patientDetail: any = {};
  tempSummaryData: any[];
  isNotIncome: boolean = false;
  toggleValue: boolean = false;
  constructor(
    public fb: FormBuilder,
    private commonService: CommonService,
    private httpService: HttpService,
    private loader: LoaderService,
  ) { }

  ngOnInit() {
    this.initForm();

  }

  initForm() {
    this.packagePostingForm = this.fb.group({
      Id: [''],
      RegNo: ['', Validators.required],
      FolioNo: [''],
      PackageCode: [''],
      FromDate: [new Date(), Validators.required],
      ToDate: [new Date(), Validators.required],
      FromTime: [this.getCurrentTime()],
      ToTime: [this.getCurrentTime()],
      PatientCategory: [''],
      BedCategory: [''],
      PackageDept: [''],
      PackageService: [''],
      VoucherNo: [''],
      Remarks: [''],
      UserId: [localStorage.getItem("UserName")],
      Amount: [''],
      TotalAmount: [''],
      ApplyDate: [false],
      Packages: this.fb.array([]),
      PostType: ['PE'],
      AddNegativeAmount: [true]
    });

    this.packageControl.disable();
    this.addPackages();
    this.enableDate();
  }

  // method for getting changed toggle value.
  addNegativeAmount(event, element) {
    // this.calculateDifference()
    // this.filterSummaryData();
    this.getPackageServiceDtls();
  }

  addPackages() {

    this.packagesArray.push(this.fb.group({
      packageControl: [''],
      Department: [{ value: '', disabled: true }],
      Service: [{ value: '', disabled: true }],
      Amount: [{ value: '', disabled: true }],
    }));

    this.initPackageLookup();
  }

  removePackage(index: number) {
    this.packagesArray.removeAt(index);
    if (index === 0) {
      this.addPackages();
    }
  }


  get f() {
    return this.packagePostingForm.controls;
  }
  get packagesArray(): FormArray {
    return this.packagePostingForm.controls.Packages as FormArray;
  }

  getCurrentTime() {
    let currentDate = new Date();
    let currentHours = currentDate.getHours();
    let currentMinutes = currentDate.getMinutes();
    return (currentHours < 10 ? ('0' + currentHours) : currentHours) + ':' + (currentMinutes < 10 ? ('0' + currentMinutes) : currentMinutes);
  }

  // sets patient details on event emit
  setPatientDetail(patient: any) {

    this.patientDetail = patient;

    this.packagePostingForm.patchValue({
      "RegNo": patient.RegNo, "FolioNo": patient.FolioNo, "PatientCategory": patient.PatientCategoryCode, "BedCategory": patient.BedCategory
    });

    this.packageControl.setValue("");
    if (!this.commonService.isValidStringValue(patient.RegNo)) {
      this.packageControl.disable();
      this.initForm();
      this.packageServiceDtls = new MatTableDataSource([]);
      this.filterPackageList = new MatTableDataSource([]);
      this.isSaveDisabled = false;
      this.isSearchDisabled = false;
      this.totalActual = "0.00";
      this.totalPackageAmount = "0.00";
      this.totalDifference = "0.00";

      this.total = "0.00";
    }
    else {
      this.packageControl.enable();
      // if (patient.RegNo === "1828811") {
      //   this.setDummyData();
      // }
      // else {
      //   this.getPackagePostedDetails();

      // }

      this.getPackagePostedDetails();
      // this.packageLookup.nativeElement.focus()
    }

    //If package already posted then fetch posted details

  }
  setDummyData() {

    this.addPackages();
    this.addPackages();

    let packageItem = [{
      packageControl: "PPNG21 RESECTION AND ANASTOMOSIS OF SMALL INTESTINE",
      Department: "PACKAGE DEPARTMENT",
      Service: "RESECTION AND ANASTOMOSIS",
      Amount: "80000",
    },
    {
      packageControl: "PPNG07A CHOLECYSTECTOMY - LAP",
      Department: "PACKAGE DEPARTMENT",
      Service: "CHOLECYSTECTOMY",
      Amount: "71000",
    },
    {
      packageControl: "PPNG06B APPENDECTOMY - OPEN",
      Department: "PACKAGE DEPARTMENT",
      Service: "APPENDECTOMY",
      Amount: "50000",
    }];
    this.packagesArray.setValue(packageItem)

    let summarydata = [{
      "ComponentId": 0, "DepartmentCode": '100', "ServiceCode": '1',
      "DeptName": 'PACKAGE DEPARTMENT', "ServiceName": 'RESECTION AND ANASTOMOSIS',
      "Cost": null, "PackageAmount": '80000.00', "ServiceDate": this.commonService.convertDateToString(new Date()),
      "Type": "PS", "Remarks": "PACKAGE SERVICE", "ServslNo": null
    },
    {
      "ComponentId": 0, "DepartmentCode": '100', "ServiceCode": '2',
      "DeptName": 'PACKAGE DEPARTMENT', "ServiceName": 'CHOLECYSTECTOMY',
      "Cost": null, "PackageAmount": '35500.00', "ServiceDate": this.commonService.convertDateToString(new Date()),
      "Type": "PS", "Remarks": "PACKAGE SERVICE", "ServslNo": null
    },
    {
      "ComponentId": 0, "DepartmentCode": '100', "ServiceCode": '3',
      "DeptName": 'PACKAGE DEPARTMENT', "ServiceName": 'APPENDECTOMY',
      "Cost": null, "PackageAmount": '12500.00', "ServiceDate": this.commonService.convertDateToString(new Date()),
      "Type": "PS", "Remarks": "PACKAGE SERVICE", "ServslNo": null
    }]
    this.filterPackageList = new MatTableDataSource(summarydata);
    this.total = "128000.00";
    this.f.VoucherNo.setValue('01');
    this.f.Remarks.setValue('MULTIPLE PACKAGES');
    this.isSaveDisabled = true;
    this.disableAllFields();
  }

  // sets from date and to date from library element
  setDate(event) {
    if (!isNullOrUndefined(event)) {
      this.f.FromDate.setValue(new Date(event.FromDate.value).toLocaleDateString());
      this.f.ToDate.setValue(new Date(event.ToDate.value).toLocaleDateString());
    }
  }

  setFromTime(selectedTime: string) {
    let time = this.commonService.convertTo24HrFormat(selectedTime);
    let formattedTime = time.replace(':', '').replace(':', '');
    this.minTime = "00:00";

    let hours = parseInt(formattedTime.substring(0, 2));
    let mins = parseInt(formattedTime.substring(2, 4));

    let newTime = (hours < 10 ? ('0' + hours) : hours) + ':' + (mins < 10 ? ('0' + mins) : mins);
    this.f.FromTime.setValue(newTime);
    this.minTime = newTime;
  }

  setToTime(selectedTime: string) {
    let time = this.commonService.convertTo24HrFormat(selectedTime);
    let formattedTime = time.replace(':', '').replace(':', '');
    this.minTime = "00:00";

    let hours = parseInt(formattedTime.substring(0, 2));
    let mins = parseInt(formattedTime.substring(2, 4));

    let newTime = (hours < 10 ? ('0' + hours) : hours) + ':' + (mins < 10 ? ('0' + mins) : mins);
    this.f.ToTime.setValue(newTime);
    this.minTime = newTime;
  }

  getPackagePostedDetails() {
    this.httpService.Get(urlConstant.PackagePosting.GetPackagePostedDtls(this.f.RegNo.value, this.f.FolioNo.value)).subscribe(response => {
      if (response.Data.BillPackageHD.length > 0 && response.Data.BillPackageDT.length > 0) {

        var headerDetail = response.Data.BillPackageHD[0];
        this.f.TotalAmount.setValue(headerDetail.TotalAmount);
        this.total = this.f.TotalAmount.value;
        this.setPackageValue(headerDetail);
        this.f.VoucherNo.setValue(headerDetail.VoucherNo);
        this.f.Remarks.setValue(headerDetail.Remarks);
        this.f.PostType.setValue(headerDetail.PostType);
        this.f.ApplyDate.setValue(headerDetail.ApplyDate);
        this.f.AddNegativeAmount.setValue(headerDetail.AddNegativeAmount);
        this.fromDateToDate.FromDate.setValue(headerDetail.FromDate);
        this.fromDateToDate.ToDate.setValue(headerDetail.ToDate);
        this.packageServiceDtls = new MatTableDataSource(response.Data.BillPackageDT.filter(x => x.IsSummary === 0));
        this.filterPackageList = new MatTableDataSource(response.Data.BillPackageDT.filter(x => x.IsSummary != 0));

        this.totalActual = this.packageServiceDtls.data.map(s => parseFloat(s.Amount)).reduce((a, b) => a + b, 0).toString();
        this.totalPackageAmount = this.packageServiceDtls.data.map(s => parseFloat(s.PackageAmount)).reduce((a, b) => a + b, 0).toString();
        this.calculateDifference();

        this.isNotIncome = isNullOrUndefined(this.filterPackageList.data.filter(s => s.Type === "PI")[0]);


        // disable all fields if data already posted 
        this.disableAllFields();
      }
    })
  }

  calculateDifference() {
    if (this.f.AddNegativeAmount.value)
      this.totalDifference = this.packageServiceDtls.data.map(s => parseFloat(s.Difference)).reduce((a, b) => a + b, 0).toString();
    else
      this.totalDifference = this.packageServiceDtls.data.filter(s => parseFloat(s.Difference) > 0).map(s => parseFloat(s.Difference)).reduce((a, b) => a + b, 0).toString();
  }

  disableAllFields() {
    this.packageControl.disable();
    this.fromDateToDate.FromDate.disable();
    this.fromDateToDate.ToDate.disable();
    this.packagePostingForm.disable();
    this.isSaveDisabled = true;
    this.isSearchDisabled = true;
  }

  getPackageServiceDtls() {

    const packageServInput = this.packagePostingForm.getRawValue();

    if (!this.commonService.isValidStringValue(packageServInput.Packages[0].packageControl)) {
      this.commonService.openSnackBar("Select a package first", "Ok");
      return;
    }

    this.loader.spin.next(true);
    this.httpService.Post(urlConstant.PackagePosting.GetPackageServiceDtls(), packageServInput).subscribe(response => {
      if (response.Status === 200) {

        if (!isNullOrUndefined(response.Data.packageDetail) && response.Data.packageDetail.length > 0) {
          this.packageServiceDtls = new MatTableDataSource(response.Data.packageDetail);

          this.totalActual = this.packageServiceDtls.data.map(s => parseFloat(s.Amount)).reduce((a, b) => a + b, 0).toString();
          this.totalPackageAmount = this.packageServiceDtls.data.map(s => parseFloat(s.PackageAmount)).reduce((a, b) => a + b, 0).toString();
          this.calculateDifference();

          let summaryData = this.summaryData.data;
          summaryData = summaryData.concat(response.Data.summary);

          this.isNotIncome = isNullOrUndefined(response.Data.summary.filter(s => s.Type === "PI")[0]);
          // let isAny =  isNullOrUndefined(response.Data.summary.filter(s => s.Type === "PL" || s.Type === "PE")[0]);
          if (!this.isNotIncome) {
            this.f.PostType.setValue("");
            this.filterPackageList = new MatTableDataSource(summaryData);
          }
          else {
            this.tempSummaryData = summaryData;
            this.filterSummaryData();
          }

          let totalAmount = (Math.round(this.filterPackageList.data.filter(s => ["PI"].indexOf(s.Type) === -1)
            .map(s => parseFloat(s.PackageAmount)).reduce((a, b) => a + b, 0) / 10) * 10).toString();
          this.total = this.commonService.formatAmount(totalAmount);


        }
        else {
          this.commonService.displayPromptMessage("Package Posting", "No services to post, please change the date and time !");
          this.packageServiceDtls = new MatTableDataSource([]);
          this.filterPackageList = new MatTableDataSource([]);
        }
      }
      else {
        this.packageServiceDtls = new MatTableDataSource([]);
        this.filterPackageList = new MatTableDataSource([]);
      }
      this.loader.spin.next(false);
    })
  }


  validateForm() {
    let isValid = true;

    if (!this.commonService.isValidStringValue(this.f.RegNo.value)) {
      this.commonService.openSnackBar("No patient is selected. Please select a patient!", "Ok");
      return false;
    }

    if (this.packageServiceDtls.data.length === 0) {
      this.commonService.openSnackBar("No services to post in inclusion list", "Ok");
      return false;
    }

    if (this.filterPackageList.data.length === 0) {
      this.commonService.openSnackBar("No services to post in summary list", "Ok");
      return false;
    }


    if (!this.commonService.isValidStringValue(this.f.VoucherNo.value)) {
      this.commonService.openSnackBar("Voucher number is mandatory", "Ok");
      return false;
    }

    if (this.f.VoucherNo.value.length > 2) {
      this.commonService.openSnackBar("Voucher number is cannot be greater than 2 digits", "Ok");
      return false;
    }

    return isValid;
  }


  saveDetails() {

    if (!this.validateForm()) return;

    this.commonService.confirmAction("Package Posting", "Do you want to save package details ?")
      .subscribe(response => {
        if (response) {
          this.loader.spin.next(true);
          // this.pkgInput = this.packageServiceDtls.data[0];
          this.pkgInput = this.packagePostingForm.getRawValue();
          this.pkgInput.TotalAmount = this.total;
          this.pkgInput.packageServiceDtls = this.packageServiceDtls.data;
          this.pkgInput.summary = this.filterPackageList.data;


          this.httpService.Post(urlConstant.PackagePosting.SavePackagePosting(), this.pkgInput).subscribe(response => {
            if (response.Data) {
              this.commonService.displayPromptMessage("Package Posting", "Package posted successfully.");
              this.print(false);
            }
            else {
              this.commonService.displayPromptMessage("Package Posting", "Error while Package Posting.");
            }
            this.loader.spin.next(false);
          })
        }

      });

  }

  /**
   * method for reset button click
   */
  resetAll() {
    this.commonService.confirmAction("Package Posting", "Do you want to reset the page ?")
      .subscribe(response => {
        if (response) {
          window.location.reload();
        }

      });

  }


  initPackageLookup() {
    const waitTime = pipe(debounceTime(200));
    const distinct = pipe(distinctUntilChanged());
    this.packagesArray.controls[0].get("packageControl").valueChanges
      .pipe(waitTime)
      .pipe(distinct)
      .pipe(
        switchMap(text =>
          !isNullOrUndefined(text) && text.toString().trim() !== ''
            ? this.httpService.Get(urlConstant.PackagePosting.GetPackages(text.toString()))
            : []
        )
      )
      .subscribe(result => {
        if (result.Status === 200) {
          this.packageList = result.Data;
        } else {
          return;
        }
      });
  }


  setValueOnTab() {
    setTimeout(() => {
      let firstValue = this.packageList[0];
      if (!isNullOrUndefined(firstValue)) {
        let value = `(${firstValue.PackageCode}) ${firstValue.PackageName}`;
        this.packageControl.setValue(value);
        this.setPackageValue(firstValue);
      }
    }, 500);

  }

  clearLookupSearch(index: number) {

    this.commonService.confirmAction("Package Posting", "Removing the package will reset the table data.Do you want to continue?")
      .subscribe(Response => {
        if (Response) {
          this.packagesArray.controls[index].reset();
          this.packageControl.setValue("");
          this.f.PackageCode.setValue("");
          this.packageData = {};
          this.total = "0.00";
          this.packageServiceDtls = new MatTableDataSource([]);
          this.filterPackageList = new MatTableDataSource([]);

        }

      })
  }

  setPackageValue(item: any) {

    let param = { "PackageCode": item.PackageCode, "BedCategory": this.f.BedCategory.value, "PatientCategory": this.f.PatientCategory.value };

    this.httpService.Post(urlConstant.PackagePosting.GetPackagesDetail(), param)
      .subscribe(Response => {

        this.packageData = Response.Data[0];

        if (!this.commonService.isValidStringValue(this.packageData.PackageAmount)) {
          this.commonService.displayPromptMessage("Package Posting", "Package amount not set in master !");
          return;
        }


        this.f.PackageCode.setValue(item.PackageCode);
        this.f.Id.setValue(item.Id);
        let packageItem = {
          packageControl: item.PackageCode + " " + item.PackageName,
          Department: this.packageData.PackageDept,
          Service: this.packageData.PackageService,
          Amount: this.packageData.PackageAmount,
        };
        this.packagesArray.setValue([packageItem])

        let summarydata = [{
          "ComponentId": 0,"ComponentName": "", "DepartmentCode": this.packageData.PkgDeptCode, "ServiceCode": this.packageData.PkgServCode,
          "DeptName": this.packageData.PackageDept, "ServiceName": this.packageData.PackageService,
          "Cost": null, "PackageAmount": this.packageData.PackageAmount, "ServiceDate": this.commonService.convertDateToString(new Date()),
          "Type": "PS", "Remarks": "PACKAGE SERVICE", "ServslNo": null
        }]
        this.f.Amount.setValue(this.packageData.PackageAmount);
        this.summaryData = new MatTableDataSource(summarydata);
      })

  }

  print(isManual: boolean = true, isMain: boolean = true) {

    let param = this.packagePostingForm.getRawValue();

    for (var k in this.patientDetail) param[k] = this.patientDetail[k];

    param["IsMain"] = isMain;

    if (isMain) {
      param["Services"] = this.f.PostType.value === "PL" ? this.filterPackageList.data.filter(s => s.Type !== "PE") : this.filterPackageList.data;
    }
    else
      param["InclusionServices"] = this.packageServiceDtls.data;

    if (isManual) {
      if (!this.validateForm()) return;
    }

    this.loader.spin.next(true);

    this.httpService.Post(urlConstant.PackagePosting.PrintPackage(), param)
      .subscribe(response => {
        if (!isManual) window.location.reload();
        this.loader.spin.next(false);
        this.httpService.openFile(response.Data);
      });

  }

  deletePackage() {
    this.loader.spin.next(true);

    this.httpService.Get(urlConstant.PackagePosting.DeletePackage(this.f.RegNo.value))
      .subscribe(response => {
        this.loader.spin.next(false);
        window.location.reload();
      });
  }

  enableDate() {
    if (this.f.ApplyDate.value) {
      this.fromDateToDate.FromDate.enable();
      this.fromDateToDate.ToDate.enable();
      this.f.FromDate.enable();
      this.f.ToDate.enable();
    }
    else {
      this.fromDateToDate.FromDate.disable();
      this.fromDateToDate.ToDate.disable();
      this.f.FromDate.disable();
      this.f.ToDate.disable();
    }
  }


  filterSummaryData(isManual: boolean = false): any {
    let tempServices: any = [];
    let services: any = [];
    this.tempSummaryData.forEach(s => {
      let service = {
        "ComponentId": s.ComponentId,"ComponentName": s.ComponentName, "DepartmentCode": s.DepartmentCode, "ServiceCode": s.ServiceCode,
        "DepartmentName": s.DepartmentName, "ServiceName": s.ServiceName,
        "Cost": null, "PackageAmount": s.PackageAmount,
        "ServiceDate": this.commonService.convertDateToString(new Date()),
        "Type": s.Type, "Remarks": s.Remarks, "ServslNo": null
      };
      tempServices.push(service);
    });

    services = tempServices.filter(s => s.Type !== "PE");
    let packageExtraData = tempServices.filter(s => s.Type === "PE");

    if (!this.f.AddNegativeAmount.value && this.f.PostType.value !== "PL") {
      for (var i = 0; i < tempServices.length; i++) {
        let el = tempServices[i];
        let counter = 0;
        if (el.Type === "PE") {
          el.DepartmentCode =this.packageData.PkgDeptCode;
          el.ServiceCode = this.packageData.PkgServCode;
          el.ServiceName = el.ComponentName+" - PE";
          services.splice(1 + counter, 0, el);
          counter++;
        }

      }
    }
    else {
      
      let extraAmount = (Math.round(packageExtraData.map(s => parseFloat(s.PackageAmount)).reduce((a, b) => a + b, 0) / 10) * 10).toString();
      if (packageExtraData.length > 0) {
        let packageExtraService = {
          "ComponentId": 0,"ComponentName":"", "DepartmentCode": this.packageData.PkgDeptCode, "ServiceCode": this.packageData.PkgServCode,
          "DepartmentName": this.packageData.PackageDept, "ServiceName": this.packageData.PackageService + " - PE ",
          "Cost": null, "PackageAmount": extraAmount,
          "ServiceDate": this.commonService.convertDateToString(new Date()),
          "Type": "PE", "Remarks": "PACKAGE EXTRA", "ServslNo": null
        };

        services.splice(1, 0, packageExtraService);
      }

      if (this.f.PostType.value === "PL") {

        for (var i = 0; i < tempServices.length; i++) {
          let el = tempServices[i];
          let counter = 0;
          if (el.Type === "PE") {
            el.Remarks = "PACKAGE LOSS";
            el.Type = "PL";
            el.PackageAmount = "-" + el.PackageAmount.trim();
            services.splice(2 + counter, 0, el);
            counter++;
          }

        }

      }
    }

    this.filterPackageList = new MatTableDataSource(services);

    if (isManual) {
      let totalAmount = (Math.round(this.filterPackageList.data.filter(s => ["PI"].indexOf(s.Type) === -1)
        .map(s => parseFloat(s.PackageAmount)).reduce((a, b) => a + b, 0) / 10) * 10).toString();
      this.total = this.commonService.formatAmount(totalAmount);
    }



  }
}