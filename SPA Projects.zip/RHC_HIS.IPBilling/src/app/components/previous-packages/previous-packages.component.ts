import { Component, OnInit, ViewChild } from "@angular/core";
import { MatDialogRef, MatTableDataSource, MatSort } from '@angular/material';
import { LoaderService } from 'src/app/services/loader.service';
import { HttpService } from 'src/app/services/http.service';
import { PackageMasterListModel } from 'src/app/models/ppn-package-master.model';
import { urlConstant } from 'src/app/constants/urlConstants';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';

@Component({
    selector: 'app-previous-packages',
    templateUrl: './previous-packages.component.html',
    styleUrls: ['./previous-packages.component.css']
})

export class PreviousPackagesComponent implements OnInit {
    @ViewChild(MatSort) sort: MatSort;
    isPopup: boolean = false;
    previousPackageForm: FormGroup;
    action: string = "S"; // Default action is save
    selectedRowData: any;
    selectedRowIndex: number = -1;
    categories: any = [];
    previousPackagesList: MatTableDataSource<PackageMasterListModel> = new MatTableDataSource();
    displayedColumns = ["PackageCode", "PackageName", "Amount", "Category"];

    constructor(
        private http: HttpService,
        private loader: LoaderService,
        private fb: FormBuilder,
        private commonService: CommonService,
        private dialogRef: MatDialogRef<PreviousPackagesComponent>) { }

    ngOnInit() {
        this.initializeform();
        this.getPreviousPackages();
    }

    // Initialize form
    initializeform() {
        this.previousPackageForm = this.fb.group({
            PackageCode: [""],
            Amount: [""],
            Category: [""],
            PackageName: [""]
        });
    }

    // Get form controls
    get f() {
        return this.previousPackageForm.controls;
    }

    // Author - Vinayak Savale
    // Get Previous packages
    getPreviousPackages() {
        this.loader.spin.next(true);

        this.http.Get(urlConstant.Billing.GetPreviousPackages()).subscribe(response => {
            this.previousPackagesList = new MatTableDataSource(response.Data.PreviousPackages);
            this.categories = response.Data.Categories;
            this.previousPackagesList.sort = this.sort;
        });

        this.loader.spin.next(false);
    }

    // Update category
    updateCategory() {
        this.loader.spin.next(true);

        this.previousPackageForm.patchValue({
            PackageCode: this.selectedRowData.PackageCode, PackageName: this.selectedRowData.PackageName, Amount: this.selectedRowData.Amount, Category: this.selectedRowData.Category
        });

        this.f.PackageCode.disable();
        this.f.PackageName.disable();
        this.f.Amount.disable();
        this.action = "U";

        this.loader.spin.next(false);
    }

    // Author - Vinayak Savale
    // Save or Update Package based on action value
    savePackage() {
        if (!this.validateForm()) return;

        const packageMasterInput = this.previousPackageForm.getRawValue();

        // if action is "S" that means save package master
        if (this.action === "S") {
            this.commonService.confirmAction("Save Package Master", "Do you want to save ?").subscribe(response => {
                if (response) {
                    this.http.Post(urlConstant.Billing.SavePackage(), packageMasterInput).subscribe(response => {
                        if (response.Status === 200) {
                            this.commonService.displayPromptMessage("Save Package Master", "Package master saved successfully").subscribe(response => {
                                window.location.reload();
                            });
                        }
                    });
                }
            });
        }
        // if action is U that means update package master
        else {
            this.commonService.confirmAction("Update Package Master", "Do you want to update package master ?").subscribe(response => {
                if (response) {
                    this.http.Post(urlConstant.Billing.UpdateCategory(), packageMasterInput).subscribe(response => {
                        if (response.Status === 200) {
                            this.commonService.displayPromptMessage("Update Package Master", "Package master updated successfully").subscribe(response => {
                                window.location.reload();
                            });
                        }
                    });
                }
            });
        }
    }

    // Validate form before saving or updating
    validateForm(): boolean {
        if (!this.commonService.isValidStringValue(this.f.PackageCode.value)) {
            this.commonService.openSnackBar("Please enter code", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.PackageName.value)) {
            this.commonService.openSnackBar("Please enter description", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.Amount.value)) {
            this.commonService.openSnackBar("Please enter amount", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.Category.value)) {
            this.commonService.openSnackBar("Please select category", "Ok");
            return false;
        }

        return true;
    }

    // Reset form values
    resetForm() {
        this.previousPackageForm.reset();
        this.f.PackageCode.enable();
        this.f.PackageName.enable();
        this.f.Amount.enable();
        this.action = "S";
    }

    // close dialog box
    closeDialog() {
        this.dialogRef.close();
    }

    // Highlight selected row and add row details
    highlightSelectedRow(index, rowDetails) {
        this.selectedRowData = rowDetails;

        if (this.selectedRowIndex == index) {
            this.selectedRowIndex = -1;
            this.selectedRowData = null;
        } else {
            this.selectedRowIndex = index;
        }
    }
}