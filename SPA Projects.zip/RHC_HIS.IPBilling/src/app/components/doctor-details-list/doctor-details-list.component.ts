import { Component, OnInit, ViewChild, HostBinding, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MatTableDataSource, MatSort, MatDialogRef } from '@angular/material';
import { urlConstant } from 'src/app/constants/urlConstants';
import { ParseDate } from 'shared-utility';
import { messageConstant } from 'src/app/constants/messageConstants';
import { isNullOrUndefined } from 'util';
import { BillDropdownComponent } from 'bill-dropdown';
import { EventListener } from '@angular/core/src/debug/debug_node';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';


@Component({
  selector: 'app-doctor-details-list',
  templateUrl: './doctor-details-list.component.html',
  styleUrls: ['./doctor-details-list.component.css'],
  host: { 'class': 'section__main' },

})
export class DoctorDetailsListComponent implements OnInit, AfterViewInit {
  //permissions: any[];
  canExportToExcel: boolean;
  isPopup: boolean = false;
  regNo: string;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('patDetails') patDetailComp: PatientDetailsComponent;
  @ViewChild('billDropdown') billDropdownComponent: BillDropdownComponent;
  selectedRowData: any;
  @ViewChild('date') dateComp;
  selectedRowIndex: number = -1;
  doctorDetailsForm: FormGroup;
  doctorServiceDetailsList: MatTableDataSource<any> = new MatTableDataSource([]);
  doctorList: MatTableDataSource<any> = new MatTableDataSource([]);
  patientList: MatTableDataSource<any> = new MatTableDataSource([]);
  displayedColumnsList: string[] = ['SerialNo', 'DoctName', 'DoctorCode', 'ServiceName', 'DepartmentCode', 'Quantity', 'ServiceCost', 'ServiceAmount', 'ServiceNo', 'BillNo', 'BillDate', 'GeneralDepartmentNo'];
  displayedPatientListColumns: string[] = ['BillNo', 'BillDate', 'FolioNo', 'RegNo', 'PatientName', 'Amount', 'BedNo', 'Status'];
  displayedDoctorListColumns: string[] = ['DoctorName', 'Code', 'Amount'];
  hiddenItems: any = ['FinalButton', 'InterimButton', 'DoctorButton', 'ApprovedAmount',
    'TPA', 'DischDateTime', 'InsCompanyName'];
  UserId: string;
  constructor(
    private fb: FormBuilder,
    private commonService: CommonService,
    private httpService: HttpService,
    private loader: LoaderService,
    public dialogRef: MatDialogRef<DoctorDetailsListComponent>) {
    //#region Permission Section
    //this.permissions = JSON.parse(localStorage.getItem('Permission'));
    // Export to excel
    this.UserId = localStorage.getItem('UserName');
    if (this.UserId === 'SYSTEM') {
      this.canExportToExcel = true;
    }

    //#endregion
  }

  ngAfterViewInit(): void {
    if (this.isPopup && this.commonService.isValidStringValue(this.regNo)) {
      this.patDetailComp.setPatientDetailByRegNo(this.regNo, true);
      setTimeout(() => {
        this.showDoctorServiceDetails();
      }, 5000);

    }
  }


  /// added o apply full class when this component will be used as a popup
  @HostBinding('class.full') get valid() { return this.isPopup; }

  ngOnInit() {
    this.initForm();


  }

  // initialize the form
  initForm() {
    this.doctorDetailsForm = this.fb.group({
      RegNo: [{ value: '', disabled: true }],
      PatientName: [''],
      FromDate: new Date(),
      ToDate: new Date(),
      BillNo: [{ value: '', disabled: true }],
      BillDate: [{ value: '', disabled: true }],
      FolioNumberForBill: [{ value: '', disabled: true }],
      NetAmount: [{ value: '0.00', disabled: true }]
    });

    this.doctorServiceDetailsList = new MatTableDataSource([]);
    this.billDropdownComponent.myControl.reset();

  }

  enableDate() {
    // if (this.f.DateChecker.value) {
    //   this.dateComp.FromDate.enable();
    //   this.dateComp.ToDate.enable();
    // } else {
    //   this.dateComp.FromDate.disable();
    //   this.dateComp.ToDate.disable();
    // }
  }

  // the function returns the form controls to access in both files.
  public get f() {
    return this.doctorDetailsForm.controls;
  }

  // sets patient details on event emit
  setPatientDetail(patient: any, patDetails?: any, date?) {
    if (!this.commonService.isValidStringValue(patient.RegNo)) {
      this.resetForm(patDetails, date);
      return;
    }
    this.initForm();
    this.doctorDetailsForm.patchValue({
      "RegNo": patient.RegNo, "PatientName": patient.PatientName, "BedNo": patient.BedNo,
      "RoomNo": patient.RoomNo, "AdmitDate": patient.AdmitDate, "Category": patient.PatientCategoryCode,
      "DiscDate": patient.DischargeDate, "DiscTime": patient.DischargeTime, "BillNo": patient.BillNo,
      "FolioNo": patient.FolioNumberForBill
    });

    this.billDropdownComponent.regNo = this.f.RegNo.value;
    this.billDropdownComponent.GetBills();
    if (patDetails.fromPatHelp) {
      this.patientList = new MatTableDataSource([]);
    }

    if(this.commonService.isValidStringValue(patient.RegNo))
    {
      this.showDoctorServiceDetails();
    }
  }

  // set from date and to date
  getSetDate(event) {
    this.f.FromDate.setValue(new Date(event.FromDate.value));
    this.f.ToDate.setValue(new Date(event.ToDate.value));
  }

  // Show Patient List whose billtype not equal to 'IN'
  showPatientList(date) {
    // if (!this.validateForm('patientList', date)) return;
    let fromDate, toDate;
    this.patientList = new MatTableDataSource([]);
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.DoctorServicelist.GetIpBillDetails(this.commonService.convertDateToString(this.f.FromDate.value),
      this.commonService.convertDateToString(this.f.ToDate.value))).subscribe(response => {
        if (response && response.Data.length > 0) {
          this.loader.spin.next(false);
          this.patientList = new MatTableDataSource(response.Data);
          this.patientList.sort = this.sort;
        } else {
          this.patientList = new MatTableDataSource([]);
          this.loader.spin.next(false);
        }
      });
  }

  clearPatientList() {
    this.patientList = new MatTableDataSource([]);
  }

  // reset form 
  resetForm(patDetails, date?) {
    patDetails.patientForm.reset();
    date.FromDate.setValue(new Date());
    date.ToDate.setValue(new Date());
    this.doctorServiceDetailsList = new MatTableDataSource([]);
    this.doctorList = new MatTableDataSource([]);
    this.billDropdownComponent.billList = [];
    this.patientList = new MatTableDataSource([]);
    this.initForm();
  }

  // validation of form
  validateForm(listName, date?): boolean {
    if (listName === 'doctorDetails') {
      if (!this.commonService.isValidStringValue(this.f.RegNo.value) && !this.commonService.isValidStringValue(this.selectedRowData.RegNo)) {
        this.commonService.openSnackBar(messageConstant.AllowToGo.RegNoRequired,
          messageConstant.invalidMessages.OK);
        return false;
      }
      if (!this.commonService.isValidStringValue(this.f.BillNo.value) && !this.commonService.isValidStringValue(this.selectedRowData.BillNo)) {
        this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidBillNo,
          messageConstant.invalidMessages.OK);
        return false;
      }
      if (!this.commonService.isValidStringValue(this.f.FolioNumberForBill.value) && !this.commonService.isValidStringValue(this.selectedRowData.FolioNo)) {
        this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidFolioNo,
          messageConstant.invalidMessages.OK);
        return false;
      }
    } else if (listName === 'patientList') {
      if (!this.commonService.isValidStringValue(this.f.FromDate.value)) {
        this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidFromDate,
          messageConstant.invalidMessages.OK);
        return false;
      }
      if (!this.commonService.isValidStringValue(this.f.ToDate.value)) {
        this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidToDate,
          messageConstant.invalidMessages.OK);
        return false;
      }
      // if (new ParseDate().transform(date.FromDate.value) > new ParseDate().transform(new Date())) {
      //   this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidFromDate,
      //     messageConstant.invalidMessages.OK);
      //   return false;
      // }
      // if (new ParseDate().transform(date.ToDate.value) > new ParseDate().transform(new Date())) {
      //   this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidToDate,
      //     messageConstant.invalidMessages.OK);
      //   return false;
      // }
    }
    return true;
  }

  // Show Doctor Services
  showDoctorServiceDetails() {
    //if (!this.validateForm('doctorDetails')) return;
    this.loader.spin.next(true);
    //Need to confirm if row selected from patient list then that regNo, billNo, folioNo should be used
    let billno = this.f.BillNo.value;
    let regNo = this.f.RegNo.value;
    let folioNo = this.f.FolioNumberForBill.value;



    this.httpService.Get(urlConstant.DoctorServicelist.GetDoctorServicesDetails(billno, regNo, folioNo)).subscribe(response => {
      if (response && response.Data.Detail.length > 0) {
        this.loader.spin.next(false);
        this.doctorServiceDetailsList = new MatTableDataSource(response.Data.Detail);
        this.doctorList = new MatTableDataSource(response.Data.Summary);
        this.doctorServiceDetailsList.sort = this.sort;
        this.f.NetAmount.setValue(response.Data.Detail.map(item => item.ServiceAmount).reduce((prev, next) => parseFloat(prev) + parseFloat(next)));
      } else {
        this.commonService.openSnackBar("No Doctor Services Available For This Patient", "Ok");
        this.doctorServiceDetailsList = new MatTableDataSource([]);
        this.loader.spin.next(false);
      }
    });
  }

  //To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
      this.patDetailComp.patientForm.reset();
    } else {
      this.selectedRowIndex = index;
      this.patDetailComp.patientForm.controls.RegNo.setValue(this.selectedRowData.RegNo);
      this.patDetailComp.getPatientDetails();
      this.billDropdownComponent.regNo = this.selectedRowData.RegNo;
      this.billDropdownComponent.GetBills();
      setTimeout(() => {
        this.showDoctorServiceDetails();
      }, 4000);

    }
  }

  exportToExcel() {
    this.getExportFile(false);
  }

  getPDF() {
    this.getExportFile(true);
  }


  getExportFile(isPrint: boolean) {
    let param = {
      BillNo: this.f.BillNo.value, PatientName: this.f.PatientName.value,
      RegNo: this.f.RegNo.value, FolioNo: this.f.FolioNumberForBill.value
    };

    let url = isPrint ? urlConstant.DoctorServicelist.GetDocServPDF() : urlConstant.DoctorServicelist.GetDocServExcel();
    this.httpService.Post(url, param).subscribe(response => {
      if (response && response.Data.length > 0) {
        this.httpService.openFile(response.Data);
      }
    });
  }

  setBillDetail(bill: any) {
    this.f.BillNo.setValue(bill.IpBillNo);
    this.f.BillDate.setValue(bill.BillDate);
    this.f.FolioNumberForBill.setValue(bill.FolioNo);
  }

  closeDialog() {
    this.dialogRef.close();
  }
}
