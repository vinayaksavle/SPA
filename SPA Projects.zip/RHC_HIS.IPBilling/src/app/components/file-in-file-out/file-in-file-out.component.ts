import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSort, MatTableDataSource } from '@angular/material';
import { FromDateToDateComponent } from 'from-date-to-date';
import { RegnoTabFieldComponent } from 'regno-tab-field';
import { ParseDate } from 'shared-utility';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';

@Component({
    selector: 'app-file-in-file-out',
    templateUrl: './file-in-file-out.component.html',
    styleUrls: ['./file-in-file-out.component.css'],
    host: { 'class': 'section__main' },
})
export class FileInFileOutComponent implements OnInit {

    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('fromDateToDate') dates: FromDateToDateComponent;
    @ViewChild('patDetails') patDetails: RegnoTabFieldComponent;

    listDetails: MatTableDataSource<any> = new MatTableDataSource([]);

    displayedColumns: string[] = ['SNo', 'RegNo', 'Status', 'UserId', 'DischargeDate', 'Remark'];
    fileInOutForm: FormGroup;

    constructor(private loader: LoaderService, private httpService: HttpService, public fb: FormBuilder,
        private common: CommonService) {
    }

    ngOnInit() {
        this.initForm();
        this.showList();
    }
    initForm() {
        this.fileInOutForm = this.fb.group({
            DischargeDate: [new Date(), Validators.required],
            Status: [''],
            Remark: ['', Validators.required]
        });
    }
    // the function returns the form controls to access in both files.
    public get f() {
        return this.fileInOutForm.controls;
    }

    saveDetails() {
        let obj = this.fileInOutForm.getRawValue();
        obj.RegNo = this.patDetails.RegNo;
        if (this.validateForm(obj)) {
            obj.DischargeDate = new ParseDate().transform(obj.DischargeDate);
            obj.UserId = localStorage.getItem("UserName");
            this.common.confirmAction("File In File Out", "Do you want to save?").
                subscribe(response => {
                    if (response) {
                        this.loader.spin.next(true);
                        this.httpService.Post(urlConstant.FileInFileOut.SaveFileInOutDetailsUrl, obj).subscribe(res => {
                            if (res.Status == 200 && res.Data) {
                                this.loader.spin.next(false);
                                this.common.displayPromptMessage("File In Out", "Details Saved Successfully!");
                                this.clearForm();
                            } else {
                                this.loader.spin.next(false);
                                this.common.displayPromptMessage("Error", "Unable to save record");
                            }
                        }, (error) => {
                            this.loader.spin.next(false);
                            this.common.displayPromptMessage("Error", "Unable to save record");
                            console.log(error);
                        });
                    }
                    else {
                        return;
                    }
                });
        }
        else {
            return;
        }

    }
    validateForm(obj: any): boolean {
        if (!this.common.isValidStringValue(obj.RegNo)) {
            this.common.openSnackBar("Invalid RegNo", "OK");
            return false;
        } else if (!this.common.isValidStringValue(obj.DischargeDate)) {
            this.common.openSnackBar("Invalid Discharge Date", "OK");
            return false;
        }
        else if (!this.common.isValidStringValue(obj.Status)) {
            this.common.openSnackBar("Invalid Status", "OK");
            return false;
        }
        else if (!this.common.isValidStringValue(obj.Remark)) {
            this.common.openSnackBar("Invalid Remarks", "OK");
            return false;
        }
        else {
            return true;
        }
    }
    showList() {
        let fromDate = new ParseDate().transform(this.dates.FromDate.value);
        let toDate = new ParseDate().transform(this.dates.ToDate.value);
        this.listDetails = new MatTableDataSource([]);

        this.loader.spin.next(true);
        this.httpService.Get(urlConstant.FileInFileOut.GetFileInOutDetailsUrl(fromDate, toDate)).subscribe(response => {
            if (response && response.Status === 200 && response.Data.length > 0) {
                this.listDetails = new MatTableDataSource(response.Data);
                this.listDetails.sort = this.sort;
                this.loader.spin.next(false);
            } else {
                this.loader.spin.next(false);
            }
        }, (error) => {
            this.listDetails = new MatTableDataSource([]);
            this.loader.spin.next(false);
            console.log(error);
        });

    }
    clearList() {
        this.dates.FromDate.setValue(new Date());
        this.dates.ToDate.setValue(new Date());
        this.showList()
    }
    clearForm() {
        this.initForm();
        this.patDetails.clearFields();
    }
    exportToExcel() {
        let fromDate = new ParseDate().transform(this.dates.FromDate.value);
        let toDate = new ParseDate().transform(this.dates.ToDate.value);
        this.listDetails = new MatTableDataSource([]);
        this.loader.spin.next(true);
        this.httpService.Get(urlConstant.FileInFileOut.GetExcelDataFileInOut(fromDate, toDate)).subscribe(response => {
            if (response && response.Status === 200 && response.Data.length > 0) {
                this.httpService.openFile(response.Data);
                this.loader.spin.next(false);
            } else {
                this.loader.spin.next(false);
            }
        }, (error) => {
            this.listDetails = new MatTableDataSource([]);
            this.loader.spin.next(false);
            console.log(error);
        });
    }

}
