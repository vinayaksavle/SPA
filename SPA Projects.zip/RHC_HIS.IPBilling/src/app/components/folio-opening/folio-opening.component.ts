import { Component, OnInit, ViewChild } from '@angular/core';
import 'rxjs/add/operator/filter';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatTableDataSource } from '@angular/material';
import { ParseDBDateToDOBPipe } from 'shared-utility/lib/pipes/parse-dbDate-to-dob.pipe';

@Component({
  selector: 'app-folio-opening',
  templateUrl: './folio-opening.component.html',
  styleUrls: ['./folio-opening.component.css'],
  host: { 'class': 'section__main' }
})
export class FolioOpeningComponent implements OnInit {

  displayedColumns = ["Folio", "Open Date", "Bill No", "Close Date"]
  folioListDetails: MatTableDataSource<any> = new MatTableDataSource();
  folioOpeningForm: FormGroup;
  newButton: boolean;
  saveButton: boolean;
  cancelButton: boolean;
  resetButton: boolean;
  folioObj: any;

  constructor(private fb: FormBuilder, private commonService: CommonService,
    private httpService: HttpService,
    private loader: LoaderService) {
  }
  ngOnInit(): void {
    this.initForm();
  }

  // Initialize form
  // Author:- Bhushan T
  initForm() {
    this.folioOpeningForm = this.fb.group({
      RegNo: [''],
      FolioDate: [{ value: new Date(), disabled: true }],
      FolioTime: [{ value: new Date().getHours() + ':' + new Date().getMinutes() + ':' + new Date().getSeconds(), disabled: true }],
      FolioNumber: ['']
    })
    this.folioListDetails = new MatTableDataSource();
    this.newButton = false;
    this.saveButton = false;
    this.cancelButton = false;
    this.resetButton = false;
  }

  public get f() {
    return this.folioOpeningForm.controls;
  }

  // Set Patient Details after entering RegNo.
  // Author:- Bhushan T
  setPatientDetail(event) {
    this.f.RegNo.setValue(event.RegNo);
    this.folioListDetails = new MatTableDataSource();
    this.getFolioDetailsByRegNo();
    // this.loader.spin.next(true);
    // this.httpService.Get(urlConstant.Masters.FolioOpening.GetFolioDetailsByRegNo(this.f.RegNo.value)).subscribe(response => {
    //   if (response.Status == 200 && response.Data.length > 0) {
    //     this.folioListDetails = new MatTableDataSource(response.Data);
    //     console.log(this.folioListDetails.data.length)
    //     this.loader.spin.next(false);
    //   }
    //   else {
    //     this.loader.spin.next(false);
    //   }
    //   this.loader.spin.next(false);
    // });
  }

  getFolioDetailsByRegNo() {
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.Masters.FolioOpening.GetFolioDetailsByRegNo(this.f.RegNo.value)).subscribe(response => {
      if (response.Status == 200 && response.Data.length > 0) {
        this.folioListDetails = new MatTableDataSource(response.Data);
        //console.log(this.folioListDetails.data.length)
        this.loader.spin.next(false);
      }
      else {
        this.loader.spin.next(false);
      }
      this.loader.spin.next(false);
    });
  }

  // Function to check duplicate Folio No.
  validateFolioNo() {
    if (this.commonService.isValidStringValue(this.f.FolioNumber.value)
      && this.folioListDetails.data.length > 0) {
      this.folioListDetails.data.forEach(element => {
        if (element.FolioNo === this.f.FolioNumber.value) {
          this.commonService.displayPromptMessage("Folio Opening", "Folio Number Already Exist");
          this.f.FolioNumber.setValue("");
          this.f.FolioNumber.setErrors(Validators.required);
        }
      });
    }
  }

  // Function to Save Folio Details.
  onSave() {
    if (!this.commonService.isValidStringValue(this.f.RegNo.value)) {
      this.commonService.openSnackBar("Enter Registration Number", "Ok");
    }
    else if (!this.commonService.isValidStringValue(this.f.FolioNumber.value)) {
      this.commonService.openSnackBar("Enter Folio Number", "Ok");
    }
    else {
      this.loader.spin.next(true);
      this.folioObj = {
        RegNo: this.f.RegNo.value,
        FolioNo: this.f.FolioNumber.value,
      }
      this.httpService.Post(urlConstant.Masters.FolioOpening.SaveFolio, this.folioObj).subscribe(response => {
        if (response.Status == 200 && response.Data == true) {
          this.commonService.displayPromptMessage("Folio Opening", "Folio Saved Succesfully!");
          // After Save reload the folio list and reset the folio Number.
          this.f.FolioNumber.reset();
          this.getFolioDetailsByRegNo();
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
          this.commonService.displayPromptMessage("Folio Opening", "This Folio Number Is Already Generated");
        }
        this.loader.spin.next(false);
      });
      // After Save reload the folio list and reset the folio Number.
      // this.f.FolioNumber.reset();
      // this.loader.spin.next(true);
      // this.httpService.Get(urlConstant.Masters.FolioOpening.GetFolioDetailsByRegNo(this.f.RegNo.value)).subscribe(response => {
      //   if (response.Status == 200 && response.Data.length > 0) {
      //     this.folioListDetails = new MatTableDataSource(response.Data);
      //     this.loader.spin.next(false);
      //   }
      //   else {
      //     this.loader.spin.next(false);
      //   }
      //   this.loader.spin.next(false);
      // });
    }
  }

  resetForm(patDetailsComp) {
    patDetailsComp.patientForm.reset();
    this.initForm();
  }

}