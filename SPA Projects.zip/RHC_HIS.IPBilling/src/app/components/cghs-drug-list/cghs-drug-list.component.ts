import { Component, OnInit } from '@angular/core';
import 'rxjs/add/operator/filter';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';

@Component({
  selector: 'app-cghs-drug-list',
  templateUrl: './cghs-drug-list.component.html',
  styleUrls: ['./cghs-drug-list.component.css'],
  host: { 'class': 'section__main' }
})
export class CghsDrugListComponent implements OnInit {

    displayedColumns = ["Cghs Drug No","Date","Reg No","Patient Name","Status"]
    
    deptListDetails;
      
      constructor(private fb: FormBuilder, private commonService: CommonService,
        private dataService: DataTranferService, private httpService: HttpService) {
      }  
    ngOnInit(): void {
     }
  

}