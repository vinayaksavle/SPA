import { Component, OnInit, ViewChild } from '@angular/core';
import 'rxjs/add/operator/filter';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';
import { PPNPackageMasterLookupComponent } from 'ppn-package-master-lookup';
import { CreditCompanyLookupComponent } from 'credit-company-lookup';
import { PatientSourceDropdownComponent } from 'patient-source-dropdown';
import { Router } from '@angular/router';
import { LoaderService } from 'src/app/services/loader.service';
import { ParseDate } from 'shared-utility';
import { common } from 'src/app/common/common';

@Component({
  selector: 'app-cash-credit',
  templateUrl: './cash-credit.component.html',
  styleUrls: ['./cash-credit.component.css'],
  host: { 'class': 'section__main' }
})

export class CashCreditComponent implements OnInit {
  currentDate: any = new Date();
  minTime: string = "00:00";
  admissionDate: any; // set value from patient details
  cashCreditForm: FormGroup;
  localStoragePatientDetails: any = {};
  relative: boolean;
  // View child declarations
  @ViewChild('patientDetailComponent') patientDetailComponent: PatientDetailsComponent;
  @ViewChild('patientSourceDropdown') patientSourceDropdown: PatientSourceDropdownComponent;
  @ViewChild('ppnComponent') ppnComponent: PPNPackageMasterLookupComponent;
  @ViewChild('creditComp') creditComp: CreditCompanyLookupComponent;
  @ViewChild('insCreditComp') insCreditComp: CreditCompanyLookupComponent;
  @ViewChild('refCreditComp') refCreditComp: CreditCompanyLookupComponent;

  constructor(private fb: FormBuilder, private commonService: CommonService,
    private dataService: DataTranferService, private httpService: HttpService, private router: Router, private loader: LoaderService) {
  }

  ngOnInit() {
    this.initializeform();
    this.changeCredit({ value: "CASH" })
  }

  // Initialize form
  initializeform() {
    this.cashCreditForm = this.fb.group({
      RegNo: [""],
      PatientName: [""],
      OldCategory: [""],
      NewCategory: [""],
      CreditDate: [{ value: new Date(), disabled: true }],
      CreditTime: [{ value: this.getCurrentTime(), disabled: true }],
      CreditTo: ["C"], // Default Company
      PaidType: ["CASH"], // Default Cash
      CreditTPACode: [""],
      CreditCompanyCode: [""],
      DispensaryNo: [""],
      TokenNo: [""],
      Relation: [""],
      LetterNo: ["", Validators.required],
      LetterDate: [new Date(), Validators.required],
      InsuranceCompanyCode: [""],
      InsuranceCompanyName: [""],
      PackageCode: [""],
      PackageName: [""],
      IsStudent: false,
      ReferredCompanyCode: [""],
      Responsible: [""],
      UserId: [{ value: localStorage.getItem("UserName"), disabled: true }]
    });

  }

  // get form controls
  get f() {
    return this.cashCreditForm.controls;
  }

  // Need to Check where should this method get called later
  getCurrentTime() {
    let currentDate = new Date();
    let currentHours = currentDate.getHours();
    let currentMinutes = currentDate.getMinutes();
    return (currentHours < 10 ? ('0' + currentHours) : currentHours) + ':' + (currentMinutes < 10 ? ('0' + currentMinutes) : currentMinutes);
  }

  // Set Patient details
  setPatientDetail(patient: any) {
    this.cashCreditForm.patchValue({
      "RegNo": patient.RegNo, "PatientName": patient.PatientName, "OldCategory": patient.PatientCategoryCode
      , "NewCategory": patient.PatientCategoryCode
    });

    this.patientSourceDropdown.myControl.setValue(patient.PatientCategoryCode);

    // If patient category is "07 Staff" then change credit to radio button to staff else company
    if (this.commonService.isValidStringValue(patient.CompanyName)) {
      if (this.f.OldCategory.value === "07")
        this.f.CreditTo.setValue("S");
      else
        this.f.CreditTo.setValue("C");

      this.f.CreditTo.setValue("S");

      // setting referred company details
      if (this.commonService.isValidStringValue(patient.RefComp)) {
        this.refCreditComp.myControl.setValue(`(${patient.RefComp}) ${patient.ReferredCompany}`);
        this.f.ReferredCompanyCode.setValue(patient.RefComp)
        this.refCreditComp.myControl.disable();
      }

      // setting credit company details 
      if (this.commonService.isValidStringValue(patient.CompanyCode)) {
        this.f.CreditCompanyCode.setValue(patient.CompanyCode);
        this.creditComp.myControl.setValue(patient.CompanyName);
      }

      // setting insurance company details
      if (this.commonService.isValidStringValue(patient.InsCompanyName)) {
        this.f.InsuranceCompanyCode.setValue(patient.InsCompCode);
        this.f.InsuranceCompanyName.setValue(patient.InsCompanyName);
        this.insCreditComp.myControl.setValue(patient.InsCompanyName);
      }

    }
    else {
      this.f.CreditTo.setValue("C");
    }

    // Fetch Pat Credit details if already present
    this.getPatCreditDetails(patient.RegNo);

    // setting patient details for local storage.
    this.localStoragePatientDetails = patient;
    // this.setLocalStorageRegNo();
    // console.log(this.localStoragePatientDetails);

    if (!this.commonService.isValidStringValue(patient.RegNo)) {
      this.clearForm();
      return;
    }

  }

  // sets patient category in form
  setPatientCategory(category) {
    this.f.NewCategory.setValue(category.Code);
  }

  // sets package detail
  setPackageDetail(packageData: any) {
    if (this.commonService.isValidStringValue(packageData.PackageCode)) {
      this.f.PackageCode.setValue(packageData.PackageCode);
      this.f.PackageName.setValue(packageData.PackageName);
    }
    else {
      this.f.PackageCode.setValue("");
      this.f.PackageName.setValue("");
    }
  }

  // Author - Vinayak Savale
  // Fetch relative details for Staff (07) category
  setPatInfoTokenNo() {

    if (this.f.OldCategory.value === "07" || this.f.CreditTo.value === "S") {
      if (this.commonService.isValidStringValue(this.f.TokenNo.value)) {
        const cashCreditInput = this.cashCreditForm.getRawValue();
        this.httpService.Post(urlConstant.Billing.GetPatInfoTokenNo(), cashCreditInput).subscribe(response => {

          if (response.Status === 200 && response.Data) {
            this.relative = response.Data.Relative;
            this.commonService.displayPromptMessage(response.Data.PopupMessage, response.Data.EmployeeName)
              .subscribe(response => {
                if (!this.relative) {
                  this.commonService.displayPromptMessage("Cash/Credit", "Patient Name Not in the Relative List of the Employee...");
                  this.f.TokenNo.setValue("");
                  this.f.CreditTo.setValue("");
                  this.creditComp.myControl.setValue("");
                  this.f.CreditCompanyCode.setValue("");
                }
              });
            this.f.LetterNo.setValue(response.Data.LetterNo);
          }
          else {
            this.commonService.displayPromptMessage("Cash/Credit", "Invalid PF No.");
            this.f.TokenNo.setValue("");
            this.f.CreditTo.setValue("");
            this.creditComp.myControl.setValue("");
            this.f.CreditCompanyCode.setValue("");
          }


        })
      }
      else {
        this.commonService.displayPromptMessage("Cash/Credit", "Invalid PF No.");
        this.f.TokenNo.setValue("");
        this.f.CreditTo.setValue("");
        this.creditComp.myControl.setValue("");
        this.f.CreditCompanyCode.setValue("");
      }


    }
  }

  // Get Credit company code
  getCreditCompany(company: any) {
    if (company.CrLock === "Y") {
      this.commonService.openSnackBar("Credit facility Locked Company : " + company.CompanyName, "Ok");
      this.creditComp.myControl.setValue("");
      this.f.CreditCompanyCode.setValue("");
      return false;
    }

    if (this.commonService.isValidStringValue(company.PatientCategory)) {
      this.commonService.confirmAction("Credit company ", "Change patient source to " + company.PatientCategoryName + " ?")
        .subscribe(response => {
          if (response) {
            this.f.OldCategory.setValue(company.PatientCategory);
          }
          else {
            this.f.OldCategory.setValue(this.f.OldCategory.value);
          }
        })
    }
    else
      this.f.OldCategory.setValue(this.f.OldCategory.value);
    this.f.CreditCompanyCode.setValue(company.CompanyCode);
  }

  // Get Insurance company code
  getInsuranceCompany(company: any) {
    this.f.InsuranceCompanyCode.setValue(company.CompanyCode);
  }

  // Get Referred company code
  getReferredCompany(company: any) {
    this.f.ReferredCompanyCode.setValue(company.CompanyCode);
  }

  // Need to check on this Get Insurance company details
  // getInsuranceCompany() {
  //   const companyCode = this.f.InsuranceCompanyCode.value;
  //   this.httpService.Get(urlConstant.Billing.GetInsuranceCompany(companyCode)).subscribe(response => {
  //     if (response.Status === 200) {
  //       this.f.InsuranceCompanyName.setValue(response.Data[0].CompanyName);
  //       this.f.InsuranceCompanyName.disable();
  //     }
  //     else {
  //       this.commonService.openSnackBar("Invaid Insurance company code", "Ok");
  //     }
  //   });
  // }

  // Get Patient Credit Details if already present.
  getPatCreditDetails(regNo: string) {
    this.httpService.Get(urlConstant.Billing.GetPatCreditDetails(regNo)).subscribe(response => {
      if (response.Data && response.Data.length > 0) {
        console.log(response.Data[0]);
        this.commonService.isValidStringValue(response.Data[0].DispNo) ? this.f.DispensaryNo.setValue(response.Data[0].DispNo) : "";
        this.commonService.isValidStringValue(response.Data[0].TokenNo) ? this.f.TokenNo.setValue(response.Data[0].TokenNo) : "";
        this.commonService.isValidStringValue(response.Data[0].Relation) ? this.f.Relation.setValue(response.Data[0].Relation) : "";
        this.commonService.isValidStringValue(response.Data[0].LetterNo) ? this.f.LetterNo.setValue(response.Data[0].LetterNo) : "";
        this.commonService.isValidStringValue(response.Data[0].LetterDate) ? this.f.LetterDate.setValue(common.getMomentDateFromString(response.Data[0].LetterDate)) : "";
        this.commonService.isValidStringValue(response.Data[0].CreditDate) ? this.f.CreditDate.setValue(response.Data[0].CreditDate) : "";
        this.commonService.isValidStringValue(response.Data[0].CreditTime) ? this.f.CreditTime.setValue(response.Data[0].CreditTime) : "";
        this.commonService.isValidStringValue(response.Data[0].EditUser) ? this.f.UserId.setValue(response.Data[0].EditUser) : "";
        this.commonService.isValidStringValue(response.Data[0].UserId) ? this.f.UserId.setValue(response.Data[0].UserId) : this.f.UserId.setValue(localStorage.getItem("UserName"));

        this.f.PaidType.setValue("CREDIT");

        // setting credit to company/staff value
        if (response.Data[0].CreditToFlag === "C")
          this.f.CreditTo.setValue("C");
        else
          this.f.CreditTo.setValue("S");
      }
    })
  }

  // Update new patient category
  updatePatientCategory() {

    // Add required validations
    if (!this.commonService.isValidStringValue(this.f.PatientName.value)) {
      this.commonService.openSnackBar("Please enter patient details first", "Ok");
      return;
    }

    if (!this.commonService.isValidStringValue(this.patientSourceDropdown.myControl.value)) {
      this.commonService.openSnackBar("Please select new patient category first", "Ok");
      return;
    }

    let patCategoryInput = this.cashCreditForm.getRawValue();
    patCategoryInput.LetterDate = new ParseDate().transform(patCategoryInput.LetterDate);

    this.commonService.confirmAction("Update Patient Source", "Confirm to change patient source ?").subscribe(response => {
      if (response) {
        this.httpService.Post(urlConstant.Billing.UpdatePatientCategory(), patCategoryInput).subscribe(response => {
          if (response.Status === 200) {
            this.commonService.displayPromptMessage("Update Patient Source", "Patient source changed. Please Check.")
              .subscribe(response => {
                this.redirectToConvertServCharges();
                this.patientDetailComponent.clearPatientLookup();
                this.patientSourceDropdown.myControl.setValue('');
              });
          }
        })
      }
    });
  }

  // Save IP cash credit information
  saveCashCreditDetails() {
    if (!this.validateForm()) return;

    let cashCreditInput = this.cashCreditForm.getRawValue();

    cashCreditInput.LetterDate = new ParseDate().transform(cashCreditInput.LetterDate);

    this.commonService.confirmAction("Save Cash/Credit", "Are you sure you want to save cash/credit details ?").subscribe(response => {
      if (response) {
        this.loader.spin.next(true);
        this.httpService.Post(urlConstant.Billing.SaveIPCreditInfo(), cashCreditInput).subscribe(response => {
          if (response.Status === 200) {
            this.commonService.displayPromptMessage("Save Cash/Credit", "Patient Cash/Credit info saved successfully")
              .subscribe(response => {
                if (response) {
                  this.loader.spin.next(false);
                  this.redirectToConvertServCharges();
                }
              });

          } else {
            this.commonService.displayPromptMessage("Error", "Unable to save or update the details");
            this.loader.spin.next(false);
          }
        });
      }
    });

  }

  setLocalStorageRegNo() {
    if (this.commonService.isValidStringValue(this.localStoragePatientDetails.RegNo))
      localStorage.setItem("CSCPatientDetails", JSON.stringify(this.localStoragePatientDetails));
  }

  redirectToConvertServCharges() {
    this.commonService.confirmAction("Redirection", "Do you want to redirect to convert service charges?").subscribe(response => {
      if (response) {
        this.setLocalStorageRegNo();
        this.router.navigateByUrl("billing/change-patient-source");
      }
      else
        window.location.reload();
    })
  }

  validateForm(): boolean {

    if (!this.commonService.isValidStringValue(this.f.RegNo.value)) {
      this.commonService.openSnackBar("Please enter registration number", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.LetterNo.value)) {
      this.commonService.openSnackBar("Please enter letter details", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.LetterDate.value)) {
      this.commonService.openSnackBar("Letter date is invalid", "Ok");
      return false;
    }

    // if (this.commonService.convertDateToString(this.f.LetterDate.value) > this.commonService.convertDateToString(new Date())) {
    //   this.commonService.openSnackBar("Letter date cannot be greater than todays date", "Ok");
    //   return false;
    // }

    if ((this.f.OldCategory.value.trim() === "13" || this.f.NewCategory.value.trim() === "13") && !this.commonService.isValidStringValue(this.f.InsuranceCompanyCode.value)) {
      this.commonService.openSnackBar("Please enter insurance company", "Ok");
      return false;
    }

    if ((this.f.OldCategory.value.trim() === "07" || this.f.NewCategory.value.trim() === "07") && this.f.CreditTo.value === "S"
      && !this.commonService.isValidStringValue(this.f.TokenNo.value) && this.f.IsStudent.value === false) {
      this.commonService.openSnackBar("Please enter Token/PF No.", "Ok");
      return false;

    }

    if (!this.commonService.isValidStringValue(this.f.CreditCompanyCode.value) && this.f.PaidType.value === "CREDIT") {
      this.commonService.openSnackBar("Please enter credit company code", "Ok");
      return false;
    }

    if (this.f.PaidType.value === "CREDIT") {
      if (this.f.CreditTo.value === "C" || this.f.CreditTo.value === "S") {
        if (!this.commonService.isValidStringValue(this.f.CreditCompanyCode.value)) {
          this.commonService.openSnackBar("Credit company code cannot be blank", "Ok");
        }
      }
    }

    return true;
  }

  resetForm() {
    this.commonService.confirmAction("Save Cash/Credit", "Do you want to reset?").subscribe(response => {
      if (response) {
        this.clearForm();
      } else {
        return;
      }
    });
  }

  clearForm() {
    this.initializeform();
    this.patientDetailComponent.clearPatientLookup();
    this.ppnComponent.clearLookupSearch();
    this.creditComp.clearLookupSearch();
    this.insCreditComp.clearLookupSearch();
    this.refCreditComp.clearLookupSearch();
    this.patientSourceDropdown.myControl.setValue('');
  }

  changeCredit(event: any) {
    this.creditComp.myControl.setValue("");
    this.f.CreditCompanyCode.setValue("");
    if (event.value === "CASH") {
      if (this.f.OldCategory.value === "07")
        this.f.CreditTo.setValue("S");
      else
        this.f.CreditTo.setValue("");
      this.f.CreditTo.disable();
      //this.f.CreditTo.setValue("");
      this.creditComp.myControl.setValue("");
      // this.creditComp.myControl.disable();
      this.f.DispensaryNo.setValue("");
      this.f.TokenNo.setValue("");
      this.f.Relation.setValue("");
    }
    else {
      this.f.CreditTo.enable();
      this.creditComp.myControl.enable();
      if (this.f.OldCategory.value === "07")
        this.f.CreditTo.setValue("S");
      else
        this.f.CreditTo.setValue("C");
    }

  }
}