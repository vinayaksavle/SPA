export class DoctorServiceModel {
    DoctCode: string;
    DoctName: string;
    Amount: string;

    constructor(doctCode: string, doctName: string, amount: string) {
        this.DoctCode = doctCode;
        this.DoctName = doctName;
        this.Amount = amount;
    }
}