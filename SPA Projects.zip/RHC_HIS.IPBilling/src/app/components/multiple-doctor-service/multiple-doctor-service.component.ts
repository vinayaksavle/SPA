import { Component, OnInit } from '@angular/core';
import 'rxjs/add/operator/filter';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { MatTableDataSource } from '@angular/material';
import { LoaderService } from 'src/app/services/loader.service';
import { DoctorServiceModel } from './DoctorService';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-multiple-doctor-service',
  templateUrl: './multiple-doctor-service.component.html',
  styleUrls: ['./multiple-doctor-service.component.css'],
  host: { 'class': 'section__main' }
})

export class MultipleDoctorServiceComponent implements OnInit {
  isDeleteDisabled: boolean = true;
  isSaveDisabled: boolean = false;
  doctorServiceForm: FormGroup;
  displayedColumns = ["DoctCode", "DoctName", "Amount"];
  doctServiceList: MatTableDataSource<DoctorServiceModel> = new MatTableDataSource();

  constructor(private fb: FormBuilder, private commonService: CommonService, private httpService: HttpService, private loaderService: LoaderService) {
  }

  ngOnInit() {
    this.initializeform();
    this.addDoctorServices(5);
    this.ServiceArray.enable();
  }

  // initialize form
  initializeform() {
    this.doctorServiceForm = this.fb.group({
      ServslNo: [""],
      SrgpName: [""],
      RegNo: [""],
      PatName: [""],
      ServAmt: [""],
      GDeptNo: [""],
      DptCode: [""],
      ServCode: [""],
      ServDate: "",
      PatSrc: [""],
      Action: [""],
      UserId: [localStorage.getItem("UserName")],
      Services: this.fb.array([])
    });
  }

  get f() {
    return this.doctorServiceForm.controls;
  }

  get ServiceArray(): FormArray {
    return this.doctorServiceForm.get('Services') as FormArray;
  }

  serviceControl(index: number) {
    return this.ServiceArray.controls[index]["controls"];
  }

  // Author - Vinayak Savale
  // Get patient and doctor fees details
  getDoctorServiceDetails() {
    let servslNo = this.f.ServslNo.value;

    this.loaderService.spin.next(true);
    this.httpService.Get(urlConstant.Billing.GetDoctorServicesDetails(servslNo)).subscribe(response => {

      let patient = response.Data.PatientDetails[0];
      // this.doctServiceList = new MatTableDataSource(response.Data.DoctorFeesDtls);
      if (!isNullOrUndefined(patient) && patient.length > 0) {
        // set patient details on the basis of service serial number
        this.doctorServiceForm.patchValue({
          "SrgpName": patient.SrgpName, "RegNo": patient.RegNo, "PatName": patient.PatName, "ServAmt": patient.ServAmt, "GDeptNo": patient.GDeptNo, "DptCode": patient.DptCode, "ServCode": patient.ServCode, "ServDate": patient.ServDate, "PatSrc": patient.PatSrc
        });

        let doctServiceData = response.Data.DoctorFeesDtls;
        let doctServiceLength = doctServiceData.length;

        if (doctServiceLength === 5) {
          this.addDoctorServices(1);
        }
        else if (doctServiceLength > 5) {
          this.addDoctorServices(doctServiceLength + 1);
        }
        else if (doctServiceLength > 0 && doctServiceLength < 5) {
          this.addDoctorServices(5);
        }
        // if count is less than 0 then clear previous grid values
        else {
          this.addDoctorServices(5);
          this.clearServiceGrid();
        }

        for (let i = 0; i < doctServiceLength; i++) {
          this.ServiceArray.controls[i].patchValue(doctServiceData[i]);
        }

        if (patient.GDeptNo === "MD" || patient.GDeptNo.trim().length > 0) {
          this.commonService.openSnackBar(`Already multiple doctor service`, "Ok");
          this.isSaveDisabled = true;
          this.ServiceArray.disable();
        }
        else {
          this.isSaveDisabled = false;
          this.ServiceArray.enable();
        }
      }
      else {
        this.commonService.openSnackBar("Invalid Service Serial No.", "Ok");
      }
    });
    this.calculateTotalAmount();
    this.loaderService.spin.next(false);
  }

  // add doctor services rows on the basis of count
  addDoctorServices(count: number = 1) {
    let doctServices = this.doctServiceList.data;
    let doctServiceObj = new DoctorServiceModel('', '', '');
    for (let i = 0; i < count; i++) {
      doctServices.push(doctServiceObj);
      this.ServiceArray.push(this.initDoctorServices);
    }
    this.doctServiceList = new MatTableDataSource<DoctorServiceModel>(doctServices);
  }

  //initialiazes doctor services
  get initDoctorServices(): any {
    return this.fb.group({
      DoctCode: [''],
      DoctName: [''],
      Amount: ['']
    })
  }

  // Get doctor details on the basis of doctor code
  getDoctorDetails(i: number) {

    if (!this.commonService.isValidStringValue(this.ServiceArray.value[i].DoctCode)) {
      this.ServiceArray.controls[i].reset();
      return;
    }

    let doctCode = this.ServiceArray.value[i].DoctCode;
    this.httpService.Get(urlConstant.Billing.GetDoctors(doctCode)).subscribe(response => {
      if (response.Data.length === 0)
        this.commonService.openSnackBar(`Invalid doctor name`, "Ok");
      else {
        this.serviceControl(i).DoctName.setValue(response.Data[0].DoctorName);
        this.serviceControl(i).Amount.setValue(response.Data[0].DoctorPayment);
        this.calculateTotalAmount();
      }
    });

  }

  // save or delete multiple doctor service on the basis of action 
  saveDoctorServices(action: string) {
    if (!this.validateForm()) return;

    // if action is delete then set Action form value as "D"
    if (action === "delete") {
      this.f.Action.setValue("D");
    }
    else {
      this.f.Action.setValue("");
    }

    this.commonService.confirmAction("Doctor Fees", `Are you sure you want to ${action} multiple doctor service ?`).subscribe(response => {
      if (response) {
        let doctorServices = this.doctorServiceForm.getRawValue();
        doctorServices.Services = doctorServices.Services.filter(s => this.commonService.isValidStringValue(s.DoctCode));
        this.httpService.Post(urlConstant.Billing.SaveDoctorService(), doctorServices).subscribe(response => {
          if (response.Status === 200) {
            this.commonService.displayPromptMessage("Multiple Doctor Service", `Multiple doctor service ${action}ed successfully`).subscribe(response => {
              this.getDoctorServiceDetails();
            });
          }
        });
      }
    });
  }

  // calculate total amount for doctor service
  calculateTotalAmount() {
    let total = 0;
    let services = this.ServiceArray.value;
    for (let i = 0; i < services.filter(s => this.commonService.isValidStringValue(s.DoctCode)).length; i++) {
      total = total + parseFloat(services[i].Amount);
    }

    if (total > 0) {

      if (total > this.f.ServAmt.value) {
        this.commonService.openSnackBar("Total Doctor Amount cannot be greater than Service Amount", "Ok");
      }
      this.isDeleteDisabled = false;
    }
    else {
      this.isDeleteDisabled = true;
    }
  }

  // validate form
  validateForm(): boolean {
    if (this.ServiceArray.length === 0) {
      this.commonService.openSnackBar(`Please add doctor fees details first to post`, "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.ServiceArray.value[0].DoctCode)) {
      this.commonService.openSnackBar(`Please add doctor fees details first to post`, "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.ServslNo.value)) {
      this.commonService.openSnackBar(`Please enter service serial number`, "Ok");
      return false;
    }

    return true;
  }

  // clear service grid
  clearServiceGrid() {
    this.doctServiceList = new MatTableDataSource<DoctorServiceModel>([]);
    this.ServiceArray.reset();
    this.addDoctorServices(5);
  }

  // reset form
  resetForm() {
    this.doctorServiceForm.reset();
    this.clearServiceGrid();
  }
}