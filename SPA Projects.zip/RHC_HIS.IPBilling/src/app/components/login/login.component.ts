import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { AuthService } from 'src/app/security/auth.service';
import { CommonService } from 'src/app/services/common.service';
import { urlConstant } from 'src/app/constants/urlConstants';

export interface Facility {
    value: string;
    viewValue: string;
}

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html',
    styleUrls: ['./login.component.css']
})
export class LoginComponent {

    constructor(public formBuilder: FormBuilder, public router: Router, public dataTransferService: DataTranferService,
        public httpService: HttpService, public auth: AuthService, public loader: LoaderService
        , public commonService: CommonService) { }


    facility: Facility[] = [
        { value: '001', viewValue: 'Ruby Hall Main' },
        { value: '002', viewValue: 'Ruby Hall Clinic Wanowrie' },
        { value: '003', viewValue: 'Ruby Hall Hinjewadi' }
    ];

    public loginForm: FormGroup;
    public submitted = false;
    public loading: boolean;
    public selectFacility: boolean;
    public selectedIPDCounterName: string;
    public selectedIPDCounterCode: string;

    // Funcction to return controls of loginForm
    get f() { return this.loginForm.controls; }


    ngOnInit() {
        this.initDefaultValues();
    }

    // Function to init default
    private initDefaultValues() {
        this.selectFacility = false;
        this.loginForm = this.formBuilder.group({
            username: ['', Validators.required],
            password: ['', Validators.required],
            facility: ['001', Validators.required],
        });
    }

    onFacilityChange(facility: string) {
        if (facility !== '') {
            this.selectFacility = true;
            this.dataTransferService.setFacility(facility);
        } else {
            this.selectFacility = false;
            this.dataTransferService.setFacility(null);
        }
    }

    onSubmit() {
        this.submitted = true;
        if (this.loginForm.invalid) {
            return;
        }
        const model = this.loginForm.value;
        model.username = model.username.toUpperCase();
        model.password = model.password.toUpperCase();
        this.loader.spin.next(true);
        this.httpService.Post(urlConstant.Login.Authentication, model).subscribe(response => {

            if (response.Status === 200) {
                if (response.Data && response.Data.length > 0) {
                    if (response.Data.indexOf("04") < 0) {
                        this.commonService.openSnackBar("User not authorized to use this module", "Ok");
                        return;
                    }
                    this.dataTransferService.setlogin(true);
                    this.dataTransferService.setUserName(this.f.username.value.toUpperCase());
                    this.dataTransferService.setFacility(this.f.facility.value.toUpperCase());
                    this.dataTransferService.setObject("LoginDateTime", new Date());

                    this.auth.sendToken(this.loginForm.controls['username'].value.toUpperCase());
                    this.redirectUser(response.Data);
                } else {

                    this.commonService.openSnackBar(response.Message, 'Ok');
                }
                this.loader.spin.next(false);
            } else {
                this.loader.spin.next(false);
                this.commonService.openSnackBar(response.Message, 'Ok');
            }
        }, error => {
            this.loader.spin.next(false);
            this.selectFacility = false;
            this.dataTransferService.errorPage();
        });
    }



    redirectUser(groupCodes: Array<string>) {
        this.dataTransferService.setObject("UserGroup", groupCodes.join(','));
        let AuthorizationModel = {
            "UserName": this.loginForm.controls.username.value.toUpperCase(),
            "UserGroup": groupCodes
        };
        this.httpService.Post(urlConstant.Authorization, AuthorizationModel).subscribe(Response => {
            if (Response.Status == 200 && Response.Message == "Successful") {
                this.dataTransferService.setPermission(Response.Data);
                this.dataTransferService.setUserGroup(groupCodes);
                this.dataTransferService.setObject("AuthorizedModules", groupCodes);
                this.router.navigate(['/billing']);
                this.loader.spin.next(false);
            }
            else {
                this.loader.spin.next(false);
                this.commonService.openSnackBar('Failed', 'Ok');
            }
        });
    }



}


