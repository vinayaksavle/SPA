import { Component, OnInit } from '@angular/core';
import 'rxjs/add/operator/filter';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';

@Component({
  selector: 'app-new-credit-note',
  templateUrl: './new-credit-note.component.html',
  styleUrls: ['./new-credit-note.component.css'],
  host: { 'class': 'section__main' }
})
export class NewCreditNoteComponent implements OnInit {
    displayedColumns = [
        "PackageCode",
        "ServiceCode",
        "ServiceName",
        "Amount",
        "Qty"
      ];

      displayedColumns1 = [
        "Bill No",
        "Bill Date",
        "Folio",
        "Net Bill Amt",
        "Rcvd+CR.Amt",
        "TDS Amt",
        "Rfnd Amt",
        "Net Amt",
      ];
      billListDetails;
      chargeListDetails;
      doctorserviceListDetails;
       constructor(private fb: FormBuilder, private commonService: CommonService,
        private dataService: DataTranferService, private httpService: HttpService) {
      }  
    ngOnInit(): void {
     }
  

}