import { Component, OnInit, ViewChild, HostBinding, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { messageConstant } from 'src/app/constants/messageConstants';
import { urlConstant } from 'src/app/constants/urlConstants';
import { patientCategoryConstant } from 'src/app/constants/patientCategoryConstants';
import { isNullOrUndefined } from 'util';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';
import { MatDialogRef, MatTableDataSource } from '@angular/material';
import { FromDateToDateComponent } from 'from-date-to-date';
import { ParseDate } from 'shared-utility';
@Component({
  selector: 'app-allow-to-go',
  templateUrl: './allow-to-go.component.html',
  styleUrls: ['./allow-to-go.component.css'],
  host: { 'class': 'section__main' },

})
export class AllowToGoComponent implements OnInit, AfterViewInit {
  allowToGoForm: FormGroup;
  currentDate: string;
  currentTime: string;
  discStatusList = [
    { value: 'D', viewValue: 'DISCHARGED' },
    { value: 'E', viewValue: 'EXPIRED' },
    { value: 'M', viewValue: 'DAMA' },
    { value: 'S', viewValue: 'ABSCOND' },

  ];
  private allowtoGoObject: any = {};
  isPopup: boolean = false;
  regNo: string;
  status: string = "3";
  dischStatus: string = "D";
  @ViewChild('patDetails') patDetailComp: PatientDetailsComponent;
  @ViewChild('fromDateToDate') fromDateToDate: FromDateToDateComponent;

  hiddenItems: any = ['Address', 'FinalButton', 'InterimButton', 'DoctorButton', 'ApprovedAmount',
    'TPA', 'DischDateTime', 'InsCompanyName', 'CompanyName', 'FolioNo'];
  disableItems: any = ['BedNo']
  permissions: any = [];
  canSave: boolean;
  atgGiven: boolean = false;

  atgList: MatTableDataSource<any> = new MatTableDataSource();
  displayedColumns = ["SNo", "RegNo", "PatName", "DiscDate", "Status", "Remark", "User"];
  selectedIndex: number = 0;

  constructor(public fb: FormBuilder, private commonService: CommonService, private httpService: HttpService,
    private loader: LoaderService, public dialogRef: MatDialogRef<AllowToGoComponent>) {
    //#region permission
    this.permissions = JSON.parse(localStorage.getItem('Permission'));

    if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
      // Allow To GO Save Permissons set
      this.canSave = this.permissions.includes('4009') ? true : false;
    }
    //#endregion
  }
  ngAfterViewInit(): void {
    if (this.isPopup && this.commonService.isValidStringValue(this.regNo)) {
      this.patDetailComp.setPatientDetailByRegNo(this.regNo, true);
    }
    // Using View Child after the view initialization
    this.search();
  }

  ngOnInit() {
    this.discStatusList = patientCategoryConstant.getPatientStatus().filter(d => d.DBValue !== 'A');
    this.initForm();
    
    // this.f.Status.setValue(this.status);
    // this.f.DiscStatus.setValue(this.dischStatus);
  }

  @HostBinding('class.full') get valid() { return this.isPopup; }

  // initialize form
  initForm() {
    this.allowToGoForm = this.fb.group({
      PatientRegNo: ['', Validators.required],
      PatientName: [{ value: '', disabled: true }],
      Category: [{ value: '', disabled: true }],
      AdmDate: [{ value: '', disabled: true }],
      RoomNo: [{ value: '', disabled: true }],
      BedNo: [{ value: '', disabled: true }],
      BedType: [{ value: '', disabled: true }],
      DiscDate: [{ value: '', disabled: true }],
      DiscTime: [{ value: '', disabled: true }],
      DiscStatus: [this.dischStatus],
      Status: [this.status],
      UserId: [localStorage.getItem("UserName")],
      Remark: ['', Validators.required],
      Discharge: ['AllowToGo'],
      DiscOnADM: false,
      DiscOnNmADM: false,
      Phone: '',
      Date: [{ value: new Date(), disabled: true }],
      Time: [this.commonService.getCurrentTime()]
    });


  }

  // the function returns the form controls to access in both files.
  public get f() {
    return this.allowToGoForm.controls;
  }

  // sets patient details on event emit
  setPatientDetail(patient: any, patDetails?: any) {
    if (!this.commonService.isValidStringValue(patient.RegNo)) {
      this.resetform();
      return;
    }


    this.allowToGoForm.patchValue({
      "PatientRegNo": patient.RegNo, "PatientName": patient.PatientName, "BedNo": patient.BedNo,
      "RoomNo": patient.RoomNo, "AdmitDate": patient.AdmitDate, "Category": patient.PatientCategoryCode, "Phone": patient.MobileNo
    });

    if (this.commonService.isValidStringValue(patient.Pexpdate)) {

      let param = { "RegNo": patient.RegNo };
      this.httpService.Post(urlConstant.AllowToGo.GetAllowToGo, param).subscribe(resp => {
        if (resp && resp.Data) {
          this.f.Remark.setValue(resp.Data[0].Remarks);
          this.f.UserId.setValue(patient.Pexpdate);
          let isAtg = resp.Data[0].TStatus === 'O';
          this.f.Discharge.setValue(isAtg ? 'AllowToGo' : 'DiscOnAdm');
          this.f.DiscOnADM.setValue(isAtg);
          this.f.DiscOnNmADM.setValue(!isAtg);
          this.f.Remark.disable();
          this.f.Discharge.disable();
          this.f.DiscStatus.disable();
          this.f.Time.setValue(resp.Data[0].DischargeTime);
          this.f.Date.setValue(this.commonService.convertStringToDate(resp.Data[0].DischargeDate));
        }
      });
      this.atgGiven = true;
      this.commonService.displayPromptMessage('Allow To Go [ ATG ]', "Allow to go already given by " + patient.Pexpdate);
    }
    else {
      this.httpService.Get(urlConstant.AllowToGo.GetCreditPatientDetails(this.f.PatientRegNo.value, this.f.DiscOnADM.value)).
        subscribe(response => {
          if (response && !response.Data) {
            this.commonService.displayPromptMessage('Allow To Go [ ATG ]', "Final bill not Prepared for the Patient");
            this.resetform(patDetails);
          }
        });
    }
  }

  // Reprint ATG
  rePrintATG(patDetails: any) {
    this.commonService.confirmAction("Print ATG", "Do you want ATG print ?").subscribe(response => {
      if (response) {
        this.createAllowToGoObject();
        this.printATGSlip();
        // this.resetform(patDetails);
      }
    })
  }

  // change radio button
  onChangeSourceType(discType: string): void {
    if (discType === 'DiscOnAdm') {
      this.f.DiscOnADM.setValue(true);
    } else if (discType === 'DiscOnNmAdm') {
      this.f.DiscOnNmADM.setValue(false);
      this.f.DiscOnNmADM.setValue(true);
    } else {
      this.f.DiscOnNmADM.setValue(false);
      this.f.DiscOnNmADM.setValue(false);
    }
  }

  //validates form before saving
  validateForm(): boolean {
    if (!this.commonService.isValidStringValue(this.f.PatientRegNo.value)) {
      this.commonService.openSnackBar(messageConstant.AllowToGo.RegNoRequired,
        messageConstant.invalidMessages.OK);
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.Remark.value)) {
      this.commonService.openSnackBar(messageConstant.AllowToGo.RemarkRequired,
        messageConstant.invalidMessages.OK);
      return false;
    }

    if (this.f.Remark.value.length > 40) {
      this.commonService.openSnackBar("Remark length cannot be greater than 40!",
        messageConstant.invalidMessages.OK);
      return false;
    }

    return true;
  }

  // save allow to go details
  saveAllowToGo(patDetails?: any) {
    if (!this.validateForm()) return;
    this.createAllowToGoObject();

    this.commonService.confirmAction(messageConstant.AllowToGo.Header, messageConstant.AllowToGo.SaveConfirm).
      subscribe(response => {
        if (response) {
          this.loader.spin.next(true);
          this.httpService.Post(urlConstant.AllowToGo.SaveAllowToGo(), this.allowtoGoObject).
            subscribe(result => {
              if (result && result.Status === 200) {
                this.loader.spin.next(false);
                this.commonService.displayPromptMessage(messageConstant.AllowToGo.Header, 'Details saved successfully.');
                this.resetform(patDetails);
                this.printATGSlip();
              } else {
                this.loader.spin.next(false);
                this.commonService.displayPromptMessage(messageConstant.AllowToGo.Header, 'Error while saving details');
                this.resetform(patDetails);
              }


            });
        }
        else { return; }
      });
  }

  printATGSlip() {
    this.loader.spin.next(true);
    // this.allowtoGoObject["PrintType"] ="Patient";
    this.httpService.Post(urlConstant.AllowToGo.PrintATGSlip, this.allowtoGoObject).subscribe(
      res => {
        this.httpService.openFile(res.Data);
        this.loader.spin.next(false);
        if (this.isPopup) {
          this.dialogRef.close(true);
          //this.closeDialog();
        }
      });

  }

  // create json to save details
  createAllowToGoObject() {
    this.allowtoGoObject.RegNo = this.f.PatientRegNo.value;
    this.allowtoGoObject.DiscStatus = this.f.DiscStatus.value;
    this.allowtoGoObject.DiscTime = '';
    this.allowtoGoObject.DiscDate = '';
    this.allowtoGoObject.RoomNo = this.f.RoomNo.value;
    this.allowtoGoObject.BedNo = this.f.BedNo.value;
    this.allowtoGoObject.Remarks = this.f.Remark.value;
    this.allowtoGoObject.UserID = localStorage.getItem("UserName");
    this.allowtoGoObject.DiscOnADM = this.f.DiscOnADM.value;
    this.allowtoGoObject.DiscOnNmADM = this.f.DiscOnNmADM.value;
    this.allowtoGoObject.PatientName = this.f.PatientName.value;
    this.allowtoGoObject.Status = this.f.Status.value;
    this.allowtoGoObject.Phone = this.f.Phone.value;
  }
  // reset form
  resetform(patDetails?: any) {
    this.initForm();
    this.patDetailComp.clearPatientLookup();
    setTimeout(() => {
      this.f.Remark.enable();
      this.f.Discharge.enable();
      this.f.DiscStatus.enable();
    }, 1000);
    this.atgGiven = false;
    // window.location.reload();
  }


  closeDialog() {
    this.dialogRef.close(false);
  }

  setDischargeStatus(event: any, items: any) {

    if (!event.isUserInput)
      return;


    this.f.Status.setValue(items.value)
  }

  exportToExcel() { }

  highlightSelectedRow() { }

  search() {
    if(this.isPopup)
    {
      return;
    }
    let param = { FromDate: new ParseDate().transform(this.fromDateToDate.FromDate.value), ToDate: new ParseDate().transform(this.fromDateToDate.ToDate.value) };
    this.httpService.Post(urlConstant.AllowToGo.GetAllowToGo, param)
      .subscribe(response => {
        this.atgList = new MatTableDataSource<any>(response.Data);
      })
  }

  reset() {
    this.fromDateToDate.FromDate.setValue(new Date());
    this.fromDateToDate.ToDate.setValue(new Date());
    this.search();
  }
}
