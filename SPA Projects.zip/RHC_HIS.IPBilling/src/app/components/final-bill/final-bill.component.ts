import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-final-bill',
  templateUrl: './final-bill.component.html',
  styleUrls: ['./final-bill.component.css'],
  host: { 'class': 'section__main' }
})
export class FinalBillComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
