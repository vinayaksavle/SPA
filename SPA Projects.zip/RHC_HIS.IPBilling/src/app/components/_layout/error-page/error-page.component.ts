import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

@Component({
  selector: 'app-error-page',
  templateUrl: './error-page.component.html',
  styleUrls: ['./error-page.component.css'],
})
export class ErrorPageComponent implements OnInit {
  status: string;
  errMsg: string;
  errorInfoMessage: string;
  errorInfoMessageDetails: string;
  showmore: boolean = false;
  constructor(public dialogRef: MatDialogRef<ErrorPageComponent>, @Inject(MAT_DIALOG_DATA) public catchError: any) { }

  ngOnInit() {
    this.status = "";
    this.errMsg = ""; 
    this.errMsg = "Error occurred, please contact administrator !"; 
    this.errorInfoMessage = this.catchError.key.error.Message;
    this.errorInfoMessageDetails = this.catchError.key.error.MessageDetail;


  }

  clearData(): void {
    this.dialogRef.close();
  }

  toggleShow() {

    this.showmore = !this.showmore;

  }
}
