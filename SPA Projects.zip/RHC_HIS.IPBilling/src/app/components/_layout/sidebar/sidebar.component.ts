import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { DataTranferService } from '../../../services/data-transfer.service';
import { HttpService } from '../../../services/http.service';
import { isNullOrUndefined } from 'util';
import { ActivatedRoute, Router } from '@angular/router';
import hotkeys from 'hotkeys-js';

@Component({
    selector: 'sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.css'],
    host: { 'class': 'section__sidenav' }
})
export class SidebarComponent implements OnInit {
    userAccess: any;
    urlMenu = "dashboard";
    showToken: boolean;
    moduleId: string;
    userGroups: string[] = [];
    // permissions
    permissions: any[];
    canViewMaster: boolean;
    canViewEstimate:boolean;
    constructor(private dataTransferService: DataTranferService, private httpService: HttpService, public route: ActivatedRoute, private router: Router) { 
        
        //#region Permission Section
        this.permissions = JSON.parse(localStorage.getItem('Permission'));
        // Export to excel
        if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
            this.canViewMaster = this.permissions.includes('400');
            this.canViewEstimate = this.permissions.includes('4010');
        }
    }

    ngOnInit(): void {
        this.moduleId = JSON.parse(localStorage.getItem('moduleId'))[0];
        this.showSubMenu(localStorage.getItem("SideMenu"));
    }

    isModuleAuthorized(moduleId: string) {
        // return this.userGroups.indexOf(moduleId.trim()) > -1;
        return this.moduleId === moduleId;
    }

    CheckPermission(moduleId: string): boolean {
        return this.dataTransferService.checkAccessRights(moduleId);
    }

    showSubMenu(val: string): void {
        localStorage.setItem("SideMenu", val);
        if (!isNullOrUndefined(val) && val.length > 0 && !isNullOrUndefined(document.getElementById(val))) {
            document.getElementById(val).style.left = '0';
        }
    }


    hideSubMenu(val: string): void {
        localStorage.removeItem("SideMenu");
        if (!isNullOrUndefined(val) && val.length > 0 && !isNullOrUndefined(document.getElementById(val))) {
            document.getElementById(val).style.left = '-150px';
        }
    }

    highlightMenu() {
        let urlValue: any = (!isNullOrUndefined(this.route.children[0])) ? this.route.children[0].url : null;
        this.urlMenu = "";
        if (isNullOrUndefined(urlValue)) {
            return;
        }
        //console.log(urlValue.value);//UrlSegment
        if (urlValue.value.length >= 1) {

            if (urlValue.value[0].path === "search") {
                this.urlMenu = "search";
            }

            else if (urlValue.value[0].path === "ipd") {
                this.showSubMenu('ipd');
                this.urlMenu = "ipd";
            }

        }
    }

    redirect(subModule, route) {
        this.router.navigateByUrl('' + route);
        setTimeout(() => {
            this.showSubMenu(subModule)
        }, 100)
    }

}
