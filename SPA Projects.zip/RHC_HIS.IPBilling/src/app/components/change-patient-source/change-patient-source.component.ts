import { Component, OnInit, ViewChildren, QueryList, ViewChild, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatTableDataSource } from '@angular/material';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';

@Component({
  selector: 'app-change-patient-source',
  templateUrl: './change-patient-source.component.html',
  styleUrls: ['./change-patient-source.component.css'],
  host: { 'class': 'section__main' },
})
export class ChangePatientSourceComponent implements OnInit, AfterViewInit {
  services = new MatTableDataSource();
  displayedColumns: any = ['Date and Time', 'Department', 'Service-Package Name', 'Quantity',
    'Current Price', 'New Price', 'Multiple Doctor'];
  hiddenItems: any = ['Address', 'FinalButton', 'InterimButton', 'DoctorButton', 'ApprovedAmount',
    'TPA', 'DischDateTime', 'InsCompanyName', 'CompanyName', 'AdmitDateTime'];
  total: string = "0.00";
  VoucherNo: string = "";
  selectedRowIndex: number = -1;
  selectedRowData: any = {};
  patient: any = {};
  doctorList: any = [];
  formDetails: any = {};
  serviceDetails: any = [];
  @ViewChild('patientDetailComponent') patientDetailComponent: PatientDetailsComponent;

  constructor(public fb: FormBuilder, private commonService: CommonService, private httpService: HttpService,
    private loader: LoaderService,) { }

  ngOnInit() {
  }

  ngAfterViewInit(): void {
    const localStoragePatientDetails = JSON.parse(localStorage.getItem("CSCPatientDetails"));
    if (localStoragePatientDetails != null) {
      this.patientDetailComponent.setPatientDetailByRegNo(localStoragePatientDetails.RegNo);
      this.setPatientDetail(localStoragePatientDetails);
      localStorage.removeItem("CSCPatientDetails");
    }
  }

  /**
    * click action on button save
    */
  saveDetails() {
    if (!this.commonService.isValidStringValue(this.VoucherNo)) {
      this.commonService.openSnackBar("Voucher cannot be blank", "Ok");
      return;
    }


    if (this.VoucherNo.length > 2) {
      this.commonService.openSnackBar("Voucher number length cannot be greater than 2", "Ok");
      return;
    }

    this.commonService.confirmAction("Change patient category", "Do you want to post services ?").subscribe(response => {
      if (response) {
        let services = this.services.data.filter((s: any) => s.Amount.trim() !== s.NewAmount.trim());

        if (services.length > 0) {
          var postData = this.formDetails;

          postData["Voucher"] = this.VoucherNo;
          postData["IsCategoryChanged"] = true;
          postData["Services"] = services;

          this.loader.spin.next(true);
          this.httpService.Post(urlConstant.ServicePosting.SaveService(), postData)
            .subscribe(response => {
              this.loader.spin.next(false);
              this.resetAll();
              this.commonService.displayPromptMessage("Change patient category", "Services posted successfully !").subscribe();
            });
        }
        else {
          this.commonService.displayPromptMessage("Change patient category", "No services to post !").subscribe();
        }
      }
    });

  }


  resetForm() {
    this.commonService.confirmAction("Convert service charges", "Do you want to reset?")
      .subscribe(res => {
        if (res) {
          this.resetAll();
        }
      });
  }

  /**
   * click action on reset button 
   */
  resetAll() {
    this.patientDetailComponent.clearPatientLookup();
    this.services = new MatTableDataSource([]);
    this.total = "0.00";
    this.VoucherNo = "";
    this.selectedRowIndex = -1;
    this.selectedRowData = {};
    this.patient = {};
    this.doctorList = [];
    this.formDetails = {};
  }




  setPatientDetail(patient: any) {

    if (this.commonService.isValidStringValue(patient.RegNo)) {
      this.patient = patient;
      this.formDetails = {
        "RegNo": patient.RegNo, "PatientCategory": patient.PatientCategoryCode,
        "PatientSource": patient.CategorySource, "BedCategory": patient.BedCategory,
        "FolioNo": patient.FolioNo
      };
      this.getServices(this.formDetails);
    }
    else {
      this.resetAll();
    }

  }

  getServices(param: any) {
    this.loader.spin.next(true);
    this.httpService.Post(urlConstant.ServicePosting.GetUpdatedServiceCost(), param)
      .subscribe(response => {
        this.serviceDetails = response.Data;
        this.services = new MatTableDataSource(response.Data);
        this.calculateTotalAmount();
        this.loader.spin.next(false);

      })
  }

  calculateTotalAmount() {
    this.total = this.services.data.map((d: any) => parseFloat(d.NewAmount)).reduce((prev, curr) => prev + curr, 0).toFixed(2);
  }

  //To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex != index) {
      this.selectedRowIndex = index;
    }
    this.doctorList = rowDetails.ServiceDoctors;
  }





  // converts mutiple doctor string to doctor list
  // gets concated doctor code and amount string 
  getMultipleDoctorString(index: number) {
    this.doctorList[index].Amount = this.commonService.formatAmount(this.doctorList[index].Amount);
    this.services.data[this.selectedRowIndex]["MultipleDoctor"] = this.doctorList
      .map(d => d.Code + " ₹ " + d.Amount).join();
    this.services = new MatTableDataSource(this.services.data);
  }

  formatServiceAmount(index, amount) {

    if (parseFloat(amount) < parseFloat(this.serviceDetails[index].NewRate)) {
      this.commonService.displayPromptMessage("Change patient category", "New service amount cannot be smaller than" + this.serviceDetails[index].NewRate + "!").subscribe();
      this.services.data[index]["NewAmount"] = this.serviceDetails[index].NewRate;
    }
    else
      this.services.data[index]["NewAmount"] = this.commonService.formatDecimalAmount(amount);
    this.services = new MatTableDataSource(this.services.data);
    this.calculateTotalAmount();
  }

  setFolio(folioNo: string) {
    if (this.commonService.isValidStringValue(this.formDetails.FolioNo)
      && this.formDetails.FolioNo !== folioNo) {
      this.formDetails.FolioNo = folioNo;
      this.getServices(this.formDetails);
    }
  }
}