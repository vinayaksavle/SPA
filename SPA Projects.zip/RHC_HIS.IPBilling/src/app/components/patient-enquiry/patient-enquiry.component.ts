import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { PatientEnquiryComponent as LibPatientEnquiryComponent } from 'patient-enquiry';
import { isNullOrUndefined } from 'util';
@Component({
  selector: 'app-patient-enquiry',
  template: '<lib-patient-enquiry #patientEnquiry></lib-patient-enquiry>',
  styleUrls: ['./patient-enquiry.component.css']
})
export class PatientEnquiryComponent implements AfterViewInit {

  @ViewChild('patientEnquiry') patientEnquiry: LibPatientEnquiryComponent;

  constructor() { }
  isPopup: boolean = false;
  patientName: string = "";

  ngAfterViewInit(): void {
    this.patientEnquiry.isPopup = this.isPopup;
    if (!isNullOrUndefined(this.patientName) && this.patientName.trim() != "")
    {
      this.patientEnquiry.f.DateChecker.setValue(false);
      this.patientEnquiry.f.Name.setValue(this.patientName);
      this.patientEnquiry.getPatient();
    }
     
  }
}
