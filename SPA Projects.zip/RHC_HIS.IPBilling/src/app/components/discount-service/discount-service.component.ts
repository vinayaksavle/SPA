import { Component, OnInit } from '@angular/core';
import { MatDialogRef, MatTableDataSource } from '@angular/material';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';

@Component({
  selector: 'app-discount-service',
  templateUrl: './discount-service.component.html',
  styleUrls: ['./discount-service.component.css']
})
export class DiscountServiceComponent implements OnInit {

  regNo: string = "";
  billNo: string = "";
  discountServiceList: MatTableDataSource<any> = new MatTableDataSource();

  displayedColumns = ["SNO", "DptCode", "ServCode", "Amount", "Discount"];
  constructor(private commonService: CommonService, private httpService: HttpService,
    public dialogRef: MatDialogRef<DiscountServiceComponent>) { }

  ngOnInit() {
    this.getDiscountServices();
  }


  getDiscountServices() {
    if(!this.commonService.isValidStringValue(this.regNo))
    return;
    this.httpService.Get(urlConstant.Billing.GetTPAServices(this.regNo, this.billNo))
      .subscribe(response => {
        this.discountServiceList = new MatTableDataSource<any>(response.Data);
      })
  }

  closeDialog() {
    this.dialogRef.close();
  }

}
