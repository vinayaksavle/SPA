import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { urlConstant } from 'src/app/constants/urlConstants';
import { HttpService } from 'src/app/services/http.service';
import { ParseDate } from 'shared-utility';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';
import { PatientFolioComponent } from '../../patient-folio/patient-folio.component';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-discharged-patient-query',
  templateUrl: './discharged-patient-query.component.html',
  styleUrls: ['./discharged-patient-query.component.css'],
  host: { 'class': 'section__main' }
})

export class DischargedPatientQueryComponent implements OnInit {
  @ViewChild('date') date;
  @ViewChild('patientSource') patientSource;
  totalBillAmount: number = 0.00;
  totalPaidAmount: number = 0.00;
  totalDueAmount: number = 0.00;
  totalUnBilledAmount: number = 0.00;
  index = -1;
  DischargedPatientForm: FormGroup;
  patientList: MatTableDataSource<any> = new MatTableDataSource([]);
  displayedColumnsList: string[] = ['RegNo', 'Name', 'DischargeDate', 'BillAmount', 'PaidAmount', 'DueAmount', 'UnBilledAmount', 'PatientSourceCode', 'CrCode', 'TPACode', 'LetterDetails'];
  constructor(public fb: FormBuilder, public httpService: HttpService, public loader: LoaderService, public dialog: MatDialog ) { }

  initializeForm() {
    this.DischargedPatientForm = this.fb.group({
      FromDate: [new Date(), Validators.required],
      ToDate: [new Date(), Validators.required],
      Category: [""],
      BillType: ["WITHOUTDUE"]
    })
  }

  get f() {
    return this.DischargedPatientForm.controls;
  }

  ngOnInit() {
    this.initializeForm();
  }

  // sets from date and to date from library element
  setDate(event) {
    if (!isNullOrUndefined(event)) {
      this.f.FromDate.setValue(new Date(event.FromDate.value).toLocaleDateString());
      this.f.ToDate.setValue(new Date(event.ToDate.value).toLocaleDateString());
    }
  }

  setPatientSource(event) {
    if (!isNullOrUndefined(event.Code))
      this.f.Category.setValue(event.Code);
    else
      this.f.Category.setValue("");
  }

  // Modified By - Vinayak Savale
  // Get Discharge Patients Report
  getDischPatReports() {
    this.loader.spin.next(true);
    const input = this.DischargedPatientForm.getRawValue();
    this.httpService.Post(urlConstant.Reports.DischargedPatientsReport(), input).subscribe(response => {
      if (response.Status === 200) {
        console.log(response.Data);
        this.patientList = new MatTableDataSource(response.Data);
        this.totalBillAmount = response.Data.map(x => parseFloat(x.BillAmount != null ? x.BillAmount : 0)).reduce((prev, curr) => prev + curr, 0).toFixed(2);
        this.totalPaidAmount = response.Data.map(x => parseFloat(x.PaidAmount != null ? x.PaidAmount : 0)).reduce((prev, curr) => prev + curr, 0).toFixed(2);
        this.totalDueAmount = response.Data.map(x => parseFloat(x.DueAmount != null ? x.DueAmount : 0)).reduce((prev, curr) => prev + curr, 0).toFixed(2);
        this.totalUnBilledAmount = response.Data.map(x => parseFloat(x.UnBilledAmount != null ? x.UnBilledAmount : 0)).reduce((prev, curr) => prev + curr, 0).toFixed(2);
        this.loader.spin.next(false);
      } else {
        this.totalBillAmount = 0.00;
        this.totalPaidAmount = 0.00;
        this.totalDueAmount = 0.00;
        this.totalUnBilledAmount = 0.00;
        this.loader.spin.next(false);
      }
      this.loader.spin.next(false);
    });
  }

  clearSearch(patientSource) {
    patientSource.myControl.setValue('');
    this.patientList = new MatTableDataSource([]);
    this.initializeForm();
  }

  exportToExcel() {
    this.loader.spin.next(true);
    const input = this.DischargedPatientForm.getRawValue();
    this.httpService.Post(urlConstant.Reports.ExportDischargedPatientsReport(), input).subscribe(response => {
      if (response && !isNullOrUndefined(response.Data) && response.Data.length > 0) {
        this.httpService.exportToExcel(response.Data);
        this.loader.spin.next(false);
      }
    }, (error) => {
      this.loader.spin.next(false);
      console.error(error);
    });
  }

  highlightRow(index, row) {
    if(index !== this.index) {
      this.index = index;
      // this.openPatientFolio(row);
    } else {
      this.index = -1;
    }
  }

    //open patient folio
    openPatientFolio(selectedIndex, row) {
      this.index = selectedIndex;
      const dialogRef = this.dialog.open(PatientFolioComponent, {
        disableClose: true,
      });
  
      dialogRef.componentInstance.isPopup = true;
      dialogRef.componentInstance.regNo = row.RegNo;
  
      dialogRef.afterClosed().subscribe();
    }
}
