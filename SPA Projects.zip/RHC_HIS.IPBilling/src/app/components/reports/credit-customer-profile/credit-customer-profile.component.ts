import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSort, MatTableDataSource } from '@angular/material';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { ParseDBDateToDOBPipe } from 'shared-utility/lib/pipes/parse-dbDate-to-dob.pipe';
import { LoaderService } from 'src/app/services/loader.service';
import { ParseDate } from 'shared-utility';
import { FormControl } from '@angular/forms';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-credit-customer-profile',
  templateUrl: './credit-customer-profile.component.html',
  styleUrls: ['./credit-customer-profile.component.css'],
  host: { 'class': 'section__main' },
})
export class CreditCustomerProfileComponent implements OnInit {
  compCode: any;
  @ViewChild('date') date;
  @ViewChild('company') company;
  @ViewChild(MatSort) sort: MatSort;
  fromDate: any;
  toDate: any;
  BillNo = new FormControl('');
  public displayedColumnsList: string[] = ['BillNo', 'BillDate', 'RegNo', 'PatientName', 'BillAmount', 'ReceivedAmount','RefundAmount','CNAmount', 'DueAmount','TPAmount','SponsorAmount'];
  creditCompanyList: MatTableDataSource<any> = new MatTableDataSource([]);
  billAmount: string = "0.00";
  rcvdAmount: string = "0.00";
  rfndAmount: string = "0.00";
  cnAmount: string = "0.00";
  dueAmount: string = "0.00";

  constructor(private commonService: CommonService, private httpService: HttpService, public loader: LoaderService) { }

  ngOnInit() {
    this.fromDate = this.date.FromDate.value;
    this.toDate = this.date.ToDate.value;
    this.company.myControl.setValue('');
    this.compCode = this.company.myControl.value;
  }

  onSubmit() {
    if (!this.commonService.isValidStringValue(this.compCode)) {
      this.commonService.openSnackBar("Enter Company Code", "Ok");
      return;
    }

    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.Reports.CreditCompanyReport(new ParseDate().transform(this.fromDate),
      new ParseDate().transform(this.toDate), this.compCode, this.BillNo.value)).subscribe(response => {
        if (response.Status == 200 && response.Data.length > 0) {
          this.creditCompanyList = new MatTableDataSource(response.Data);

          this.billAmount = response.Data.map(d=>parseFloat(d.BillAmount)).reduce((prev, next) => prev + next);
          this.rcvdAmount = response.Data.map(d=>parseFloat(d.ReceivedAmount)).reduce((prev, next) => prev + next);
          this.rfndAmount = response.Data.map(d=>parseFloat(d.RefundAmount)).reduce((prev, next) => prev + next);
          this.cnAmount = response.Data.map(d=>parseFloat(d.CNAmount)).reduce((prev, next) => prev + next);
          this.dueAmount = response.Data.map(d=>parseFloat(d.DueAmount)).reduce((prev, next) => prev + next);


          this.creditCompanyList.sort = this.sort;
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
        }
      }, (error) => {
        this.loader.spin.next(false);
      });
  }

  clearSearch(date, company) {
    date.FromDate.setValue(new Date);
    date.ToDate.setValue(new Date);
    company.myControl.setValue('');
    this.compCode = "";
    this.creditCompanyList = new MatTableDataSource();
  }

  exportToExcel() {
    this.httpService.Get(urlConstant.Reports.ExportCreditCompanyReport(new ParseDate().transform(this.fromDate),
      new ParseDate().transform(this.toDate), this.compCode, this.BillNo.value)).subscribe(response => {
        this.loader.spin.next(true);
        if (response.Status == 200) {
          this.httpService.exportToExcel(response.Data);
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
        }
      }, (error) => {
        this.loader.spin.next(false);
      });
  }

  getDate() {
    this.fromDate = this.date.FromDate.value;
    this.toDate = this.date.ToDate.value;
  }

  getCompany(event) {
    if (!isNullOrUndefined(event.CompanyCode))
      this.compCode = event.CompanyCode;
    else
      this.compCode = '';
  }

}
