import { Component, OnInit, ViewChild } from '@angular/core';
import { isNullOrUndefined } from 'util';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { MatTableDataSource } from '@angular/material';
import { urlConstant } from 'src/app/constants/urlConstants';

@Component({
  selector: 'app-department-wise-settled-bills',
  templateUrl: './department-wise-settled-bills.component.html',
  styleUrls: ['./department-wise-settled-bills.component.css'],
  host: { 'class': 'section__main' }
})
export class DepartmentWiseSettledBillsComponent implements OnInit {
  DepartmentWiseSettledBillsForm: FormGroup;
  DepartmentWiseSettledBills: MatTableDataSource<any> = new MatTableDataSource([]);
  maxDate: any = new Date();
  @ViewChild('date') date;
  displayedColumnsList: string[] = ['RegNo', 'PatName', 'BillAmt', 'ServiceName', 'SettlementDate','RcptDt', 'SrcName', 'DisConcessionAmt', 'BillNo'];

  constructor(public fb: FormBuilder, private common: CommonService, private httpService: HttpService) { }

  ngOnInit() {
    this.initializeForm();
  }

  initializeForm() {
    this.DepartmentWiseSettledBillsForm = this.fb.group({
      ServiceFromDate: [new Date(2014, 4, 30), Validators.required],
      FromDate: [new Date(), Validators.required],
      ToDate: [new Date(), Validators.required],
      DeptCode: [''],
      DisplayValue: ['']
    });
  }

  get f() {
    return this.DepartmentWiseSettledBillsForm.controls;
  }

  getDate() {
    this.f.FromDate.setValue(this.date.FromDate.value);
    this.f.ToDate.setValue(this.date.ToDate.value);
  }

  // sets department value 
  setDepartment(event: any) {
    if (!isNullOrUndefined(event.DepartmentCode)) {
      this.f.DeptCode.setValue(event.DepartmentCode);
      this.f.DisplayValue.setValue(event.DisplayValue);
    }
  }

  onClear() {
    this.ngOnInit();
  }

  onSubmit() {

    if (!this.validateForm()) return;

    const input = this.DepartmentWiseSettledBillsForm.getRawValue();
    this.httpService.Post(urlConstant.Reports.DepartmentWiseSettledBillsReport(), input).subscribe(response => {
      if (response.Status === 200) {
        console.log(response);
        this.DepartmentWiseSettledBills = new MatTableDataSource(response.Data);
      }
    });

  }

  // Export to Excel
  exportToExcel() {

    if (!this.validateForm()) return;

    const input = this.DepartmentWiseSettledBillsForm.getRawValue();

    this.httpService.Post(urlConstant.Reports.ExportExcelDepartmentWiseSettledBillsReport(), input).subscribe(response => {
      if (response.Status === 200) {
        this.httpService.exportToExcel(response.Data);
      }
    });
  }

  validateForm() {
    if (this.f.FromDate.value < this.f.ServiceFromDate.value) {
      this.common.openSnackBar("Invalid Dates. Settlement Date Should be Less or Equal to Billdate", "Ok");
      return false;
    }

    if (!this.common.isValidStringValue(this.f.DeptCode.value)) {
      this.common.openSnackBar("Invalid Department. Select Department", "Ok");
      return false;
    }

    return true;
  }

}
