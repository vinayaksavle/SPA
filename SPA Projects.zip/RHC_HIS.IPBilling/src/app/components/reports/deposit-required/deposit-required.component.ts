import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { LoaderService } from 'src/app/services/loader.service';
import { HttpService } from 'src/app/services/http.service';
import { MatTableDataSource } from '@angular/material';
import { WardLookupComponent } from 'ward-lookup';
import { PatientSourceDropdownComponent } from 'patient-source-dropdown';
import { urlConstant } from 'src/app/constants/urlConstants';
import { ParseDate } from 'shared-utility';
import { CommonService } from 'src/app/services/common.service';
import { isNullOrUndefined } from 'util';
import { MatSort } from '@angular/material';
import { MatDialog } from '@angular/material';
import { PatientFolioComponent } from '../../patient-folio/patient-folio.component';
import { common } from 'src/app/common/common';
import { isMoment } from 'moment';

@Component({
  selector: 'app-deposit-required',
  templateUrl: './deposit-required.component.html',
  styleUrls: ['./deposit-required.component.css'],
  host: { 'class': 'section__main' }

})
export class DepositRequiredComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('wardNo') wardNo: WardLookupComponent;
  @ViewChild('patientCategory') patientCategory: PatientSourceDropdownComponent;

  DepositRequiredForm: FormGroup;
  maxDate = new Date();
  floatLabel = 'always';
  selectedRowData: any;
  selectedRowIndex: number = -1;
  patientList: MatTableDataSource<any> = new MatTableDataSource();
  public displayedColumnsList: string[] = ['RegNo', 'Name', 'BedNo', 'AdmitDate', 'TotalBillAmount', 'DepositAmount',
    'BalanceAmount', 'PatCatgName', 'CreditCompany', 'BillEstimate', 'ContactNo', 'RelativeName', 'RelativeNo', 'DoctorName'];
  totalDepositAmount: any = '0.00';
  totalBalanceAmount: any = '0.00';
  totalBillAmount: any = '0.00';

  constructor(public fb: FormBuilder, private loader: LoaderService, private httpService: HttpService,
    private commonService: CommonService, private dialog: MatDialog) { }

  ngOnInit() {
    this.initForm();
  }

  initForm() {
    this.DepositRequiredForm = this.fb.group({
      BalanceAmount: ['10000'],
      DateChecker: [false],
      AdmissionDate: [{ value: new Date(), disabled: true }],
      IsAllInPatients: [false],
      WardNo:[''],
      PatientCategory:[''],
      OrderBy:['']
    });
  }

  // on click of date checker checkbox
  enableDate() {
    if (this.f.DateChecker.value){
      this.f.AdmissionDate.enable();
    }
    else{
      this.f.AdmissionDate.disable();
    }
  }

  get f() {
    return this.DepositRequiredForm.controls;
  }

  // To highlight selected row
  highlightSelectedRow(index) {
    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }

  // on double click open patient folio
  openPatientFolio(index, rowDetails) {
    this.selectedRowData = rowDetails;
    const dialogRef = this.dialog.open(PatientFolioComponent, {
      maxHeight: '650px',
      disableClose: true,
      minWidth: '88vw',
    });

    dialogRef.componentInstance.isPopup = true;
    dialogRef.componentInstance.regNo = this.selectedRowData.RegNo;

    dialogRef.afterClosed().subscribe();
  }

  exportToExcel() {
    this.loader.spin.next(true);
    this.httpService.Post(urlConstant.Reports.DepositRequired.GetDepositDetailsExcel,this.createObject()).subscribe(response => {
        if (response.Status === 200) {
          //console.log(response);
          this.httpService.exportToExcel(response.Data);
          this.loader.spin.next(false);
        } else{
          this.loader.spin.next(false);
        }
      });
  }

  onSubmit() {
    this.loader.spin.next(true);
    this.httpService.Post(urlConstant.Reports.DepositRequired.GetDepositDetails,this.createObject()).subscribe(res => {
        if (!isNullOrUndefined(res)) {
          this.patientList = new MatTableDataSource(res.Data);
          this.patientList.sort = this.sort;
          // Calculate total of Bill, Deposit, Balance Amount
          this.totalBillAmount = parseFloat(this.patientList.data.map(item => item.TotalBillAmount).reduce((prev, next) => parseFloat(prev) + parseFloat(next), 0)).toFixed(2);
          this.totalDepositAmount = parseFloat(this.patientList.data.map(item => item.DepositAmount).reduce((prev, next) => parseFloat(prev) + parseFloat(next), 0)).toFixed(2);
          this.totalBalanceAmount = parseFloat(this.patientList.data.map(item => item.TotalBalanceAmount).reduce((prev, next) => parseFloat(prev) + parseFloat(next), 0)).toFixed(2);
          this.loader.spin.next(false);
        }
        else {
          this.patientList = new MatTableDataSource([]);
          this.loader.spin.next(false);
        }
      }), error => {
        this.loader.spin.next(false);
      };
  }
  createObject():any {
    let obj:any={};
    if (this.commonService.isValidStringValue(this.wardNo.WardNo.value)) {
      this.f.WardNo.setValue(this.wardNo.WardNo.value);
    }
    if(this.commonService.isValidStringValue(this.patientCategory.myControl.value)){
      this.f.PatientCategory.setValue(this.patientCategory.myControl.value);      
    }
    obj=this.DepositRequiredForm.getRawValue();
    if(this.f.DateChecker.value){
      obj.AdmissionDate=new ParseDate().transform(this.f.AdmissionDate.value);
    } else{
      obj.AdmissionDate='';
    }
    return obj;
  }

  onClear() {
    this.initForm();
    this.patientCategory.myControl.setValue('');
    this.wardNo.WardNo.setValue('');
    this.wardNo.BedNo.setValue('');
    this.patientList = new MatTableDataSource();
  }

}
