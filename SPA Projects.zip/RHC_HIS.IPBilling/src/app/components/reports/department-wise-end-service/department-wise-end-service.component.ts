import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { ParseDate } from 'shared-utility';
import { isNullOrUndefined } from 'util';
import { FromDateToDateComponent } from 'from-date-to-date';
import { PatientSourceDropdownComponent } from 'patient-source-dropdown';
import { DepartmentLookupComponent } from 'department-lookup';

@Component({
  selector: 'app-department-wise-end-service',
  templateUrl: './department-wise-end-service.component.html',
  styleUrls: ['./department-wise-end-service.component.css'],
  host: { 'class': 'section__main' },
})
export class DepartmentWiseEndServiceComponent implements OnInit {

  displayedColumnsList: any[] = ['RegistrationNumber', 'PatientName', 'BedNumber', 'AdmissionDate', 'DischageDate', 'ServiceAmount'];
  patientList: MatTableDataSource<any> = new MatTableDataSource([]);
  highLightRow: any;
  @ViewChild('date') date: FromDateToDateComponent;
  @ViewChild('patsrc') patsrc: PatientSourceDropdownComponent;
  @ViewChild('dept') dept: DepartmentLookupComponent;
  TotalAmount: any = 0.00;
  DoctorAmount: any = 0.00;
  NetAmount: any = 0.00;

  constructor(private common: CommonService, private httpService: HttpService, public loader: LoaderService) { }

  ngOnInit() {

  }

  onSubmit() {
    let deptCode = "";
    if (this.common.isValidStringValue(this.dept.myControl.value)) {
      deptCode = this.dept.myControl.value.split(" ")[0];
    }
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.Reports.GetDepartmentWiseServiceDetail
      (new ParseDate().transform(this.date.FromDate.value), new ParseDate().transform(this.date.ToDate.value)
        , this.patsrc.myControl.value, deptCode)).subscribe(response => {
          if (response.Status === 200) {
            this.patientList = new MatTableDataSource(response.Data);
            this.TotalAmount = parseFloat(this.patientList.data[0].TotalServiceAmount).toFixed(2);
            this.DoctorAmount = parseFloat(this.patientList.data[0].DoctorAmount).toFixed(2);
            this.NetAmount = parseFloat(this.patientList.data[0].NetAmount).toFixed(2);
            this.loader.spin.next(false);
          } else {
            this.loader.spin.next(false);
            return;
          }
        });

  }

  exportToExcel() {

    let deptCode = "";
    if (this.common.isValidStringValue(this.dept.myControl.value)) {
      deptCode = this.dept.myControl.value.split(" ")[0];
    }
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.Reports.ExportDepartmentWiseServiceDetail
      (new ParseDate().transform(this.date.FromDate.value), new ParseDate().transform(this.date.ToDate.value)
        , this.patsrc.myControl.value, deptCode)).subscribe(response => {
          if (response && !isNullOrUndefined(response.Data) && response.Data.length > 0) {
            this.httpService.exportToExcel(response.Data);
            this.loader.spin.next(false);
          }
        }, (error) => {
          this.loader.spin.next(false);
          console.error(error);
        });
  }

  clearSearch(date, dept, patsrc) {
    date.FromDate.setValue(new Date);
    date.ToDate.setValue(new Date);
    dept.myControl.setValue('');
    patsrc.myControl.setValue('');
  }


}
