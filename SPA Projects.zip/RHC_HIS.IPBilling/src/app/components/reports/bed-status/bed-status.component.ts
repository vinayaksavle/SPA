import { Component, OnInit } from '@angular/core';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { MatTableDataSource } from '@angular/material';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
  selector: 'app-bed-status',
  templateUrl: './bed-status.component.html',
  styleUrls: ['./bed-status.component.css'],
  host: { 'class': 'section__main' },
})
export class BedStatusComponent implements OnInit {

  public displayedColumnsList: string[] = ['WardNumber', 'BedNumber', 'RegistrationNumber', 'PatientName', 'FinalBillStatus', 'BillDateTime',
    'ATGStatus', 'ATGDateTime', 'PhysicalVacant','Occupied', 'PatientCategoryName'];
  bedStatusList = new MatTableDataSource();

  constructor(private httpService: HttpService, public loader: LoaderService) { }

  ngOnInit() {
  }

  onSubmit() {
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.Reports.GetBedStatusDetails()).subscribe(response => {
      if (response.Status === 200) {
        this.bedStatusList = new MatTableDataSource(response.Data);
        this.loader.spin.next(false);
      } else {
        this.loader.spin.next(false);
      }
    }, (error) => {
      this.loader.spin.next(false);
      console.error(error);
    });
  }

  exportToExcel() {
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.Reports.ExportGetBedStatusDetails()).subscribe(response => {
      if (response.Status === 200) {
        this.httpService.exportToExcel(response.Data);
        this.loader.spin.next(false);
      }
      else {
        this.loader.spin.next(false);
      }
    }, (error) => {
      this.loader.spin.next(false);
      console.error(error);
    });
  }

  clearGrid(){
    this.bedStatusList = new MatTableDataSource([]);
  }
}
