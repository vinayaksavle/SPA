import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { MatTableDataSource, MatDialog, MatFormFieldBase, MatSnackBar } from '@angular/material';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';
import { PatientFolioComponent } from '../../patient-folio/patient-folio.component';
import { ParseDate } from 'shared-utility';
import { PatientSourceMultiselectLookupComponent } from 'patient-source-multiselect-lookup';

@Component({
  selector: 'app-addmitted-patient-latest-bill-list',
  templateUrl: './addmitted-patient-latest-bill-list.component.html',
  styleUrls: ['./addmitted-patient-latest-bill-list.component.css'],
  host: { 'class': 'section__main' },
})
export class AddmittedPatientLatestBillListComponent implements OnInit {
  PatientBillForm: FormGroup;
  @ViewChild('ward') ward;
  wardNo: string;
  bedNo: any;
  rowDetails: any;
  // @ViewChild('patientSource') patientSource;
  patientSource: string ="";
  @ViewChild('patientMultiselect') patientMultiselect : PatientSourceMultiselectLookupComponent;
  patientBillList = new MatTableDataSource();
  maxDate = new Date();
  selectedIndexRow: number;

  public displayedColumnsList: string[] = ['RegNo', 'PatientName', 'AdmitDate','BedNo', 'BillType', 'BillDate', 'BillNo', 'BillAmount',
    'UnBilledAmount', 'Deposit',  'CompnyName', 'PatientSorceName',
    'ApprovedAmount', 'EstimateAmount', 'ContactNumber', 'MediclaimStatus', 'Remark'];

  constructor(private common: CommonService, private httpService: HttpService, private snackBar: MatSnackBar,
    public loader: LoaderService, public dialog: MatDialog, public fb: FormBuilder) {
    this.PatientBillForm = this.fb.group({
      IsLatestBill: true,
      FromDate: [new Date()]
    });
  }


  ngOnInit() {
    this.ward.WardNo.value = "";
    this.ward.BedNo.value = "";
    this.patientMultiselect.PatientSourceControl.setValue('');
    this.patientSource = this.patientMultiselect.PatientSourceControl.value;
  }

  get f() {
    return this.PatientBillForm.controls;
  }

  // opens snack bar
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 5000
    });
  }

  onSubmit() {
     
    let billDate = new ParseDate().transform(this.f.FromDate.value);
    let todayDate = new ParseDate().transform(this.maxDate);
    this.patientSource = this.patientMultiselect.PatientSourceControl.value;
    let isLatestBill = this.f.IsLatestBill.value;
    if (billDate === todayDate && !isLatestBill) {
      this.openSnackBar('Check Is Latest Bill', 'OK');
      return;
    }
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.Reports.AdmittedPatientBill(this.f.IsLatestBill.value, new ParseDate().transform(this.f.FromDate.value),
      this.ward.WardNo.value, this.ward.BedNo.value, this.patientSource)).subscribe(response => {
        if (response.Status === 200 && response.Data.length > 0) {
          console.log(response);
          this.patientBillList = new MatTableDataSource(response.Data);
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
          this.patientBillList = new MatTableDataSource([]);
          //this.common.openSnackBar("SELECT LATEST BILLS..", "Ok");
        }
      }, (error) => {
        this.loader.spin.next(false);
        console.error(error);
      });
  }

  exportToExcel() {
    this.loader.spin.next(true);

    this.httpService.Get(urlConstant.Reports.ExportAdmittedPatientBill(this.f.IsLatestBill.value, new ParseDate().transform(this.f.FromDate.value), this.ward.WardNo.value, this.ward.BedNo.value, this.patientSource)).subscribe(response => {
      if (response && !isNullOrUndefined(response.Data) && response.Data.length > 0) {
        this.httpService.exportToExcel(response.Data);
        this.loader.spin.next(false);
      } else {
        this.loader.spin.next(false);
      }
      this.loader.spin.next(false);
    });
  }

  clearSearch(ward, patientSource) {
    ward.WardNo.setValue('');
    ward.BedNo.setValue('');
    this.patientMultiselect.PatientSourceControl.setValue('');
    this.patientSource = "";
    this.PatientBillForm.setValue({
      IsLatestBill: true,
      FromDate: new Date()
    });
    this.patientBillList = new MatTableDataSource();
  }

  getSetValue(event, component) {
    // console.log(event)
    if (component === 'Ward') {
      this.wardNo = this.ward.WardNo.value;
      console.log("ward", this.wardNo);
      if (!isNullOrUndefined(this.ward.BedNo.value)) {
        this.bedNo = this.ward.BedNo.value;
        console.log("Bed", this.bedNo);
      }
      else {
        this.bedNo = "";
      }
    } else if (component === 'PatientSource') {
      this.patientSource = event.Code;
    }
  }

  openPatientFolio(regNo) {
    const dialogRef = this.dialog.open(PatientFolioComponent, {
      maxHeight: '600px',
      disableClose: true,
      minWidth: '88vw',
    });

    dialogRef.componentInstance.isPopup = true;
    dialogRef.componentInstance.regNo = regNo;
    dialogRef.afterClosed().subscribe();
  }


  highlightSelectedRow(index: any, rowDetails: any) {
    this.rowDetails = rowDetails;
    if (this.selectedIndexRow == index) {
      this.selectedIndexRow = -1;
    }
    else {
      this.selectedIndexRow = index;
      this.openPatientFolio(rowDetails.RegNo);
    }
  }

  onChange(event) {
    if (event) {
      this.f.FromDate.setValue(new Date());
    }
  }

  CheckDate(date) {
    let selectedDate = new ParseDate().transform(date._d);
    let todayDate = new ParseDate().transform(this.maxDate);

    if (selectedDate == todayDate) {
      this.f.IsLatestBill.setValue(true);
    }
    else {
      this.f.IsLatestBill.setValue(false);
    }
  }

}
