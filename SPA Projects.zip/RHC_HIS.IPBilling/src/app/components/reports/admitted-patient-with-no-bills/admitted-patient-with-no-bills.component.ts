import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { MatTableDataSource, MatDialog, MatSort } from '@angular/material';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';
import { ParseDate } from 'shared-utility';
import { PatientSourceMultiselectLookupComponent } from 'patient-source-multiselect-lookup';
import { FromDateToDateComponent } from 'from-date-to-date';

@Component({
  selector: 'app-admitted-patient-with-no-bills',
  templateUrl: './admitted-patient-with-no-bills.component.html',
  styleUrls: ['./admitted-patient-with-no-bills.component.css'],
  host: { 'class': 'section__main' },
})
export class AdmittedPatientWithNoBillsComponent implements OnInit {
  @ViewChild('ward') ward;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('patientMultiselect') patientMultiselect: PatientSourceMultiselectLookupComponent;
  @ViewChild('date') date: FromDateToDateComponent;
  selectedIndexRow: number;
  maxDate = new Date();
  patientSource: string = "";
  PatientsWithoutBillForm: FormGroup;
  public displayedColumnsList: string[] = ['RegNo', 'Name', 'AdmitDate', 'DoctName', 'UnBilledAmount', 'DepositAmount', 'BedNo',
    'CreditCode', 'PatientSourceName', 'BillAmount', 'EstimateAmount', 'Difference', 'DischargeDate'];
  patientBillList: MatTableDataSource<any> = new MatTableDataSource();
  wardNo: string;
  bedNo: any;
  rowDetails: any;
  object: any;

  constructor(public fb: FormBuilder, private common: CommonService, private httpService: HttpService,
    public loader: LoaderService, public dialog: MatDialog) {
    this.PatientsWithoutBillForm = this.fb.group({ PatientStatus: ['IN'], IsZeroorInterimBill: false });
  }

  ngOnInit() {
    this.ward.WardNo.value = "";
    this.ward.BedNo.value = "";
    this.patientMultiselect.PatientSourceControl.setValue('');
  }

  get f() {
    return this.PatientsWithoutBillForm.controls;
  }

  serachObject() {
    this.object = this.PatientsWithoutBillForm.getRawValue();
    this.object.PatientSource = this.patientMultiselect.PatientSourceControl.value.length > 0 ? this.patientMultiselect.PatientSourceControl.value.join() : '' ;
    this.object.FromDate = new ParseDate().transform(this.date.FromDate.value);
    this.object.ToDate = new ParseDate().transform(this.date.ToDate.value);
    this.object.Bed = this.ward.BedNo.value;
    this.object.Ward = this.ward.WardNo.value;
  }

  onSubmit() {
    this.loader.spin.next(true);
    this.serachObject();
    this.httpService.Post(urlConstant.Reports.GetAdmittedPatientsWithoutBills, this.object).subscribe(response => {
        if (response.Status === 200) {
          this.patientBillList = new MatTableDataSource(response.Data);
          this.patientBillList.sort = this.sort;
          this.loader.spin.next(false);
        }
        else {
          this.patientBillList = new MatTableDataSource([]);
          this.loader.spin.next(false);
        }
      }, (error) => {
        this.loader.spin.next(false);
        console.error(error);
      });
  }

  clearSearch(ward) {
    ward.WardNo.setValue('');
    ward.BedNo.setValue('');
    this.PatientsWithoutBillForm.setValue({ FromDate: new Date(), Type: 'IN', IsZeroBill: false });
    this.patientBillList = new MatTableDataSource();
  }

  getSetValue(event, component) {
    if (component === 'Ward') {
      this.wardNo = this.ward.WardNo.value;
      if (!isNullOrUndefined(this.ward.BedNo.value)) {
        this.bedNo = this.ward.BedNo.value;
      }
      else {
        this.bedNo = "";
      }
    }
  }

  exportToExcel() {
    this.loader.spin.next(true);
    this.httpService.Post(urlConstant.Reports.ExportAdmittedPatientsWithoutBills, this.object).subscribe(response => {
        if (response && !isNullOrUndefined(response.Data) && response.Data.length > 0) {
          this.httpService.exportToExcel(response.Data);
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
        }
      }, (error) => {
        this.loader.spin.next(false);
        console.error(error);
      });
  }

}
