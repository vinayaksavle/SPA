import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { MatTableDataSource } from '@angular/material';
import { urlConstant } from 'src/app/constants/urlConstants';
import { isNullOrUndefined } from 'util';
import { ParseDate } from 'shared-utility/lib/pipes/parse-date-format';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
  selector: 'app-credit-opd-bills',
  templateUrl: './credit-opd-bills.component.html',
  styleUrls: ['./credit-opd-bills.component.css'],
  host: { 'class': 'section__main' }
})
export class CreditOpdBillsComponent implements OnInit {
  @ViewChild('date') date;
  CreditOpdBillsForm: FormGroup;
  CreditOpdBills: any;
  data: { DepartmentCode: any; ServiceCode: string; PatientCategoryCode: any; };
  fromDate: string;
  toDate: string;
  code: string;
  totalAmount : any;

  constructor(public fb: FormBuilder, private common: CommonService, private httpService: HttpService, private loader: LoaderService) { }

  displayedColumnsList: string[] = ['BillNo', 'BillDate', 'RegNo', 'PatientName', 'Amount'];

  ngOnInit() {
    this.initializeForm();
    this.CreditOpdBills = new MatTableDataSource([]);
    this.fromDate = new Date().toString();
    this.toDate = new Date().toString();
    this.code = '';
  }

  initializeForm() {
    this.CreditOpdBillsForm = this.fb.group({
      fromDate: [new Date(), Validators.required],
      toDate: [new Date(), Validators.required],
      SourceType: ['']
    });
  }

  getDate() {
    this.fromDate = this.date.FromDate.value;
    this.toDate = this.date.ToDate.value;
  }

  getCompany(event, company) {
    this.code = event.CompanyCode;
  }

  onSubmit() {
 
    if(!this.common.isValidStringValue(this.code))
    {
      this.common.displayPromptMessage("Credit bills","Please select credit company!").subscribe();
      return;
    }


    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.Reports.CreditOpdBillsReport(new Date(this.fromDate).toLocaleDateString(), new Date(this.toDate).toLocaleDateString(), this.code)).subscribe(response => {
      if (response.Status === 200) {
        //console.log(response);
        this.CreditOpdBills = new MatTableDataSource(response.Data);
        this.totalAmount = response.Data.map(s => parseFloat(s.Amount)).reduce((a, b) => a + b, 0).toString();
        this.loader.spin.next(false);
      }
    });
  }

  onChangeSourceType(systemType: any) {
  }

  // Export to Excel
  exportToExcel() {
    if(!this.common.isValidStringValue(this.code))
    {
      this.common.displayPromptMessage("Credit bills","Please select credit company!").subscribe();
      return;
    }

    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.Reports.ExportExcelCreditOpdBillsReport(new Date(this.fromDate).toLocaleDateString(), new Date(this.toDate).toLocaleDateString(), this.code)).subscribe(response => {
      if (response.Status === 200) {
        //console.log(response);
        this.httpService.exportToExcel(response.Data);
        this.loader.spin.next(false);
      }
    });
  }


  clearSearch(company) {
    company.myControl.setValue('');
    this.CreditOpdBillsForm.setValue({
      fromDate: [new Date(), Validators.required],
      toDate: [new Date(), Validators.required],
      SourceType: ['']
    });
    this.CreditOpdBills = new MatTableDataSource();
  }
}
