import { Component, OnInit } from '@angular/core';
import 'rxjs/add/operator/filter';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-level-codes',
  templateUrl: './level-codes.component.html',
  styleUrls: ['./level-codes.component.css'],
  host: { 'class': 'section__main' }
})
export class LevelCodesComponent implements OnInit {

    displayedColumns= ["Dept Code","Service Code", "Service Name" ,"Level Code1",
    "Level Code2","Level Code3" ]
    // displayedColumns = [
    //     "Estimate No","Reg No","Patient Name","Est-Date","Company Name","Ref Details","User Id","Patient Source" ,"Phone" , "UHID"
    //   ];
      ServiceLevelCodesForm: FormGroup;
      ServiceLevelCodes:any;
      deptListDetails;
      code: any;
      
      constructor(private fb: FormBuilder, private commonService: CommonService,
        private dataService: DataTranferService, private httpService: HttpService) {
      }  
    ngOnInit(): void {
      this.ServiceLevelCodesForm = this.fb.group({
          ppnPackages:[false],
          irdaLinked:[false]
          
        });
        this.ServiceLevelCodes = new MatTableDataSource([]);
     }

     getSetValue(event, component) {
      if (component === 'Dept') {
        this.code = event.DepartmentCode
      }
      
    }
      onClear()
      {
        this.ngOnInit();
      }

      onSubmit() {
        if(!this.commonService.isValidStringValue(this.code)){
          this.commonService.openSnackBar("Please Select Department","OK");
          return;
        }
        this.httpService.Get(urlConstant.Reports.ServiceLevelCodesReport(this.code,this.ServiceLevelCodesForm.controls['ppnPackages'].value,this.ServiceLevelCodesForm.controls['irdaLinked'].value)).subscribe(response => {
          if (response.Status === 200) {
              console.log(response);
              this.ServiceLevelCodes = new MatTableDataSource(response.Data);
          }
        });
    
      }
      // Export to Excel
      exportToExcel() {
        this.httpService.Get(urlConstant.Reports.ExportServiceLevelCodesReport(this.code,this.ServiceLevelCodesForm.controls['ppnPackages'].value,this.ServiceLevelCodesForm.controls['irdaLinked'].value)).subscribe(response => {
          if (response.Status === 200) {
            console.log(response);
            this.httpService.exportToExcel(response.Data);
           
        }
      });
        
      }
    
}