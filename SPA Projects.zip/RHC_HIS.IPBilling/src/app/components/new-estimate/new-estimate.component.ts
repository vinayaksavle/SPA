import { Component, OnInit, ViewChild } from '@angular/core';
import 'rxjs/add/operator/filter';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { ActivatedRoute, Router } from '@angular/router';
import { MatTableDataSource } from '@angular/material';
import { LoaderService } from 'src/app/services/loader.service';
import { ParseDate } from 'shared-utility';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';
import { DoctorLookupComponent } from 'doctor-lookup';


@Component({
  selector: 'app-new-estimate',
  templateUrl: './new-estimate.component.html',
  styleUrls: ['./new-estimate.component.css'],
  host: { 'class': 'section__main' }
})
export class NewEstimateComponent implements OnInit {

  @ViewChild('patDetailsComp') patDetailsComp: PatientDetailsComponent;
  @ViewChild('doctor') doctorLookupComp: DoctorLookupComponent;
  newEstimateForm: FormGroup;
  estimateListDetails: MatTableDataSource<any> = new MatTableDataSource();
  displayedColumns = [
    "SerialNo",
    "PPN Code",
    "Particular",
    "PPN",
    "Amt"
  ];
  newEstimateObj: any;
  doctorMobileNo: string = "";
  EstimateNo: any;
  saveButtonStatus: boolean = false;
  constructor(private fb: FormBuilder, private commonService: CommonService,
    private dataService: DataTranferService, private httpService: HttpService,
    private router: Router, private loader: LoaderService, private activateRoute: ActivatedRoute) {

  }
  // Initialize
  ngOnInit(): void {
    this.initForm();
    this.setRouteParam();
    if (this.commonService.isValidStringValue(this.EstimateNo)) {
      this.viewEstimate();
    }
  }

  // Method to view the estimate details of patient
  viewEstimate() {
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.NewEstimate.GetEstimateDetails(this.EstimateNo)).subscribe(
      res => {
        if (res.Status == 200 && res.Data) {
          this.patDetailsComp.setPatientDetailByRegNo(res.Data.RegNo);
          this.setEstimateInfo(res.Data);
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
        }
      });
  }

  // Method to set the estimate details of patient.
  setEstimateInfo(estimateInfo: any) {
    this.newEstimateForm.patchValue({
      "EstimateNo": estimateInfo.EstimateNo,
      "EstimateDate": estimateInfo.EstimateDate,
      "EstimateTime": estimateInfo.EstimateTime,
      "Diagnosis": estimateInfo.Diagnosis,
      "Procedure": estimateInfo.Procedure,
      "TotalAmount": estimateInfo.TotalAmount,
      "Note": estimateInfo.Note,
      "ReasonForDiff": estimateInfo.ReasonForDiff,
      "CheckInActive": estimateInfo.Status == 'C' ? true : false
    });
    this.doctorLookupComp.myControl.setValue(estimateInfo.DoctorCode);
    this.doctorLookupComp.myControl.disable();
    for (let i = 0; i < 10; i++) {
      this.estimateListControl(i).PPNCode.setValue(estimateInfo.ppnList[i].PPNCode);
      this.estimateListControl(i).Particulars.setValue(estimateInfo.ppnList[i].Particulars);
      this.estimateListControl(i).Amount.setValue(estimateInfo.ppnList[i].Amount);
    }
    this.newEstimateForm.disable();
    this.saveButtonStatus = true;
  }

  // Method to set the route param
  setRouteParam() {
    this.activateRoute.queryParams.subscribe(params => {
      this.EstimateNo = params['EstimateNo'];
    });

  }

  // Initialize Form
  initForm() {
    this.newEstimateForm = this.fb.group({
      UHID: [''],
      RegNo: [''],
      PatientName: [''],
      PatientCategoryCode: [''],
      BedCategoryCode: [''],
      EstimateDate: [{ value: new Date(), disabled: true }],
      EstimateTime: [{ value: new Date().toLocaleTimeString(), disabled: true }],
      EstimateNo: [{ value: '', disabled: true }],
      CheckInActive: [false],
      EstimatedStayInDay: [''],
      Diagnosis: [''],
      Procedure: [''],
      IsPPNCategory: [false],
      PTCA: [false],
      Note: [''],
      ReasonForDiff: [''],
      MsgForDoc: [''],
      TotalAmount: [{ value: '0.00', disabled: true }],
      ppnList: this.fb.array([])
    });
    this.estimateListDetails = new MatTableDataSource([]);

    this.addDefaultRows(10);
    this.initEstimateList();
  }

  // get EstimateForm Controls 
  get f() {
    return this.newEstimateForm.controls;
  }
  // get Estimate list controls
  get EstimateArray(): FormArray {
    return this.newEstimateForm.get('ppnList') as FormArray;
  }

  // initialize PPN list form Controls.
  get initializeEstimateList() {
    return this.fb.group({
      PPNCode: [''],
      Particulars: [''],
      PPN: [''],
      Amount: ['0.00', Validators.pattern('^\d{1,5}\.?\d{0,2}$')]
    });
  }

  // Function to Return Estimate List Form Controls
  estimateListControl(index: number) {
    return this.EstimateArray.controls[index]["controls"];
  }

  // General Function to add Default rows in estimate list
  addDefaultRows(length: number) {
    const recepient = { PPNCode: '', Particulars: '', PPN: '', Amount: '' };
    const exisitingData = this.estimateListDetails.data;
    for (let i = 0; i < length; i++) {
      exisitingData.push(recepient);
      this.EstimateArray.push(this.initializeEstimateList);
    }
    this.estimateListDetails = new MatTableDataSource(exisitingData);
  }

  // Function to initialize Particulars in estimate list.
  initEstimateList() {
    this.estimateListControl(0).Particulars.setValue("ICU / CCU STAY");
    this.estimateListControl(1).Particulars.setValue("HOSPITAL STAY");
    this.estimateListControl(2).Particulars.setValue("MEDICINES");
    this.estimateListControl(3).Particulars.setValue("INVESTIGATIONS");
    this.estimateListControl(4).Particulars.setValue("SURGERY");
    this.estimateListControl(5).Particulars.setValue("COST OF IMPLANT");
  }

  // Function to get OP Patient Details to Form after entering UHID
  getOPDDetails() {
    if (!this.commonService.isValidStringValue(this.f.UHID.value)) {
      this.commonService.openSnackBar("Invalid UHID", "OK");
      return;
    }
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.NewEstimate.getOPDDetails(this.f.UHID.value.trim())).subscribe(response => {
      if (response.Status == 200 && response.Data) {
        this.setOPPatientDetails(response.Data[0]);
        this.loader.spin.next(false);
      }
      else {
        this.loader.spin.next(false);
      }
      this.loader.spin.next(false);
    });
  }

  // Function to set OP Patient Details to Form after entering UHID.
  setOPPatientDetails(opDetails: any) {
    this.patDetailsComp.patientForm.patchValue({
      "PatientName": opDetails.PatientName + opDetails.Title,
    });

  }

  // Function to get Patient Details after entering RegNo.
  // and set to the form controls.
  getPatientDetails(event) {
    this.newEstimateForm.patchValue({
      'RegNo': event.RegNo,
      'PatientName': event.PatientName,
      'PatientCategoryCode': event.PatientCategoryCode,
      'BedCategoryCode': event.BedCategory,
      'IsPPNCategory': event.Tstatus == 'P' ? true : false
    })
  }

  // Funtion to redirect to estimate list.
  redirectToList() {
    this.router.navigate(['billing/estimate']);
  }

  // Function to update total Amount according to amount change.  
  calculateTotalAmt(index?: number) {
    let total = 0;
    if (isNaN(parseFloat(this.estimateListControl(index).Amount.value))) {
      this.estimateListControl(index).Amount.setValue('0.00');
      return;
    }
    this.estimateListControl(index).Amount.
      setValue(parseFloat(this.estimateListControl(index).Amount.value).toFixed(2));
    for (let i = 0; i < 10; i++) {
      total = total + parseFloat(this.estimateListControl(i).Amount.value);
    }
    this.f.TotalAmount.setValue(total.toFixed(2));
  }

  // Function to Save New Estimate. Final Post Call.
  saveNewEstimate() {
    if (!this.commonService.isValidStringValue(this.f.RegNo.value)) {
      this.commonService.openSnackBar("Invalid RegNo", "OK");
      return;
    }
    this.newEstimateObj = this.newEstimateForm.getRawValue();
    this.newEstimateObj.EstimateDate = new ParseDate().transform(this.newEstimateObj.EstimateDate);
    this.newEstimateObj.UserId = this.dataService.GetUserName();
    this.loader.spin.next(true);
    this.httpService.Post(urlConstant.NewEstimate.SaveNewEstimate, this.newEstimateObj).subscribe(response => {
      if (response.Status == 200 && response.Data) {
        this.commonService.displayPromptMessage("New Estimate", "Data Saved Successfully");
        this.f.MsgForDoc.setValue(response.Data);
        this.resetForm();
        this.loader.spin.next(false);
      } else {
        this.resetForm();
        this.loader.spin.next(false);
      }
      this.loader.spin.next(false);
    });

  }

  // Function to reset form.
  resetForm() {
    this.patDetailsComp.patientForm.reset();
    this.initForm();
  }
  getSelectedDoctor(event) {
    this.doctorMobileNo = event.Contact;
  }
  // Function to send SMS
  sendSMS() {
    if (!this.commonService.isValidStringValue(this.f.MsgForDoc.value)
      && !this.commonService.isValidStringValue(this.doctorMobileNo)) {
      this.commonService.openSnackBar("Invalid Mobile No", "OK");
      return;
    }
    else {
      this.loader.spin.next(true);
      this.httpService.Get(urlConstant.NewEstimate.SendEstimateSMS(this.doctorMobileNo.trim(), this.f.MsgForDoc.value.trim())).subscribe(response => {
        if (response.Status == 200 && response.Data) {
          this.commonService.displayPromptMessage("New Estimate", "SMS Send...")
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
        }
        this.loader.spin.next(false);
      });
    }
  }

  // Function to Update PPN list according to PTCA check.
  updatePPNList() {
    if (this.f.PTCA.value == true) {
      for (let i = 0; i < 10; i++) {
        this.estimateListControl(i).PPNCode.setValue('');
        this.estimateListControl(i).Particulars.setValue('');
        this.estimateListControl(i).Amount.setValue('0.00');
      }
      this.estimateListControl(0).Particulars.setValue('ANGIOGRAPHY [ 2.3.13 ]');
      this.estimateListControl(1).Particulars.setValue('ANGIOPLASTY [ 3.7 ]');
      this.estimateListControl(2).Particulars.setValue('MEDICINES');
      this.estimateListControl(3).Particulars.setValue('COST OF STENT');
    } else {
      this.initEstimateList();
    }
  }

  // Print Function need to write
  printData() {

  }


}