import { Component, OnInit, ViewChild } from '@angular/core';
import 'rxjs/add/operator/filter';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { MatTableDataSource } from '@angular/material';
import { isNullOrUndefined } from 'util';
import { ParseDate } from 'shared-utility';
import { ServiceTabFieldComponent } from 'service-tab-field';

@Component({
  selector: 'app-dept-wise-service',
  templateUrl: './dept-wise-service.component.html',
  styleUrls: ['./dept-wise-service.component.css'],
  host: { 'class': 'section__main' }
})
export class DeptWiseServiceComponent implements OnInit {

  options: string[] = ['IP', 'OP', 'Both', 'Health Checkup'];

  displayedSummaryColumns = ["Test Code", "Test Name", "OPD Cases", "OPD Amount",
    "IP Cases", "IP Amount", "Total Cases", "Total Amount"];
  displayedColumns = [
    "RegNo", "Name", "BedNo", "Service", "Qty", "Amount", "VoucherNumber", "UserId", "DiscountAmount"
  ];

  @ViewChild('serviceComponent') serviceComponent: ServiceTabFieldComponent;
  DeptWiseServiceForm: FormGroup;
  DeptWiseService: any;
  deptListDetails: MatTableDataSource<any> = new MatTableDataSource<any>();
  patientList: MatTableDataSource<any> = new MatTableDataSource<any>();
  selected;
  fromDate: string;
  toDate: string;
  patientSource: any;
  totalCount : number = 0
  @ViewChild('date') date;
  @ViewChild('patsrc') patsrc;
  totalAmount: string = "0.00";
  serviceData: any = {
    'DepartmentCode': '', 'ServiceCode': '',
    'PatientCategoryCode': '',
  };
  deptCode: any;
  code: any;

  constructor(private fb: FormBuilder, private commonService: CommonService, private loaderService: LoaderService,
    private dataService: DataTranferService, private httpService: HttpService) {
  }
  ngOnInit(): void {

    this.DeptWiseServiceForm = this.fb.group({
      FromDate: [new Date(), Validators.required],
      ToDate: [new Date(), Validators.required],
      Type: ['I'],
      PpnBilled: [false],
      DisplaySummary: [true],
      CreditCode: [''],
      DeptCode: [''],
      ServiceCode: [''],
      PatientCategory: [''],

    });
    this.DeptWiseService = new MatTableDataSource([]);

    this.fromDate = new Date().toString();
    this.toDate = new Date().toString();
  }

  get f() {
    return this.DeptWiseServiceForm.controls;
  }

  getDate() {
    this.fromDate = this.date.FromDate.value;
    this.toDate = this.date.ToDate.value;
  }

  getSetValue(event, component) {
    if (component === 'PatSrc') {
      this.f.PatientCategory.setValue(event.Code);
    } else if (component === 'Dept') {
      this.serviceData.DepartmentCode = event.DepartmentCode;
      this.f.DeptCode.setValue(event.DepartmentCode);
    }
  }

  onClear() {
    this.ngOnInit();
  }


  onSubmit() {
    if (this.f.DisplaySummary.value && this.f.PpnBilled.value) {
      this.f.DisplaySummary.setValue(false);
    }

    if (!this.f.PpnBilled.value && !this.commonService.isValidStringValue(this.f.DeptCode.value)) {
      this.commonService.displayPromptMessage("Department Wise Service", "Please select department first !");
      return;
    }


    this.loaderService.spin.next(true);
    if (this.f.DisplaySummary.value) {

      this.httpService.Post(urlConstant.Reports.GetTestDetails, this.getPayload()).subscribe(response => {

        if (response.Status === 200 && response.Data.length > 0) {
          this.deptListDetails = new MatTableDataSource(response.Data);
          this.totalCount = response.Data.length;
          this.totalAmount = response.Data.map(a=> parseFloat(a.TotalAmount)).reduce((a,b)=> a+b);
          this.loaderService.spin.next(false);
        }
      });
    }
    else {
      this.httpService.Post(urlConstant.Reports.DeptWiseServiceReport, this.getPayload()).subscribe(response => {

        if (response.Status === 200  && response.Data.length > 0) {
          this.patientList = new MatTableDataSource(response.Data);
          this.totalCount = response.Data.length;
          this.totalAmount = response.Data.map(a=> parseFloat(a.ServiceAmount)).reduce((a,b)=> a+b);
          this.loaderService.spin.next(false);
        }
      });
    }


  }
  // Export to Excel
  exportToExcel() {
    this.loaderService.spin.next(true);
    this.httpService.Post(urlConstant.Reports.ExportDeptWiseServiceReport, this.getPayload()).subscribe(response => {
      if (response.Status === 200) {
        this.httpService.openFile(response.Data);
        this.loaderService.spin.next(false);
      }
    });

  }

  setServiceData(service, isValid) {
    this.f.ServiceCode.setValue(service.ServiceCode);
  }

  getPayload() {
    let obj = this.DeptWiseServiceForm.getRawValue();

    obj.FromDate = new ParseDate().transform(this.date.FromDate.value);
    obj.ToDate = new ParseDate().transform(this.date.ToDate.value);
    return obj;

  }

    // sets emmitted service data from service help to service tab field
    setEmittedService(service: any) {

       
      if (service !== undefined && this.commonService.isValidStringValue(service.ServiceCode)) {
  
        setTimeout(() => {
          this.serviceComponent.service = service.ServiceCode;
          this.serviceComponent.getService(service.ServiceCode);
        }, 100);
  
      }
    }



}