import { Component, OnInit, HostBinding, ViewChild, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MatTableDataSource, MatDialogRef } from '@angular/material';
import { urlConstant } from 'src/app/constants/urlConstants';
import { isNullOrUndefined } from 'util';
import { messageConstant } from 'src/app/constants/messageConstants';
import { ParseDate } from 'shared-utility';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';

@Component({
  selector: 'app-ot-details-list',
  templateUrl: './ot-details-list.component.html',
  styleUrls: ['./ot-details-list.component.css'],
  host: { 'class': 'section__main' },
})

export class OtDetailsListComponent implements OnInit, AfterViewInit {
  otDetailsForm: FormGroup;
  otDrugPrintData: any = {};
  public otTheatreList: any;
  displayedColumnsList: string[] = ['ItemName', 'Quantity', 'MarkedPrice', 'CostPrice', 'ExpiryDate', 'BatchNo', 'ItemCode', 'TransactionDate', 'Remarks', 'Manufacturer'];
  otDetailsList: MatTableDataSource<any> = new MatTableDataSource([]);
  hiddenItems: any = ['FinalButton', 'InterimButton', 'DoctorButton', 'ApprovedAmount',
    'TPA', 'DischDateTime', 'InsCompanyName'];
  visibleCostPrice: boolean = false;
  isPopup: boolean = false;
  regNo: string;
  @ViewChild('patDetails') patDetailComp: PatientDetailsComponent;

  constructor(
    private fb: FormBuilder,
    private commonService: CommonService,
    private httpService: HttpService,
    private loader: LoaderService,
    public dialogRef: MatDialogRef<OtDetailsListComponent>) { }

  ngOnInit() {
    this.initForm();
    this.getTheartreList();


    //#region Permission Section
    //this.permissions = JSON.parse(localStorage.getItem('Permission'));
    // Export to excel
    this.visibleCostPrice = localStorage.getItem('UserName') === 'SYSTEM';
    if (!this.visibleCostPrice) {
      this.f.PrintType.disable();
    }

    //#endregion
  }

  @HostBinding('class.full') get valid() { return this.isPopup; }

  // initialize the form
  initForm() {
    this.otDetailsForm = this.fb.group({
      EnableDates: [false],
      RegNo: [{ value: '', disabled: true }],
      FromDate: new Date(),
      ToDate: new Date(),
      TheatreCode: '',
      Batch: true,
      IssueAmt: [{ value: '0.00', disabled: true }],
      ReturnAmt: [{ value: '0.00', disabled: true }],
      NetAmt: [{ value: '0.00', disabled: true }],
      IssueCostAmt: [{ value: '0.00', disabled: true }],
      ReturnCostAmt: [{ value: '0.00', disabled: true }],
      NetCostAmt: [{ value: '0.00', disabled: true }],
      CardicDtl: 'OTDrugs',
      PrintType: 'MFR'
    });
  }

  ngAfterViewInit(): void {
    if (this.isPopup && this.commonService.isValidStringValue(this.regNo)) {
      this.patDetailComp.setPatientDetailByRegNo(this.regNo, true);
      setTimeout(() => {
        this.getOTDetailsList();
      }, 5000);

    }
  }

  // the function returns the form controls to access in both files.
  public get f() {
    return this.otDetailsForm.controls;
  }

  // sets patient details on event emit
  setPatientDetail(patient: any, patDetails?: any, date?) {
    if (!this.commonService.isValidStringValue(patient.RegNo)) {
      this.initForm();
      date.FromDate.setValue(new ParseDate().transform(new Date()));
      date.ToDate.setValue(new ParseDate().transform(new Date()));
      // this.searchObject = {};
      this.otDetailsList = new MatTableDataSource([]);
      return;
    }
    this.otDetailsList = new MatTableDataSource([]);
    this.initForm();
    // For Printing purpose
    this.otDrugPrintData.RegNo = patient.RegNo;
    this.otDrugPrintData.PatientName = patient.Title + " " + patient.PatientName;
    this.otDrugPrintData.DischargeDate = patient.DischargeDate;

    this.otDetailsForm.patchValue({
      "RegNo": patient.RegNo, "PatientName": patient.PatientName, "BedNo": patient.BedNo,
      "RoomNo": patient.RoomNo, "AdmitDate": patient.AdmitDate, "Category": patient.PatientCategoryCode,
      "DiscDate": patient.DischargeDate, "DiscTime": patient.DischargeTime,
    });
  }

  // set from date and to date
  getSetDate(event) {
    this.f.FromDate.setValue(new Date(event.FromDate.value));
    this.f.ToDate.setValue(new Date(event.ToDate.value));
  }

  // change cardic radio button
  onChangeCardicType(btnNm) {
    this.f.CardicDtl.setValue(btnNm);
  }

  // change print type
  onChangePrintType(btnNm) {
    this.f.PrintType.setValue(btnNm);
  }

  // get bill categories
  getTheartreList() {
    if (isNullOrUndefined(this.otTheatreList) ||
      this.otTheatreList.length === 0) {
      this.httpService.Get(urlConstant.OTServiceDetails.GetTheaterList()).subscribe(response => {
        this.otTheatreList = response.Data;
      });
    }
  }

  // change Theatre
  changeTheatre(otTheatreCode) {
    this.f.TheatreCode.setValue(otTheatreCode);
  }

  // validation of form
  validateForm(date): boolean {

    if (!this.commonService.isValidStringValue(date.FromDate.value)) {
      this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidFromDate,
        messageConstant.invalidMessages.OK);
      return false;
    }
    if (!this.commonService.isValidStringValue(date.ToDate.value)) {
      this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidToDate,
        messageConstant.invalidMessages.OK);
      return false;
    }
    // if (new ParseDate().transform(date.FromDate.value) > new ParseDate().transform(new Date())) {
    //   this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidFromDate,
    //     messageConstant.invalidMessages.OK);
    //   return false;
    // }
    // if (new ParseDate().transform(date.ToDate.value) > new ParseDate().transform(new Date())) {
    //   this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidToDate,
    //     messageConstant.invalidMessages.OK);
    //   return false;
    // }
    return true;
  }

  // Author - Vinayak Savale
  // Get OT details list
  getOTDetailsList() {
    //if (!this.validateForm(date)) return;

    const drugInput = this.otDetailsForm.getRawValue();

    // Check whether date checkbox checked or not
    if (this.f.EnableDates.value) {
      drugInput.FromDate = this.f.FromDate.value;
      drugInput.ToDate = this.f.ToDate.value;
    }
    else {
      drugInput.FromDate = '';
      drugInput.ToDate = '';
    }

    this.loader.spin.next(true);

    this.httpService.Post(urlConstant.OTServiceDetails.GetPatientOTDrugDetails(), drugInput).subscribe(response => {
      if (response.Status === 200) {

        // Get OT Issue details

        let tempObj = this.otDrugPrintData;

        this.otDrugPrintData = response.Data;
        this.otDrugPrintData.PatientName = tempObj.PatientName;
        this.otDrugPrintData.RegNo = tempObj.RegNo;

        const issueDetails = response.Data.OTDrugIssue;
        const returnsDetails = response.Data.OTDrugReturns;

        if (response.Data.IssueAmt != null && response.Data.IssueAmt != '')
          this.f.IssueAmt.setValue(parseFloat(response.Data.IssueAmt).toFixed(2));
        else
          this.f.IssueAmt.setValue('0.00');

        if (response.Data.IssueCostAmt != null && response.Data.IssueCostAmt != '')
          this.f.IssueCostAmt.setValue(parseFloat(response.Data.IssueCostAmt).toFixed(2));
        else
          this.f.IssueCostAmt.setValue('0.00');

        if (response.Data.ReturnAmt != null && response.Data.ReturnAmt != '')
          this.f.ReturnAmt.setValue(parseFloat(response.Data.ReturnAmt).toFixed(2));
        else
          this.f.ReturnAmt.setValue('0.00');

        if (response.Data.ReturnCostAmt != null && response.Data.ReturnCostAmt != '')
          this.f.ReturnCostAmt.setValue(parseFloat(response.Data.ReturnCostAmt).toFixed(2));
        else
          this.f.ReturnCostAmt.setValue('0.00');

        if (response.Data.NetAmt != null && response.Data.NetAmt != '')
          this.f.NetAmt.setValue(parseFloat(response.Data.NetAmt).toFixed(2));
        else
          this.f.NetAmt.setValue('0.00');

        if (response.Data.NetCostAmt != null && response.Data.NetCostAmt != '')
          this.f.NetCostAmt.setValue(parseFloat(response.Data.NetCostAmt).toFixed(2));
        else
          this.f.NetCostAmt.setValue('0.00');

        // Using spread operator combined two results
        const otDrugDetails = [...issueDetails, ...returnsDetails];

        this.otDetailsList = new MatTableDataSource(otDrugDetails);
      }
      else {
        this.otDetailsList = new MatTableDataSource([]);
        this.f.IssueAmt.setValue('0.00');
        this.f.IssueCostAmt.setValue('0.00');
        this.f.ReturnAmt.setValue('0.00');
        this.f.ReturnCostAmt.setValue('0.00');
        this.f.NetAmt.setValue('0.00');
        this.f.NetCostAmt.setValue('0.00');
      }
      this.loader.spin.next(false);
    });

  }

  getOTPrintDetails() {


    let printData = this.otDrugPrintData;
    printData.PrintType = this.f.PrintType.value;

    this.httpService.Post(urlConstant.Billing.GetOTDrugDetailsPrint(), printData).subscribe(response => {
      if (this.commonService.isValidStringValue(response))
        this.httpService.openFile(response);
    });
  }

  // reset form
  resetForm(patDetails, date) {
    patDetails.patientForm.reset();
    date.FromDate.setValue(new Date());
    date.ToDate.setValue(new Date());
    this.initForm();
    this.otDetailsList = new MatTableDataSource([]);
    //patDetails.admissionNumberLookup.myControl.setValue('');
  }


  closeDialog() {
    this.dialogRef.close();
  }
}
