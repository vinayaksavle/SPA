import { Component, OnInit, HostBinding, ViewChild, AfterViewInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { LibPatientFolioComponent } from 'lib-patient-folio';
import { PatientEnquiryComponent } from 'src/app/components/patient-enquiry/patient-enquiry.component';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-patient-folio',
  template: '<lib-patient-folio #patientFolio [regNo]="regNo" [hiddenFields]="hiddenFields" (openEnquiry)="openPatientEnquiry($event)" [displayNewCNButton]="true"></lib-patient-folio>',
  styleUrls: ['./patient-folio.component.css']
})
export class PatientFolioComponent implements AfterViewInit {
  regNo: string;
  hiddenFields: any = [];
  isPopup: boolean = false;

  @ViewChild('patientFolio') patientFolio: LibPatientFolioComponent;

  constructor(public dialog: MatDialog) {
  }

  ngAfterViewInit(): void {
    this.patientFolio.isPopup = this.isPopup;
  }

  openPatientEnquiry(open: any) {
    const dialogRef = this.dialog.open(PatientEnquiryComponent, {
      disableClose: true,
      maxHeight: '600px',

    });

    dialogRef.componentInstance.isPopup = true;
    dialogRef.componentInstance.patientName= this.patientFolio.f.PatientName.value;

    dialogRef.afterClosed().subscribe(dialogResult => {

      if (!isNullOrUndefined(dialogResult)) {
        
        this.regNo = dialogResult.AdmissionNumber;
        this.patientFolio.regNo = this.regNo;
        this.patientFolio.getDetailsByRegNo(this.regNo);;
      }
    });
     
  }
}
