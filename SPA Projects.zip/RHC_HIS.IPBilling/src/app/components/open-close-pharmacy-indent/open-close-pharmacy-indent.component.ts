import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { HttpService } from 'src/app/services/http.service';
import { messageConstant } from 'src/app/constants/messageConstants';
import { urlConstant } from 'src/app/constants/urlConstants';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ParseDate } from 'shared-utility';
import { FromDateToDateComponent } from 'from-date-to-date';

@Component({
  selector: 'app-open-close-pharmacy-indent',
  templateUrl: './open-close-pharmacy-indent.component.html',
  styleUrls: ['./open-close-pharmacy-indent.component.css'],
  host: { 'class': 'section__main' },

})
export class OpenClosePharmacyIndentComponent implements OnInit {
  openCloseIndentForm: FormGroup;
  displayedColumns= ["RegNo","UserId", "Remarks"];
  @ViewChild('fromDateToDate') fromDateToDate : FromDateToDateComponent;
  @ViewChild(MatSort) sort: MatSort;
  pharmacyIntendList=new MatTableDataSource([]);
  constructor(public fb: FormBuilder, private commonService: CommonService, private httpService: HttpService,
    private loader: LoaderService) { }

  ngOnInit() {
    this.initForm();
  }
// initialize the form
initForm() {
  this.openCloseIndentForm = this.fb.group({
    PatientRegNo: ['', Validators.required],
    PatientName: [{ value: '', disabled: true }],
    CurrentStatus: [{ value: '', disabled: true }],
    Remark : ['' , Validators.maxLength(200)]
  });
}

ngAfterViewInit(): void {
  //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
  //Add 'implements AfterViewInit' to the class.
  this.onSearch();  
}
// the function returns the form controls to access in both files.
public get f() {
  return this.openCloseIndentForm.controls;
}
//validates form before saving
validateForm(): boolean {
  if (!this.commonService.isValidStringValue(this.f.PatientRegNo.value)) {
    this.commonService.openSnackBar(messageConstant.ServiceTranfer.InvalidPatRegNo,
      messageConstant.invalidMessages.OK);
    return false;
  }else if(!this.commonService.isValidStringValue(this.f.Remark.value)){
    this.commonService.openSnackBar("Remark is required","OK");
    return false;

  } else if(this.f.Remark.value.length>200){
    this.commonService.openSnackBar("Remark can not exceed 200 characters","OK");
    return false;
  }
  return true;
}

 // get patient reg no and name 
 getPatientName(patient) {
  if (!this.commonService.isValidStringValue(patient.AdmissionNo)) {
    this.initForm();
    return;
  }
  this.openCloseIndentForm.patchValue({
    "PatientRegNo": patient.AdmissionNo, "PatientName": patient.Title + '. ' + patient.PatientName,
  });
  //patDetails.myControl.setValue(patient.AdmissionNo);
  this.httpService.Get(urlConstant.OpenclosePharmacyindent.CheckPharmacyStatus(this.f.PatientRegNo.value))
  .subscribe(result=> {
    if(result && result.Data){
      this.f.CurrentStatus.setValue(messageConstant.OpenClosePharmacyIndent.OpenStatus);
    } else {
      this.f.CurrentStatus.setValue(messageConstant.OpenClosePharmacyIndent.CloseStatus);
    }
  });
}

// close pharmacy indent
ClosePharmacyIndent(patDetails) {
  if (!this.validateForm()) return;
  this.commonService.confirmAction(messageConstant.OpenClosePharmacyIndent.Header,messageConstant.OpenClosePharmacyIndent.ConfirmCloseIndent)
    .subscribe(response=>{
      if(response) {
        this.loader.spin.next(true);
        this.httpService.Get(urlConstant.OpenclosePharmacyindent.ClosePharamcyIndent(this.f.PatientRegNo.value,localStorage.getItem("UserName")
        ,this.f.Remark.value)).subscribe(result=> {
            if(result && result.Data) {
              this.loader.spin.next(false);
              this.commonService.displayPromptMessage(messageConstant.OpenClosePharmacyIndent.Header,messageConstant.OpenClosePharmacyIndent.CloseSucess);
              this.Resetform(patDetails);
              this.onSearch();  
            } else {
              this.loader.spin.next(false);
              this.commonService.displayPromptMessage(messageConstant.OpenClosePharmacyIndent.Header,messageConstant.OpenClosePharmacyIndent.AlreadyClose);
              this.Resetform(patDetails);
              this.onSearch();  
            }
          });
      
      } else {return;}
    });

}

// close pharmacy indent
OpenPharmacyIndent(patDetails) {
  if (!this.validateForm()) return;
  this.commonService.confirmAction(messageConstant.OpenClosePharmacyIndent.Header,messageConstant.OpenClosePharmacyIndent.ConfirmOpenIndent)
  .subscribe(response=>{
    if(response) {
      this.loader.spin.next(true);
      this.httpService.Get(urlConstant.OpenclosePharmacyindent.OpenPharamcyIndent(this.f.PatientRegNo.value,localStorage.getItem("UserName"),this.f.Remark.value))
      .subscribe(result => {
          if(result && result.Data) {
            this.loader.spin.next(false);
            this.commonService.displayPromptMessage(messageConstant.OpenClosePharmacyIndent.Header,messageConstant.OpenClosePharmacyIndent.OpenSucess);
            this.Resetform(patDetails);
            this.onSearch();
          } else {
            this.loader.spin.next(false);
            this.commonService.displayPromptMessage(messageConstant.OpenClosePharmacyIndent.Header,messageConstant.OpenClosePharmacyIndent.AlreadyOpen);
            this.Resetform(patDetails);
            this.onSearch();
          }
        });
    
    } else {return;}
  });
}
Resetform(patDetails) {
  this.initForm();
  patDetails.RegNo='';
  patDetails.PatientName='';
  this.onSearch();
}
// Method to get service transfer list on search button click
onSearch(){
  console.log(this.fromDateToDate.FromDate.value);
  if(!this.commonService.isValidStringValue(this.fromDateToDate.FromDate.value) && 
  !this.commonService.isValidStringValue(this.fromDateToDate.ToDate.value)){
    return;
  } else{
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.ServiceTransfer.GetServiceTransferList(
      "PHARMACY INDENT",
      new ParseDate().transform(this.fromDateToDate.FromDate.value),
      new ParseDate().transform(this.fromDateToDate.ToDate.value),
    )).subscribe(res=>{
      if(res.Status==200 && res.Data.length>0){
          this.pharmacyIntendList=new MatTableDataSource(res.Data);
          this.pharmacyIntendList.sort=this.sort;
          this.loader.spin.next(false);
      } else{
        this.loader.spin.next(false);
      }
      this.loader.spin.next(false);
    });
  }
}
}
