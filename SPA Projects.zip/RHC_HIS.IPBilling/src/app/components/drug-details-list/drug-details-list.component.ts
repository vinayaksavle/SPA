import { Component, OnInit, ViewChild, HostBinding } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MatTableDataSource, MatSort, MatDialogRef } from '@angular/material';
import { toDate } from '@angular/common/src/i18n/format_date';
import { urlConstant } from 'src/app/constants/urlConstants';
import { ParseDate } from 'shared-utility';
import { isNullOrUndefined } from 'util';
import { messageConstant } from 'src/app/constants/messageConstants';
import { BillDropdownComponent } from 'bill-dropdown';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';
@Component({
  selector: 'app-drug-details-list',
  templateUrl: './drug-details-list.component.html',
  styleUrls: ['./drug-details-list.component.css'],
  host: { 'class': 'section__main' },
})

export class DrugDetailsListComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('billDropdown') billDropdownComponent: BillDropdownComponent;
  @ViewChild('patDetails') patDetailComp: PatientDetailsComponent;
  @ViewChild('date') dateComp;


  isPopup: boolean = false;
  regNo: string;
  drugDetailsForm: FormGroup;
  drugPrintData: any = {};
  drugDetailsList: MatTableDataSource<any> = new MatTableDataSource([]);
  issueCost: any = '0.00';
  issueAmount: any = ' 0.00';
  returnCost: any = '0.00';
  returnAmount: any = '0.00';
  netCost: any = '0.00';
  netAmount: any = '0.00';
  displayedColumnsList: string[] = ['ItemName', 'Quantity', 'Amount', 'ChargePrice', 'ExpiryDate', 'BatchNo',
    'ISRDate', 'Manufacturer', 'ServiceNo'];
  hiddenItems: any = ['FinalButton', 'InterimButton', 'DoctorButton', 'ApprovedAmount',
    'TPA', 'DischDateTime', 'InsCompanyName'];
  UserId: string;
  visibleCostPrice: boolean = false;

  constructor(
    private fb: FormBuilder,
    private commonService: CommonService,
    private httpService: HttpService,
    private loader: LoaderService,
    public dialogRef: MatDialogRef<DrugDetailsListComponent>) {


  }

  ngOnInit() {
    this.initForm();

    //#region Permission Section
    //this.permissions = JSON.parse(localStorage.getItem('Permission'));
    // Export to excel
    this.UserId = localStorage.getItem('UserName');
    if (this.UserId === 'SYSTEM') {
      this.visibleCostPrice = true;
    }
    else {
      this.f.PrintType.disable();
    }

    //#endregion
  }

  @HostBinding('class.full') get valid() { return this.isPopup; }



  ngAfterViewInit(): void {
    if (this.isPopup && this.commonService.isValidStringValue(this.regNo)) {
      this.patDetailComp.setPatientDetailByRegNo(this.regNo, true);
      setTimeout(() => {
        this.getDrugDetails();
      }, 5000);

    }
  }

  // initialize the form
  initForm() {
    this.drugDetailsForm = this.fb.group({
      RegNo: [{ value: '', disabled: true }],
      DateChecker: [false],
      FromDate: new Date(),
      ToDate: new Date(),
      Before2004: false,
      IRDAFormat: false,
      PrintType: 'MFR',
      IssueDate: true,
      DrugDetail: 'All',
      BillNo: [{ value: '', disabled: true }],
      BillDate: [{ value: '', disabled: true }],
      FolioNo: [{ value: '', disabled: true }],
    });

    this.drugDetailsList = new MatTableDataSource([]);
    this.dateComp.FromDate.disable();
    this.dateComp.ToDate.disable();
    this.billDropdownComponent.myControl.reset();
    this.issueCost = '0.00';
    this.issueAmount = ' 0.00';
    this.returnCost = '0.00';
    this.returnAmount = '0.00';
    this.netCost = '0.00';
    this.netAmount = '0.00';
  }

  // the function returns the form controls to access in both files.
  get f() {
    return this.drugDetailsForm.controls;
  }

  enableDate() {
    if (this.f.DateChecker.value) {
      this.dateComp.FromDate.enable();
      this.dateComp.ToDate.enable();
    } else {
      this.dateComp.FromDate.disable();
      this.dateComp.ToDate.disable();
    }
  }

  // sets patient details on event emit
  setPatientDetail(patient: any, patDetails?: any, date?) {
    if (!this.commonService.isValidStringValue(patient.RegNo)) {
      this.resetForm(patDetails, date);
      return;
    }
    this.initForm();
    this.drugDetailsForm.patchValue({
      "RegNo": patient.RegNo, "PatientName": patient.PatientName, "BedNo": patient.BedNo,
      "RoomNo": patient.RoomNo, "AdmitDate": patient.AdmitDate, "Category": patient.PatientCategoryCode,
      "DiscDate": patient.DischargeDate, "DiscTime": patient.DischargeTime, "BillNo": patient.BillNo, "FolioNo": patient.FolioNo
    });
    this.billDropdownComponent.regNo = this.f.RegNo.value;
    this.billDropdownComponent.GetBills();
    this.drugPrintData.RegNo = patient.RegNo;
    this.drugPrintData.PatientName = patient.Title + " " + patient.PatientName;
    this.drugPrintData.DischargeDate = patient.DischargeDate;
  }

  // set from date and to date
  getSetDate(event) {
    this.f.FromDate.setValue(new ParseDate().transform(new Date(event.FromDate.value)));
    this.f.ToDate.setValue(new ParseDate().transform(new Date(event.ToDate.value)));
  }

  // change radio button
  onChangeRadioBtn(btnNm, contrlName) {
    if (contrlName === 'PrintType') {
      this.f.PrintType.setValue(btnNm);
    }
    else if (contrlName === 'DrugDetail') {
      this.f.DrugDetail.setValue(btnNm);
    }
  }

  // get checkbox value
  getCheckBoxValue(event, control) {
    if (control === 'Before2004') {
      this.f.Before2004.setValue(event.checked)
    } else if (control === 'IRDA') {
      this.f.IRDAFormat.setValue(event.checked);
    }
  }

  // validation of form
  validateForm(date): boolean {

    if (!this.commonService.isValidStringValue(date.FromDate.value)) {
      this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidFromDate,
        messageConstant.invalidMessages.OK);
      return false;
    }
    if (!this.commonService.isValidStringValue(date.ToDate.value)) {
      this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidToDate,
        messageConstant.invalidMessages.OK);
      return false;
    }

    if (new ParseDate().transform(date.FromDate.value) > new ParseDate().transform(new Date())) {
      this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidFromDate,
        messageConstant.invalidMessages.OK);
      return false;
    }
    if (new ParseDate().transform(date.ToDate.value) > new ParseDate().transform(new Date())) {
      this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidToDate,
        messageConstant.invalidMessages.OK);
      return false;
    }
    return true;
  }

  // Author - Vinayak Savale
  // Get Pharmacy Drug Details (Issues and Returns)
  getDrugDetails() {
    this.loader.spin.next(true)
    //if (!this.validateForm(date)) return;

    const phDrugInput = this.drugDetailsForm.getRawValue();
    if (!this.f.DateChecker.value) {
      phDrugInput.FromDate = '';
      phDrugInput.ToDate = '';
    }

    this.httpService.Post(urlConstant.DrugServiceDetails.GetPharmacyDrugDetails(), phDrugInput).subscribe(response => {
      if (response.Status === 200) {
        let tempData = this.drugPrintData;




        this.drugPrintData = response.Data;
        this.drugPrintData.RegNo = tempData.RegNo;
        this.drugPrintData.PatientName = tempData.PatientName;


        this.issueCost = response.Data.CostAmount;
        this.netCost = response.Data.CostNetAmount;
        this.returnCost = response.Data.CostReturnAmount;
        this.issueAmount = response.Data.IssueAmount;
        this.netAmount = response.Data.IssueNetAmount;
        this.returnAmount = response.Data.IssueReturnAmount;
        this.drugDetailsList = new MatTableDataSource(response.Data.PharmacyDrugDetails);
        this.drugDetailsList.sort = this.sort;
        this.loader.spin.next(false)

      }
    });
  }

  // reset form
  resetForm(patDetails, date) {
    patDetails.patientForm.reset();
    date.FromDate.setValue(new ParseDate().transform(new Date()));
    date.ToDate.setValue(new ParseDate().transform(new Date()));
    //patDetails.admissionNumberLookup.myControl.setValue('');
    this.billDropdownComponent.billList = [];
    this.initForm();
  }

  // Get Print Data
  printDrugDetails() {
    this.loader.spin.next(true);
    this.drugPrintData.PrintType = this.f.PrintType.value;
    this.drugPrintData.IRDAFormat = this.f.IRDAFormat.value;
    this.drugPrintData.IssueDate = this.f.IssueDate.value;
    this.httpService.Post(urlConstant.Billing.GetDrugDetailsPrint(), this.drugPrintData).subscribe(response => {
      if (this.commonService.isValidStringValue(response))
        this.loader.spin.next(false);
      this.httpService.openFile(response);
    });

  }


  setBillDetail(bill: any) {
    this.f.BillNo.setValue(bill.IpBillNo);
    this.f.BillDate.setValue(bill.BillDate);
    this.f.FolioNo.setValue(bill.FolioNo);
  }


  closeDialog() {
    this.dialogRef.close();
  }
}
