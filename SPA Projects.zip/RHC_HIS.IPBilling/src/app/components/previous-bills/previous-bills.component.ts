import { Component, OnInit, ViewChild, AfterViewInit, ElementRef } from '@angular/core';
import { MatDialogRef, MatTableDataSource, MatSort } from '@angular/material';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { PreviousBills } from 'src/app/models/previous-bill.model';
import { ServiceBillModel } from 'src/app/models/service-bill.model';
import { LoaderService } from 'src/app/services/loader.service';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';
import { isNumber, isNullOrUndefined } from 'util';
import { CommonService } from 'src/app/services/common.service';

@Component({
    selector: 'app-previous-bills',
    templateUrl: './previous-bills.component.html',
    styleUrls: ['./previous-bills.component.css']
})

export class PreviousBillsComponent implements OnInit, AfterViewInit {

    @ViewChild('sortPrev') sortPrev: MatSort;
    @ViewChild('sortServ') sortServ: MatSort;
    @ViewChild('patientDetailComponent') patientDetailComponent: PatientDetailsComponent;

    previousBillsList: MatTableDataSource<PreviousBills> = new MatTableDataSource();
    displayedColumns: string[] = ['SNO', 'BillType', 'IpBillNo', 'BillDate', 'BillAmt'];
    isPopup: boolean = false;
    selectedRowIndex: number = -1;
    selectedRowData: any;
    serviceListDetails: MatTableDataSource<ServiceBillModel> = new MatTableDataSource();
    displayedServColumns: string[] = ["DepartmentCode", "ServiceCode", "ServiceDate", "Qty", "Rate", "Amount", "UserId", "VoucherNo"];
    hiddenItems: any = ['FinalButton', 'InterimButton', 'DoctorButton', 'ApprovedAmount',
        'TPA', 'DischDateTime', 'RoomNo', 'CompanyName', 'BedCategory'
        , 'AdmitDateTime', 'FolioButton'];

    isNew: boolean = false;
    regNo: string;
    folioNo: string;
    ipBillNo: string;
    totalBillAmount: any = "0.00";
    serviceTotal: any = "0.00";
    constructor(private http: HttpService, private loader: LoaderService,
        private dialogRef: MatDialogRef<PreviousBillsComponent>, private commonService: CommonService) { }

    ngOnInit() {
    }

    ngAfterViewInit(): void {
        this.isNew = true;
        this.patientDetailComponent.setPatientDetailByRegNo(this.regNo, true);
    }

    /// Author -  Vinayak Savale
    /// Gets Previous bills
    /// date - 3 July 2020 
    getPreviousBills() {

        this.loader.spin.next(true);
        this.http.Get(urlConstant.Billing.GetPreviousBills() + "?regNo=" + this.regNo + "&folioNo=" + this.folioNo).subscribe(response => {
            this.totalBillAmount = response.Data
                .map((d) => parseFloat(d.BillAmt))
                .reduce((prev, curr) => prev + curr, 0)
                .toFixed(2);
            this.previousBillsList = new MatTableDataSource<PreviousBills>(response.Data);
            this.previousBillsList.sort = this.sortPrev;
            this.serviceTotal = "0.00";
            this.serviceListDetails = new MatTableDataSource<ServiceBillModel>([]);

            setTimeout(() => {

                this.patientDetailComponent.setPatientFolioNo(this.folioNo);
                this.loader.spin.next(false);
                this.isNew = false;
            }, 500);
        });
    }

    /// Author -  Vinayak Savale
    // on highlight click of row fetch service details
    getServiceDetails() {
        this.ipBillNo = this.selectedRowData.IpBillNo.trim();
        this.loader.spin.next(true);
        this.http.Post(urlConstant.Billing.GetServiceListForPrevBill(), { IpBillNo: this.ipBillNo, RegNo: this.regNo, FolioNo: this.folioNo }).subscribe((response: any) => {
            this.serviceListDetails = new MatTableDataSource<ServiceBillModel>(response.Data);
            this.serviceListDetails.sort = this.sortServ;
            this.serviceTotal = response.Data
                .map((d) => parseFloat(d.Amount))
                .reduce((prev, curr) => prev + curr, 0)
                .toFixed(2);
            this.loader.spin.next(false);
        });
    }

    //close dialog box
    closeDialog() {
        this.dialogRef.close();
    }

    // highlight selected row of grid
    highlightSelectedRow(index, rowDetails) {
        // after sorting column index number won't change, rowdetails will fetch correct details
        this.selectedRowData = rowDetails;
        this.selectedRowIndex = index;
        this.getServiceDetails();
    }

    // called on patient regno change
    getPreviousBillsDetail(patient: any) {
        if (this.commonService.isValidStringValue(patient.RegNo)) {
            if (!isNullOrUndefined(patient.RegNo)) {
                if (this.regNo !== patient.RegNo) {
                    this.folioNo = patient.FolioNo;
                }

                this.regNo = patient.RegNo;
                this.getPreviousBills();

            }
        }
        else {
            this.resetForm();
        }

    }

    //called on change patient folio
    setFolio(folio: string) {
        if (this.folioNo !== folio && !this.isNew) {
            this.folioNo = folio;
            this.getPreviousBills();
        }

    }

    ///resets for value
    resetForm() {
        this.previousBillsList = new MatTableDataSource<PreviousBills>([]);
        this.serviceListDetails = new MatTableDataSource<ServiceBillModel>([]);
        this.regNo = "";
        this.folioNo = "";
        this.ipBillNo = "";
        this.totalBillAmount = "0.00";
        this.serviceTotal = "0.00";
    }
}