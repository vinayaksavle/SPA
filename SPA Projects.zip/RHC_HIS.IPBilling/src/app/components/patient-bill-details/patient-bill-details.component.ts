import { Component, OnInit, ViewChild } from '@angular/core';
import 'rxjs/add/operator/filter';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { MatDialog, MatTableDataSource } from '@angular/material';
import { FromDateToDateComponent } from 'from-date-to-date';
import { PatientSourceDropdownComponent } from 'patient-source-dropdown';
import { RegnoTabFieldComponent } from 'regno-tab-field';
import { CreditCompanyLookupComponent } from 'credit-company-lookup';
import { ParseDate } from 'shared-utility';
import { PatientFolioComponent } from '../patient-folio/patient-folio.component';
import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-patient-bill-details',
  templateUrl: './patient-bill-details.component.html',
  styleUrls: ['./patient-bill-details.component.css'],
  host: { 'class': 'section__main' }
})
export class PaientBillDetailsComponent implements OnInit {

  displayedColumns = ["SNO", "PatientCategory", "BillDate", "RegNo", "PatientName",
    "TotalBillAmount", "TotalRecievedAmount", "RefundAmount", "TDSAmount", "IPFCrNoteAmt",
    "DoctorCrNoteAmt", "OtherCrNoteAmt", "BalanceAmount", "CashSettlement", "CreditSeller",
    "ApprovedAmount", "AdmissionDate", "DischargeDate", "DoctorName", "CreditCompany", "BillType",
    "Foliodiscount", "FolioNo", "UTR", "CreditSettlementDate", "Cid", "Phone"]

  deptListDetails;
  fromDate: string;
  toDate: string;
  BillDetailsForm: FormGroup;
  BillDetails: any;
  patientSource: any;
  selectedRowData: any;
  orderBy = [
    { Key: 'P', Value: 'Patient Category' },
    { Key: 'AN', Value: 'Admission Number' },
    { Key: 'AD', Value: 'Admission date' },
    { Key: 'C', Value: 'Company Name' },
    { Key: 'B', Value: 'Bill Type' },
  ]
  @ViewChild('fromDateToDate') date: FromDateToDateComponent;
  @ViewChild('patsrc') patsrc: PatientSourceDropdownComponent;
  @ViewChild('regNo') regNo: RegnoTabFieldComponent;
  @ViewChild('creditComp') creditComp: CreditCompanyLookupComponent;
  department: string = '';
  service: string = '';
  serviceData: { DepartmentCode: any; ServiceCode: string; PatientCategoryCode: string; OpCategoryCode: string; CreditCompanyCode: string; };

  constructor(private fb: FormBuilder, private commonService: CommonService, private loaderService: LoaderService,
    private dataService: DataTranferService, private httpService: HttpService, private dialog: MatDialog) {
  }
  ngOnInit(): void {
    this.BillDetailsForm = this.fb.group({
      CreditNoteNo: [''],
      OrderBy: [''],
      IsOnlyFinalBills: [true],
      CheckBalance: [false]
    });
    this.BillDetails = new MatTableDataSource([]);
    this.fromDate = new Date().toString();
    this.toDate = new Date().toString();
  }

  onClear() {
    this.ngOnInit();
  }
  onSubmit() {
    this.loaderService.spin.next(true);
    this.httpService.Post(urlConstant.Reports.PatientBillDetailsReport, this.getPayload()).subscribe(response => {
      if (response.Status === 200) {
        this.BillDetails = new MatTableDataSource(response.Data);
        this.loaderService.spin.next(false);
      }
    });

  }

  // Export to Excel
  exportToExcel() {
    this.loaderService.spin.next(true);
    this.httpService.Post(urlConstant.Reports.ExportPatientBillDetailsReport, this.getPayload()).subscribe(response => {
      if (response.Status === 200) {
        this.loaderService.spin.next(false);
        this.httpService.openFile(response.Data);
       
      }
    });

  }


  getPayload() {
    let billDetailObj = this.BillDetailsForm.getRawValue();
    billDetailObj.FromDate = new ParseDate().transform(this.date.FromDate.value);
    billDetailObj.ToDate = new ParseDate().transform(this.date.ToDate.value);
    billDetailObj.AdmissionNo = this.regNo.RegNo;
    billDetailObj.PatientCategory = this.patsrc.myControl.value;
    billDetailObj.CreditCompany = this.commonService.isValidStringValue(this.creditComp.myControl.value)
      ? this.creditComp.myControl.value.trim().split("(")[1].split(")")[0] : "";
    return billDetailObj;
  }

  // on double click open patient folio
  openPatientFolio(index, rowDetails) {
    this.selectedRowData = rowDetails;
    const dialogRef = this.dialog.open(PatientFolioComponent, {
      // maxHeight: '650px',
      disableClose: true,
      // minWidth: '88vw',
    });

    dialogRef.componentInstance.isPopup = true;
    dialogRef.componentInstance.regNo = this.selectedRowData.RegNo;

    dialogRef.afterClosed().subscribe();
  }

  setDepartment(value: any) {
    if (!isNullOrUndefined(value) && value.DepartmentCode.trim().indexOf(" ") < 0) {
      this.department = value;
      this.serviceData = {
        'DepartmentCode': value.DepartmentCode, 'ServiceCode': '',
        'PatientCategoryCode': '01', 'OpCategoryCode': '01',
        'CreditCompanyCode': ''
      };
    }
  }

  setServiceData(service: any) {
    this.service = service.ServiceCode;

  }

}