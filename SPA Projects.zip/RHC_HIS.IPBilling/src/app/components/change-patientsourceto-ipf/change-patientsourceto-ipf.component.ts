import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { messageConstant } from 'src/app/constants/messageConstants';
import { urlConstant } from 'src/app/constants/urlConstants';
import { RegnoTabFieldComponent } from 'regno-tab-field';

@Component({
  selector: 'app-change-patientsourceto-ipf',
  templateUrl: './change-patientsourceto-ipf.component.html',
  styleUrls: ['./change-patientsourceto-ipf.component.css'],
  host: { 'class': 'section__main' },
})
export class ChangePatientsourcetoIpfComponent implements OnInit {
  changePatSourceForm: FormGroup;
  @ViewChild('patDetails') patDetailsComponent: RegnoTabFieldComponent;
  constructor(public fb: FormBuilder, private commonService: CommonService, private httpService: HttpService,
    private loader: LoaderService) { }

  ngOnInit() {
    this.initForm();
    //alert(localStorage.getItem("UserName"))
  }

  // initialize the form
  initForm() {
    this.changePatSourceForm = this.fb.group({
      PatientRegNo: ['', Validators.required],
      PatientName: [{ value: '', disabled: true }],
      Category: [{ value: '', disabled: true }],
      CategoryName: [{ value: '', disabled: true }],
      Income: ['', Validators.maxLength(14)]
    });
  }

  // the function returns the form controls to access in both files.
  public get f() {
    return this.changePatSourceForm.controls;
  }

  // set patient details
  getPatientName(patient) {
    if (!this.commonService.isValidStringValue(patient.AdmissionNo)) {
      this.initForm();
      return;
    }

    console.log(patient.DischargeDate.substring(0, 6));
    console.log(this.commonService.convertDateToString(new Date()).substring(0, 6));
    if (this.commonService.isValidStringValue(patient.DischargeDate)
      && patient.DischargeDate.substring(0, 6) !== this.commonService.convertDateToString(new Date()).substring(0, 6)) {
      this.commonService.displayPromptMessage("Change patient source to ipf", "PATIENT FINAL BILL PREPARED...DISCHARGE DATE [ " + this.commonService.convertStringToDate(patient.DischargeDate).toLocaleDateString() + " ] NOT OF CURRENT MONTH...CATEGORY CANNOT BE CHANGED...");
      this.Resetform(this.patDetailsComponent);
      return;
    }
    this.changePatSourceForm.patchValue({
      "PatientRegNo": patient.AdmissionNo, "PatientName": patient.Title + '. ' + patient.PatientName,
      "Category": patient.PatientCatCode, "CategoryName": '(' + patient.PatientCatCode + ') ' + patient.PatientCategory
    });
  }

  // validation of form
  validateForm(saveIncome: boolean): boolean {
    if (!this.commonService.isValidStringValue(this.f.PatientRegNo.value)) {
      this.commonService.openSnackBar(messageConstant.AllowToGo.RegNoRequired,
        messageConstant.invalidMessages.OK);
      return false;
    }
    if (saveIncome) {
      if (!this.commonService.isValidStringValue(this.f.Income.value)) {
        this.commonService.openSnackBar(messageConstant.ChangePatientSource.IncomeRequired,
          messageConstant.invalidMessages.OK);
        return false;
      }
      if (this.f.Income.value.length > 14) {
        this.commonService.openSnackBar(messageConstant.ChangePatientSource.MaxlengthError,
          messageConstant.invalidMessages.OK);
        return false;
      }
    } else {
      if (!this.commonService.isValidStringValue(this.f.Category.value)) {
        this.commonService.openSnackBar(messageConstant.ChangePatientSource.CatgRequired,
          messageConstant.invalidMessages.OK);
        return false;
      }
    }
    return true;
  }

  // save patient category as free case
  SaveFreeCase(patDetails) {
    if (!this.validateForm(false)) return;

    const input = this.getInputDetails();

    this.commonService.confirmAction(messageConstant.ChangePatientSource.Header, messageConstant.ChangePatientSource.ConfirmFreeCase)
      .subscribe(response => {
        if (response) {
          this.loader.spin.next(true);
          this.httpService.Post(urlConstant.ChangePatientSource.FreeCase(), input).subscribe(result => {
            if (result && result.Status === 200) {
              this.loader.spin.next(false);
              this.commonService.displayPromptMessage(messageConstant.ChangePatientSource.Header, messageConstant.ChangePatientSource.SucessSaveIncome);
              this.Resetform(patDetails);
            } else {
              this.loader.spin.next(false);
              this.commonService.displayPromptMessage(messageConstant.ChangePatientSource.Header, messageConstant.ChangePatientSource.FailSaveIncome);
              this.Resetform(patDetails);
            }
          });

        } else { return; }
      });
  }

  // save patient category as concession
  SaveConcession(patDetails) {
    if (!this.validateForm(false)) return;

    const input = this.getInputDetails();

    this.commonService.confirmAction(messageConstant.ChangePatientSource.Header, messageConstant.ChangePatientSource.ConfirmConsession)
      .subscribe(response => {
        if (response) {
          this.loader.spin.next(true);
          this.httpService.Post(urlConstant.ChangePatientSource.SaveConcession(), input).subscribe(result => {
            if (result && result.Status === 200) {
              this.loader.spin.next(false);
              this.commonService.displayPromptMessage(messageConstant.ChangePatientSource.Header, messageConstant.ChangePatientSource.SucessSaveIncome);
              this.Resetform(patDetails);
            } else {
              this.loader.spin.next(false);
              this.commonService.displayPromptMessage(messageConstant.ChangePatientSource.Header, messageConstant.ChangePatientSource.FailSaveIncome);
              this.Resetform(patDetails);
            }
          });

        } else { return; }
      });
  }

  // save income
  SaveIncome(patDetails) {
    if (!this.validateForm(true)) return;

    const input = this.getInputDetails();

    this.commonService.confirmAction(messageConstant.ChangePatientSource.Header, messageConstant.ChangePatientSource.ConfirmIncome)
      .subscribe(response => {
        if (response) {
          this.loader.spin.next(true);
          this.httpService.Post(urlConstant.ChangePatientSource.SaveIncome(), input).subscribe(result => {
            if (result && result.Status === 200) {
              this.loader.spin.next(false);
              this.commonService.displayPromptMessage(messageConstant.ChangePatientSource.Header, messageConstant.ChangePatientSource.SucessSaveIncome);
              this.Resetform(patDetails);
            } else {
              this.loader.spin.next(false);
              this.commonService.displayPromptMessage(messageConstant.ChangePatientSource.Header, messageConstant.ChangePatientSource.FailSaveIncome);
              this.Resetform(patDetails);
            }
          });

        } else { return; }
      });
  }

  // Get input form details for POST call
  getInputDetails() {
    return {
      RegNo: this.f.PatientRegNo.value,
      CategoryCode: this.f.Category.value,
      DeclaredIncome: this.f.Income.value,
      UserId: localStorage.getItem("UserName")
    }
  }

  Resetform(patDetails) {
    this.initForm();
    patDetails.RegNo = '';
    patDetails.PatientName = '';
  }
}
