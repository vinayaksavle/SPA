import { Component, OnInit, ViewChild, Optional } from '@angular/core';
import 'rxjs/add/operator/filter';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { MatSort, MatTableDataSource, MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { isNullOrUndefined } from 'util';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
    selector: 'app-credit-companies-list',
    templateUrl: './credit-companies.component.html',
    styleUrls: ['./credit-companies.component.css'],
    host: { 'class': 'section__main' }
})
export class CreditCompaniesListComponent implements OnInit {

    // displayedColumns = ["Company Code","Company Name"]
    // deptListDetails;

    @ViewChild(MatSort) sort: MatSort;
    listDetails: MatTableDataSource<any> = new MatTableDataSource([]);

    doctorForm: FormGroup;

    selectedIndexRow: number;
    selectedRowData: any;
    filterValue: any;

    isButtonDisabled: boolean;
    isViewButtonDisabled: boolean;
    isView: boolean;

    displayedColumns: string[] = ['SNo', 'CompanyCode', 'CompanyName', 'Address1', 'CtrlActCode', 'ContactPerson'
        , 'Phone', 'CompanyType', 'Major', 'Officer', 'CrLock', 'PatientCategory'
        , 'GstNo'];
    autoCompleteList: any;
    routeToCompany: string;

    constructor(private fb: FormBuilder, private commonService: CommonService,
        private loader: LoaderService, private httpService: HttpService) {
    }


    ngOnInit() {
        this.initForm();
    }

    initForm() {
        this.filterValue = '';
        this.selectedIndexRow = -1;
        this.selectedRowData = {};
        this.showList();
    }

    highlightSectedRow(index: number, rowDetails: any) {
        if (this.selectedIndexRow === index) {
            this.selectedIndexRow = -1;
            this.isButtonDisabled = false;
            this.isViewButtonDisabled = false;
            this.selectedRowData = null;
        } else {
            this.selectedIndexRow = index;
            if (rowDetails.Status) { this.isButtonDisabled = true; } else { this.isButtonDisabled = false; }
            this.isViewButtonDisabled = true;
            this.selectedRowData = rowDetails;
        }
    }


    // function to filter grid view on the basis of company name and code.
    applyFilter(filterValue: string) {
        this.listDetails.filter = filterValue.trim().toLocaleLowerCase();
        this.onSortChange();
    }

    showList() {
        this.loader.spin.next(true);
        this.httpService.Get(urlConstant.Masters.GetCreditCompanies()).subscribe(response => {
            if (response && response.Status === 200 && response.Data.length > 0) {
                this.loader.spin.next(false);
                this.listDetails = new MatTableDataSource(response.Data);
                this.listDetails.sort = this.sort;
                this.listDetails.filterPredicate = function (data, filter: string): boolean {
                    return data.CompanyCode.toLowerCase().includes(filter.toLowerCase()) ||
                        data.CompanyName.toLowerCase().includes(filter.toLowerCase());
                };
            } else {
                this.loader.spin.next(false);
                this.listDetails = new MatTableDataSource([]);
                this.listDetails.filterPredicate = function (data, filter: string): boolean {
                    return data.CompanyCode.toLowerCase().includes(filter.toLowerCase()) ||
                        data.CompanyName.toLowerCase().includes(filter.toLowerCase());
                };
            }
        }, error => {
            this.listDetails = new MatTableDataSource([]);
            this.loader.spin.next(false);
            return;
        });
    }

    onSortChange() {
        this.selectedIndexRow = -1;
        this.isButtonDisabled = false;
        this.isViewButtonDisabled = false;
    }


}