import { Component, OnInit, ViewChild } from '@angular/core';
import 'rxjs/add/operator/filter';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { MatSort, MatTableDataSource } from '@angular/material';
import { FromDateToDateComponent } from 'from-date-to-date';
import { PatientSourceDropdownComponent } from 'patient-source-dropdown';
import { LoaderService } from 'src/app/services/loader.service';
import { ParseDate } from 'shared-utility';
import { CommonService } from 'src/app/services/common.service';
import { RegnoTabFieldComponent } from 'regno-tab-field';
import { FormControl } from '@angular/forms';
import { NavigationExtras, Router } from '@angular/router';

@Component({
  selector: 'app-estimate-list',
  templateUrl: './estimate-list.component.html',
  styleUrls: ['./estimate-list.component.css'],
  host: { 'class': 'section__main' }
})
export class EstimateListComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('date') date: FromDateToDateComponent;
  @ViewChild('regNoTabfield') regNoTabfield: RegnoTabFieldComponent;
  @ViewChild('patsrc') patSrc: PatientSourceDropdownComponent;
  displayedColumns = [
    "EstimateNo", "RegNo", "PatientName", "EstimateDate", "CompanyName", "TotalAmount", "UserId", "PatientCategoryName", "Phone", "UHID"
  ];

  estimateListDetails: MatTableDataSource<any> = new MatTableDataSource([]);
  Phone = new FormControl();
  RegDate = new FormControl();
  IncludeNonAdm = new FormControl();
  highLightRow: number = -1;
  rowDetails: any;

  constructor(private loader: LoaderService,
    private httpService: HttpService, private commonService: CommonService, private router: Router) {
  }


  ngOnInit(): void {
    this.estimateListDetails = new MatTableDataSource([]);
    this.RegDate.setValue(new Date());
    //this.showEstimateList();
  }

  // Function to show the estimate list
  showEstimateList() {
    let obj = {
      FromDate: new ParseDate().transform(this.date.FromDate.value),
      ToDate: new ParseDate().transform(this.date.ToDate.value),
      RegNo: this.regNoTabfield.RegNo,
      PatientName: this.regNoTabfield.PatientName,
      PatientCategoryCode: this.patSrc.myControl.value,
      Phone: this.Phone.value,
      CheckNonAdmitted: this.IncludeNonAdm.value
    };

    this.estimateListDetails = new MatTableDataSource([]);
    this.loader.spin.next(true);
    this.httpService.Post(urlConstant.NewEstimate.GetEstimateList, obj).subscribe(res => {
      if (res.Status == 200 && res.Data.length > 0) {
        this.estimateListDetails = new MatTableDataSource(res.Data);
        this.estimateListDetails.sort = this.sort;
        this.loader.spin.next(false);
      } else {
        this.loader.spin.next(false);
      }
      this.loader.spin.next(false);
    });
  }

  // Highlight row from grid.
  setActiveServiceRow(index: number, item: any) {
    this.rowDetails = item;
    if (this.highLightRow === index) {
      this.highLightRow = -1;
    } else {
      this.highLightRow = index;
    }

  }

  // Function to navigate to view of estimate details
  navigateToViewEstimate() {
    if (this.highLightRow == -1) {
      this.commonService.openSnackBar("Please select row", "OK");
      return;
    }
    if (!this.commonService.isValidStringValue(this.rowDetails.EstimateNo)) {
      this.commonService.openSnackBar("Invalid Estimate No", "OK");
      return;
    }
    const navigationExtras: NavigationExtras = {
      queryParams: {
        'EstimateNo': this.rowDetails.EstimateNo
      }
    };
    this.router.navigate(['/billing/estimate/new-estimate'], navigationExtras)
  }

  // Function to get non estimated list of patients based on Reg Date.
  getNonEstimatedPatients() {
    if (!this.commonService.isValidStringValue(this.RegDate.value)) {
      this.commonService.openSnackBar("Invalid Reg Date", "OK");
      return;
    }
    let regDate = new ParseDate().transform(this.RegDate.value);
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.NewEstimate.GetNonEstimatedPatients(regDate)).subscribe(
      res => {
        if (res.Status == 200) {
          this.estimateListDetails = new MatTableDataSource(res.Data);
          this.estimateListDetails.sort = this.sort;
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
        }
      });
  }

  // Function to reset form values
  resetForm() {
    this.date.FromDate.setValue(new Date());
    this.date.ToDate.setValue(new Date());
    this.regNoTabfield.clearFields();
    this.patSrc.myControl.setValue('');
    this.Phone.reset();
    this.IncludeNonAdm.setValue(false);
    this.RegDate.setValue(new Date());
    this.estimateListDetails = new MatTableDataSource([]);
  }

}