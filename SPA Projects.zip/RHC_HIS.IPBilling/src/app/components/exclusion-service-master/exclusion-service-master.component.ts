import { Component, ElementRef, ViewChild } from '@angular/core';
import { MatSort, MatTableDataSource } from '@angular/material';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { map, startWith } from 'rxjs/operators';
import { LoaderService } from 'src/app/services/loader.service';
import { CommonService } from 'src/app/services/common.service';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { PatientSourceMultiselectLookupComponent } from 'patient-source-multiselect-lookup';

@Component({
  selector: 'app-exclusion-service-master',
  templateUrl: './exclusion-service-master.component.html',
  styleUrls: ['./exclusion-service-master.component.css'],
  host: { 'class': 'section__main' }
})

export class ExclusionServiceMasterComponent {

  exclusionServiceForm: FormGroup;
  @ViewChild('search') searchTextBox: ElementRef;
  @ViewChild('department') department;
  @ViewChild(MatSort) sort: MatSort;
  serviceList: any[];
  filteredOptions: any;
  selectAll: boolean;
  selectedValues = [];
  ServiceControl = new FormControl();
  searchTextboxControl = new FormControl();
  isServiceDisable: boolean;
  exclusionServiceDetails = new MatTableDataSource([]);
  displayedColumns = [
    "SerialNo", "DepartmentCode", "ServiceCode", "PatientCategory", "Type"
  ];
  departmentCode: any;
  UserId: any;
  selectedRowData: any;
  selectedRowIndex: any;
  action: string = "N";
  @ViewChild('patientmultiselect') patientmultiselect: PatientSourceMultiselectLookupComponent;
  type: string = "N";
  constructor(

    private httpService: HttpService, private loader: LoaderService, private commonService: CommonService,
    private dataTransfer: DataTranferService) { }

  ngOnInit() {
    this.departmentCode = "";
    this.isServiceDisable = true;
    this.UserId = this.dataTransfer.GetUserName();
    this.selectAll = true;
    // this.getServiceList("");
    this.getExclusionServDetails();
  }

  getExclusionServDetails() {
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.ExclusionServiceMaster.GetExclusionServDetails()).subscribe(
      res => {
        if (res.Status == 200 && res.Data.length > 0) {
          this.exclusionServiceDetails = new MatTableDataSource(res.Data);
          this.exclusionServiceDetails.sort = this.sort;
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
        }
        this.loader.spin.next(false);
      });
  }

  getDepartmentCode(event) {
    this.departmentCode = event.DepartmentCode;
    this.getServiceList(event.DepartmentCode);
  }

  getServiceList(deptCode: string) {
    this.serviceList = [];
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.ExclusionServiceMaster.GetServices(deptCode)).subscribe((response: any) => {
      this.serviceList = response.Data;
      this.loader.spin.next(false);
      this.filteredOptions = this.searchTextboxControl.valueChanges.pipe(
        startWith<string>(''),
        map(name => this._filter(name))
      );
      this.loader.spin.next(false);
    });
  }
  openedChange(e) {
    // Set search textbox value as empty while opening selectbox
    this.searchTextboxControl.patchValue('');
    // Focus to search textbox while clicking on selectbox
    if (e === true) {
      this.searchTextBox.nativeElement.focus();
    }
  }
  selectionChange(event) {
    if (event.isUserInput && event.source.selected === false) {
      const index = this.selectedValues.indexOf(event.source.value);
      this.selectedValues.splice(index, 1);
    }
  }
  clearLookup(event) {
    event.stopPropagation();
    this.searchTextboxControl.patchValue('');
  }
  private _filter(name: any): any[] {
    const filterValue = name.toLowerCase();
    // Set selected values to retain the selected checkbox state
    this.setSelectedValues();
    this.ServiceControl.patchValue(this.selectedValues);
    let filteredList = this.serviceList.filter(option => option.ServiceName.toLowerCase().indexOf(filterValue) === 0 || option.ServiceCode.toLowerCase().indexOf(filterValue) === 0);
    return filteredList;
  }



  setSelectedValues() {
    if (this.ServiceControl.value && this.ServiceControl.value.length > 0) {
      this.ServiceControl.value.forEach((e) => {
        if (this.selectedValues.indexOf(e) === -1) {
          this.selectedValues.push(e);
        }
      });
    }
  }

  SelectAll(list) {
    const newList = list.map(x => x.ServiceCode);
    this.ServiceControl.patchValue(newList);
    this.selectAll = false;
  }

  DeSelectAll() {
    this.selectAll = true;
    this.ServiceControl.patchValue([]);
    this.selectedValues = [];
  }

  AddNewService() {

    if (!this.commonService.isValidStringValue(this.departmentCode) ) {
      this.commonService.openSnackBar("Invalid Department or Service", "OK");
      return;
    }
    const obj = {
      DepartmentCode: this.departmentCode,
      ServiceCodeList: this.ServiceControl.value,
      UserId: this.UserId,
      Action: this.action,
      Type: this.type,
      Category: this.patientmultiselect.PatientSourceControl.value.join(","),
      Id: this.action === "U" ? this.selectedRowData.Id : 0
    }

    this.commonService.confirmAction("Exclusion Service Master", "Do you want to save?").subscribe(
      response => {
        if (response) {
          this.loader.spin.next(true);
          this.httpService.Post(urlConstant.ExclusionServiceMaster.PostNewService(), obj).subscribe(
            res => {
              if (res.Status == 200 && res.Data) {
                this.loader.spin.next(false);
                if (this.action == "N") {
                  this.commonService.displayPromptMessage("Exclusion Service Master", "Service Added Successfully!");
                  window.location.reload();
                } else {
                  this.commonService.displayPromptMessage("Exclusion Service Master", "Service Updated Successfully!");
                  window.location.reload();
                }
              } else {
                this.loader.spin.next(false);
                window.location.reload();
              }
              this.loader.spin.next(false);
            });

        } else {
          return;
        }

      })

  }

  // To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }
  UpdateServiceDetails() {
    this.department.myControl.setValue('(' + this.selectedRowData.DepartmentCode + ') ' +
      this.selectedRowData.DepartmentName);
    this.departmentCode = this.selectedRowData.DepartmentCode;
    this.getServiceList(this.selectedRowData.DepartmentCode);
    const serviceCodes = [this.selectedRowData.ServiceCode];
    this.ServiceControl.patchValue(serviceCodes);
    this.action = "U";
    this.type = this.selectedRowData.Type;
    const categoryCodes = [this.selectedRowData.Category.trim().split(",")];
    this.patientmultiselect.PatientSourceControl.setValue(categoryCodes[0]);
  }
  resetForm() {
    this.selectedRowIndex = -1;
    this.departmentCode = "";
    this.department.myControl.setValue("");
    this.ServiceControl.setValue("");
    this.selectedValues = [];
    this.ngOnInit();
  }


}
