import { Component, OnInit } from "@angular/core";
import { MatDialogRef, MatTableDataSource } from '@angular/material';
import { urlConstant } from 'src/app/constants/urlConstants';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
    selector: 'app-eligible-finalbill-patients',
    templateUrl: './eligible-finalbill-patients.html',
    styleUrls: ['./eligible-finalbill-patients.css']
})

export class EligibleFinalbillPatientsComponent implements OnInit {
    isPopup: boolean = false;
    eligibleForFinalBillList: MatTableDataSource<any> = new MatTableDataSource();
    displayedColumns: string[] = ['SNo', 'RegNo', 'PatName', 'BedNo', 'RegDate'];

    constructor(
        private http: HttpService,
        private loader: LoaderService,
        private dialogRef: MatDialogRef<EligibleFinalbillPatientsComponent>
    ) { }

    ngOnInit() {
        this.getEligibleForFinalBillList();
    }

    // Author - Vinayak Savale
    // Get Eligible Patient list for Final Bill Creation
    getEligibleForFinalBillList() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.Billing.GetEligibleForFNBillList()).subscribe(response => {
            this.eligibleForFinalBillList = new MatTableDataSource(response.Data);
        });
        this.loader.spin.next(false);
    }

    //close dialog box
    closeDialog() {
        this.dialogRef.close();
    }
}