import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { MatTableDataSource, MatDialog, MatSort, throwMatDialogContentAlreadyAttachedError } from '@angular/material';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';
import { isNullOrUndefined } from 'util';
import { messageConstant } from 'src/app/constants/messageConstants';

@Component({
  selector: 'app-ip-credit-note-new',
  templateUrl: './ip-credit-note-new.component.html',
  styleUrls: ['./ip-credit-note-new.component.css'],
  host: { 'class': 'section__main' },
})
export class IpCreditNoteNewComponent implements OnInit, AfterViewInit {
  ipCreditNewForm: FormGroup;
  @ViewChild('patDetails') patDetails: PatientDetailsComponent;
  @ViewChild(MatSort) sort: MatSort;
  creditNo: any;
  action: any;
  initSearcObject: any = {};
  savePatientDtlObject: any = {};
  panelOpenState = true;
  isRecordDisabled = false;
  isCancelDisabled = false;
  isPrintDisabled = false;
  isRemoveDisabled = false;
  isChangeDisabled = false;
  isAddDisabled = false;
  flag79 = false;
  doctorServiceDetailsList: MatTableDataSource<any> = new MatTableDataSource([]);
  ipBillList: MatTableDataSource<any> = new MatTableDataSource([]);
  doctorServiceList: MatTableDataSource<any> = new MatTableDataSource([]);
  CreditDtlList: MatTableDataSource<any> = new MatTableDataSource([]);
  // Doctor List Column names.
  displayedColumnsList: string[] = ['SerialNo', 'DoctName', 'DoctorCode', 'ServiceName', 'DepartmentCode', 'Quantity', 'ServiceCost', 'ServiceAmount', 'ServiceNo', 'BillNo', 'BillDate', 'GeneralDepartmentNo'];
  displayedBillColumnsList: string[] = ['SerialNo', 'NetBillAmt', 'RcvdCRAmt', 'TDSAmt', 'RefndAmt', 'NetAmt', 'GrossAmt', 'DepAmt', 'BillNo', 'BillDate', 'FolioNo'];
  displayedDoctServiceColumnsList: string[] = ['SerialNo', 'ServCode', 'ServName', 'Amount', 'DoctCode', 'CCCode'];
  displayedCreditColumnsList: string[] = ['SerialNo', 'ChargCode', 'ChargDesc', 'ServCode', 'ServName', 'Amount', 'ACCode', 'CCCode', 'Remarks'];
  currentDate: string;
  currentTime: string = this.commonService.getCurrentTime();
  highLightRow: number;
  selectedIndex: number;
  doctorAccountingDetailsShow: any = [];
  charge: string[] = [];
  amount: string[] = [];
  acCode: string[] = [];
  cCCodeT: string[] = [];
  //charge: new Array[];
  rowDetails: any;
  newData: any[];
  newService: any[];
  serviceData: any = {
    'DepartmentCode': '19', 'ServiceCode': '',
    'PatientCategoryCode': '', 'OpCategoryCode': '', 'CreditCompanyCode': ''
  };
  ccCode: any;
  doctCode: any;
  doctFlag: boolean;
  hiddenItems: any = ['FinalButton', 'InterimButton', 'DoctorButton', 'ApprovedAmount',
    'TPA', 'DischDateTime', 'InsCompanyName', 'AdmitDateTime'];
  creditNote: any = {};
  title: string;
  patientDetails: any = {};
  permissions: any = [];
  canPrintNote: boolean;


  constructor(
    private activateRoute: ActivatedRoute,
    public fb: FormBuilder,
    private commonService: CommonService,
    private httpService: HttpService,
    private loader: LoaderService,
    private router: Router,
    public dialog: MatDialog) {

    //#region permission
    this.permissions = JSON.parse(localStorage.getItem('Permission'));

    if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
      // Credit Note Print Permissons set
      this.canPrintNote = this.permissions.includes('4004P') ? true : false;
    }
    //#endregion
  }

  ngAfterViewInit(): void {
    setTimeout(() => {
      let regNo = localStorage.getItem("CNRegno");
      if (this.commonService.isValidStringValue(regNo)) {
        this.patDetails.setPatientDetailByRegNo(regNo);
      }
    }, 2000);
  }

  ngOnInit() {

    this.initForm();
    this.setRouteParameters();
    this.getFormDetailsBasedOnAction();
  }




  // initialize the form
  initForm() {
    // this.getCurrentDateString();
    this.ipCreditNewForm = this.fb.group({
      Action: [""],
      RegNo: [{ value: '', disabled: true }],
      PatSrcCode: [{ value: '', disabled: true }], // used while N 
      CounterNo: [{ value: '11', disabled: true }],
      CounterSLNo: [{ value: '', disabled: true }],
      FolioNo: [{ value: '', disabled: true }],
      IpBillNo: [{ value: '', disabled: true }], // false
      CreditNo: [{ value: '', disabled: true }],
      CreditDate: [{ value: this.commonService.convertDateToString(), disabled: true }],
      CreditTime: [{ value: this.currentTime, disabled: true }],
      TXTDoctCD: [{ value: '', disabled: true }], //used to check patient source while action is N
      DeclareIncome: [{ value: '', disabled: true }],
      ChargCode: [''],
      Status: [''],
      CnAmount: ['0.00'],
      NetAmount: ['0.00'],
      ChargDesc: [{ value: '', disabled: true }],
      Amount: [''],
      ACCode: [{ value: '', disabled: true }],
      CCCode: [{ value: '', disabled: true }], // false
      Remark: [''],
      Reason: [''],
      UserId: [{ value: localStorage.getItem('UserName'), disabled: true }],
      Total: [{ value: '0.00', disabled: true }],
      DoctorServices: this.fb.array([]),
      Departments: this.fb.array([]),
    });
    this.highLightRow = -1;

  }

  // the function returns the form controls to access in both files.
  public get f() {
    return this.ipCreditNewForm.controls;
  }

  // get doctor list controls
  get ServiceArray(): FormArray {
    return this.ipCreditNewForm.get('DoctorServices') as FormArray;
  }


  // get department list controls
  get DepartmentArray(): FormArray {
    return this.ipCreditNewForm.get('Departments') as FormArray;
  }

  // initializes doctor 
  initService(service): any {

    if (isNullOrUndefined(service)) {
      return this.fb.group({
        ServCode: [''],
        ServiceName: [''],
        Amount: [''],
        DoctCode: [''],
        DoctName: [''],
        PatientSrc: [''],
        CCCode: ['']
      });
    }
    else {

      return this.fb.group({
        ServCode: [{ value: service.ServCode, disabled: true }],
        ServiceName: [{ value: service.ServiceName, disabled: true }],
        Amount: [{ value: service.Amount, disabled: true }],
        DoctCode: [{ value: service.DoctCode, disabled: true }],
        DoctName: [{ value: service.DoctName, disabled: true }],
        PatientSrc: [{ value: service.PatientSrc, disabled: true }],
        CCCode: [{ value: service.CCCode, disabled: true }]
      });
    }

  }


  // initializes doctor 
  initDepartment(department?): any {
    if (isNullOrUndefined(department)) {
      return this.fb.group({
        ChrgCode: [''],
        ChrgDesc: [''],
        Amount: [''],
        AcCode: [''],
        CcCode: [''],
        ServCode: [''],
        Remarks: [''],
        ServiceName: [''],
      });
    }
    else {
      return this.fb.group({
        ChrgCode: [{ value: department.ChrgCode, disabled: true }],
        ChrgDesc: [{ value: department.ChrgDesc, disabled: true }],
        ServiceName: [{ value: department.ServiceName, disabled: true }],
        Amount: [{ value: department.Amount, disabled: true }],
        AcCode: [{ value: department.AcCode, disabled: true }],
        CcCode: [{ value: department.CcCode, disabled: true }],
        ServCode: [{ value: department.ServCode, disabled: true }],
        Remarks: [{ value: department.Remarks, disabled: true }],
      });
    }

  }

  addDepartment(count: number = 1, department?) {
    let departments = this.CreditDtlList.data;
    for (let i = 0; i < count; i++) {
      this.DepartmentArray.push(this.initDepartment(department));
      departments.push({});
    }

    this.CreditDtlList = new MatTableDataSource(departments);
  }

  addService(count: number = 1, service?) {
    let services = this.doctorServiceList.data;
    for (let i = 0; i < count; i++) {
      this.ServiceArray.push(this.initService(service));
      services.push({});
    }

    this.doctorServiceList = new MatTableDataSource(services);
  }

  setRouteParameters() {
    this.activateRoute.params.subscribe(params => {
      this.creditNo = params['creditNo'];
      this.action = params['action'];
      this.f.Action.setValue(this.action);
    });
  }

  // sets patient details on event emit
  setPatientDetail(patient: any, patDetails?: any) {
    this.patientDetails = patient;
    if (!this.commonService.isValidStringValue(patient.RegNo)) {
      this.ipBillList = new MatTableDataSource([]);
      this.doctorServiceList = new MatTableDataSource([]);
      this.CreditDtlList = new MatTableDataSource([]);
      this.initForm();
      return;
    }
    this.ipCreditNewForm.patchValue({
      "RegNo": patient.RegNo, "PatSrcCode": patient.PatientCategoryCode,
      "TXTDoctCD": patient.TreatingDoctorCode,
      "FolioNo": patient.FolioNo, "CreditNo": this.creditNo
    });



    if (this.action === 'N') {
      this.ipBillList = new MatTableDataSource([]);
      this.doctorServiceList = new MatTableDataSource([]);
      this.CreditDtlList = new MatTableDataSource([]);
      // this.doctorServiceList = new MatTableDataSource([]);
      this.f.Remark.setValue("");
      this.f.Total.setValue("0.00");
      this.RetrieveIpCnFormDetails();
    }

  }

  // sets service data i.e. amount quantity, price 
  setServiceData(service: any, isSelected: boolean) {
    if (!this.commonService.isValidStringValue(service.ServiceCode)) {
      // this.serviceComponent.serviceName = "";
    }
    this.commonService.confirmAction(messageConstant.IpCreditNew.Header, messageConstant.IpCreditNew.ConfirmAddservice).subscribe(
      result => {
        if (result) {
          this.httpService.Get(urlConstant.IpCreditNoteList.GetDoctCodeAndCcCode(service.ServiceCode, '19')).subscribe(
            response => {
              if (response && response.Data.length > 0) {
                this.doctCode = response.Data[0].DoctCode;
                this.ccCode = response.Data[0].CCCode;
              }
              this.newService = this.doctorServiceList.data;
              this.newService.push({
                ServCode: service.ServiceCode,
                DoctName: service.ServiceName,
                Amount: '',
                DoctCode: this.doctCode,
                CCCode: this.ccCode,
                PatientSrc: ''
              });
              this.doctorServiceList = new MatTableDataSource<any>(
                this.newService
              );
            });
        } else {
          return;
        }
      });
  }

  RetrieveIpCnFormDetails() {
    this.createInItSearchObject();
    this.loader.spin.next(true);
    this.httpService.Post(urlConstant.IpCreditNoteList.DisplayIpCnFormDetails(), this.initSearcObject).subscribe(
      response => {
        if (response) {
          this.creditNote = response.Data;
          this.f.DeclareIncome.setValue(response.Data.DeclareAmount);
          if (this.action !== 'N') {
            this.setPatientDetailsIfIorD(response.Data.RetrieveIpCnFormPatientDetails[0])
            this.setFormValues(response.Data.RetrieveIpCnFormDetails[0])
            // this.f.Total.setValue(response.Data.RetrieveIpCnFormTranDetails.map(item => item.Amount).reduce((prev, next) => parseFloat(prev) + parseFloat(next)));
            this.creditNote.CnAmount = this.f.Total.value;
            this.ipBillList = new MatTableDataSource(response.Data.RetrieveIpCnFormPatientDetails);

            if (response.Data.RetrieveIpCnFormPatientDetails.length > 0) {
              this.setActiveServiceRow(0, this.ipBillList.data[0]);
            }

            for (let i = 0; i < response.Data.RetrieveIpCnFormTranDetails.length; i++) {
              this.addDepartment(1, response.Data.RetrieveIpCnFormTranDetails[i]);
            }

            for (let i = 0; i < response.Data.RetriveDoctorServiceDetails.length; i++) {
              this.addService(1, response.Data.RetriveDoctorServiceDetails[i]);
            }
            // this.CreditDtlList = new MatTableDataSource(response.Data.RetrieveIpCnFormTranDetails);
            // this.doctorServiceList = new MatTableDataSource(response.Data.RetriveDoctorServiceDetails);

          }
          else {
            this.ipBillList = new MatTableDataSource(response.Data.RetrieveIpCnFormPatientDetails);
            if (response.Data.RetrieveIpCnFormPatientDetails.length > 0) {
              this.setActiveServiceRow(0, this.ipBillList.data[0]);
            }
          }
        }
        this.loader.spin.next(false);

      });
    this.showDoctorServiceDetails();

  }

  // get transaction detail based on charge code
  getChargeName(event) {
    if (!isNullOrUndefined(event) && event.length > 0) {
      //this.loader.spin.next(true);
      if (event.length === 1) {
        event = '0' + event;
      }
      if (event === '79' && this.CreditDtlList.data.length >= 1) {
        this.commonService.displayPromptMessage("Credit Note", messageConstant.IpCreditNew.InvalidChargeCode);
        this.f.ChargCode.setValue('');
      } else {
        this.loader.spin.next(true);
        this.httpService.Get(urlConstant.IpCreditNoteList.CommGetStlmntChrgName(event))
          .subscribe(response => {
            if (response && response.Data.length > 0) {
              this.loader.spin.next(false);
              this.f.ChargDesc.setValue(response.Data[0].ChrgDesc);
              this.f.ACCode.setValue(response.Data[0].AcCode);
              this.f.CCCode.setValue(response.Data[0].CcCode);
            } else {
              this.loader.spin.next(false);
            }
          });
      }
    } else {
      this.nullTransaction();
    }
  }

  // set form values
  setFormValues(patientData) {
    if (!isNullOrUndefined(patientData)) {
      this.patDetails.patientForm.controls.RegNo.setValue(patientData.RegNo);
      //  this.patDetails.getPatientDetails(patientData.RegNo);
      this.f.RegNo.setValue(patientData.RegNo);
      this.patDetails.patientForm.controls.RegNo.disable();
      this.patDetails.patientForm.controls.BedNo.disable();
      this.patDetails.patientForm.controls.BedCategory.disable();
      this.patDetails.patientForm.controls.FolioNo.disable();
      this.f.CounterNo.setValue(patientData.CntrNo);
      this.f.CounterSLNo.setValue(patientData.CntrSlNo);
      this.f.FolioNo.setValue(patientData.ShiftNo);
      this.f.IpBillNo.setValue(patientData.BillNo);
      this.f.CreditNo.setValue(patientData.IpCnNo);
      this.f.CreditDate.setValue(patientData.IpCnDate);
      this.f.CreditTime.setValue(patientData.IpCnTime);
      this.currentTime = patientData.IpCnTime;
      this.f.Remark.setValue(patientData.Remarks);
      this.f.Reason.setValue(patientData.Reason);
      this.action === "D" ? this.f.Reason.enable() : this.f.Reason.disable();
      this.f.UserId.setValue(patientData.UserId);
      this.f.Total.setValue(patientData.CnAmount);
      this.f.Status.setValue(patientData.Status);
      if (patientData.Status === 'C') {
        this.commonService.displayPromptMessage('Credit Note', 'Credit Note Cancelled !');
        this.isRecordDisabled = true;
      }
    } else {
      // this.commonService.displayPromptMessage("Credit Note",messageConstant.AllowToGo.RegNoRequired);
      this.resetForm();
      // this.router.navigate([urlConstant.IpCreditNoteList.NavigateToNewNote]);

    }
  }

  // set patient details 
  setPatientDetailsIfIorD(patientData) {
    if (!isNullOrUndefined(patientData)) {
      this.patDetails.setPatientDetailByRegNo(patientData.RegNo);
      this.f.RegNo.setValue(patientData.RegNo);

    } else {
      this.commonService.displayPromptMessage("Credit Note", messageConstant.AllowToGo.RegNoRequired);
      this.resetForm();
    }
  }

  // create search object
  createInItSearchObject() {
    this.initSearcObject.RegNo = this.f.RegNo.value;
    this.initSearcObject.IpCnNo = this.creditNo;
    this.initSearcObject.FolioNo = this.f.FolioNo.value;
    this.initSearcObject.IpBillNo = this.f.IpBillNo.value;
    this.initSearcObject.Action = this.action;
  }

  // get form details based on action
  getFormDetailsBasedOnAction() {
    if (this.action === 'D' || this.action === 'I') {
      this.hiddenItems.push("EnquiryButton");
      if (this.action === 'D') {
        this.isPrintDisabled = true;
        this.title = "Cancel";
      } else if (this.action === 'I') {
        this.isRecordDisabled = true;
        this.title = "View";
      }
      this.isCancelDisabled = true;
      this.ipCreditNewForm.disable();
      this.RetrieveIpCnFormDetails();
    } else if (this.action === 'N') {
      this.f.CreditDate.setValue(this.commonService.convertDateToString());
      this.f.CreditTime.setValue(this.currentTime);
      this.title = "New";
    }
  }



  // Highlight row from grid.
  setActiveServiceRow(index: number, item: any) {
    this.rowDetails = item;
    this.highLightRow = index;
    this.f.IpBillNo.setValue(item.IpBillNo);
    this.f.CnAmount.setValue(item.CnAmount);
    this.f.NetAmount.setValue(item.NetAmt);

    if (index > -1 && this.CreditDtlList.data.length === 0 && this.action === 'N') {
      this.addDepartment(1);
      this.addService(1);
    }

  }

  // check charge code 79
  check79() {
    return !isNullOrUndefined(this.DepartmentArray.value.filter(d => d.ChrgCode.trim() === '79' && d.AcCode.trim() === '3-30-371')[0]);
  }

  //validates form before saving
  validateTransaction(): boolean {
    if (!this.commonService.isValidStringValue(this.f.ChargCode.value)) {
      this.commonService.openSnackBar(messageConstant.IpCreditNew.RequiredChargeCode,
        messageConstant.invalidMessages.OK);
      return false;
    } else if (!this.commonService.isValidStringValue(this.f.ChargDesc.value)) {
      this.commonService.openSnackBar(messageConstant.IpCreditNew.RequiredChargeDesc,
        messageConstant.invalidMessages.OK);
      return false;
    }
    else if (!this.commonService.isValidStringValue(this.f.Amount.value)) {
      this.commonService.openSnackBar(messageConstant.IpCreditNew.RequiredAmount,
        messageConstant.invalidMessages.OK);
      return false;
    } else if (this.f.ChargCode.value.length > 2) {
      this.commonService.openSnackBar(messageConstant.IpCreditNew.RequiredChargeCode,
        messageConstant.invalidMessages.OK);
      this.f.ChargCode.setValue('');
      return false;
    } else if (this.f.Amount.value.length > 14) {
      this.commonService.openSnackBar(messageConstant.IpCreditNew.RequiredAmount,
        messageConstant.invalidMessages.OK);
      this.f.Amount.setValue('');
      return false;
    }
    return true;
  }
  // add transaction
  addTransaction() {

    this.check79();
    if (this.flag79) {
      this.commonService.displayPromptMessage("Credit Note", messageConstant.IpCreditNew.InvalidChargeCode);
      this.nullTransaction();
    } else if (!this.validateTransaction()) {
      return;
    } else if (this.ipBillList.data.length > 0 && parseFloat(this.f.Amount.value) > parseFloat(this.ipBillList.data[0].NetAmt) &&
      this.f.ChargCode.value !== '79' && this.f.ACCode.value !== '3-30-371') {
      this.commonService.displayPromptMessage("Credit Note", messageConstant.IpCreditNew.InvalidAmount);
      this.f.Amount.setValue('');
      return;
    } else if (this.ipBillList.data.length > 0 && (parseFloat(this.f.Amount.value) + parseFloat(this.f.Total.value)) > parseFloat(this.ipBillList.data[0].NetAmt) &&
      this.f.ChargCode.value !== '79' && this.f.ACCode.value !== '3-30-371') {
      this.commonService.displayPromptMessage("Credit Note", messageConstant.IpCreditNew.InvalidAmountWithNetAmt);
      this.f.Amount.setValue('');
      return;
    } else {
      this.commonService.confirmAction(messageConstant.IpCreditNew.Header, messageConstant.IpCreditNew.ConfirmAddTransaction).subscribe(
        result => {
          if (result) {
            this.newData = this.CreditDtlList.data;
            this.newData.push({
              AcCode: this.f.ACCode.value,
              Amount: this.f.Amount.value,
              ChrgDesc: this.f.ChargDesc.value,
              CcCode: this.f.CCCode.value,
              ChrgCode: this.f.ChargCode.value
            });
            this.CreditDtlList = new MatTableDataSource<any>(this.newData);
            this.f.Total.setValue(this.CreditDtlList.data.map(item => item.Amount).reduce((prev, next) => parseFloat(prev) + parseFloat(next)));
            this.nullTransaction();
          } else {
            return;
          }
        });
    }
  }

  // remove transaction
  removeTransaction(index) {
    this.commonService.confirmAction(messageConstant.IpCreditNew.Header, messageConstant.IpCreditNew.ConfirmRemoveTransaction).subscribe(
      result => {
        if (result) {
          if (this.CreditDtlList.data.length > 2) {
            this.CreditDtlList.data.splice(index, 1);
            this.CreditDtlList = new MatTableDataSource(this.CreditDtlList.data);
          } else {
            this.CreditDtlList = new MatTableDataSource([]);
          }
          this.nullTransaction();
          if (this.CreditDtlList.data.length > 2) {
            this.f.Total.setValue(this.CreditDtlList.data.map(item => item.Amount).reduce((prev, next) => parseFloat(prev) + parseFloat(next)));
          } else {
            this.f.Total.setValue('0.00');
          }
        } else { return; }
      });
  }

  // change transaction
  changeTransaction(index) {
    this.commonService.confirmAction(messageConstant.IpCreditNew.Header, messageConstant.IpCreditNew.ConfirmChangeTransaction).subscribe(
      result => {
        if (result) {
          if (this.CreditDtlList.data.length > 2) {
            this.CreditDtlList.data.splice(index, 1);
            this.CreditDtlList = new MatTableDataSource(this.CreditDtlList.data);
          } else {
            this.CreditDtlList = new MatTableDataSource([]);
          }
          this.addTransaction();
        } else { return; }
      });
  }

  // validation save form
  saveFormValidation() {
    this.doctFlag = false;

    if (this.action === 'N') {
      if (!this.commonService.isValidStringValue(this.f.RegNo.value)) {
        this.commonService.openSnackBar('Invalid patient registration number.',
          'OK');
        return false;
      } else if (this.ipBillList.data.length < 1) {
        this.commonService.openSnackBar('Bill Is Not Generated For Patient.',
          'OK');
        return false;
      } else if (isNaN(parseFloat(this.f.Total.value)) || parseFloat(this.f.Total.value) === 0) {
        this.commonService.openSnackBar("Total amount cannot be blank!",
          "OK");
        return false;
      } else if (parseFloat(this.f.Total.value) > parseFloat(this.f.NetAmount.value)) {
        this.commonService.openSnackBar("Credit amount is greater than bill net amount",
          'OK');
        return false;
      } else if (!this.commonService.isValidStringValue(this.f.Remark.value)) {
        this.commonService.openSnackBar('Remark is required', 'OK');
        return false;
      } else if (this.f.Remark.value.length > 40) {
        this.commonService.openSnackBar('Remark can not exceed 40 character.',
          'OK');
        return false;
      } else if (this.f.Total.value.toString().length > 14) {
        this.commonService.openSnackBar('Charge Amount Can Not Be Greater Than Total Amount.',
          'OK');
        return false;
      } else if (this.commonService.isValidStringValue(this.f.DeclareIncome.value) && this.f.DeclareIncome.value.toString().length > 14) {
        this.commonService.openSnackBar('Declared Income can not exceed 14 digit',
          'OK');
        this.f.DeclareIncome.setValue('');
        return false;
      }



      this.check79();
      if (!this.flag79) {
        if (this.ipBillList.data.length > 0 && parseFloat(this.f.Total.value) > parseFloat(this.f.NetAmount.value)) {
          this.commonService.openSnackBar('Credit Amount is greater than Net Bill Amount',
            'OK');
          return false;
        }
      }
      let DOCTAMT = 0, DOCTSERVAMT = 0;
      let transactionRowCount = this.DepartmentArray.length;
      for (let i = 0; i < transactionRowCount; i++) {
        if (this.DepartmentArray.value[i].ChrgCode === '19') {
          DOCTAMT = DOCTAMT + parseFloat(this.DepartmentArray.value[i].Amount)
          this.doctFlag = true;
        }

        // commented validation as per suggestion by Vinayak
        // if (this.commonService.isValidStringValue(this.departmentControl(i).ChrgCode.value)
        //   && !this.commonService.isValidStringValue(this.departmentControl(i).ServiceName.value)) {
        //   this.commonService.displayPromptMessage("Credit Note", "Invalid service selected for row " + (i + 1));
        //   return false;
        // }
      }
      let serviceRowCount = this.ServiceArray.length;
      for (let i = 0; i < serviceRowCount; i++) {
        if (this.commonService.isValidStringValue(this.ServiceArray.value[i].Amount))
          DOCTSERVAMT = DOCTSERVAMT + parseFloat(this.ServiceArray.value[i].Amount);
      }

      // commented validation as per suggestionby user on 21 dec 2020 by Aditya
      if (DOCTAMT !== DOCTSERVAMT && this.doctFlag) {
        this.commonService.displayPromptMessage("Credit Note", messageConstant.IpCreditNew.InvalidServiceAmt);
        return false;
      }

    }

    if (this.action === "D") {

      if (!this.commonService.isValidStringValue(this.f.Reason.value)) {
        this.commonService.openSnackBar('Reason for cancellation is required', 'OK');
        return false;
      } else if (this.f.Reason.value.length > 40) {
        this.commonService.openSnackBar('Reason for cancellation can not exceed 40 character.',
          'OK');
        return false;
      }
    }

    return true;
  }

  // save record
  saveRecord() {
    if (!this.saveFormValidation()) return;

    this.createSaveObject();
    this.commonService.confirmAction(messageConstant.IpCreditNew.Header, messageConstant.IpCreditNew.ConfirmActionMsg(this.action)).subscribe(
      response => {
        if (response) {
          this.loader.spin.next(true);
          this.httpService.Post(urlConstant.IpCreditNoteList.SaveIPCNFormDetails(), this.savePatientDtlObject).subscribe(
            response => {
              if (response && response.Data) {
                if (this.action === 'D') {
                  this.commonService.displayPromptMessage(messageConstant.IpCreditNew.Header, messageConstant.IpCreditNew.ConfirmDelete);
                  this.resetForm();
                  this.isRecordDisabled = true;
                  this.redirectToList();
                } else {
                  this.commonService.confirmAction(messageConstant.IpCreditNew.Header, "Do you want to Print?").subscribe(
                    res => {
                      if (res) {
                        // Permission Check For Print
                        if (this.canPrintNote) {
                          this.Print(response.Data, true);
                        }
                      } else {
                        this.redirectToList();
                        this.commonService.displayPromptMessage(messageConstant.IpCreditNew.Header, messageConstant.IpCreditNew.ConfirmNew);
                        this.resetForm();
                        this.isRecordDisabled = false;
                      }

                    });
                }
              } else {
                this.commonService.displayPromptMessage(messageConstant.IpCreditNew.Header, messageConstant.IpCreditNew.Error);
              }

              this.loader.spin.next(false);
            });
        }

      });

  }

  // set blank trancaction value 
  nullTransaction() {
    // this.serviceControl(i)
  }

  // resetForm
  resetForm(fromHtml?: boolean) {
    if (!fromHtml) {
      this.initForm();
      this.doctorServiceList = new MatTableDataSource([]);
      this.ipBillList = new MatTableDataSource([]);
      this.CreditDtlList = new MatTableDataSource([]);
      this.patDetails.patientForm.reset();
      this.doctorServiceDetailsList = new MatTableDataSource([]);
      return;
    }
    this.commonService.confirmAction(messageConstant.IpCreditNew.Header, messageConstant.IpCreditNew.ConfirmResetAction).subscribe(
      response => {
        if (response) {
          this.initForm();
          this.doctorServiceList = new MatTableDataSource([]);
          this.ipBillList = new MatTableDataSource([]);
          this.CreditDtlList = new MatTableDataSource([]);
          this.doctorServiceDetailsList = new MatTableDataSource([]);
          this.patDetails.patientForm.reset();
          return;
        } else {
          return;
        }
      });

  }


  // CREATE SAVE OBJECT
  createSaveObject() {

    this.f.Action.setValue(this.action); /// Added after issue reported on 2 July 2021

    this.savePatientDtlObject = this.ipCreditNewForm.getRawValue();
    this.savePatientDtlObject.IpCnNo = this.f.CreditNo.value;
    this.savePatientDtlObject.TotalAmt = this.f.Total.value;
    this.savePatientDtlObject.DeclaredIncome = this.f.DeclareIncome.value;
    this.doctorAccountingDetailsShow = [];

    if (this.action === 'N') {
      this.createDoctorAccountingObjectToN();
      this.savePatientDtlObject.DoctFlag = this.doctFlag;
      this.savePatientDtlObject.DoctorServices = this.doctorAccountingDetailsShow
        .filter(d => this.commonService.isValidStringValue(d.ServCode)
          && this.commonService.isValidStringValue(d.Amount) && parseFloat(d.Amount) > 0);
      this.savePatientDtlObject.Departments = this.savePatientDtlObject.Departments
        .filter(d => this.commonService.isValidStringValue(d.ChrgCode)
          && this.commonService.isValidStringValue(d.Amount) && parseFloat(d.Amount) > 0);
    }

    

  }

  // create transaction service object if action is N
  createTransactioObject() {
    let rowCount = this.CreditDtlList.data.length;
    for (let i = 0; i < rowCount; i++) {
      this.charge.push(this.CreditDtlList.data[i].ChrgCode)
      this.acCode.push(this.CreditDtlList.data[i].AcCode)
      this.amount.push(this.CreditDtlList.data[i].Amount)
      this.cCCodeT.push(this.CreditDtlList.data[i].CcCode)
    }
  }

  // create doctor accounting object
  createDoctorAccountingObjectToN() {
    let services = this.ServiceArray.value;
    let rowCount = services.length;
    for (let i = 0; i < rowCount; i++) {
      let patientSrc;
      if (this.f.PatSrcCode.value === '05' && services[i].DoctCode !== this.f.TXTDoctCD.value) {
        patientSrc = '10';
      } else if (services[i].DoctCode !== this.f.TXTDoctCD.value) {
        patientSrc = this.f.PatSrcCode.value;
      } else if (this.f.PatSrcCode.value === '06' || this.f.PatSrcCode.value === '13') {
        if (services[i].DoctCode === '0001') {
          patientSrc = '01';
        } else if (services[i].DoctCode !== this.f.TXTDoctCD.value) {
          patientSrc = '10';
        } else {
          patientSrc = '05';
        }
      }

      this.doctorAccountingDetailsShow.push({
        ServCode: services[i].ServCode,
        Amount: services[i].Amount,
        DoctCode: services[i].DoctCode,
        PatientSrc: patientSrc,
        CCCode: services[i].CCCode
      });
    }
  }

  departmentControl(index: number) {
    return this.DepartmentArray.controls[index]["controls"];
  }

  getDepartment(index: number) {
    if (!this.commonService.isValidStringValue(this.DepartmentArray.value[index].ChrgCode)) {
      return;
    }
    this.httpService.Get(urlConstant.Billing.GetDepartment(this.DepartmentArray.value[index].ChrgCode))
      .subscribe(response => {
        let department = response.Data[0];
        if (!isNullOrUndefined(department)) {

          if (department.DepartmentCode === 79 && department.AcCode.trim() === '3-30-371' && this.ServiceArray.length > 1) {
            this.departmentControl(index).ChrgCode.setValue("")
            this.commonService.displayPromptMessage("Credit Note",
              messageConstant.IpCreditNew.InvalidChargeCode);
            return;
          }

          this.departmentControl(index).ChrgDesc.setValue(department.DepartmentName);
          this.departmentControl(index).Amount.setValue('');
          this.departmentControl(index).AcCode.setValue(department.ACCode);
          this.departmentControl(index).CcCode.setValue(department.CCCode);

          this.addDepartment(1);

        }
      });
  }


  serviceControl(index: number) {
    return this.ServiceArray.controls[index]["controls"];
  }


  getDoctorService(index: number) {
    if (!this.commonService.isValidStringValue(this.ServiceArray.value[index].ServCode)) {
      return;
    }


    let param = { ServiceCode: this.serviceControl(index).ServCode.value };
    this.httpService.Post(urlConstant.IpCreditNoteList.GetDoctorServices(), param)
      .subscribe(response => {
        let service = response.Data[0];
        if (!isNullOrUndefined(service)) {
          this.serviceControl(index).ServiceName.setValue(service.ServiceName);
          this.serviceControl(index).DoctCode.setValue(service.DoctorCode);
          this.serviceControl(index).CCCode.setValue(service.CCCode);
          this.addService(1);
        }
      });

  }

  removeDepartment(index: number) {

    if (this.action !== 'N'
      || (!this.commonService.isValidStringValue(this.DepartmentArray.value[index].ChrgCode)
        && this.DepartmentArray.value.length - 1 === index)) {
      return;
    }


    if (!this.commonService.isValidStringValue(this.DepartmentArray.value[index].ChrgDesc)) {
      return;
    }


    let tempServices = this.CreditDtlList.data;
    let updatedServices = [];


    for (let i = 0; i < tempServices.length; i++) {
      if (i !== index) {
        updatedServices.push(tempServices[i]);
      }
    }

    this.CreditDtlList = new MatTableDataSource(updatedServices);
    this.DepartmentArray.removeAt(index);

    if (this.DepartmentArray.length === 0) {
      this.addDepartment(1);
    }

    this.calculateTotalAmount();


  }


  removeService(index: number) {
    if (this.action !== 'N' ||
      (!this.commonService.isValidStringValue(this.ServiceArray.value[index].ServCode) && this.ServiceArray.value.length - 1 === index)) {

      return;
    }

    let tempServices = this.doctorServiceList.data;
    let updatedServices = [];


    for (let i = 0; i < tempServices.length; i++) {
      if (i !== index) {
        updatedServices.push(tempServices[i]);
      }
    }

    this.doctorServiceList = new MatTableDataSource(updatedServices);
    this.ServiceArray.removeAt(index);

    this.calculateTotalAmount();

    if (this.ServiceArray.length === 0) {
      this.addService(1);
    }
  }


  // calculates total amount for added service in the grid
  calculateTotalAmount(index?: number) {
    if (!isNullOrUndefined(index)) {

      let amount = this.DepartmentArray.value[index].Amount;

      this.departmentControl(index).Amount
        .setValue(parseFloat(this.commonService.isValidStringValue(amount) ? amount : '0.00').toFixed(2));

      let currentDepartment = this.DepartmentArray.value[index];

      if (this.ipBillList.data.length > 0 &&
        currentDepartment.ChargCode !== '79' && currentDepartment.ACCode !== '3-30-371') {

        if (parseFloat(currentDepartment.Amount) > parseFloat(this.ipBillList.data[0].NetAmt)) {
          this.commonService.displayPromptMessage("Credit Note", messageConstant.IpCreditNew.InvalidAmount);
          this.departmentControl(index).Amount.setValue('');
          return;
        }

        if ((parseFloat(this.f.Amount.value) + parseFloat(this.f.Total.value)) > parseFloat(this.ipBillList.data[0].NetAmt)) {
          this.commonService.displayPromptMessage("Credit Note", messageConstant.IpCreditNew.InvalidAmountWithNetAmt);
          this.departmentControl(index).Amount.setValue('');
          return;
        }
      }
    }

    let departments = this.DepartmentArray.value
      .filter(d => this.commonService.isValidStringValue(d.ChrgDesc));

    if (departments.length > 0)
      this.f.Total.setValue(departments
        .map(item => item.Amount).reduce((prev, next) => parseFloat(prev) + parseFloat(next)));
    else
      this.f.Total.setValue('0.00');
  }


  //on click of display button it will redirect to bill list.
  redirectToList() {
    this.router.navigate(['billing/ip-credit-note-list']);
  }


  validateServiceAmonunt(index: number) {

    let amount = this.ServiceArray.value[index].Amount;
    this.serviceControl(index).Amount
      .setValue(parseFloat(this.commonService.isValidStringValue(amount) ? amount : '0.00').toFixed(2));


    let totalServiceAmount = this.ServiceArray.value
      .filter(d => this.commonService.isValidStringValue(d.ServiceName))
      .map(item => item.Amount).reduce((prev, next) => parseFloat(prev) + parseFloat(next))


    if (parseFloat(this.f.Total.value) < parseFloat(totalServiceAmount)) {
      this.commonService.displayPromptMessage("Credit Note", "Doctor Service Amount Greater Than Net Amount").subscribe();
      this.serviceControl(index).Amount.setValue("");
    }

  }


  Print(counterSlNo?: string, redirect: boolean = false) {
    var creditNote = this.creditNote;
    this.loader.spin.next(true);
    if (this.action === 'N') {
      creditNote.RetrieveIpCnFormTranDetails = this.DepartmentArray.value
        .filter(d => this.commonService.isValidStringValue(d.ChrgDesc));
      let tempArray = creditNote.RetrieveIpCnFormPatientDetails[this.highLightRow];
      creditNote.RetrieveIpCnFormPatientDetails = [];
      creditNote.RetriveDoctorServiceDetails = [];
      creditNote.RetrieveIpCnFormPatientDetails.push(tempArray);
      var doctorServices = this.ServiceArray.value.filter(d => this.commonService.isValidStringValue(d.ServiceName));
      for (var i = 0; i < doctorServices.length; i++) {
        var obj = { "ServiceName": doctorServices[i].ServiceName, "Amount": doctorServices[i].Amount, "Remarks": "" };
        creditNote.RetriveDoctorServiceDetails.push(obj);
      }

      let formDetails = { 'CntrSlNo': counterSlNo, 'UserId': localStorage.getItem('UserName'), 'Remarks': this.f.Remark.value };
      creditNote.RetrieveIpCnFormDetails.push(formDetails);

      creditNote.CnAmount = this.f.Total.value;
    }

    this.httpService.Post(urlConstant.IpCreditNoteList.GetCreditNotePrint(), creditNote)
      .subscribe(response => {
        this.httpService.openFile(response);
        this.loader.spin.next(false);
        if (redirect) {
          this.commonService.displayPromptMessage(messageConstant.IpCreditNew.Header, messageConstant.IpCreditNew.ConfirmNew);
          this.redirectToList();
        }
      })

  }




  // sets Folio No on event emit
  setFolio(folioNo: any) {

    if (this.f.FolioNo.value !== folioNo && this.action === 'N') {
      this.f.FolioNo.setValue(folioNo);
      this.RetrieveIpCnFormDetails();
    }
  }

  // Method for API hit of Doctor List.
  showDoctorServiceDetails() {

    this.loader.spin.next(true);

    let billno = this.initSearcObject.IpBillNo;
    let regNo = this.initSearcObject.RegNo;
    let folioNo = this.initSearcObject.FolioNo;

    this.httpService.Get(urlConstant.DoctorServicelist.GetDoctorServicesDetails("", regNo, folioNo)).subscribe(response => {
      if (response && response.Data.Detail.length > 0) {
        this.loader.spin.next(false);
        this.doctorServiceDetailsList = new MatTableDataSource(response.Data.Detail);
        this.doctorServiceDetailsList.sort = this.sort;
      } else {
        this.doctorServiceDetailsList = new MatTableDataSource([]);
        this.loader.spin.next(false);
      }
    });
  }


  // get service based on department code
  getService(i: number) {

    let currentDepartment = this.DepartmentArray.value[i];
    if (!this.commonService.isValidStringValue(currentDepartment.ServCode)) {
      // this.setServiceData({
      //   'ServiceCode': '', 'ServiceName': '',
      //   'Quantity': '', 'ServiceCost': '',
      // }, false, i);
      return;
    }


    let departmentCode = currentDepartment.ChrgCode;

    if (i > 0 && !this.commonService.isValidStringValue(this.DepartmentArray.value[i - 1].ChrgCode)
      && this.commonService.isValidStringValue(departmentCode)) {
      this.commonService.openSnackBar("Enter previous row details first !", "ok");
      // this.clearService(i);
      return;
    }

    if (!this.commonService.isValidStringValue(departmentCode)) {
      this.commonService.openSnackBar("Invalid department selected !", "ok");
      // this.clearService(i);
      return;
    }
    let serviceData = {
      'DepartmentCode': departmentCode, 'ServiceCode': currentDepartment.ServCode,
      'PatientCategoryCode': this.patientDetails.CategorySource, 'OpCategoryCode': this.patientDetails.BedCategory,
      'CreditCompanyCode': this.patientDetails.CompanyCode
    };

    this.httpService.Post(urlConstant.Billing.GetService(), serviceData).subscribe(response => {
      let selectedService = response.Data[0];
      if (!isNullOrUndefined(selectedService)) {
        this.departmentControl(i).Amount.setValue(selectedService.ServiceCost);
        this.departmentControl(i).ServiceName.setValue(selectedService.ServiceName);

      }
      else {
        this.departmentControl(i).Amount.setValue('');
        this.departmentControl(i).ServiceName.setValue('');
      }

      this.calculateTotalAmount(i);

    });
  }

  removeDptService(index: number) {
    this.departmentControl(index).Amount.setValue('');
    this.departmentControl(index).ServiceName.setValue('');
    this.calculateTotalAmount();
  }


}