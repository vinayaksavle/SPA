import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatSort, MatTableDataSource, MatDialog } from '@angular/material';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { isNullOrUndefined } from 'util';
import { messageConstant } from 'src/app/constants/messageConstants';
import { ParseDate } from 'shared-utility';
import { Router, NavigationExtras } from '@angular/router';
import { PatientEnquiryComponent } from 'patient-enquiry';
import { RegnoTabFieldComponent } from 'regno-tab-field';
import { CreditCompanyLookupComponent } from 'credit-company-lookup';
import { PatientSourceDropdownComponent } from 'patient-source-dropdown';
import { FromDateToDateComponent } from 'from-date-to-date';
@Component({
  selector: 'app-ip-credit-note-list',
  templateUrl: './ip-credit-note-list.component.html',
  styleUrls: ['./ip-credit-note-list.component.css'],
  host: { 'class': 'section__main' },
})
export class IpCreditNoteListComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  ipCreditNoteForm: FormGroup;
  private searchObject: any = {};
  // MatDataSource
  creditNoteList: MatTableDataSource<any> = new MatTableDataSource([]);
  displayedColumnsList: string[] = ['SerialNo', 'CreditNo', 'CreditDate',
    'RegNo', 'PatientName', 'TotCrNoteAmount', 'Status', 'CreditDescription', 'Reason', 'UserID',
    'CrCode', 'CNTRSLNO', 'PostFlag', 'PatientSource', 'IncomeHeadCrNote', 'IncHeadDoctCrNoteAmt',
    'OtherCrNoteAmt', 'BillAmount', 'ApprAmt', 'RecvdAmt', 'RefundAmt', 'TDSAmt'];
  highLightRow: number;
  rowDetails: any;
  isDeleteDisabled: boolean = false;
  isDisplayDisabled: boolean = false;
  @ViewChild('regNoTabfield') regNoTabfield: RegnoTabFieldComponent;
  @ViewChild('creditComp') creditComp: CreditCompanyLookupComponent;
  @ViewChild('catg') catg: PatientSourceDropdownComponent;
  @ViewChild('date') date: FromDateToDateComponent;
  permissions: any=[];
  canAccessNew: boolean;
  canViewCredit: boolean;
  canDeleteCredit: boolean;
  constructor(public fb: FormBuilder, private commonService: CommonService, private httpService: HttpService,
    private loader: LoaderService, private router: Router, public dialog: MatDialog) { 
      
    //#region permission
    this.permissions = JSON.parse(localStorage.getItem('Permission'));
    
    if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
      // New Credit Note Permissons set 
      this.canAccessNew =  this.permissions.includes('4004N') ? true :false;
      this.canViewCredit =  this.permissions.includes('4004V') ? true :false;
      this.canDeleteCredit =  this.permissions.includes('4004D') ? true :false;
    }
    //#endregion
    }

  ngOnInit() {
    this.initForm();

    this.stateManagement();
    this.GetIpCreditNoteList();
    localStorage.removeItem('CreditNoteObj');
    localStorage.removeItem('FromCreditNote');
  }

  stateManagement() {
    let obj = localStorage.getItem("CreditNoteObj");
    const searchData: any = JSON.parse(obj);
    if (searchData !== null && searchData !== '{}') {
      if (localStorage.getItem('FromCreditNote') != null) {
        if (this.commonService.isValidStringValue(searchData.FromDate) || this.commonService.isValidStringValue(searchData.ToDate)) {
          this.date.FromDate.setValue(new Date(searchData.FromDate));
          this.date.ToDate.setValue(new Date(searchData.ToDate));
          this.f.FromDate.setValue(new Date(searchData.FromDate));
          this.f.ToDate.setValue(new Date(searchData.ToDate));
        }
        if (this.commonService.isValidStringValue(searchData.CatgCode)) {
          this.regNoTabfield.setValues(searchData.PatientRegNo, '');
          this.regNoTabfield.getPatientDetails();
          this.f.PatientRegNo.setValue(searchData.PatientRegNo);
        }
        if (this.commonService.isValidStringValue(searchData.CreditCompCode)) {
          this.creditComp.myControl.setValue('(' + searchData.CreditCompCode + ')' + searchData.CreditCompName);
          this.f.CreditCompCode.setValue(searchData.CreditCompCode);
        }
        if (this.commonService.isValidStringValue(searchData.CatgCode)) {
          this.catg.myControl.setValue(searchData.CatgCode);
          this.f.CatgCode.setValue(searchData.CatgCode);
        }
      } else {
        return;
      }
    } else {
      return;
    }

  }

  // initialize the form
  initForm() {
    this.ipCreditNoteForm = this.fb.group({
      PatientRegNo: [''],
      CounterNo: [{ value: '11', disabled: true }],
      CreditCompCode: [{ value: '', disabled: true }],
      CreditCompName: [{ value: '', disabled: true }],
      CatgCode: [{ value: '', disabled: true }],
      FromDate: new Date(),
      ToDate: new Date(),
      IncomeHeadNote: [{ value: '0.00', disabled: true }],
      IncomeHeadDrNote: [{ value: '0.00', disabled: true }],
      OthersCrNote: [{ value: '0.00', disabled: true }],
      TotalIncomeHeadAmt: [{ value: '0.00', disabled: true }],
      TotalIncomeAmt: [{ value: '0.00', disabled: true }],
    });
    this.highLightRow = -1;
  }

  // the function returns the form controls to access in both files.
  public get f() {
    return this.ipCreditNoteForm.controls;
  }

  // get llokup values
  getPatientDetail(event) {
    this.f.PatientRegNo.setValue(event.AdmissionNo);
  }

  // create search object
  createObject() {
    this.searchObject.FromDate = this.commonService.convertDateToString(new Date(this.f.FromDate.value));
    this.searchObject.ToDate = this.commonService.convertDateToString(new Date(this.f.ToDate.value));
    this.searchObject.RegNo = this.f.PatientRegNo.value;
    this.searchObject.CreditComp = this.f.CreditCompCode.value;
    this.searchObject.PatientCategory = this.f.CatgCode.value;
  }

  // validation of form
  validateForm(): boolean {

    let date = this.f;

    if (!this.commonService.isValidStringValue(date.FromDate.value)) {
      this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidFromDate,
        messageConstant.invalidMessages.OK);
      return false;
    }
    if (!this.commonService.isValidStringValue(date.ToDate.value)) {
      this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidToDate,
        messageConstant.invalidMessages.OK);
      return false;
    }
    if (new ParseDate().transform(date.FromDate.value) > new ParseDate().transform(new Date())) {
      this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidFromDate,
        messageConstant.invalidMessages.OK);
      return false;
    }
    if (new ParseDate().transform(date.ToDate.value) > new ParseDate().transform(new Date())) {
      this.commonService.openSnackBar(messageConstant.DoctorDetailsService.InvalidToDate,
        messageConstant.invalidMessages.OK);
      return false;
    }
    return true;
  }
  // get ip credit note list
  GetIpCreditNoteList() {
    //if (!this.validateForm()) return;
    this.createObject();
    this.loader.spin.next(true);
    this.httpService.Post(urlConstant.IpCreditNoteList.GetIpCreditNoteList(), this.searchObject).subscribe(
      response => {
        if (response && !isNullOrUndefined(response) && response.Data.length > 0 && response.Status === 200) {
          this.loader.spin.next(false);
          this.creditNoteList = new MatTableDataSource(response.Data);
          this.creditNoteList.sort = this.sort;
          this.searchObject = {};
          const incomeHead = response.Data.filter(i => i.Status != 'C').map(item => item.IncomeHeadCreditAmount).reduce((prev, next) => parseFloat(prev) + parseFloat(next));
          const incomeDrAmt = response.Data.filter(i => i.Status != 'C').map(item => item.ConcessionDocAmt).reduce((prev, next) => parseFloat(prev) + parseFloat(next));
          this.f.IncomeHeadNote.setValue(incomeHead);
          this.f.IncomeHeadDrNote.setValue(incomeDrAmt);

          this.f.TotalIncomeAmt.setValue(response.Data.filter(i => i.Status != 'C').map(item => item.CnAmount).
            reduce((prev, next) => parseFloat(prev) + parseFloat(next)));

          this.f.TotalIncomeHeadAmt.setValue(parseFloat(incomeHead) + parseFloat(incomeDrAmt));

          this.f.OthersCrNote.setValue(response.Data.filter(i => i.Status != 'C').map(item => item.ConcessionOtherThanDoc).reduce((prev, next) => parseFloat(prev) + parseFloat(next)));

        } else {
          this.searchObject = {};
          this.creditNoteList = new MatTableDataSource([]);
          // To remove older results
          this.f.IncomeHeadNote.setValue('0.00');
          this.f.IncomeHeadDrNote.setValue('0.00');
          this.f.TotalIncomeAmt.setValue('0.00');
          this.f.TotalIncomeHeadAmt.setValue('0.00');
          this.f.OthersCrNote.setValue('0.00');
          this.loader.spin.next(false);
        }
      });
  }

  // reset form
  restForm(date, creditComp, catg) {
    date.FromDate.setValue(new Date());
    date.ToDate.setValue(new Date());
    this.creditNoteList = new MatTableDataSource([]);
    this.initForm();

    creditComp.myControl.setValue('');
    catg.myControl.setValue('');
    catg.myControl.enable();
    this.regNoTabfield.RegNo = "";
    this.regNoTabfield.PatientName = "";
  }

  // Highlight row from grid.
  setActiveServiceRow(index: number, item: any) {
    this.rowDetails = item;
    if (this.highLightRow === index) {
      this.highLightRow = -1;
    } else {
      this.highLightRow = index;
    }
  }

  // delete record
  deleteRecord() {
    if (this.rowDetails.Status === 'C') {
      this.isDeleteDisabled = true;
    } else if (this.rowDetails.PostFlag === 'P') {
      this.isDeleteDisabled = true;
    } else {
      const navigationExtras: NavigationExtras = {
        queryParams: {
          'creditNo': this.rowDetails.IpcnNo.trim(),
          'action': 'D'
        }
      };
      this.router.navigate([urlConstant.IpCreditNoteList.NavigateToNewNote], navigationExtras);
    }
  }

  // redirect to view
  displayRecord(status: string) {
    // Setting local storage Obj
    localStorage.setItem("CreditNoteObj", JSON.stringify(this.ipCreditNoteForm.getRawValue()));

    if (status === "D" && ((this.rowDetails.Status === 'C' || this.rowDetails.PostFlag === 'P'))) {
      this.commonService.displayPromptMessage("Credit Note", "Credit note cannot be cancelled");
      return;
    }


    if (this.highLightRow === -1 || isNullOrUndefined(this.highLightRow)) {
      this.commonService.openSnackBar("Please select a record first !", "Ok");
      return;
    }

    if (!this.commonService.isValidStringValue(this.rowDetails.IpcnNo.trim())) {
      this.commonService.openSnackBar("Invalid IPCreditNote number selected !", "Ok");
      return;
    }

    // IpcnNo and Action passed through route
    this.router.navigate([urlConstant.IpCreditNoteList.NavigateToViewNote, this.rowDetails.IpcnNo.trim(), status]);
  }

  // create new ip credit note transaction
  createNew() {
    // Setting local storage Obj
    localStorage.setItem("CreditNoteObj", JSON.stringify(this.ipCreditNoteForm.getRawValue()));
    this.router.navigate([urlConstant.IpCreditNoteList.NavigateToNewNote, "N"]);
  }

  // IP credit note list will exported to excel file
  exportToExcel() {
    this.createObject();
    this.loader.spin.next(true);
    this.httpService.Post(urlConstant.IpCreditNoteList.GetCreditNoteExcel(), this.searchObject).subscribe(
      response => {
        if (response && !isNullOrUndefined(response) && response.Data.length > 0 && response.Status === 200) {
          this.httpService.openFile(response.Data);
        } else {

        }
        this.loader.spin.next(false);
      });
  }



  // open patient help
  openPatientHelp() {
    const dialogRef = this.dialog.open(PatientEnquiryComponent, {
      disableClose: true,
      maxHeight: '800px',

    });

    dialogRef.componentInstance.isPopup = true;

    dialogRef.afterClosed().subscribe(dialogResult => {

      if (!isNullOrUndefined(dialogResult)) {
        this.f.PatientRegNo.setValue(dialogResult.AdmissionNumber);
        this.regNoTabfield.setValues(dialogResult.AdmissionNumber, dialogResult.PatientName);
      }
    });
  }

  setDates(event) {
    if (!isNullOrUndefined(event)) {
      this.f.FromDate.setValue(new Date(event.FromDate.value).toLocaleDateString());
      this.f.ToDate.setValue(new Date(event.ToDate.value).toLocaleDateString());
    }
  }

  print() {

    if (this.highLightRow === -1 || isNullOrUndefined(this.highLightRow)) {
      this.commonService.openSnackBar("Please select a record first !", "Ok");
      return;
    }

    this.httpService.Post(urlConstant.IpCreditNoteList.GetCreditNotePrint(), this.rowDetails)
      .subscribe(response => {
        this.httpService.openFile(response.Data);
      });
  }


  validateDate(date: any) {
    if (isNullOrUndefined(date._isAMomentObject)) {
      return date;
    } else {
      return new Date(date._i.year, date._i.month, date._i.date).toLocaleDateString();
    }
  }


  setCategory(event) {
    this.f.CatgCode.setValue(event.Code)
  }

}