import { Component, OnInit, ViewChild, HostBinding, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { messageConstant } from 'src/app/constants/messageConstants';
import { urlConstant } from 'src/app/constants/urlConstants';
import { patientCategoryConstant } from 'src/app/constants/patientCategoryConstants';
import { isNullOrUndefined } from 'util';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';
import { MatDialogRef, MatTableDataSource } from '@angular/material';
import { pipe } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';

@Component({
  selector: 'approval-limit-configuration',
  templateUrl: './approval-limit-configuration.component.html',
  styleUrls: ['./approval-limit-configuration.component.css'],
  host: { 'class': 'section__main' },
})

export class ApprovalLimitConfigurationComponent implements OnInit {
  approvalLimitForm: FormGroup;
  approvalLimitList: MatTableDataSource<any> = new MatTableDataSource()
  userList;
  action = "S";
  selectedRowData: any;
  selectedRowIndex: number = -1;
  displayedColumns = ["UserId", "FromAmount", "ToAmount", "Status", "Action"];
  exchangeRateForm: FormGroup;
  selectedUserId;
  selectedUserName;

  constructor(private fb: FormBuilder, private commonService: CommonService,
    private httpService: HttpService, private loader: LoaderService) { }

  ngOnInit() {
    this.initForm();
    this.initializeUserLookup();
    this.getApprovalLimitList();
  }

  //method for form initialization
  initForm() {
    this.approvalLimitForm = this.fb.group({
      Id: [],
      UserId: [''],
      UserName: [''],
      FromAmount: [''],
      ToAmount: [''],
      Status: [true],
      CreatedBy: [localStorage.getItem('UserName')],
      UpdatedBy: [localStorage.getItem('UserName')]
    });
  }

  //method for getting all approved limits
  getApprovalLimitList() {
    this.httpService.Get(urlConstant.Billing.GetAllApprovalLimit()).subscribe(response => {
      if (response.Status == 200) {
        this.approvalLimitList = new MatTableDataSource(response.Data);
      }
      else {
        this.approvalLimitList = new MatTableDataSource([]);
      }
    })
  }

  //method for lookup
  initializeUserLookup() {
    const waitTime = pipe(debounceTime(500));
    const distinct = pipe(distinctUntilChanged());
    this.f.UserId.valueChanges
      .pipe(waitTime)
      .pipe(distinct)
      .pipe(
        switchMap(text =>
          !isNullOrUndefined(text) && text.toString().trim() !== ''
            ? this.httpService.Get(urlConstant.Billing.GetUserId(text))
            : []
        )
      )
      .subscribe(result => {
        if (result.Status === 200) {
          this.userList = result.Data;

        } else {
          return;
        }
      });
  }

  // method to handle change in option from user dropdown.
  onOptionselect(value) {
    this.selectedUserId = value.UserId;
    this.selectedUserName = value.UserName;
  }

  // the function returns the form controls to access in both files.
  public get f() {
    return this.approvalLimitForm.controls;
  }

  // function for saving, editing approval limit
  saveApproval() {
    if (!this.validateForm()) return;

    let rateInput = this.approvalLimitForm.getRawValue();
    // console.log(rateInput.UserId.split(')')[1]); get only code for user
    rateInput.UserId = this.selectedUserId;
    rateInput.UserName = this.selectedUserName;
    // set value from localStorage since form not reinitialized
    if (rateInput.CreatedBy == null || rateInput.CreatedBy == '') {
      rateInput.CreatedBy = localStorage.getItem('UserName')
    }
    // if action is S means saving approval limit
    if (this.action === "S") {
      this.commonService.confirmAction("Add Approval Limit Configuration", "Do you want to submit new approval limit configuration?").subscribe(response => {
        if (response) {
          this.httpService.Post(urlConstant.Billing.SaveLimitApproval(), rateInput).subscribe(response => {
            if (response.Status === 200) {
              this.commonService.displayPromptMessage("Add Approval Limit Configuration", "Approval Limit Configuration saved successfully").subscribe(response => {
                // window.location.reload();
                this.getApprovalLimitList();
                this.approvalLimitForm.reset();
              });
            }
          });
        }
      });
    }
    // if action is U that means update approval limit
    else {
      this.commonService.confirmAction("Update Approval Limit Configuration", `Do you want to update Approval Limit Configuration for ${rateInput.UserId} ?`).subscribe(response => {
        if (response) {
          this.httpService.Post(urlConstant.Billing.UpdateLimitApproval(), rateInput).subscribe(response => {
            if (response.Status === 200) {
              this.commonService.displayPromptMessage("Update Approval Limit Configuration", "Approval limit updated successfully").subscribe(response => {
                //window.location.reload();
                this.resetform();
                this.getApprovalLimitList();
                this.action = 'S'
              });
            }
          });
        }
      });
    }
  }

  //method for resetting form
  resetform() {
    this.approvalLimitForm.reset();
    this.f.UserId.enable();
    this.action = "S";
  }

  // method for edit icon click 
  editEntry(rowdetails) {
    this.loader.spin.next(true);
    this.approvalLimitForm.patchValue({
      Id: rowdetails.Id,
      UserId: '(' + rowdetails.UserId + ') ' + rowdetails.UserName,
      FromAmount: rowdetails.FromAmount,
      ToAmount: rowdetails.ToAmount,
      Status: rowdetails.Status,
      CreatedBy: localStorage.getItem('UserName'),
      UpdatedBy: localStorage.getItem('UserName')
    });
    this.f.UserId.disable();
    this.selectedUserName = rowdetails.UserName;
    this.selectedUserId = rowdetails.UserId;
    this.action = "U";
    this.loader.spin.next(false);
  }

  // method for deleting entry
  deleteEntry(rowdetails: any) {
    this.commonService.confirmAction("Delete Approval Limit Configuration", `Do you want to delete this approval limit configuration for ${rowdetails.UserId} ?`).subscribe(response => {
      if (response) {
        this.httpService.Post(urlConstant.Billing.DeleteApprovalLimit(), rowdetails).subscribe(response => {
          if (response.Status === 200) {
            this.commonService.displayPromptMessage("Delete Approval Limit Configuration", "Approval Limit configuration deleted successfully").subscribe(rTGesponse => {
              //window.location.reload();
              this.getApprovalLimitList();
            });
          }
        });
      }
    });
  }

  //To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;
    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }

  // clears lookup search
  clearLookupSearch() {
    this.f.UserId.setValue("");
    this.userList = [];
  }

  //method for form validation
  validateForm() {

    const duplicateUserId = this.approvalLimitList.data.some(x => x.UserId.trim().toLowerCase() === this.selectedUserId.trim().toLowerCase());
    if (duplicateUserId && this.action === "S") {
      this.commonService.displayPromptMessage("Approval Limit Configuration", `Approval Limit already added for the user ${this.f.UserId.value}.`);
      return false;
    }

    if (this.f.ToAmount.value <= this.f.FromAmount.value) {
      this.commonService.openSnackBar("'To Amount' should be more than 'From Amount'", "Ok");
      return false;
    }
    return true;
  }
}
