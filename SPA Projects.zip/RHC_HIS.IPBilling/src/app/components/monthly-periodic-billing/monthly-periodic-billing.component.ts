import { Component, OnInit, ViewChild } from '@angular/core';
import { DataTranferService } from '../../services/data-transfer.service';
import { HttpService } from '../../services/http.service';
import { ActivatedRoute, Router } from '@angular/router';
import { isNullOrUndefined } from 'util';
import { FormBuilder, FormGroup } from '@angular/forms';
import { FromDateToDateComponent } from 'from-date-to-date';
import { ParseDate } from 'shared-utility';
import { CommonService } from 'src/app/services/common.service';
import { LoaderService } from 'src/app/services/loader.service';
import { urlConstant } from 'src/app/constants/urlConstants';

@Component({
    selector: 'app-monthly-periodic-billing',
    templateUrl: './monthly-periodic-billing.component.html',
    styleUrls: ['./monthly-periodic-billing.component.css'],
    host: { 'class': 'section__main' }
})
export class MonthlyPeriodicBillingComponent implements OnInit {
    userAccess: any;
    urlMenu = "dashboard";
    showToken: boolean;
    moduleId: string;
    userGroups: string[] = [];
    permissions: any = [];
    canPrint: boolean;
    monthlyPerBillForm: FormGroup;
    @ViewChild("fromDateToDate") fromDateToDate: FromDateToDateComponent;
    printFlag: string;

    constructor(public fb: FormBuilder, private dataTransferService: DataTranferService,
        private commonService: CommonService, private httpService: HttpService,
        private loader:LoaderService) {
        //#region permission
        this.permissions = JSON.parse(localStorage.getItem('Permission'));

        if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
            // Change Permissons set
            this.canPrint = this.permissions.includes('400000') ? true : false;
        }
        //#endregion
    }

    ngOnInit(): void {
        this.initForm();
    }
    initForm() {
        this.monthlyPerBillForm = this.fb.group({
            FromCompany: [''],
            ToCompany: [''],
            Status: ['B'],
            ReceiptType: ['B'],
            PrinterName: ['']
        });
    }

    printDetails() {
        let obj = this.monthlyPerBillForm.getRawValue();
        obj.FromDate=new ParseDate().transform(this.fromDateToDate.FromDate.value);
        obj.ToDate=new ParseDate().transform(this.fromDateToDate.ToDate.value);
        
        if (!this.commonService.isValidStringValue(obj.FromCompany) && !this.commonService.isValidStringValue(obj.ToCompany)) {
            this.commonService.openSnackBar("Invalid Company", "OK");
            return;
        } else {
            if(this.openDialog()){

            } else{
                return;
            }
            let programName:string;
            let parameter: string;
            switch (this.printFlag) {
                case "1":
                    programName="PNDBLCPATP";
                    parameter = "BM01" + this.dataTransferService.GetUserName() + obj.FromCompany + obj.ToCompany;
                    break;

                case "2":
                    programName="PNDCBLSUMP";
                    parameter = "BM02" + this.dataTransferService.GetUserName() + obj.FromCompany + obj.ToCompany;
                    break;

                case "3":
                    programName="CCREMINDER";
                    parameter = "BM03" + this.dataTransferService.GetUserName() + obj.FromCompany 
                    + obj.ToCompany+ obj.FromDate+obj.ToDate+obj.ReceiptType;
                    break;

                case "4":
                    break;

                case "5":
                    break;

                case "6":
                    programName="CGHMEDBIL1";
                    parameter = "BM06" + this.dataTransferService.GetUserName() + obj.FromDate + obj.ToDate;
                    break;

                case "7":
                    programName="SUMINPCGHP";
                    parameter = "BM07" + this.dataTransferService.GetUserName() + obj.FromDate + obj.ToDate;
                    break;

                case "8":
                    programName="RSVDEPBALP";
                    parameter = "BM08" + this.dataTransferService.GetUserName();
                    break;

                case "9":
                    programName="PNDDEPLSTP";
                    parameter = "BM09" + this.dataTransferService.GetUserName() +obj.Status;
                    break;

                case "10":
                    programName="SCHEDVIDEP";
                    parameter = "BM10" + this.dataTransferService.GetUserName() + obj.FromDate + obj.ToDate;
                    break;

                default: break;
            }
            this.callRPGProgram(programName,parameter,obj.PrinterName);
        }

    }
    openDialog():boolean {
        this.commonService.inputConfirmAction("Monthly/Periodic Billing","Parameters").subscribe(res=>{
            if(res.Status && this.commonService.isValidStringValue(res.Remarks)){
                console.log(res);
                return true;
            } else{
                return false;
            }
        });
        return false;
    }

    callRPGProgram(programName: string, parameter: string, printerName: any) {
        this.loader.spin.next(true);
        this.httpService.Get(urlConstant.Reports.MonthlyBillingReport.callRPGProgramUrl(programName,parameter,printerName)).subscribe(
            res=>{
                if(res.Status==200 && res.Data){
                    console.log(res.Data);
                    this.loader.spin.next(false);
                } else{
                    this.loader.spin.next(false);
                }
                this.loader.spin.next(false);
            });
    }

    setPrintFlag(flag: string) {
        this.printFlag = flag;
        this.resetForm();
    }

    resetForm() {
        this.fromDateToDate.FromDate.setValue(new Date());
        this.fromDateToDate.ToDate.setValue(new Date());
        this.initForm();
    }

}
