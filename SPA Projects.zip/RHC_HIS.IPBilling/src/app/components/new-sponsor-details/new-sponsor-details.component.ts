import { Component, OnInit, ViewChild, HostListener } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { pipe } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { ParseDate } from 'shared-utility';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HelperService } from 'src/app/services/helper.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';
import { PatientDetailsComponent } from '../patient-details/patient-details.component';
import { ViewImageDialogComponent } from '../view-image-dialog/view-image-dialog.component';

@Component({
  selector: 'app-new-sponsor-details',
  templateUrl: './new-sponsor-details.component.html',
  styleUrls: ['./new-sponsor-details.component.css'],
  host: { 'class': 'section__main' },
})
export class NewSponsorDetailsComponent implements OnInit {


  @HostListener('document:keydown', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    // redirect to patient folio
    if (event.altKey && (event.key === "f" || event.key === "F")) {
      event.preventDefault();
      this.patDetailsComp.openPatientFolio();
    }

  }



  hiddenItems: any = ['Address', 'FinalButton', 'InterimButton', 'DoctorButton', 'ApprovedAmount',
    'TPA', 'DischDateTime', 'InsCompanyName', 'CompanyName', 'FolioNo', 'BedNo', 'RoomNo'];
  sourceType = "new";
  newSponsorDetailsForm: FormGroup;
  sponsorList: any;
  @ViewChild('patDetails') patDetailsComp: PatientDetailsComponent;
  sponsorId: any;
  fileName: string = '';
  fileData: any;
  fileUrl: any;
  currentDate = new Date();
  isView: boolean = false;
  bill: any = {};
  constructor(public fb: FormBuilder, private httpService: HttpService, private commonService: CommonService,
    private loader: LoaderService, private activateroute: ActivatedRoute, private router: Router,
    private helper: HelperService, public sanitizer: DomSanitizer, private dialog: MatDialog) { }

  ngOnInit() {
    this.activateroute.params.subscribe(params => {
      this.sourceType = params['actionType'];
      this.sponsorId = params['sponsorId']
    });
    this.initForm();
    this.initializeSponsorLookup();

    this.isView = this.sourceType === "View";
    if (this.isView) {
      this.hiddenItems.push("EnquiryButton");
      this.setFormData();
    }
  }

  // Method to set form values for View
  setFormData() {
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.SponsorDetails.ViewSponsorDetails(this.sponsorId)).subscribe(
      res => {
        if (res.Status == 200 && res.Data) {
          this.patDetailsComp.patientForm.controls["RegNo"].setValue(res.Data.AdmissionNo);
          this.patDetailsComp.getPatientDetails();
          this.patDetailsComp.patientForm.disable();
          this.newSponsorDetailsForm.patchValue({
            "AdmissionNo": res.Data.AdmissionNo,
            "SponsorName": res.Data.SponsorName,
            "SpnsorCode": res.Data.SponsorCode,
            "LetterNo": res.Data.LetterNo,
            "LetterDate": res.Data.LetterDate,
            "ApprovedAmount": this.formatAmount(res.Data.ApprovedAmount),
            "IsEmail": res.Data.IsEmail,
            "SenderName": res.Data.IsEmail ? res.Data.SenderName : "",
            "Designation": res.Data.IsEmail ? res.Data.Designation : "",
            "MailDate": res.Data.IsEmail ? res.Data.MailDate : "",
            "MailDetails": res.Data.IsEmail ? res.Data.MailDetails : "",
            "Remarks": res.Data.Remarks
          });
          // File Data assignment
          if (res.Data.SponsorFileData != null) {
            this.fileName = res.Data.SponsorFileData.DocumentName;
            this.fileData = res.Data.SponsorFileData.FileContent;
          }
          this.newSponsorDetailsForm.disable();
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
        }
      });
  }

  // Method to initialize form
  initForm() {
    this.newSponsorDetailsForm = this.fb.group({
      AdmissionNo: ['', Validators.required],
      SponsorCode: ['', Validators.required],
      SponsorName: ['', Validators.required],
      LetterNo: ['', Validators.compose([Validators.required, Validators.maxLength(50)])],
      LetterDate: [new Date(), Validators.required],
      ApprovedAmount: ['', Validators.required],
      IsEmail: [0],
      SenderName: [{ value: '', disabled: true }],
      Designation: [{ value: '', disabled: true }],
      MailDate: [{ value: '', disabled: true }],
      MailDetails: [{ value: '', disabled: true }],
      Remarks: ['']
    })
  }



  // Method to set the selected value of sponsor lookup
  setAutocompleteValue(event: any, item: any) {
    if (!event.isUserInput) {
      return;
    } else {
      this.f.SponsorCode.setValue(item.CompanyCode);
      this.f.SponsorName.setValue(item.CompanyCode + " " + item.CompanyName);
    }
  }

  // Method to enable or disable the mail details based on IsEmail check box.
  enableMailDetails() {
    if (this.f.IsEmail.value) {
      this.f.IsEmail.setValue(1);
      this.f.SenderName.enable();
      this.f.Designation.enable();
      this.f.MailDate.enable();
      this.f.MailDate.setValue(new Date());
      this.f.MailDetails.enable();
    } else {
      this.f.SenderName.disable();
      this.f.Designation.disable();
      this.f.MailDate.disable();
      this.f.MailDetails.disable();
      this.newSponsorDetailsForm.patchValue({
        "SenderName": "",
        "Designation": "",
        "MailDate": "",
        "MailDetails": "",
      });
      return;
    }
  }

  // Method to initialize the Sponsor Lookup
  initializeSponsorLookup() {
    const waitTime = pipe(debounceTime(200));
    const distinct = pipe(distinctUntilChanged());
    this.f.SponsorName.valueChanges
      .pipe(waitTime)
      .pipe(distinct)
      .pipe(
        switchMap(text =>
          !isNullOrUndefined(text) && text.toString().trim() !== ''
            ? this.httpService.Get(urlConstant.SponsorDetails.GetCreditCompanyLookup(text))
            : []
        )
      )
      .subscribe(result => {
        if (result.Status === 200) {
          this.sponsorList = result.Data;
        } else {
          return;
        }
      });
  }
  // Method to clear sponsor lookup values
  clearSponsorLookup() {
    this.f.SponsorName.setValue("");
    this.sponsorList = [];
  }

  // Method to set the Admission No of pat details comp
  setAdmissionNo(event) {
    if (this.commonService.isValidStringValue(event.RegNo)) {
      this.f.AdmissionNo.setValue(event.RegNo);
      this.getBillDetails();
    } else {
      this.clearForm();
    }

  }
  getBillDetails() {
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.SponsorDetails.GetBillDetails(this.f.AdmissionNo.value))
      .subscribe(resp => {
        this.bill = resp.Data;


        this.bill.MaxSponsorship = this.bill.BillAmount - this.bill.TPAmount - this.bill.SponsorAmount;

        this.loader.spin.next(false);

      });
  }

  // Method to return the form controls
  public get f() {
    return this.newSponsorDetailsForm.controls;
  }

  // Method to save the sponsor Details Save API Hit
  saveSponsorDetails() {
    if (!this.validateForm()) {
      return;
    } else {
      let obj: any = {};
      obj = this.newSponsorDetailsForm.getRawValue();
      obj.LetterDate = new ParseDate().transform(obj.LetterDate);
      obj.MailDate = new ParseDate().transform(obj.MailDate);
      let formData = new FormData();
      formData.append("SponsorDetails", JSON.stringify(obj));
      formData.append("SponsorFileData", this.fileData);
      this.commonService.confirmAction("Confirmation", "Do you want to save this Sponsor?").subscribe(res => {
        if (res) {
          this.loader.spin.next(true);
          this.httpService.Post(urlConstant.SponsorDetails.SaveNewSponsorDetailsUrl, formData).subscribe(
            res => {
              if (res.Status == 200 && res.Data) {
                this.loader.spin.next(false);
                this.commonService.displayPromptMessage("New Sponsor", "Sponsor Details saved successfully");
                this.clearForm();
                this.backToList();
              } else {
                this.loader.spin.next(false);
                this.commonService.displayPromptMessage("Error", "Something went wrong");
              }
            }, (error) => {
              console.log(error);
              this.loader.spin.next(false);
            });
        }
      });
    }
  }

  // Method to validate the form values.
  validateForm(): boolean {

    let formValue = this.newSponsorDetailsForm.getRawValue();

    if (!this.commonService.isValidStringValue(formValue.AdmissionNo)) {
      this.commonService.openSnackBar("Invalid Patient selected!", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(formValue.SponsorName)) {
      this.commonService.openSnackBar("Invalid Sponsor Name selected!", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(formValue.LetterNo)) {
      this.commonService.openSnackBar("Enter valid Letter Number", "Ok");
      return false;
    }

    if (formValue.LetterNo.length > 50) {
      this.commonService.openSnackBar("Letter Number cannot be greater than 50 !", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(formValue.ApprovedAmount)) {
      this.commonService.openSnackBar("Enter valid Approved Amount!", "Ok");
      return false;
    }




    if (this.f.IsEmail.value) {
      if (this.commonService.isValidStringValue(formValue.SenderName) && !this.validateEmail(formValue.SenderName)) {
        this.commonService.openSnackBar("Enter valid email value!", "Ok");
        return false;
      }

      if (formValue.SenderName.length > 100) {
        this.commonService.openSnackBar("Email cannot be greater than 100!", "Ok");
        return false;
      }

      if (this.commonService.isValidStringValue(formValue.Designation) && formValue.Designation.length > 100) {
        this.commonService.openSnackBar("Designation cannot be greater than 100 characters long!", "Ok");
        return false;
      }

      if (this.commonService.isValidStringValue(formValue.MailDetails) && formValue.MailDetails.length > 200) {
        this.commonService.openSnackBar("Mail details cannot be greater than 200 characters long!", "Ok");
        return false;
      }

      if (this.commonService.isValidStringValue(formValue.Remarks) && formValue.Remarks.length > 200) {
        this.commonService.openSnackBar("Remarks cannot be greater than 200 characters long!", "Ok");
        return false;
      }

    }


    return true;
  }

  // Method to reset form values
  resetForm() {
    this.commonService.confirmAction("Sponsor details", "Do you want to reset the form?").subscribe(res => {
      if (res) {
        this.clearForm();

      }
    });

  }

  clearForm() {
    this.initForm();
    this.patDetailsComp.clearPatientLookup();
    this.fileData = {};
    this.fileName = "";
    this.bill = {};
  }

  // Method to navigate back to Sponsor Details List
  backToList() {
    this.router.navigate(['/billing/sponsor-details-list']);
  }

  // function to open file dialog to select a file
  openFileDialog() {
    document.getElementById("fileUpload").click();
  }

  // function to get the file data for upload the document
  onDocumentUpload(event: any) {
    this.fileData = event.target.files[0];
    const fileExtension = this.commonService.isValidStringValue(this.fileData.name) ? this.fileData.name.split('.').pop() : '';
    if (
      fileExtension != "" &&
      (fileExtension.toLowerCase() === "pdf" ||
        fileExtension.toLowerCase() === "jpeg" ||
        fileExtension.toLowerCase() === "jpg" ||
        fileExtension.toLowerCase() === "png")
    ) {
      this.fileName = this.fileData.name;
    } else {
      this.commonService.openSnackBar('Please check the file format. Only PDF, JPEG, JPG, PNG formarts are supported.', 'Ok');
      return;
    }
  }

  // Function to view the File
  viewFile() {
    if (!isNullOrUndefined(this.fileData)) {
      if (this.commonService.isValidStringValue(this.fileName)) {
        let fileExtension = this.fileName.split(
          "."
        )[1].toLowerCase();

        let type = `application/${fileExtension}`;
        let data = this.helper.base64toBlob(
          this.fileData,
          type
        );
        let fileURL = URL.createObjectURL(data);
        this.fileUrl = this.sanitizer.bypassSecurityTrustResourceUrl(fileURL);
        // console.log(fileURL);
        if (fileExtension != "" && fileExtension.toLowerCase() === "pdf") {
          window.open(fileURL);
        } else if (
          fileExtension != "" &&
          (fileExtension.toLowerCase() === "png" ||
            fileExtension.toLowerCase() === "jpeg" ||
            fileExtension.toLowerCase() === "jpg")
        ) {
          const dialogRef = this.dialog.open(ViewImageDialogComponent, {
            width: "92%",
            maxWidth: "1150px",
            data: {
              url: this.fileUrl,
            },
          });
          dialogRef.afterClosed().subscribe();
        } else {
          let fileLink = document.createElement("a");
          fileLink.href = fileURL;
          fileLink.download = this.fileName;
          fileLink.click();
          fileLink.remove();
        }
      } else {
        this.commonService.openSnackBar(
          "Could Not View the File, Please Contact Administrator",
          "Ok"
        );
        return;
      }
    } else {
      this.commonService.openSnackBar(
        "Could Not View the File, Please Save The File",
        "Ok"
      );
      return;
    }
  }

  // common fucntion for formatting amount
  formatAmount(amount: string) {
    let parsedValue = parseInt(amount);
    if (!isNaN(parsedValue))
      return parsedValue.toFixed(2);
    else return "0.00"
  }


  formatApprAmount() {

    if (parseFloat(this.f.ApprovedAmount.value) > this.bill.MaxSponsorship) {
      this.commonService.openSnackBar("Entered approved amount cannot be greater than " + this.formatAmount(this.bill.MaxSponsorship), "ok");
      this.f.ApprovedAmount.setValue("0.00");
      return;
    }


    this.f.ApprovedAmount.setValue(this.formatAmount(this.f.ApprovedAmount.value));
  }


  validateEmail(email) {
    const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
  }
}
