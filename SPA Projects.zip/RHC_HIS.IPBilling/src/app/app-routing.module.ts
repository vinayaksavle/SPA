import { NotAuthorizedComponent } from './components/_layout/not-authorized/not-authorized.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { NotFoundComponent } from './components/_layout/not-found/not-found.component';
import { LoginComponent } from './components/login/login.component';
import { LayoutComponent } from './components/_layout/layout/layout.component';
import { AuthGuard } from './security/auth.guard'; 
import { PermissionGuard } from './security/permission.guard';
// route configuration
const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  {
    path: 'billing', component: LayoutComponent, canActivate: [AuthGuard], canActivateChild: [AuthGuard],
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'dashboard', loadChildren: './modules/dashboard/dashboard.module#DashboardModule' },
      { path: 'exchange-rate-master', loadChildren: './modules/exchange-rate-master/exchange-rate-master.module#ExchangeRateMasterModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '409'] } },
      { path: 'exclusion-service-master', loadChildren: './modules/exclusion-service-master/exclusion-service-master.module#ExclusionServiceMasterModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '410'] } },
      {
        path: 'approval-limit-configuration', loadChildren: './modules/approval-limit-configuration/approval-limit-configuration.module#ApprovalLimitConfigurationModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '4003B'] }
      },
      {
        path: 'credit', loadChildren: './modules/new-credit-note/new-credit-note.module#NewCreditNoteModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '4004N'] }
      },
      {
        path: 'estimate', loadChildren: './modules/estimate-mediclaim/estimate-mediclaim.module#EstimateMediclaimModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '4010'] }
      },
      {
        path: 'package-posting', loadChildren: './modules/package-posting/package-posting.module#PackagePostingModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '4011'] }
      },
      {
        path: 'request-approval-dashboard', loadChildren: './modules/request-approval-dashboard/request-approval-dashboard.module#RequestApprovalDashboardModule',
        canActivate: [PermissionGuard], data: { accessRights: ['04', '4003A'] }
      },
      {
        path: 'change-patient-source', loadChildren: './modules/change-patient-source/change-patient-source.module#ChangePatientSourceModule',
        canActivate: [PermissionGuard], data: { accessRights: ['04', '4012'] }
      },
      // { path: 'dept', loadChildren: './modules/dept-list/dept-list.module#DeptListModule' },
      {
        path: 'level-codes', loadChildren: './modules/level-codes/level-codes.module#LevelCodesModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '400S'] }
      },

      {
        path: 'service-posting', loadChildren: './modules/service-posting/service-posting.module#ServicePostingModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '4001'] }
      },
      {
        path: 'ppn-package-master', loadChildren: './modules/ppn-package-master/ppn-package-master.module#PPNPackageMasterModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '400'] }
      },

      {
        path: 'drug-list', loadChildren: './modules/cghs-drug-list/cghs-drug-list.module#CghsDrugListModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '402'] }
      },

      { path: 'new-cghs-drug', loadChildren: './modules/cghs-drug-list/new-cghs-drug.module#NewCghsDrugModule' },
      {
        path: 'credit-companies', loadChildren: './modules/credit-companies/credit-companies.module#CreditCompaniesListModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '403'] }
      },

      {
        path: 'cash-credit', loadChildren: './modules/cash-credit/cash-credit.module#CashCreditModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '405'] }
      },
      {
        path: 'folio-opening', loadChildren: './modules/folio-opening/folio-opening.module#FolioOpeningModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '406'] }
      },
      {
        path: 'folio-open-close', loadChildren: './modules/folio-open-close/folio-open-close.module#FolioOpenCloseModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '407'] }
      },
      {
        path: 'summary-bill-master', loadChildren: './modules/summary-bill-master/summary-bill-master.module#SummaryBillMasterModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '408'] }
      },
      {
        path: 'multiple-doctor-service', loadChildren: './modules/multiple-doctor-service/multiple-doctor-service.module#MultipleDoctorServiceModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '400'] }
      },
      {
        path: 'patient-folio', loadChildren: './modules/patient-folio/patient-folio.module#PatientFolioModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '4005'] }
      },
      {
        path: 'bill-list/:billType', loadChildren: './modules/billing/bill-list.module#BillListModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '4002'] }
      },
      {
        path: 'new-bill/:billType', loadChildren: './modules/billing/billing.module#BillingModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '4002N'] }
      },
      {
        path: 'new-bill/:billType/:regNo/:folioNo', loadChildren: './modules/billing/billing.module#BillingModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '4002N'] }
      },
      {
        path: 'view-bill/:billType/:regNo/:billNumber/:folioNo', loadChildren: './modules/billing/billing.module#BillingModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '4002V'] }
      },
      { path: 'interim-bill', loadChildren: './modules/billing/interim-billing.module#InterimBillingModule' },
      {
        path: 'allow-to-go', loadChildren: './modules/allow-to-go/allow-to-go.module#AllowToGoModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '4009'] }
      },
      {
        path: 'service-transfer', loadChildren: './modules/service-transfer/service-transfer.module#ServiceTransferModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '4008'] }
      },
      {
        path: 'tpa-completion', loadChildren: './modules/tpa-completion/tpa-completion.module#TpaCompletionModule'
      },
      {
        path: 'open-close-pharmacy-indent', loadChildren: './modules/open-close-pharmacy-indent/open-close-pharmacy-indent.module#OpenClosePharmacyIndentModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '4008B'] }
      },
      {
        path: 'change-patientsourceto-ipf', loadChildren: './modules/change-patientsourceto-ipf/change-patientsourceto-ipf.module#ChangePatientsourcetoIpfModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '4008B'] }
      },
      {
        path: 'ip-credit-note-list', loadChildren: './modules/ip-credit-note-list/ip-credit-note-list.module#IpCreditNoteListModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '4004'] }
      },
      {
        path: 'ip-credit-note-new/:action', loadChildren: './modules/ip-credit-note-new/ip-credit-note-new.module#IpCreditNoteNewModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '4004N'] }
      },
      { path: 'ip-credit-note-view/:creditNo/:action', loadChildren: './modules/ip-credit-note-new/ip-credit-note-new.module#IpCreditNoteNewModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '4004V'] } },
      {
        path: 'drug-details', loadChildren: './modules/drug-details-list/drug-details-list.module#DrugDetailsListModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '4006'] }
      },
      {
        path: 'ot-details', loadChildren: './modules/ot-details-list/ot-details-list.module#OtDetailsListModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '4006'] }
      },
      {
        path: 'doctor-details-list', loadChildren: './modules/doctor-details-list/doctor-details-list.module#DoctorDetailsListModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '4006'] }
      },
      {
        path: 'final-bill', loadChildren: './modules/billing/final-billing.module#FinalBillingModule'
        ,
      },
      { path: 'bill-list', loadChildren: './modules/billing/bill-list.module#BillListModule' },
      {
        path: 'lab-service', loadChildren: './modules/lab-service-details/lab-service-details.module#LabServiceDetailsModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '4006'] }
      },
      {
        path: 'billing-count', loadChildren: './modules/billing-count/billing-count.module#BillingCountModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '400001'] }
      },
      {
        path: 'package-report', loadChildren: './modules/package-report/package-report.module#PackageReportModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '400002'] }
      },
      {
        path: 'file-in-file-out', loadChildren: './modules/file-in-file-out/file-in-file-out.module#FileInFileOutModule' 
      },
      // {
      //   path: 'read-log-files', loadChildren: './modules/read-log-files/read-log-files.module#ReadLogFilesModule' 
      // },
      {
        path: 'report/kidney-donor', loadChildren: './modules/reports/kidney-donor-patient.module#KidneyDonorPatientModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '40009'] }
      },
      {
        path: 'report/credit-customer-profile', loadChildren: './modules/reports/credit-customer-profile.module#CreditCustomerProfileModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '40006'] }
      },
      {
        path: 'report/service-booked-for-patient', loadChildren: './modules/reports/service-booked-for-patient.module#ServiceBookedForPatientModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '40005'] }
      },
      {
        path: 'report/department-wise-wend-service', loadChildren: './modules/reports/department-wise-end-service.module#DepartmentWiseEndServiceModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '40007'] }
      },
      {
        path: 'package', loadChildren: './modules/package-collection/package-collection.module#PackageCollectionModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '4007'] }
      },
      {
        path: 'report/admitted-patient-with-no-bill', loadChildren: './modules/reports/admitted-patient-with-no-bills.module#AdmittedPatientWithNoBillsModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '40007'] }
      },
      {
        path: 'report/admitted-patient-latest-bill-list', loadChildren: './modules/reports/addmitted-patient-latest-bill-list.module#AddmittedPatientLatestBillListModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '40007'] }
      },
      { path: 'report/folio-log', loadChildren: './modules/reports/folio-log.module#FolioLogModule' },
      { path: 'report/credit-opd-bills', loadChildren: './modules/reports/credit-opd-bills.module#CreditOpdBillsModule' },
      {
        path: 'report/bed-status', loadChildren: './modules/reports/bed-status.module#BedStatusModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '40008'] }
      },
      {
        path: 'report/doctor-wise-bills', loadChildren: './modules/reports/doctor-wise-bills.module#DoctorWiseBillstModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '40004'] }
      },
      {
        path: 'report/ip-bill-list', loadChildren: './modules/reports/ip-bill-list.module#IpBillListtModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '40001'] }
      },
      {
        path: 'report/ip-pending-bills', loadChildren: './modules/reports/ip-pending-bills.module#IpPendingBillModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '40002'] }
      },
      {
        path: 'report/patient-wise-bills', loadChildren: './modules/reports/patient-wise-bills.module#PatientWiseBillsModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '40004'] }
      },
      {
        path: 'report/discharged-patient-query', loadChildren: './modules/reports/discharged-patient-query.module#DischargedPatientQueryModule'
        , canActivate: [PermissionGuard], data: { accessRights: ['04', '40005'] }
      },
      { path: 'report/deposit-required', loadChildren: './modules/reports/deposit-required.module#DepositRequiredModule' },
      {
        path: 'report/staff-billing-ledger', loadChildren: './modules/reports/staff-billing-ledger.module#StaffBillingLedgerModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '40009'] }
      },
      // { path: 'report/cghs-package-list', loadChildren: './modules/reports/cghs-package-list.module#CghsPackageListModule' },
      {
        path: 'report/negative-posted-service', loadChildren: './modules/reports/negative-posted-service.module#NegativePostedServiceModule', canActivate: [PermissionGuard], data: { accessRights: ['04', '400003'] }
      },
      { path: 'report/unattended-credit-ledger', loadChildren: './modules/reports/unattended-credit-ledger.module#UnattendedCreditLedgerModule' },
      { path: 'report/dispatch-file', loadChildren: './modules/reports/dispatch-file.module#DispatchFileModule' },
      { path: 'queries/department-wise-settled-bills', loadChildren: './modules/reports/department-wise-settled-bills.module#DepartmentWiseSettledBillsModule' },
      {
        path: 'queries/dept-wise-service', loadChildren: './modules/queries/dept-wise-service.module#DeptWiseServiceModule'
      },
      {
        path: 'queries/patient-bill-details', loadChildren: './modules/queries/patient-bill-details.module#PatientBillDetailstModule'
      },
      { path: 'queries/monthly-periodic-billing', loadChildren: './modules/queries/monthly-periodic-billing.module#MonthlyPeriodicBillingodule' },
      { path: 'queries/ipd-opd-free-concession-list', loadChildren: './modules/reports/ipd-opd-free-concession-list.module#IpdOpdFreeConcessionListModule' },
      { path: 'report/ipf-patient-list', loadChildren: './modules/reports/lib-ipf-patient-query.module#LibIpfPatientQueryModule' },
      { path: 'report/discharge-process', loadChildren: './modules/reports/lib-discharge-process.module#LibDischargeProcessModule' },

      // Newly Added Components for Sponsor Details
      { path: 'sponsor-details-list', loadChildren: './modules/sponsor-details-list/sponsor-details-list.module#SponsorDetailsListModule' },
      { path: 'new-sponsor-details/:actionType', loadChildren: './modules/new-sponsor-details/new-sponsor-details.module#NewSponsorDetailsModule' },
      { path: 'new-sponsor-details/:actionType/:sponsorId', loadChildren: './modules/new-sponsor-details/new-sponsor-details.module#NewSponsorDetailsModule' },

      { path: 'not-authorized', component: NotAuthorizedComponent },
    ]
  },
  { path: '**', component: NotFoundComponent },

]

@NgModule({
  imports: [
    RouterModule.forRoot(routes)
  ],
  exports: [RouterModule]
})

export class AppRoutingModule { }
