import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/_layout/header/header.component';
import { SidebarComponent } from './components/_layout/sidebar/sidebar.component';
import { LayoutComponent } from './components/_layout/layout/layout.component';
import { ErrorPageComponent } from './components/_layout/error-page/error-page.component';
import { NotAuthorizedComponent } from './components/_layout/not-authorized/not-authorized.component';
import { NotFoundComponent } from './components/_layout/not-found/not-found.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { SharedUtilityModule, AppMatModule } from 'shared-utility';
import { ConfirmDialogComponent } from './components/confirm-dialog/confirm-dialog.component';
import { LoginComponent } from './components/login/login.component';
import { MatTableModule, MatIconModule } from '@angular/material';
import { DragDropModule } from '@angular/cdk/drag-drop';
import { InputConfirmDialogComponent } from './components/input-confirm-dialog/input-confirm-dialog.component';
import { DocumentScanDialogComponent } from './components/document-scan-dialog/document-scan-dialog.component';
import { ViewImageDialogComponent } from './components/view-image-dialog/view-image-dialog.component';


@NgModule({

  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    LayoutComponent,
    LoginComponent,
    ErrorPageComponent,
    NotAuthorizedComponent,
    NotFoundComponent,
    ConfirmDialogComponent,
    InputConfirmDialogComponent,
    DocumentScanDialogComponent,
    ViewImageDialogComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    AppMatModule,
    MatTableModule,
    MatIconModule,
    DragDropModule,
    SharedUtilityModule
  ],
  providers: [{ provide: LocationStrategy, useClass: HashLocationStrategy }],
  entryComponents: [ErrorPageComponent, NotAuthorizedComponent, NotFoundComponent, LayoutComponent, ConfirmDialogComponent, InputConfirmDialogComponent,DocumentScanDialogComponent,ViewImageDialogComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
