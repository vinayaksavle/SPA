import { isNullOrUndefined } from 'util';
import * as moment from 'moment';

// Move to common TODO
export const common = {
  // Function to  check null and empty string and if gets treu it set string as empty i. e. ''
  checkEmptyString(str: string): string {
    if (isNullOrUndefined(str) || str === '') { return ''; } else { return str; }
  },
  // Function to convert yyyyMMdd to Angular date formate.
  getMomentDateFromString(dateString: string) {
    if (!isNullOrUndefined(dateString) && dateString !== '') {
      const date = new Date(
        // tslint:disable-next-line: radix
        parseInt(dateString.substring(0, 4)),
        // tslint:disable-next-line: radix
        parseInt(dateString.substring(4, 6)) - 1,
        // tslint:disable-next-line: radix
        parseInt(dateString.substring(6, 8))
      );
      return moment(date);
    } else {
      return '';
    }
  }
};
