import { environment } from "src/environments/environment";
import { from } from 'rxjs';
import { env } from "process";

export const urlConstant = {
  Login: {
    Authentication: environment.apiURL + "Authentication/AuthenticateUser",
  },
  Authorization: environment.apiURL + "Authorization/AuthorizeUser",
  CostCentre: {
    GetCostCentresList() {
      return environment.apiURL + "CostCentres/GetCostCentresList";
    },
    InsertNewCostCentre() {
      return environment.apiURL + "CostCentres/InsertNewCostCentre";
    },
    UpdateCostCentre() {
      return environment.apiURL + "CostCentres/UpdateCostCentre";
    },
    DeactivateCostCentreCode() {
      return environment.apiURL + "CostCentres/DeactivateCostCentreCode";
    },
    ExportToExcel() {
      return environment.apiURL + "CostCentres/ExportToExcel";
    }
  },

  JSON: 'assets/GLReportConfig.json',

  DeptGLMappingMaster: {
    GetDeptGLMappingListUrl: environment.apiURL + `DepartmentGLMapping/GetDepartmentGLMappingList`,
    ExportToExcelUrl: environment.apiURL + `DepartmentGLMapping/GetDeptGLMapExportToExcelData`,
    DeactivateDeptGLMapping: environment.apiURL + `DepartmentGLMapping/DeactivateDeptGLMapping`,
    SaveNewDeptGLMapUrl: environment.apiURL + `DepartmentGLMapping/SaveNewDepartmentGLMapping`,
    UpdateDeptGLMapUrl: environment.apiURL + `DepartmentGLMapping/UpdateDeptGLMappingDetails`,
    GetDrugStoreLookupData(text) {
      return environment.apiURL + `DepartmentGLMapping/GetDeptGLMapLookups?lookupName=${'DRUG STORE'}&inputValue=${text}`;
    },
    GetCostCenterLookupData(text) {
      return environment.apiURL + `DepartmentGLMapping/GetDeptGLMapLookups?lookupName=${'COST CENTER'}&inputValue=${text}`;
    },
    GetMMSLookupData(text) {
      return environment.apiURL + `DepartmentGLMapping/GetDeptGLMapLookups?lookupName=${'COST CENTER'}&inputValue=${text}`;
    },
    GetGeneralStoreData(text) {
      return environment.apiURL + `DepartmentGLMapping/GetDeptGLMapLookups?lookupName=${'DRUG STORE'}&inputValue=${text}`;
    },
    GetDeptGLMappingDetails(departmentCode: string) {
      return environment.apiURL + `DepartmentGLMapping/GetDeptGLMappingDetails?departmentCode=${departmentCode}`
    }
  },

  VoucherTypeMaster: {
    GetVoucherTypeListUrl: environment.apiURL + 'VoucherTypeMaster/GetVoucherTypesList',
    ExportToExcelUrl: environment.apiURL + 'VoucherTypeMaster/GetVoucherTypesListExcel',
    SaveVoucherTypeDetailsUrl: environment.apiURL + 'VoucherTypeMaster/SaveNewVoucherType',
    UpdateVoucherTypeDetailsUrl: environment.apiURL + 'VoucherTypeMaster/UpdateVoucherTypeDetails',
    DeactivateVoucherTypeUrl: environment.apiURL + 'VoucherTypeMaster/DeactivateVoucherType'
  },

  ChargeCodeGLMapping: {
    GetChargeCodeGLMappingList() {
      return environment.apiURL + "ChargeCodeGL/GetChargeCodeList";
    },
    InsetNewChargeCodeGL() {
      return environment.apiURL + "ChargeCodeGL/InsertNewChargeCode";
    },
    UpdateChargeCodeGL() {
      return environment.apiURL + "ChargeCodeGL/UpdateChargeCode";
    },
    DeactivateChargeCodeGLMapping() {
      return environment.apiURL + "ChargeCodeGL/DeactivateChargeCode";
    },
    ExportToExcel() {
      return environment.apiURL + "ChargeCodeGL/ExportToExcel";
    },
    GetGLCodeLookupData(text) {
      return environment.apiURL + `ChargeCodeGL/GetGLCodeLookupData?code=${text}`;
    }

  },

  AccountMaster: {
    GetAccountMasterList() {
      return environment.apiURL + "AccountMaster/GetAccountMasterList";
    },
    InsertNewAcMaster() {
      return environment.apiURL + "AccountMaster/InsertNewAcMaster";
    },
    UpdateAcMaster() {
      return environment.apiURL + "AccountMaster/UpdateAcMaster";
    },
    DeactivateAccountMaster() {
      return environment.apiURL + "AccountMaster/DeactivateAcCode";
    },
    ExportToExcel() {
      return environment.apiURL + "AccountMaster/ExportToExcel";
    },
    GetMainGroupData(text) {
      return environment.apiURL + `AccountMaster/GetMainGroupData?code=${text}`;
    },
    GetSubGroupData(text) {
      return environment.apiURL + `AccountMaster/GetGroupAcCodeLookup?inputValue=${text}`;
    },
    GetAcCodeDetails(acCode: string) {
      return environment.apiURL + `AccountMaster/GetAcCodeDetails?acCode=${acCode}`;
    },
  },
  PayrollGLMappingMaster: {
    GetPayrollGLMappingListUrl: environment.apiURL + `PayRollGLMapping/GetPayRollGLMappingList`,
    ExportToExcelUrl: environment.apiURL + `PayRollGLMapping/ExportToExcelPayRollGLMapList`,
    SavePayrollDetails: environment.apiURL + `PayRollGLMapping/SaveNewPayRollGLMappingDetails`,
    EditPayrollDetails: environment.apiURL + `PayRollGLMapping/UpdatePayRollGLMapping`
  },
  BankReconciliation: {
    GetBankReconciliationList: environment.apiURL + 'BankReconciliation/GetBankReconciliationDetailsList',
    UnmatchTransactionEntry(bankTransactionNo: string): string {
      return environment.apiURL + `BankReconciliation/UnmatchTransactionEntry?bankTransactionNo=${bankTransactionNo}`;
    },
    ContraMatchTransactionEntryUrl: environment.apiURL + "BankReconciliation/ContraMatchTransactionEntry",
    GetBankReconciliationMatchEntries: environment.apiURL + `BankReconciliation/GetBankReconciliationMatchEntries`,
    SaveMatchEntries: environment.apiURL + `BankReconciliation/SaveMatchEntries`,
    ExportToExcel: environment.apiURL + `BankReconciliation/ExportToExcel`
  },
  DeductionCodeGLMapping: {
    GetDeductionSetupDetails: environment.apiURL + 'DeductionCodeGLMapping/GetDeductionSetupDetails',
    SaveNewDeduction(obj: any) {
      return environment.apiURL + `DeductionCodeGLMapping/SaveNewDeductionCodeGLMapping?deductionName=${obj.Deduction}&accountCode=${obj.AccountCode}`
    },
    UpdateDeductionDetails(obj: any) {
      return environment.apiURL + `DeductionCodeGLMapping/UpdateDeductionCodeGLMappingDetails?deductionName=${obj.Deduction}&accountCode=${obj.AccountCode}`
    }
  },

  UnmatchedEntriesFromPassBook: {
    GetUnmatchedEntriesListUrl: environment.apiURL + 'UnmatchedEntriesFromPassBook/GetUnmatchedPassBookEntriesList',
    ExportToExcelUrl: environment.apiURL + `UnmatchedEntriesFromPassBook/ExportToExcelUnmatchedPassBookList`
  },

  StoreCode: {
    GetStoreCodesList() {
      return environment.apiURL + "StoreCodeGL/GetStoreCodesList";
    },
    ExportToExcel() {
      return environment.apiURL + "StoreCodeGL/ExportToExcel";
    },
    GetStoreCodeDetails(storeCode) {
      return environment.apiURL + `StoreCodeGL/GetStoreCodeDetails?strCode=${storeCode}`;
    },
    UpdateStoreCode() {
      return environment.apiURL + "StoreCodeGL/UpdateStoreCodeDetail";
    }
  },

  MMSStoreGlMapping: {
    ExportToExcel() {
      return environment.apiURL + "MMSStoreGL/ExportToExcel";
    },
    GetMMSStoreList() {
      return environment.apiURL + "MMSStoreGL/GetMMSStoreGList";
    },
    UpdateMMSStoreCode() {
      return environment.apiURL + "MMSStoreGL/UpdateMMSStore";
    }
  },
  BillingCashCounter: {
    GetBillingCashCounterList() {
      return environment.apiURL + "BillingCashCounter/GetBillingCashCounterList";
    },
    SaveBillingCashCounter() {
      return environment.apiURL + "BillingCashCounter/SaveBillingCashCounter";
    }
  },

  MainGroupMaster: {
    ExportToExcel() {
      return environment.apiURL + "MainGroupMaster/ExportToExcel";
    },
    GetMainGroupList() {
      return environment.apiURL + "MainGroupMaster/GetMainGroupList";
    },
    DeactivateMainGroupCode() {
      return environment.apiURL + "MainGroupMaster/DeactivateMainGroup";
    },
    InsertNewMainGroup() {
      return environment.apiURL + "MainGroupMaster/InsertNewMainGroup";
    },
    UpdateMainGroup() {
      return environment.apiURL + "MainGroupMaster/UpdateMainGroup";
    }

  },

  SubGroupMaster: {
    ExportToExcel() {
      return environment.apiURL + "SubGroupMaster/ExportToExcel";
    },
    GetSubGroupList() {
      return environment.apiURL + "SubGroupMaster/GetSubGroupList";
    },
    DeactivateSubGroupCode() {
      return environment.apiURL + "SubGroupMaster/DeactivateSubGroupCode";
    },
    InsertNewSubGroup() {
      return environment.apiURL + "SubGroupMaster/InsertNewSubGroup";
    },
    UpdateSubGroup() {
      return environment.apiURL + "SubGroupMaster/UpdateSubGroup";
    },
    GetMainGroupCodeLookup(text) {
      return environment.apiURL + `SubGroupMaster/GetMainGroupCodeLookup?inputValue=${text}`;
    }
  },
  Voucher: {
    GetVoucherList() { return environment.apiURL + "Voucher/GetVoucherList"; },
    GetBankCreditVoucherList() { return environment.apiURL + "Voucher/GetBankCreditVoucherList"; },
    GetVoucherDetails(docNo: string, docType: string) { return environment.apiURL + `Voucher/GetVoucherDetails?docNo=${docNo}&docType=${docType}` },
    GetAccountMasterLookup(acCode: string) {
      return environment.apiURL + `AccountMaster/GetAccountMasterLookup?inputValue=${acCode}`;
    },
    GetCostCenterLookup(ccCode: string) {
      return environment.apiURL + `CostCentres/GetCostCenterLookup?inputValue=${ccCode}`;
    },
    SaveVoucher: environment.apiURL + "Voucher/SaveVoucher",
    UpdateVoucher: environment.apiURL + "Voucher/UpdateVoucher",
    DeactivateVoucher: environment.apiURL + "Voucher/DeactivateVoucher",
    ExportVoucherList: environment.apiURL + "Voucher/ExportVoucherList",
    ExportCreditList: environment.apiURL + "Voucher/ExportCreditList",
    CheckVoucherNumber(voucherNo: string, docType: string) { return environment.apiURL + `Voucher/CheckExistingVoucher?voucherNo=${voucherNo}&docType=${docType}` },
    GetTemplate(accountCode: string, type: string) { return environment.apiURL + `VoucherNumberGeneration/GetVoucherTemplate?accountCode=${accountCode}&type=${type}` },
    CheckUsedSeries(series: string, docType: string) { return environment.apiURL + `VoucherNumberGeneration/CheckUsedSeries?prefix=${series}&voucherType=${docType}` },
  },
  ChargeCodeData(fromDate: string, toDate: string, ccCode: string, chargeCode: string) {
    return environment.apiURL + `ChargeCodeAnalysis/GetData?fromDate=${fromDate}&toDate=${toDate}&code=${ccCode}&chargeCode=${chargeCode}`;
  },
  ChargeCodeExcel(fromDate: string, toDate: string, ccCode: string, chargeCode: string) {
    return environment.apiURL + `ChargeCodeAnalysis/ExportToExcel?fromDate=${fromDate}&toDate=${toDate}&code=${ccCode}&chargeCode=${chargeCode}`;
  },
  GetChargeCode(code) {
    return environment.apiURL + "ChargeCodeAnalysis/GetCCode?code=" + code;
  },
  GetCreditCustProfile(code) {
    return environment.apiURL + "CreditCustomerProfile/GetCreditCustProfile?input=" + code;
  },

  GetSuppierCompany(code) {
    return environment.apiURL + "SupplierProfile/GetSubAccLookup?code=" + code;
  },
  GetVoucherData(tableName, voucherNo) {
    return environment.apiURL + "FactUpdate/GetVoucherData?tableName=" + tableName + '&voucherNo=' + voucherNo;
  },

  UnmatchedEntriesFromBankBook: {
    GetUnmatchedListUrl: environment.apiURL + "UnmatchedEntriesFromBankBook/GetUnmatchedEntriesFromBankBookList",
    ExportToExcelUrl: environment.apiURL + "UnmatchedEntriesFromBankBook/GetUnmatchedEntriesFromBankBookExcel",
    UpdateBankBook: environment.apiURL + "UnmatchedEntriesFromBankBook/UpdateBankBook",
  },

  GetNegativeEntryPatient(fromDate: string, toDate: string) {
    return environment.apiURL + "NegativeBill/GetNegativeBill?fromDate=" + fromDate + "&toDate=" + toDate;
  },

  GetNegativeEntryExcel(fromDate: string, toDate: string) {
    return environment.apiURL + "NegativeBill/ExportToExcel?fromDate=" + fromDate + "&toDate=" + toDate;
  },
  GetNegativeEntryDetailsExcel() {
    return environment.apiURL + "NegativeBill/GetNegativeEntryDetailsExcel";
  },
  GetNegativeEntryDetail(regNo: string, folioNo: string) {
    return environment.apiURL + "NegativeBill/GetNegativeBillDetails?regNo=" + regNo + "&folioNo=" + folioNo;
  },

  GetAccYearData() {
    return environment.apiURL + "AccountYearSetup/GetAccYearData";
  },
  GetAccYearExcel() {
    return environment.apiURL + "AccountYearSetup/ExportToExcel";
  },
  AddNewAcYear() {
    return environment.apiURL + "AccountYearSetup/AddNewAccYear";
  },
  // Credit Company
  GetCustomerBillDetail(fromDate: string, toDate: string, code: string) {
    return environment.apiURL + "CreditCustomerProfile/GetCustomerBillDetail?code=" + code + "&fromDate=" + fromDate + "&toDate=" + toDate;
  },

  GetCustomerPendingBillDetail(code: string) {
    return environment.apiURL + "CreditCustomerProfile/GetCustomerPendingBillDetail?code=" + code;
  },

  GetCustomerReceiptDetail(fromDate: string, toDate: string, code: string) {
    return environment.apiURL + "CreditCustomerProfile/GetCustomerReceiptDetail?code=" + code + "&fromDate=" + fromDate + "&toDate=" + toDate;
  },

  CreditCustomerProfileExcel(fromDate: string, toDate: string, code: string, type: string) {
    return environment.apiURL + "CreditCustomerProfile/ExportToExcel?code=" + code + "&fromDate=" + fromDate + "&toDate=" + toDate + "&type=" + type;
  },

  GetReceiptNoData(receiptNo: string) {
    return environment.apiURL + "CreditCustomerProfile/GetDetailsOnRecepit?receiptNo=" + receiptNo;
  },


  // Supplier Profile
  GetBillDetails(fromDate: string, toDate: string, supplierCode: string, code: string) {
    return environment.apiURL + "SupplierProfile/GetBillDetails?fromDate=" + fromDate + "&toDate=" + toDate + "&supplierCode=" + supplierCode + "&code=" + code;
  },

  GetPaymentDetails(fromDate: string, toDate: string, code: string, supplierCode) {
    return environment.apiURL + "SupplierProfile/GetPaymentDetails?fromDate=" + fromDate + "&toDate=" + toDate + "&supplierCode=" + supplierCode + "&code=" + code;
  },

  GetDueDetails(supplierCode: string, code: string) {
    return environment.apiURL + "SupplierProfile/GetDueDetails?supplierCode=" + supplierCode + "&code=" + code;
  },

  GetSupplierReceiptData(receiptNo: string, docType: string) {
    return environment.apiURL + "SupplierProfile/GetPaymentReceiptDetails?voucherNo=" + receiptNo + "&docType=" + docType;
  },

  SupplierExcelSheet(fromDate: string, toDate: string, code: string, supplierCode, type: string) {
    return environment.apiURL + "SupplierProfile/ExportToExcel?fromDate=" + fromDate + "&toDate=" + toDate + "&supplierCode=" + supplierCode + "&code=" + code + "&type=" + type;
  },

  //Voucher Number
  GetVoucherNumberData: environment.apiURL + "VoucherNumberGeneration/GetVoucherData",
  DeactivateVoucherData() { return environment.apiURL + "VoucherNumberGeneration/DeactivateVoucherData" },
  InsertVoucherNumberData: environment.apiURL + "VoucherNumberGeneration/InsertVoucherData",
  UpdateVoucherData: environment.apiURL + "VoucherNumberGeneration/UpdateVoucherData",

  //Reports
  reports: {
    GetDataOnPeriod(fromDate: string, toDate: string) {
      return environment.apiURL + "TrailBalance/GetDataOnPeriod?fromDate=" + fromDate + "&toDate=" + toDate;
    },

    GetDataOnYOP(year: string) {
      return environment.apiURL + "TrailBalance/GetDataOnYOP?year=" + year;
    },

    GetDataAsOnMonth() {
      return environment.apiURL + "TrailBalance/GetDataAsOnMonth";
    },

    GetCostCenterCodeName(code: string) {
      return environment.apiURL + "CostCenterBudget/GetCostCenter?code=" + code;
    },

    GetCostCenterData(code: string) {
      return environment.apiURL + "CostCenterBudget/GetCostCenterData?code=" + code;
    },

    GetUnpostedData(fromDate: string, toDate: string, transactionType: string) {
      return environment.apiURL + "UnpostedTransaction/TransactionsDetails?fromDate=" + fromDate + "&toDate=" + toDate + "&transactionType=" + transactionType;
    },

    GetGLWiseOnDate(code: string, fromDate: string, toDate: string, exclude: string) {
      return environment.apiURL + "CostCenterWiseGLBalance/GetCostCenterWiseGL?code=" + code + "&fromDate=" + fromDate + "&toDate=" + toDate + "&exclude=" + exclude;
    },

    GetGLWiseData(code: string, exclude: string) {
      return environment.apiURL + "CostCenterWiseGLBalance/GetCostCenter?code=" + code + "&exclude=" + exclude;
    },

    GetVoucherDetails(code: string, fromDate: string, toDate: string) {
      return environment.apiURL + "CheckForCtlAcTran/GetVoucherDetails?code=" + code + "&fromDate=" + fromDate + "&toDate=" + toDate;
    },
    ExportToExcel(code: string, fromDate: string, toDate: string) {
      return environment.apiURL + "CheckForCtlAcTran/ExportToExcel?code=" + code + "&fromDate=" + fromDate + "&toDate=" + toDate;
    },
    GetBlankAcCodes(fromDate: string, toDate: string) {
      return environment.apiURL + "CheckForBlnkAcCodes/GetBlankAccDetails?fromDate=" + fromDate + "&toDate=" + toDate;
    },
    ExportBlankAcCodesToExcel(fromDate: string, toDate: string) {
      return environment.apiURL + "CheckForBlnkAcCodes/ExportToExcel?fromDate=" + fromDate + "&toDate=" + toDate;
    },

    GetTallyAccounts(fromDate: string, toDate: string) {
      return environment.apiURL + "TallyAccount/GetVoucherDetails?fromDate=" + fromDate + "&toDate=" + toDate;
    },
    ExportTallyAccounts(fromDate: string, toDate: string) {
      return environment.apiURL + "TallyAccount/ExportToExcel?fromDate=" + fromDate + "&toDate=" + toDate;
    },
    GetListOfTrans() {
      return environment.apiURL + "ListOfTrans/ShowJournalRegister";
    },
    ExcelListOfTrans() {
      return environment.apiURL + "ListOfTrans/ExportToExcel";
    },
    GetVoucherMatchings(fromDate: string, toDate: string) {
      return environment.apiURL + "VoucherMatchings/GetVoucherMatchings?fromDate=" + fromDate + "&toDate=" + toDate;
    },
    ExportVoucherMatchingToExcel(fromDate: string, toDate: string) {
      return environment.apiURL + "VoucherMatchings/ExportToExcel?fromDate=" + fromDate + "&toDate=" + toDate;
    },
    GetGLChartOfAc(Code: string) {
      return environment.apiURL + "GLChartOfAc/GetGLAc?GrpCode=" + Code;
    },
    GLChartOfActToExcel(Code: string) {
      return environment.apiURL + "GLChartOfAc/ExportToExcel?GrpCode=" + Code;
    },
    DeptWiseServiceReport: environment.apiURL + `DeptWiseServ/GetDepartmentWiseService`,
    GetTestDetails: environment.apiURL + `DeptWiseServ/GetTestDetails`,
    GetDepartments(text: any) {
      return environment.apiURL + "ServiceCharge/GetDepartments?code=" + text;
    },
    GetService(text: any, deptCode: string) { return environment.apiURL + `ServiceCharge/GetServices?code=${text}&deptCode=${deptCode}` },
    ExportDeptWiseServiceReport: environment.apiURL + `DeptWiseServ/ExportToExcel`,
    GetLedgerReports: environment.apiURL + "LedgerReport/GetLedgerReport",
    ExportLedgerReportToExcel: environment.apiURL + "LedgerReport/ExportToExcel?acCode=",
    GetSubLedgerReports(supCode: string, acCode: string, fromDate: string, toDate: string) {
      return environment.apiURL + "SubsidiaryLedger/GetSubLedgerReport?SUPCODE=" + supCode + "&ACCODE=" + acCode + "&fromDate=" + fromDate + "&toDate=" + toDate;
    },
    GetSubLedgerACBal() {
      return environment.apiURL + "SubLedgerACBal/GetSubLedgerACBal";
    },
    ExcelSubLedgerACBal() {
      return environment.apiURL + "SubLedgerACBal/ExcelSubLedgerACBal";
    },
    GetIncomeExpenditure(fromDate: string, toDate: string, view: string, ReportType: string, month: string, year: string) {
      return environment.apiURL + `IncomeExpenditureReport/GetIncomeExpenditureReport?fromdate=${fromDate}&todate=${toDate}&view=${view}&ReportType=${ReportType}&month=${month}&year=${year}`
    },
    GetGroups(accountCode: string) {
      return environment.apiURL + `TrailBalance/GetMainAndSubAccount?accountCode=${accountCode}`
    },
    GetGLAcBalance(acYear: string, acCode: string, fromYear: string, fromMonth: string) {
      return environment.apiURL + `GLAcBalance/GetGLAcBalance?acYear=${acYear}&acCode=${acCode}&fromYear=${fromYear}&fromMonth=${fromMonth}`;
    },
    GetGLAcExcel(acYear: string, acCode: string, fromYear: string, fromMonth: string) {
      return environment.apiURL + `GLAcBalance/ExportToExcel?acYear=${acYear}&acCode=${acCode}&fromYear=${fromYear}&fromMonth=${fromMonth}`;
    }
  },

  UpdateAndInsertFactUpdate: environment.apiURL + `FactUpdate/UpdateAndInsert`,
  CardPayment: {
    GetReceipts: environment.apiURL + `CardPayment/GetReceipts`,
    GetEnteries: environment.apiURL + `CardPayment/GetEnteries`,
    SaveReceipts: environment.apiURL + `CardPayment/SaveCardDetails`,
    ExportExcel: environment.apiURL + `CardPayment/ExportExcel`,
  }
}
