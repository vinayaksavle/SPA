export const dataConstant = {
  // search criteria for new system
  SearchPatientCriteriaForNewSystem: [
    { value: 'PID', viewValue: 'PID' },
    { value: 'REGNO', viewValue: 'Registration Number' },
    { value: 'UHID', viewValue: 'UHID' },
    { value: 'PHONE', viewValue: 'Mobile Number' },
    { value: 'NAME', viewValue: 'Patient Name' },
    { value: 'AADHAARNUMBER', viewValue: 'Aadhar Number' },
    { value: 'PASSPORTNUMBER', viewValue: 'Passport Number' },
    { value: 'ADMISSIONNUMBER', viewValue: 'Admission Number' },
    { value: 'PFNUMBER', viewValue: 'PF Number' },

  ],

  // search criteria for jeeva system
  SearchPatientCriteriaForJeevaSystem: [
    { value: 'REGNO', viewValue: 'Registration Number' },
    { value: 'UHID', viewValue: 'UHID' },
    { value: 'PHONE', viewValue: 'Mobile Number' },
    { value: 'NAME', viewValue: 'Patient Name' },
    { value: 'PASSPORTNUMBER', viewValue: 'Passport Number' },
    { value: 'ADMISSIONNUMBER', viewValue: 'Admission Number' },
    { value: 'PFNUMBER', viewValue: 'PF Number' },

  ],

  MonthList: [
    { Key: '01', Value: 'JANUARY' },
    { Key: '02', Value: 'FEBRUARY' },
    { Key: '03', Value: 'MARCH' },
    { Key: '04', Value: 'APRIL' },
    { Key: '05', Value: 'MAY' },
    { Key: '06', Value: 'JUNE' },
    { Key: '07', Value: 'JULY' },
    { Key: '08', Value: 'AUGUST' },
    { Key: '09', Value: 'SEPTEMBER' },
    { Key: '10', Value: 'OCTOBER' },
    { Key: '11', Value: 'NOVEMBER' },
    { Key: '12', Value: 'DECEMBER' },
  ]
};
