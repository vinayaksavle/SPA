export const regexConstant = {
      PatternRegex: {
            Phone: '^([0-9]{10})$',
            UHID: '[a-z|A-Z|0-9]{1,13}',
            PID: '^[P-P][0-9.,$;]{11}$',
            RegNo: '[a-z|A-Z|0-9]{1,12}',
            Name: '[a-z|A-Z| ]{2,35}',
            AadhaarNumber: '\\d{12}',
            Passport: '[a-z|A-Z|0-9]{1,15}',
            AdmissionNumber: '[HhWw0-9]{1,12}',
            Address: /^[a-zA-Z 0-9\.\,\#\.\;\:\°\-\/]*$/,
            VTC: /^[a-zA-Z 0-9\-\,\.\;\&\/\(\)]*$/,
            PFNumber: '[a-z|A-Z|0-9]{2,6}'
      },
      AllowPattern: {
            Number: /^[0-9]$/,
            Alphabets: /[A-Za-z ]$/,
            AlphaNumberic: /[A-Za-z0-9]$/,
            PID : /[Pp0-9]$/,
            Admission : /[HhWw0-9]$/,
      }
};
