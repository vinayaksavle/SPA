export const patientCategoryConstant = {
  patientCategory: {
    NH: "01",
    CSMAPVT: "02",
    CGHS: "03",
    ESIS: "04",
    PPPD: "05",
    STATEGOVT: "06",
    STAFF: "07",
    COMPANY: "08",
    IPFFREECASE: "09",
    OTHERREFERENCE: "10",
    IPFCONCESSION: "11",
    TELCO: "12",
    MEDICLAIM: "13",
    DONTUSECGHSPAYING: "14",
    ECHS: "15",
    OVERSEAS: "16",
    CSMAGOVT: "17",
    OVERSEASPP: "18",
    PCMCDHANWANTARYYOJ: "19",
    MEDICLAIMGIPSA: "20",
    OVERSEASMEDICLAIM: "21",
  },

  getPatientCategory() {
    return [
      { value: "01", viewValue: "NH" },
      { value: "02", viewValue: "CSMAPVT" },
      { value: "03", viewValue: "CGHS" },
      { value: "04", viewValue: "ESIS" },
      { value: "05", viewValue: "PPPD" },
      { value: "06", viewValue: "STATEGOVT" },
      { value: "07", viewValue: "STAFF" },
      { value: "08", viewValue: "COMPANY" },
      { value: "09", viewValue: "IPFFREECASE" },
      { value: "10", viewValue: "OTHERREFERENCE" },
      { value: "11", viewValue: "IPFCONCESSION" },
      { value: "12", viewValue: "TELCO" },
      { value: "13", viewValue: "MEDICLAIM" },
      { value: "14", viewValue: "DONTUSECGHSPAYING" },
      { value: "15", viewValue: "ECHS" },
      { value: "16", viewValue: "OVERSEAS" },
      { value: "17", viewValue: "CSMAGOVT" },
      { value: "18", viewValue: "OVERSEASPP" },
      { value: "19", viewValue: "PCMCDHANWANTARYYOJ" },
      { value: "20", viewValue: "MEDICLAIMGIPSA" },
      { value: "21", viewValue: "OVERSEASMEDICLAIM" }
    ];
  },

  getPatientStatus() {

    return [
      { value: "0", viewValue: "ADMITTED", DBValue: "A" },
      { value: "1", viewValue: "DAMA", DBValue: "M" },
      { value: "2", viewValue: "EXPIRED", DBValue: "E" },
      { value: "3", viewValue: "DISCHARGE", DBValue: "D" },
      { value: "4", viewValue: "ABSCOND", DBValue: "S" },
    ];
  }
};
