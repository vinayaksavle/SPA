export const messageConstant = {
    gatePass: {
        BlankAdmissionNumber: 'Admission Number cannot be blank',
        NoRecords: 'No Records found for Admission Number ',
        ConfirmGatePass: 'Are sure you want to generate pass?',
        successfullGatePass(data): string {
            return `Gate pass with pass number ${data} has been generated successfully`;
        }

    },

    // Placeholder messages.
    PlaceHolder: {
        PHONE: 'Enter Mobile Number',
        UHID: 'Enter UHID',
        PID: 'Enter PID',
        REGNO: 'Enter Registration Number',
        NAME: 'Enter Patient Name',
        PASSPORTNUMBER: 'Enter Passport Number',
        ADMISSIONNUMBER: 'Enter Admission Number',
        AADHAARNUMBER: 'Enter Aadhar Number',
        PFNUMBER: 'Enter PF Number',

    },

    // required messages.
    RequiredMessage: {
        PHONE: 'Mobile Number is required',
        UHID: 'UHID is required',
        PID: 'PID is required',
        REGNO: 'Registration Number is required',
        NAME: 'Patient Name is required',
        PASSPORTNUMBER: 'Passport Number is required',
        ADMISSIONNUMBER: 'Admission Number is required',
        AADHAARNUMBER: 'Aadhar Number is required',
        Facility: 'Facility is required',
        SearchPatientBy: 'Search patient by is required',
        PFNUMBER: 'PF Number is required',

    },

    // validation messages.
    ValidationMessage: {
        PHONE: 'Mobile Number is not valid',
        UHID: 'UHID is not valid',
        PID: 'PID is not valid',
        REGNO: 'Registration Number is not valid',
        NAME: 'Patient Name is not valid',
        PASSPORTNUMBER: 'Passport Number is not valid',
        ADMISSIONNUMBER: 'Admission Number is not valid',
        AADHAARNUMBER: 'Aadhar Number is not valid',
        PFNUMBER: 'PF Number is not valid',
        InvalidValue: '{0} has invalid value !',
    },

    viewPatient: {
        BlankAdmissionNumber: 'Admission Number cannot be blank',
        BlankReservationNumber: 'Reservation Number cannot be blank',
        BlankPid: 'PID cannot be blank'
    },
    reservationAccount: {
        BlankPid: 'Invalid PID.',
        StaffErrorMessage: 'Patient Category could not be Staff.',
        PPPDErrorMessage: 'Private patient can not be hospital case.',
        CreditCompany: 'Credit Company could not be Staff.',
        ReservationHeader: 'Patient Reservation Account',
        DomesticMessage: 'Only domestic patient can have reservation account.',
        ConfirmCreate: 'Are you sure you want to create reservation account?',
        Duplicate: 'Patient already has a reservation account',
        AdmittedReservation: 'Admitted patient cannot have a reservation account',
        Message: 'Message !',
        DOB: 'D.O.B. can not be greater than current date'
    },

    invalidMessages: {
        Header: 'Invalid !',
        Invalid: 'Invalid ',
        HeaderForReservation: 'Already Reserved',
        SolutionCardHeader: 'Solution Card',
        CardNumberNotFound: 'Card number not found ! ',
        HeaderForAdmitted: 'Already Admitted',
        HeaderForAdmission: 'Patient Admission ',
        HeaderForEdit: 'Edit Patient ',
        HeaderForSave: 'Save patient',
        HeaderForReset: 'Reset Form',
        ReferralMessage: 'Referral Source STAFF can not be selected',
        Referral: 'Referral Source can not be changed',
        StaffCategoryMessage: 'Patient category STAFF can not be selected',
        PrivatePatientMessage: 'Private Patient cannot be Hospital case',
        InvalidPatientCategoryStaffMessage: 'Invalid patient category for staff patient.',
        InvalidCreditCompanyMessage: 'Invalid Credit Company / Patient Source for staff patient.',
        ReferralCompanyMessage: 'Ref. Company can not be Staff.',
        InvalidReferralCompanyForStaff: 'Invalid referral company for staff patient.',
        AdmittedPatientMessage: 'Patient is already admitted with PID/UHID : ',
        BWardMessage: 'Admit male patient in female ward ?',
        FemaleAdmit: 'Admit female patient in male ward ?',
        ConfirmAdmission: 'Are you sure you want to submit the admission?',
        ConfirmEdit: 'Are you sure you want to update the patient admission details?',
        InvalidForm: 'Invalid form value',
        ResetMessage: 'Do you want to reset form ?',
        LabourRoom: 'Admit male patient in female ward ?',
        BedHeader: 'Bed Type',
        CaseTypeMessage: 'Male patient can not be GYNAEC case.',
        CaseTypeHeader: 'Case Type',
        TreatingDoctorHeader: 'Treating Doctor',
        TreatingDoctorMessage: 'Treating doctor for staff patient must be Hospital case',
        DuplicateEntryHeader: 'Duplicate patient entry',
        SomethingWrongHeader: 'Something went wrong',
        DocumentMessage: 'Please enter Document details',
        OK: 'OK',
        IncorrectPinCodeMessage: 'Incorrect pincode',
        InvalidAgeMesage: 'Invalid Age',
        InvalidEmail: 'Invalid Email Id !',
        InvalidPassportMesage: 'Passport number ',
        InvalidIssueDateMesage: 'Invalid Issue Date',
        InvalidExpiryDateMesage: 'Invalid Expiry Date',
        InvalidIssuePlaceMesage: 'Issue Place',
        InvalidMobileNoMesage: 'Invalid Mobile No',
        NoDocumentSelected: 'Upload documents for upload',
        AdmissionNo: 'and Admission number :',
        InvalidFormReceiveTimeMessage: 'Form Receive time should be greater than Form Given Time'
    },
    searchPatient: {
        Header: 'Patient View',
        ReservationAccountMessage: 'This patient has reservation account, view this patient details from reservation list.'
    },
    SuccessFull: {
        AdmissionSuccessful: 'Admission Successful',
        SuccessFullMessage: ` Patient has been registered successfully.`,
        successfullEditMessage(pid, flagDemo) {
            if (flagDemo === 1) {
                return 'Patient demographic Information has been updated successfully with  PID - ' + pid;
            } else {
                return 'Patient IPD Information has been updated successfully with  PID - ' + pid;
            }
        },
        updateSuccessful: 'Update Successful'

    },
    ServiceTranfer: {
        Header: 'Service Transfer',
        ServiceTransferConfirmAction(donerRegNo, patientRegNo) {
            return 'Do you want to transfer services? All services will be transfered from - ' + donerRegNo + ' To ' + patientRegNo + '.';
        },
        InvalidPatRegNo: `Please enter valid patient registration number.`,
        InvalidDonorRegNo: `Please enter valid donor registration number.`,
        SameDonorPatRegNo: `Donor and Patient registration number should not be same.`
    },

    AllowToGo: {
        Header: 'Allow To Go',
        RemarkRequired: 'Remark can not be blank.',
        RemarkMaxlength: 'Remark can not exceed 40 letter. ',
        RegNoRequired: 'Invalid patient registration number.',
        SaveConfirm: 'Do You Want To Save ?',
        InvalidRegNo: 'Invalid Registration Number OR Patient Already Discharged OR Final Bill Not Prepared.'
    },

    TPACompletion: {
        SendSms: 'Succesfully saved details.',
        Confirm: 'Do you want to save the details ?',
        Header: 'TPA Completion',
        FailResponse: 'Discharge from doctor already entered.'
    },

    ChangePatientSource: {
        CatgRequired: 'Invalid patient current category.',
        IncomeRequired: 'Invalid patient yearly declared income.',
        MaxlengthError: 'Patient yearly declared income can not exceed 14 letter.',
        Header: 'Change Patient Source To IPF',
        ConfirmFreeCase: 'Do you want to change patient source to free case ?',
        ConfirmConsession: 'Do you want to change patient source to concession case ?',
        ConfirmIncome: 'Do you want to save patient yearly declared income?',
        FailSaveIncome: 'Record not saved, Final bill not prepared...',
        SucessSaveIncome: 'Patient record saved sucessfully.'
    },

    OpenClosePharmacyIndent: {
        OpenStatus: 'Indent Option OPEN',
        CloseStatus: 'Indent Option CLOSED',
        ConfirmOpenIndent: 'Do you want to start patient indent ?',
        ConfirmCloseIndent: 'Do you want to  stop patient indent from wards ?',
        ConfirmReset: 'Do you want to reset form ? ',
        AlreadyClose: 'File Already Cleared For Discharge.',
        CloseSucess: 'File Closed For Indent From WARDS.',
        OpenSucess: 'File Open For Indent',
        AlreadyOpen: 'File Already Open For Indent',
        Header: 'Pharmacy  Indent  For Patient'
    },

    DoctorDetailsService: {
        InvalidBillNo: 'Invalid patient Bill Number.',
        InvalidFolioNo: 'Invalid patient Folio Number.',
        InvalidFromDate: 'Invalid from date.',
        InvalidToDate: 'Invalid to date.',
        GreaterToDate: 'From date should be less than to date.'
    },
    IpCreditNew: {
        InvalidChargeCode: 'Allowed only single entry for : 79-DISCOUNT HEALTH FINANCE :  3-30-371 : 02',
        SelectBill: 'Bill is not generated for patient.',
        MoreCreditAmt: 'Credit amount is greater than net bill amount',
        ConfirmNew: 'Records successfully saved.',
        ConfirmDelete: 'Record sucessfully Cancelled.',
        Error: 'Unable to save credit note.',
        Header: 'IP Credit Note',
        InvalidServiceAmt: 'Doctor service amount mismatch, make different credit notes for doctors fees & relative department.',
        RequiredChargeCode: 'Invalid charge code.',
        RemarkMax: 'Remark can not exceed 40 character.',
        DeclaredIncomeMax: 'Declaraed income can not exceed 14 digit',
        RequiredChargeDesc: 'Invalid charge description.',
        RequiredAmount: 'Invalid amount.',
        InvalidAmount: 'Charge amount can not be greater than total amount.',
        InvalidAmountWithNetAmt: 'Total amount can not be greater than net amount',
        ConfirmAddservice: "Do you want to add doctor service ?",
        ConfirmAddTransaction: 'Do you want to add transaction ?',
        ConfirmRemoveTransaction: 'Do you want to remove transaction ?',
        ConfirmChangeTransaction: 'Do you want to change transaction ?',
        ConfirmActionMsg(action) {
            if (action === 'D') {
                return 'Do you want to cancel ?';
            } else if (action === 'N') {
                return 'Are the entries correct. do you want to save ?';
            }
        },
        ConfirmResetAction: 'Do you want to reset ?',
        ConfirmActionPrint: 'Do you want to print the details ?'
    }
};
