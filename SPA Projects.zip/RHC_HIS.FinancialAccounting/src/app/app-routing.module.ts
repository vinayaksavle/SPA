import { NotAuthorizedComponent } from './components/_layout/not-authorized/not-authorized.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { NotFoundComponent } from './components/_layout/not-found/not-found.component';
import { LoginComponent } from './components/login/login.component';
import { LayoutComponent } from './components/_layout/layout/layout.component';
import { AuthGuard } from './security/auth.guard';
import { PermissionGuard } from './security/permission.guard';
import { UnauthorizedComponent } from './components/unauthorized/unauthorized.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  {
    path: 'financial-account', component: LayoutComponent, canActivate: [AuthGuard], canActivateChild: [AuthGuard],
    children: [
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
      { path: 'cost-center', loadChildren: './modules/cost-center/cost-center.module#CostCenterModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3301M'] } },
      { path: 'charge-code-gl-mapping', loadChildren: './modules/charge-code-gl-mapping/charge-code-gl-mapping.module#ChargeCodeGlMappingModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3303M'] } },
      { path: 'ac-code-mapping/department-gl-mapping', loadChildren: './modules/department-gl-mapping/department-gl-mapping.module#DepartmentGlMappingModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3304M'] } },
      { path: 'new-dept-gl-mapping/:actionType/:deptCode', loadChildren: './modules/new-dept-gl-mapping/new-dept-gl-mapping.module#NewDeptGlMappingModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3304M'] } },
      { path: 'store-code-gl-mapping', loadChildren: './modules/store-code-gl-mapping/store-code-gl-mapping.module#StoreCodeGlMappingModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3305M'] } },
      { path: 'store-code-gl-mapping/:actionType/:storeCode', loadChildren: './modules/new-store-code-gl-mapping/new-store-code-gl-mapping.module#NewStoreCodeGlMappingModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3305M'] } },
      { path: 'billing-cash-counter', loadChildren: './modules/billing-cash-counter/billing-cash-counter.module#BillingCashCounterModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3306M'] } },
      { path: 'payroll-gl-mapping', loadChildren: './modules/payroll-gl-mapping/payroll-gl-mapping.module#PayrollGlMappingModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3307M'] } },
      { path: 'deduction-code-gl-mapping', loadChildren: './modules/deduction-code-gl-mapping/deduction-code-gl-mapping.module#DeductionCodeGlMappingModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3307M'] } },
      { path: 'mms-store-gl-mapping', loadChildren: './modules/mms-store-gl-mapping/mms-store-gl-mapping.module#MMSGlMappingModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3308M'] } },
      { path: 'ac-master', loadChildren: './modules/ac-master/ac-master.module#AccountMasterModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3309M'] } },
      { path: 'ac-master/:actionType/:acCode', loadChildren: './modules/new-ac-master/new-ac-master.module#NewAccountMasterModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3309M'] } },
      { path: 'main-group-master', loadChildren: './modules/main-group-master/main-group-master.module#MainGroupMasterModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3311M'] } },
      { path: 'sub-group-master', loadChildren: './modules/sub-group-master/sub-group-master.module#SubGroupMasterModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3312M'] } },
      { path: 'voucher-type', loadChildren: './modules/voucher-type/voucher-type.module#VoucherTypeModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3315M'] } },
      { path: 'voucher/:voucherType', loadChildren: './modules/bank-voucher/bank-voucher.module#BankVoucherModule' },
      { path: 'voucher/:voucherType/:actionType', loadChildren: './modules/bank-voucher-action/bank-voucher-action.module#BankVoucherActionModule' },
      { path: 'voucher/:voucherType/:actionType/:docNo', loadChildren: './modules/bank-voucher-action/bank-voucher-action.module#BankVoucherActionModule' },
      { path: 'bank-reconciliation', loadChildren: './modules/bank-reconciliation/bank-reconciliation.module#BankReconciliationModule' },
      { path: 'bank-reconciliation-match-entry', loadChildren: './modules/bank-reconciliation-match-entry/bank-reconciliation-match-entry.module#BankReconciliationMatchEntryModule' },
      { path: 'unmatched-entries-from-passbook', loadChildren: './modules/unmatched-entries-from-passbook/unmatched-entries-from-passbook.module#UnmatchedEntriesFromPassbookModule' },
      { path: 'unmatched-entries-from-bankbook', loadChildren: './modules/unmatched-entries-from-bankbook/unmatched-entries-from-bankbook.module#UnMatchedEntiresBankbookModule' },
      { path: 'fact-update', loadChildren: './modules/fact-update/fact-update.module#FactUpdateModule' },
      { path: 'voucher-number', loadChildren: './modules/voucher-number/voucher-number.module#VoucherNumberModule' },
      { path: 'charge-code-analysis', loadChildren: './modules/charge-code-analysis/charge-code-analysis.module#ChargeCodeAnalysisModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3301F'] } },
      { path: 'negative-entries', loadChildren: './modules/negative-entries/negative-entries.module#NegativeEntriesModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3302F'] } },
      { path: 'supplier-profile', loadChildren: './modules/supplier-profile/supplier-profile.module#SupplierProfileModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3303F'] } },
      { path: 'credit-customer-profile', loadChildren: './modules/credit-customer-profile/credit-customer-profile.module#CreditCustomerProfileModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3304F'] } },
      { path: 'account-year-setup', loadChildren: './modules/account-year-setup/account-year-setup.module#AccountYearSetupModule' },
      { path: 'card-payments', loadChildren: './modules/card-payments/card-payments.module#CardPaymentsModule' },
      { path: 'reports/trail-balance', loadChildren: './modules/reports/trail-balance.module#TrailBalanceModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3301R'] } },
      { path: 'reports/ledger-report', loadChildren: './modules/reports/ledger-report.module#LedgerReportModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3302R'] } },
      { path: 'reports/income-expenditure-report', loadChildren: './modules/reports/income-expenditure-report.module#IncomeExpenditureReportModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3303R'] } },
      { path: 'reports/subsidiary-ledger-report', loadChildren: './modules/reports/subsidiary-ledger-report.module#SubsidiaryLedgerReportModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3304R'] } },
      { path: 'reports/balance-sheet', loadChildren: './modules/reports/balance-sheet.module#BalanceSheetModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3305R'] } },
      { path: 'reports/unposted-transactions', loadChildren: './modules/reports/unposted-transactions.module#UnpostedTransactionsModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3306R'] } },
      { path: 'reports/cost-center-wise-gl-balance', loadChildren: './modules/reports/cost-center-wise-gl-balance.module#CostCenterWiseGlBalanceModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3307R'] } },
      { path: 'reports/list-transaction', loadChildren: './modules/reports/transaction-list.module#ListOfTransactionModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3308R'] } },
      { path: 'reports/general-ledger-ac-balance', loadChildren: './modules/reports/general-ledger-ac-bal.module#GeneralLedgerAcBalModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3309R'] } },
      { path: 'reports/department-wise-services', loadChildren: './modules/reports/dept-wise-service.module#DeptWiseServiceModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3310R'] } },
      { path: 'reports/blank-ac-codes', loadChildren: './modules/reports/blank-ac-codes.module#BlankAcCodesModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3311R'] } },
      { path: 'reports/subsidiary-ledger-account', loadChildren: './modules/reports/subsidiary-ledger-account-balance.module#SubLedgerAccountBalModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3312R'] } },
      { path: 'reports/gl-charts-ac', loadChildren: './modules/reports/gl-charts-ac.module#GlChartsAcModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3313R'] } },
      { path: 'reports/voucher-matching', loadChildren: './modules/reports/voucher-matching.module#VoucherMatchingModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3314R'] } },
      { path: 'reports/tally-accounts', loadChildren: './modules/reports/tally-accounts.module#TallyAccountsModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3315R'] } },
      { path: 'reports/control-ac-transaction', loadChildren: './modules/reports/control-ac-transaction.module#ControlACTransactionModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3316R'] } },
      { path: 'reports/cost-center-budget-variance', loadChildren: './modules/reports/cost-center-budget-variance.module#CostCenterBudgetVarianceModule', canActivate: [PermissionGuard], data: { accessRights: ['33', '3317R'] } },
      { path: 'not-authorized', component:UnauthorizedComponent }
    ]
  },
  { path: '**', component: NotFoundComponent },
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
