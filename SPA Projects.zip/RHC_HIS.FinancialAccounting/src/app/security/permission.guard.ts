import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router, CanActivate } from '@angular/router';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';
import { isNullOrUndefined } from 'util';

@Injectable({
  providedIn: 'root'
})

export class PermissionGuard implements  CanActivate {
  constructor(private auth: AuthService, private route: Router) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    // gets the user permissions stored in localstorage
    const permissions = localStorage.getItem('Permission');
    // gets the modules for which user is having access
    const module = localStorage.getItem('moduleId');

    // assigned access rights (module id, permission) which were passed in routing
    const accessRights = next.data.accessRights as Array<string>;

    let moduleId = null;
    let permission = null;
    // if accessRights is having some values then assign module id and permission
    if (!isNullOrUndefined(accessRights) && accessRights.length > 0) {
        moduleId = accessRights[0];
        permission = accessRights[1];
    }

    // if module id is same as passed in routing
    if (this.checkUserSession() && !isNullOrUndefined(module) && module.length > 0 && module.includes(moduleId)) {
       // if specified permission is not exist in user permissions then navigate to not authorized component
        if (!isNullOrUndefined(permission) && !permissions.includes(permission)) {
            this.route.navigate(['/not-authorized']);
          }
    }
     return this.checkUserSession();
  }

  // checks whether uses is logged in
  checkUserSession(): boolean {
    if (this.auth.isLoggednIn()) {
      return true;
    } else {
      return false;
    }
  }
}
