import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class AuthService {
    sendToken(token: string) {
        localStorage.setItem('UserName', token);
    }
    getToken() {
        return localStorage.getItem('UserName');
    }
    isLoggednIn() {
        return this.getToken() !== null;
    }
    logout() {
        localStorage.removeItem('UserName');
        localStorage.clear();
    }
}
