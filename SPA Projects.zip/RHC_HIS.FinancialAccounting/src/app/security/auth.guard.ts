import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, CanActivate, CanActivateChild, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { Observable } from 'rxjs';
import { AuthService } from '../security/auth.service';

import { DataTranferService } from '../services/data-transfer.service';
import { isNullOrUndefined } from 'util';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate, CanActivateChild {

  constructor(private auth: AuthService, private route: Router,
    private snackBar: MatSnackBar, private dataTransferService: DataTranferService) {
  }

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    return this.checkUserSession();
  }
  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
    return this.checkUserSession();
  }
  checkUserSession(): boolean {
    //this.checkLoginTime();
    if (this.auth.isLoggednIn()) return true;
    else {
      if (!this.checkCookie()) {
        this.openSnackBar('Login to continue', 'Login Continue');
        // this.route.navigate(['/login']); 
        window.location.href = location.origin + '/#/login';
        return false;
      }
      else return true;
    }
  }

  checkCookie() {
    let cookieValue = JSON.parse(this.dataTransferService.getCookieValue("RedirectionCookie"));

    if (!isNullOrUndefined(cookieValue)) {
      for (var prop in cookieValue) {
        this.dataTransferService.setObject(prop, cookieValue[prop]);
      }

      localStorage.removeItem("AuthorizedModules");
      localStorage.removeItem("DepositListParam");
      localStorage.removeItem("UserGroup");
      this.dataTransferService.setObject("LoggedInUser", cookieValue["UserName"]);
      document.cookie = 'RedirectionCookie=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
      return true;
    }
    else return false;

  }


  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, { duration: 2000 });
  }

  checkLoginTime() {
    let currentDate = new Date();
    let lastLoggedinTime = new Date(this.dataTransferService.getObject("LoginDateTime"));
    let minutes = Math.abs(currentDate.getTime() - lastLoggedinTime.getTime()) / 60000;

    if (minutes > 150) {
      this.openSnackBar("Session Expired! Please login again.", "Ok");
      this.dataTransferService.Logout();
      this.auth.logout();
    }
    else if (this.dataTransferService.getObject("isUserLogin") === "true") {
      this.dataTransferService.setObject("LoginDateTime", currentDate);
    }
  }
}