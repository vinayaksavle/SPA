import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
// import {IpPatientAdmissionNewComponent} from '../../../projects/HIS-Patient/src/app/components/ip-patient-admission-new/ip-patient-admission-new.component'

@Injectable()
export class PreventUnsavedChanges { }
// export class PreventUnsavedChanges implements CanDeactivate<IpPatientAdmissionNewComponent> {
//     canDeactivate(component: IpPatientAdmissionNewComponent): boolean {
//         if (component.regForm.dirty || component.demographicForm.dirty || component.ipdInfoForm.dirty
//             || component.nextOfKinForm.dirty || component.ipdDocumentsForm.dirty) {
//                 return confirm('Are you sure you want to leave this page? Changes will be lost!')
//             }
//             return true;
//     }
// }