import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { VoucherNumberActionDialog } from './voucher-number-action-dialog.component';
import { isNullOrUndefined } from 'util';
import { resolveNgModuleDep } from '@angular/core/src/view/ng_module';

@Component({
  selector: 'app-voucher-number',
  templateUrl: 'voucher-number.component.html',
  styleUrls: ['./voucher-number.component.css'],
  host: { 'class': 'section__main' }
})
export class VoucherNumber {
  @ViewChild(MatSort) sort: MatSort;
  selectedRowData: any;
  selectedRowIndex: number = -1;
  permissions: any[];
  canCreateNew: boolean;
  canEdit: boolean;
  canDeactivate: boolean;
  filteredDataBank: MatTableDataSource<any> = new MatTableDataSource();
  filteredDataVoucher: MatTableDataSource<any> = new MatTableDataSource();

  displayedColumnsBank = ["SrNo", "VoucherNumber", "CreatedModified", "CreatedModifiedDate", "Remarks"];
  displayedColumnsVoucher = ["SrNo", "VoucherNo", "CreatedModified", "CreatedModifiedDate", "Remarks"];
  selectedVoucherRowIndex: number = -1;
  selectedVoucherRowData: any;
  activeTypeRecord: string = "";
  voucherSeries: any = [];

  constructor(private httpService: HttpService, private loader: LoaderService
    , private dialog: MatDialog, private commonService: CommonService) {
    this.permissions = JSON.parse(localStorage.getItem('Permission'));
    if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
      this.canCreateNew = this.permissions.includes('3327T') ? true : false;
      this.canEdit = this.permissions.includes('3328T') ? true : false;
      this.canDeactivate = this.permissions.includes('3329T') ? true : false;
    }
  }


  ngOnInit() {
    this.init();
    this.getVoucherData();
  }

  init() {
    this.selectedRowIndex = -1;
    this.selectedRowData = {};
    this.selectedVoucherRowData = {};
    this.selectedVoucherRowIndex = -1;
  }

  getVoucherData() {
    this.init();
    this.loader.spin.next(true);
    this.filteredDataVoucher = new MatTableDataSource([]);
    this.filteredDataBank = new MatTableDataSource([]);
    this.httpService.Get(urlConstant.GetVoucherNumberData).subscribe(result => {
      if (result && result.Data) {
        this.voucherSeries = result.Data;
        this.filteredDataVoucher = new MatTableDataSource(result.Data.filter(x => x.VoucherType === 'J'));
        this.filteredDataBank = new MatTableDataSource(result.Data.filter(x => x.VoucherType === 'B'));
        this.loader.spin.next(false);
      } else {
        this.loader.spin.next(false);
      }
    })
  }

  //method for opening deactivate modal
  deactivate() {
    if (!this.commonService.isValidStringValue(this.selectedRowData.VoucherType)) {
      this.commonService.displayPromptMessage("Deactivate Voucher Number", "Please select a record first!");
      return;
    }


    if (this.selectedRowData.Status === 0) {
      this.commonService.openSnackBar("Record is not active", "OK");
      return;
    }

    //make changes as per api

    //    let accountName = this.selectedRowData.VoucherType === 'B' ? this.selectedRowData.AccountName : " JOURNAL VOUCHER ";
    let accountName = this.getVoucherTypeName();

    this.commonService.deactivateAction("Deactivate Voucher Number", `Reason For Deactivating series`).subscribe(response => {
      if (response.Status) {
        this.selectedRowData.DRemarks = response.Remarks;
        this.selectedRowData.UserId = localStorage.getItem("UserName");
        this.commonService.confirmAction("Deactivate Voucher Number", `Do you want to deactivate series for  ${accountName}  ?`).subscribe(response => {
          if (response) {
            this.loader.spin.next(true);
            this.httpService.Post(urlConstant.DeactivateVoucherData(), this.selectedRowData).subscribe(response => {
              if (response.Data) {
                this.commonService.displayPromptMessage("Deactivate Voucher Number", `${accountName} series deactivated successfully!`).subscribe(() => {
                  this.getVoucherData();
                });
              }
              else {
                this.loader.spin.next(false);
                this.commonService.displayPromptMessage("Deactivate Voucher Number", `${accountName} Number already in use, cannot deactivate!`);
              }
            })
          }
        })
      }
    });
  }

  // To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.activeTypeRecord = "B";
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedVoucherRowIndex = -1;
      this.selectedRowIndex = index;
    }
  }

  highlightSelectedRowForVoucher(index, rowDetails) {
    this.selectedRowData = rowDetails;
    this.activeTypeRecord = "J";
    if (this.selectedVoucherRowIndex == index) {
      this.selectedVoucherRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = -1;
      this.selectedVoucherRowIndex = index;
    }
  }

  openActionDialog(action: string) {

    let dialogRef = null;

    let activeVouchers = this.voucherSeries.filter(v => v.Status === 1);
    if (action == 'edit') {

      if (this.selectedRowIndex == -1 && this.selectedVoucherRowIndex == -1) {
        this.commonService.openSnackBar("Please select a row to edit", "OK");
        return;
      }

      if (this.selectedRowData.Status === 0) {
        this.commonService.openSnackBar("Record is not active", "OK");
        return;
      }

      console.log(this.selectedRowData);
      this.httpService.Get(urlConstant.Voucher.CheckUsedSeries(this.selectedRowData.Prefix, this.selectedRowData.VoucherType))
        .subscribe(res => {
          if (res.Data)
            this.commonService.displayPromptMessage("Edit Voucher Number", `${this.getVoucherTypeName()} Number already in use, cannot deactivate!`);
          else {
            dialogRef = this.dialog.open(VoucherNumberActionDialog);
            this.openVoucherActionDialog(dialogRef, action);
          }
        });
    }
    else {
      switch (activeVouchers.length) {
        case 0:
          dialogRef = this.dialog.open(VoucherNumberActionDialog);
          dialogRef.componentInstance.disableFlag = 0;
          break;
        case 1:
          dialogRef = this.dialog.open(VoucherNumberActionDialog);
          dialogRef.componentInstance.disableFlag = activeVouchers[0].VoucherType === 'B' ? 1 : 2;
          break;
        case 2:
          this.commonService.displayPromptMessage("Voucher Number", "Active series already present for both bank and journal vouchers.");
          return;
          break;
      }
      this.openVoucherActionDialog(dialogRef, action);
    }
  }

  openVoucherActionDialog(dialogRef: any, action: string) {
    if (!isNullOrUndefined(dialogRef)) {
      dialogRef.componentInstance.action = action;
      dialogRef.componentInstance.voucherSeries = this.voucherSeries;
      dialogRef.componentInstance.rowdetails = this.selectedRowData;

      dialogRef.afterClosed().subscribe(results => {
        this.getVoucherData();
      });
    }
  }

  getVoucherTypeName() 
  {
    let accountName;
    if (this.selectedRowData.VoucherType === 'B') {
      accountName = "Bank Voucher";
    } else if (this.selectedRowData.VoucherType === 'J') {
      accountName = "Journal Voucher";
    }
    return accountName;
  }

}