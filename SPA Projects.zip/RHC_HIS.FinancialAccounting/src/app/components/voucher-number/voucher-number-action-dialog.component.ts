import { AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material';
import { AcMasterLibComponent } from 'ac-master-lib';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-voucher-number-action-dialog',
  templateUrl: './voucher-number-action-dialog.component.html',
  styleUrls: ['./voucher-number.component.css'],
})
export class VoucherNumberActionDialog implements OnInit, AfterViewInit {
  // @ViewChild('bankAccount') bankAccount: AcMasterLibComponent;

  action: string;
  rowdetails: any;
  public voucherNumberForm: FormGroup;
  code: any;
  initialValue: any;
  voucherSeries: any = [];
  disableFlag: number = 0;

  constructor(private formBuilder: FormBuilder, private dialogRef: MatDialogRef<VoucherNumberActionDialog>, public fb: FormBuilder,
    private http: HttpService, private loader: LoaderService, private cd: ChangeDetectorRef,
    private common: CommonService) { }

  ngAfterViewInit(): void {
    if (this.action === 'edit') {
      this.init(this.rowdetails)
    }
    else if (this.disableFlag) {
      this.f.VoucherType.setValue(this.disableFlag === 1 ? "J" : "B");
      this.f.VoucherType.disable();
    }
  }


  ngOnInit() {
    this.voucherNumberForm = this.formBuilder.group({
      VoucherType: 'B',
      PrefixYear: '',
      Prefix: '',
      DigitCount: '',
      IsYear: false,
      StartCounter: '',
      Reset: false
    });



  }

  init(valueObj) {

    this.voucherNumberForm.setValue({
      VoucherType: valueObj.VoucherType,
      PrefixYear: valueObj.PrefixYear,
      Prefix: valueObj.Prefix,
      DigitCount: valueObj.DigitCount,
      IsYear: valueObj.IsYear,
      StartCounter: valueObj.StartCounter,
      Reset: valueObj.Reset,
    });

    this.initialValue = { Prefix: valueObj.Prefix, DigitCount: valueObj.DigitCount, StartCounter: valueObj.StartCounter };

    setTimeout(() => {
      // if (this.f.VoucherType.value === 'B') {
      //   if (valueObj !== '') {
      //     this.bankAccount.inputValue.setValue(valueObj.Accode + ' ' + valueObj.AccountName);
      //     this.code = valueObj.Accode;
      //   }
      //   else {
      //     this.bankAccount.inputValue.setValue('');
      //     this.code = "";
      //   }
      // }

      if (this.f.IsYear.value) {
        this.f.PrefixYear.disable();
      }

      if (valueObj !== '') {
        this.f.VoucherType.disable()
      }

    }, 500);


  }

  get f() {
    return this.voucherNumberForm.controls;
  }

  // method to save
  save() {
    let dataObj: any = {};
    dataObj = this.voucherNumberForm.getRawValue();

    if (!this.validateForm(dataObj))
      return;


    dataObj.IsYear === true ? dataObj.IsYear = 1 : dataObj.IsYear = 0;
    dataObj.LastResetCounter = this.f.Reset.value === true ? 1 : 0;
    dataObj.Accode = this.code;
    this.loader.spin.next(true);
    if (this.action === 'edit') {
      dataObj.ID = this.rowdetails.ID;
      dataObj.ModifiedBy = localStorage.getItem('UserName');
      this.http.Post(urlConstant.UpdateVoucherData, dataObj).subscribe(result => {
        if (result && result.Status === 200) {
          this.loader.spin.next(false);
          this.common.displayPromptMessage('Voucher Type', result.Data).subscribe(() => {
            this.dialogRef.close();
          });
        } else {
          this.loader.spin.next(false);
        }
      });
    } else {
      dataObj.CreatedBy = localStorage.getItem('UserName');
      this.http.Post(urlConstant.InsertVoucherNumberData, dataObj).subscribe(result => {
        if (result && result.Status === 200) {
          this.loader.spin.next(false);
          this.common.displayPromptMessage('Voucher Type', result.Data).subscribe(() => {
            this.dialogRef.close();
          });
        } else {
          this.loader.spin.next(false);
        }
      });
    }
  }


  validateForm(voucherNumber: any): boolean {
    let isSuccess = true;


    if (!this.common.isValidStringValue(voucherNumber.PrefixYear)) {
      this.common.openSnackBar("Prefix Year is required", "Ok");
      return false;
    }
    else if (voucherNumber.PrefixYear.length > 12) {
      this.common.openSnackBar("Prefix Year cannot be more that 12 characters long", "Ok");
      return false;
    }

    if (!this.common.isValidStringValue(voucherNumber.Prefix)) {
      this.common.openSnackBar("Prefix is required", "Ok");
      return false;
    }
    else if (voucherNumber.Prefix.length > 2) {
      this.common.openSnackBar("Prefix cannot be more than 2 characters long", "Ok");
      return false;
    }

    if (!this.common.isValidStringValue(voucherNumber.DigitCount)) {
      this.common.openSnackBar("Digit Count is required", "Ok");
      return false;
    }
    else if (parseInt(voucherNumber.DigitCount) > 4) {
      this.common.openSnackBar("Number of digits cannot greater than 4", "Ok");
      return false;
    }


    if (!this.common.isValidStringValue(voucherNumber.StartCounter)) {
      this.common.openSnackBar("Start Counter is required", "Ok");
      return false;
    }
    else if (voucherNumber.StartCounter.length > 1) {
      this.common.openSnackBar("Start Counter cannot be more than 1 character long", "Ok");
      return false;
    }

    // if (voucherNumber.VoucherType === 'B' && !this.common.isValidStringValue(this.code)) {
    //   this.common.openSnackBar("Account is required for bank vouchers", "Ok");
    //   return false;
    // }



    return isSuccess;
  }

  // method to cancel
  cancel() {
    this.dialogRef.close();
  }

  // method for setting value from lookup
  setBankAccCodeName(event) {
    this.code = event.Code;
  }

  setPrefixYear(event: any) {
    if (this.f.IsYear.value) {
      let date = new Date();
      let year = `${(date.getFullYear().toString().substr(2, 2)) + (date.getFullYear() + 1).toString().substr(2, 2)}`;
      this.f.PrefixYear.setValue(year);
      this.f.PrefixYear.disable();
    }
    else {
      this.f.PrefixYear.setValue('');
      this.f.PrefixYear.enable();
    }
  }


  resetSeries(event: any) {
    if (this.f.Reset.value) {
      this.f.Prefix.setValue('');
      this.f.DigitCount.setValue('');
      this.f.StartCounter.setValue('');
    }
    else {
      this.f.Prefix.setValue(this.initialValue.Prefix);
      this.f.DigitCount.setValue(this.initialValue.DigitCount);
      this.f.StartCounter.setValue(this.initialValue.StartCounter);
    }
  }

  validatePrefix() {
    let series = this.voucherSeries.filter(v => this.f.Prefix.value === v.Prefix)[0];
    if (!isNullOrUndefined(series)) {
      let accountName = series.VoucherType === "B" ? "Bank voucher":"Journal voucher";
      this.common.openSnackBar("Prefix value already selected for " + accountName, "Ok");
      this.f.Prefix.setValue("");
      return;
    }
  }


}