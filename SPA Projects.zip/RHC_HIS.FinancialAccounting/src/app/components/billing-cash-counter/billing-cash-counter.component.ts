import { Component, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { AcMasterLibComponent } from "ac-master-lib";
import { urlConstant } from "src/app/constants/urlConstants";
import { CommonService } from "src/app/services/common.service";
import { HttpService } from "src/app/services/http.service";
import { LoaderService } from "src/app/services/loader.service";

@Component({
    selector: 'billing-cash-counter',
    templateUrl: 'billing-cash-counter.component.html',
    styleUrls: ['billing-cash-counter.component.css'],
    host: { 'class': 'section__main' }
})

export class BillingCashCounterComponent implements OnInit {
    @ViewChild('billsInProcess') billsInProcess: AcMasterLibComponent;
    @ViewChild('billsReceivable') billsReceivable: AcMasterLibComponent;
    @ViewChild('staffReceivable') staffReceivable: AcMasterLibComponent;
    @ViewChild('depositApplied') depositApplied: AcMasterLibComponent;
    @ViewChild('patientDeposit') patientDeposit: AcMasterLibComponent;
    @ViewChild('mainCash') mainCash: AcMasterLibComponent;
    @ViewChild('bank') bank: AcMasterLibComponent;
    @ViewChild('refund') refund: AcMasterLibComponent;
    @ViewChild('concession') concession: AcMasterLibComponent;
    @ViewChild('tdsAc') tdsAc: AcMasterLibComponent;
    @ViewChild('bankCharges') bankCharges: AcMasterLibComponent;
    @ViewChild('staffMedicalBenefit') staffMedicalBenefit: AcMasterLibComponent;
    @ViewChild('cghsBillsReceivable') cghsBillsReceivable: AcMasterLibComponent;
    @ViewChild('freeTreatment') freeTreatment: AcMasterLibComponent;
    @ViewChild('companyOPDBills') companyOPDBills: AcMasterLibComponent;
    @ViewChild('cash') cash: AcMasterLibComponent;
    @ViewChild('receipt') receipt: AcMasterLibComponent;
    @ViewChild('payment') payment: AcMasterLibComponent;

    billCashForm: FormGroup;
    billCodes: any;
    cashCounterCodes: any;
    isEditable: boolean = false;

    constructor(private formBuilder: FormBuilder, private httpService: HttpService, private loader: LoaderService, private commonService: CommonService) { }

    ngOnInit() {
        this.getBillingCashCounterList();
        this.initForm();
    }

    initForm() {
        this.billCashForm = this.formBuilder.group({
            BillsInProcessAcCode: [{ value: '' }, Validators.required],
            BillsReceivedAcCode: [{ value: '' }, Validators.required],
            StaffReceivableAcCode: [{ value: '' }, Validators.required],
            DepositAppliedAcCode: [{ value: '' }, Validators.required],
            PatientDepositAcCode: [{ value: '' }, Validators.required],
            MainCashAcCode: [{ value: '' }, Validators.required],
            BankAcCode: [{ value: '' }, Validators.required],
            RefundAcCode: [{ value: '' }, Validators.required],
            ConcessionAcCode: [{ value: '' }, Validators.required],
            TDSAcCode: [{ value: '' }, Validators.required],
            BankChargesAcCode: [{ value: '' }, Validators.required],
            StaffMedAcCode: [{ value: '' }, Validators.required],
            CGHSBillsAcCode: [{ value: '' }, Validators.required],
            FreeTreatmentAcCode: [{ value: '' }, Validators.required],
            CompanyBillsAcCode: [{ value: '' }, Validators.required],
            CashAcCode: [{ value: '' }, Validators.required],
            ChequeReceiptAcCode: [{ value: '' }, Validators.required],
            ChequePaymentAcCode: [{ value: '' }, Validators.required]
        })
    }

    get f() { return this.billCashForm.controls; }

    getBillingCashCounterList() {
        this.loader.spin.next(true);
        this.httpService.Get(urlConstant.BillingCashCounter.GetBillingCashCounterList()).subscribe(response => {
            if (response.Status === 200) {
                this.billCodes = response.Data.BillGeneralCodes[0];
                this.cashCounterCodes = response.Data.CashCounterCodes[0];
                this.setFormFields(this.billCodes, this.cashCounterCodes);
                this.loader.spin.next(false);
                console.log(this.billCodes);
                console.log(this.cashCounterCodes);
            }
        })
    }

    setFormFields(bill: any, cash: any) {
        // by default non editable
        this.editCode();

        // setting form control values and lookup library values
        this.f.BillsInProcessAcCode.setValue(bill.BillsInProcessAcCode);
        this.billsInProcess.inputValue.setValue(bill.BillsInProcessAcCode + ' ' + bill.BillsInProcessAcDesc);
        this.f.BillsReceivedAcCode.setValue(bill.BillsReceivedAcCode);
        this.billsReceivable.inputValue.setValue(bill.BillsReceivedAcCode + ' ' + bill.BillsReceivedAcDesc);
        this.f.StaffReceivableAcCode.setValue(bill.StaffReceivableAcCode);
        this.staffReceivable.inputValue.setValue(bill.StaffReceivableAcCode + ' ' + bill.StaffReceivableAcDesc);
        this.f.DepositAppliedAcCode.setValue(bill.DepositAppliedAcCode);
        this.depositApplied.inputValue.setValue(bill.DepositAppliedAcCode + ' ' + bill.DepositAppliedAcDesc);
        this.f.PatientDepositAcCode.setValue(bill.PatientDepositAcCode);
        this.patientDeposit.inputValue.setValue(bill.PatientDepositAcCode + ' ' + bill.PatientDepositAcDesc);
        this.f.MainCashAcCode.setValue(bill.MainCashAcCode);
        this.mainCash.inputValue.setValue(bill.MainCashAcCode + ' ' + bill.MainCashAcDesc);
        this.f.BankAcCode.setValue(bill.BankAcCode);
        this.bank.inputValue.setValue(bill.BankAcCode + ' ' + bill.BankAcDesc);
        this.f.RefundAcCode.setValue(bill.RefundAcCode);
        this.refund.inputValue.setValue(bill.RefundAcCode + ' ' + bill.RefundAcDesc);
        this.f.ConcessionAcCode.setValue(bill.ConcessionAcCode);
        this.concession.inputValue.setValue(bill.ConcessionAcCode + ' ' + bill.ConcessionAcDesc);
        this.f.TDSAcCode.setValue(bill.TDSAcCode);
        this.tdsAc.inputValue.setValue(bill.TDSAcCode + ' ' + bill.TDSAcDesc);
        this.f.BankChargesAcCode.setValue(bill.BankChargesAcCode);
        this.bankCharges.inputValue.setValue(bill.BankChargesAcCode + ' ' + bill.BankChargesAcDesc);
        this.f.StaffMedAcCode.setValue(bill.StaffMedAcCode);
        this.staffMedicalBenefit.inputValue.setValue(bill.StaffMedAcCode + ' ' + bill.StaffMedAcDesc);
        this.f.CGHSBillsAcCode.setValue(bill.CGHSBillsAcCode);
        this.cghsBillsReceivable.inputValue.setValue(bill.CGHSBillsAcCode + ' ' + bill.CGHSBillsAcDesc);
        this.f.FreeTreatmentAcCode.setValue(bill.FreeTreatmentAcCode);
        this.freeTreatment.inputValue.setValue(bill.FreeTreatmentAcCode + ' ' + bill.FreeTreatmentAcDesc);
        this.f.CompanyBillsAcCode.setValue(bill.CompanyBillsAcCode);
        this.companyOPDBills.inputValue.setValue(bill.CompanyBillsAcCode + ' ' + bill.CompanyBillsAcDesc);
        this.f.CashAcCode.setValue(cash.CashAcCode);
        this.cash.inputValue.setValue(cash.CashAcCode + ' ' + cash.CashAcDesc);
        this.f.ChequeReceiptAcCode.setValue(cash.ChequeReceiptAcCode);
        this.receipt.inputValue.setValue(cash.ChequeReceiptAcCode + ' ' + cash.ChequeReceiptAcDesc);
        this.f.ChequePaymentAcCode.setValue(cash.ChequePaymentAcCode);
        this.payment.inputValue.setValue(cash.ChequePaymentAcCode + ' ' + cash.ChequePaymentAcDesc);
    }

    editCode(isEditable: boolean = false) {
        // setting isEditable value to disable/enable save button
        this.isEditable = isEditable;

        if (isEditable) {
            this.billsInProcess.enableEvent();
            this.billsReceivable.enableEvent();
            this.staffReceivable.enableEvent();
            this.depositApplied.enableEvent();
            this.patientDeposit.enableEvent();
            this.mainCash.enableEvent();
            this.bank.enableEvent();
            this.refund.enableEvent();
            this.concession.enableEvent();
            this.tdsAc.enableEvent();
            this.bankCharges.enableEvent();
            this.staffMedicalBenefit.enableEvent();
            this.cghsBillsReceivable.enableEvent();
            this.freeTreatment.enableEvent();
            this.companyOPDBills.enableEvent();
            this.cash.enableEvent();
            this.receipt.enableEvent();
            this.payment.enableEvent();
        }
        else {
            this.billsInProcess.disableEvent();
            this.billsReceivable.disableEvent();
            this.staffReceivable.disableEvent();
            this.depositApplied.disableEvent();
            this.patientDeposit.disableEvent();
            this.mainCash.disableEvent();
            this.bank.disableEvent();
            this.refund.disableEvent();
            this.concession.disableEvent();
            this.tdsAc.disableEvent();
            this.bankCharges.disableEvent();
            this.staffMedicalBenefit.disableEvent();
            this.cghsBillsReceivable.disableEvent();
            this.freeTreatment.disableEvent();
            this.companyOPDBills.disableEvent();
            this.cash.disableEvent();
            this.receipt.disableEvent();
            this.payment.disableEvent();
        }
    }

    saveBillingCashCounter() {
        console.log(this.billCashForm.getRawValue());

        const inputParam = this.billCashForm.getRawValue();
        this.commonService.confirmAction("Edit Billing/Cash Counter Code", "Do you want to change the Account Code ?").subscribe(response => {
            if (response) {
                this.httpService.Post(urlConstant.BillingCashCounter.SaveBillingCashCounter(), inputParam).subscribe(response => {
                    if (response.Data) {
                        this.commonService.displayPromptMessage("Edit Billing/Cash Counter Code", "Account Code updated successfullly!").subscribe(response => {
                            if (response)
                                window.location.reload();
                        });
                    }
                    else {
                        this.commonService.displayPromptMessage("Edit Billing/Cash Counter Code", "Error while updating!");
                    }
                });
            }
        })
    }

    // set Bills In Process Ac Code
    setBillsInProcess(event: any) {
        this.f.BillsInProcessAcCode.setValue(event.Code);
    }

    // set Bills Received Ac Code
    setBillsReceivable(event: any) {
        this.f.BillsReceivedAcCode.setValue(event.Code);
    }

    // set Staff Receivable Ac Code
    setStaffReceivable(event: any) {
        this.f.StaffReceivableAcCode.setValue(event.Code);
    }

    // set Deposit Applied Ac Code
    setDepositApplied(event: any) {
        this.f.DepositAppliedAcCode.setValue(event.Code);
    }

    // set Patient Deposit Ac Code
    setPatientDeposit(event: any) {
        this.f.PatientDepositAcCode.setValue(event.Code);
    }

    // set Main Cash Ac Code
    setMainCash(event: any) {
        this.f.MainCashAcCode.setValue(event.Code);
    }

    // set Bank Ac Code
    setBank(event: any) {
        this.f.BankAcCode.setValue(event.Code);
    }

    // set Refund Ac Code
    setRefund(event: any) {
        this.f.RefundAcCode.setValue(event.Code);
    }

    // set Concession Ac Code
    setConcession(event: any) {
        this.f.ConcessionAcCode.setValue(event.Code);
    }

    // set TDS Ac Code
    setTDSAc(event: any) {
        this.f.TDSAcCode.setValue(event.Code);
    }

    // set Bank Charges Ac Code
    setBankCharges(event: any) {
        this.f.BankChargesAcCode.setValue(event.Code);
    }

    // set Staff Medical Benefit Ac Code
    setStaffMedicalBenefit(event: any) {
        this.f.StaffMedAcCode.setValue(event.Code);
    }

    // set CGHS Bills Receivable Ac Code
    setCGHSBillsReceivable(event: any) {
        this.f.CGHSBillsAcCode.setValue(event.Code);
    }

    // set Free Treatment Ac Code
    setFreeTreatment(event: any) {
        this.f.FreeTreatmentAcCode.setValue(event.Code);
    }

    // set Company OPD Bills Ac Code
    setCompanyOPDBills(event: any) {
        this.f.CompanyBillsAcCode.setValue(event.Code);
    }

    // set Cash Ac Code
    setCash(event: any) {
        this.f.CashAcCode.setValue(event.Code);
    }

    // set Cheque Receipt Ac Code
    setReceipt(event: any) {
        this.f.ChequeReceiptAcCode.setValue(event.Code);
    }

    // set Cheque Payment Ac Code
    setPayment(event: any) {
        this.f.ChequePaymentAcCode.setValue(event.Code);
    }

    // cancel / reset the changes
    cancel() {
        this.isEditable = false;
        this.setFormFields(this.billCodes, this.cashCounterCodes);
    }
}