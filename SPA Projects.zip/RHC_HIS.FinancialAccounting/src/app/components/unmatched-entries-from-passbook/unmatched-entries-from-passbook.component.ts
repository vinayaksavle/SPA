import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatSort, MatTableDataSource, MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { AcMasterLibComponent } from 'ac-master-lib';
import { FromDateToDateComponent } from 'from-date-to-date';
import { error } from 'protractor';
import { ParseDate } from 'shared-utility';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-unmatched-entries-from-passbook',
  templateUrl: './unmatched-entries-from-passbook.component.html',
  styleUrls: ['./unmatched-entries-from-passbook.component.css'],
  host: { 'class': 'section__main' }
})
export class UnmatchedEntriesFromPassbookComponent implements OnInit {

  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('fromDateToDateComp') fromDateToDateComp: FromDateToDateComponent;
  @ViewChild('bankAccountCode') bankAccountCodeComp: AcMasterLibComponent;
  selectedRowData: any;
  selectedRowIndex: number = -1;
  permissions: any[];
  canSearch: boolean;
  passBookList: MatTableDataSource<any> = new MatTableDataSource();
  ChequeRefNo = new FormControl();

  displayedColumns = ["SrNo", "BankDate", "ChequeNo", "Description", "CreditAmount", "DebitAmount"];

  constructor(private loader: LoaderService, private http: HttpService, private commonService: CommonService) {
    this.permissions = JSON.parse(localStorage.getItem('Permission'));
    if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0)
      this.canSearch = this.permissions.includes('3321T') ? true : false;
  }

  ngOnInit() {
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    //Add 'implements AfterViewInit' to the class.
    // this.getPassBookList(false);
  }

  getPassBookList(isExcel: boolean) {

    if (!this.commonService.isValidStringValue(this.bankAccountCodeComp.inputValue.value)) {
      this.commonService.openSnackBar("Invalid Bank Account Code", "OK");
      return;
    } else {
      // url configuration according to isExcel flag
      let url: string;
      url = isExcel ? urlConstant.UnmatchedEntriesFromPassBook.ExportToExcelUrl : urlConstant.UnmatchedEntriesFromPassBook.GetUnmatchedEntriesListUrl
      this.loader.spin.next(true);
      this.http.Post(url, this.createSearchObject())
        .subscribe(res => {
          if (res.Status == 200 && res.Data.length > 0) {
            if (!isExcel) {
              this.passBookList = new MatTableDataSource();
              this.passBookList = new MatTableDataSource(res.Data);
              this.passBookList.sort = this.sort;
              this.loader.spin.next(false);
            } else {
              this.http.openFile(res.Data);
              this.loader.spin.next(false);
            }
          } else {
            this.loader.spin.next(false);
            this.passBookList = new MatTableDataSource([]);
          }
        }, (err) => {
          console.log(err);
          this.loader.spin.next(false);
        });
      this.createSearchObject();
    }
  }

  createSearchObject(): any {
    let obj: any = {};
    obj.FromDate = new ParseDate().transform(this.fromDateToDateComp.FromDate.value);
    obj.ToDate = new ParseDate().transform(this.fromDateToDateComp.ToDate.value);
    obj.BankCode = this.commonService.isValidStringValue(this.bankAccountCodeComp.inputValue.value) ? this.bankAccountCodeComp.inputValue.value.split(' ')[0] : '';
    obj.ChequeRefNo = this.ChequeRefNo.value;
    return obj;
  }
  // To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }

  clearSearch() {
    this.fromDateToDateComp.FromDate.setValue(new Date());
    this.fromDateToDateComp.ToDate.setValue(new Date());
    this.bankAccountCodeComp.inputValue.setValue('');
    this.ChequeRefNo.setValue('');
    this.passBookList = new MatTableDataSource();
    this.getPassBookList(false);
  }


}
