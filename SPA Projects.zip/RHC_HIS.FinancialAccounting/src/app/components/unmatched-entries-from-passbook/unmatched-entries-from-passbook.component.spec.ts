import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UnmatchedEntriesFromPassbookComponent } from './unmatched-entries-from-passbook.component';

describe('UnmatchedEntriesFromPassbookComponent', () => {
  let component: UnmatchedEntriesFromPassbookComponent;
  let fixture: ComponentFixture<UnmatchedEntriesFromPassbookComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UnmatchedEntriesFromPassbookComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UnmatchedEntriesFromPassbookComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
