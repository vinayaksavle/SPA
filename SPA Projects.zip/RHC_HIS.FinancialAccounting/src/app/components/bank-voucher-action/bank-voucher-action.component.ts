import { Component, OnInit, ViewChild, Inject, ElementRef, ViewChildren, QueryList, AfterViewInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSelect, MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { isNullOrUndefined } from 'util';
import { AcMasterLibComponent } from 'ac-master-lib';
import { CostCentreLibComponent } from 'cost-centre-lib';
import { SubGroupLibComponent } from 'sub-group-lib';

@Component({
    selector: 'app-bank-voucher-action',
    templateUrl: 'bank-voucher-action.component.html',
    styleUrls: ['./bank-voucher-action.component.css'],
    host: { 'class': 'section__main' }
})
export class BankVoucherAction implements OnInit, AfterViewInit {
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('VoucherNo') VoucherNo: ElementRef;
    @ViewChild('Narration') Narration: ElementRef;
    @ViewChild('VoucherType') VoucherType: MatSelect;
    @ViewChild('bankAcCodeName') accountMaster: AcMasterLibComponent;
    @ViewChildren('acMaster') acLookups: QueryList<AcMasterLibComponent>;
    @ViewChildren('ccMaster') ccLookups: QueryList<CostCentreLibComponent>;
    @ViewChildren('subGrpLib') subGrpLookups: QueryList<SubGroupLibComponent>;

    selectedRowData: any;
    selectedRowIndex: number = -1;
    voucherTypeList: any[];
    voucherList: MatTableDataSource<any> = new MatTableDataSource([]);
    rowdetails: any;
    bankVoucherForm: FormGroup;
    action: string;
    docNo: string;
    docType: string;
    isSaveDisable: boolean = false;
    displayedColumns = ["SrNo", "AcCode", "CCCode", "DebitAmount", "CreditAmount", "SubAcCode", "CtrlAcFlag", "TNarration"];
    accountCode: string = "1-06-206";
    accountName: string = "";
    displayViewBtn: boolean = true;
    isView: boolean = true;

    isBankVoucher: boolean = true;
    isNarrationRequired: boolean = false;
    voucherTypeName: string = "Bank Voucher";

    constructor(private http: HttpService, private commonService: CommonService,
        private fb: FormBuilder, private loader: LoaderService,
        private activateRoute: ActivatedRoute, private router: Router) { }

    ngOnInit() {
        // gets value from params
        this.activateRoute.params.subscribe(params => {
            this.action = params['actionType'];
            this.docNo = params['docNo'];
            this.docType = params['voucherType'];
            if (this.docType === "02") {
                this.isBankVoucher = true;
                this.voucherTypeName = "Bank Voucher"
            }
            else {
                this.isBankVoucher = false;
                this.voucherTypeName = "Journal Voucher";
            }
            this.getVoucherTemplate();
        });

        this.initForm();
        this.getVoucherTypes();
        this.getDefaultAccount();
    }


    ngAfterViewInit() {
        if (this.action == 'edit')
            this.setFormData()
        else if (this.action == 'view') {
            this.setFormData()
            this.bankVoucherForm.disable();
            this.isSaveDisable = true;
        }
        else
            this.addVoucher(1);
    }

    getDefaultAccount() {
        this.http.Get(urlConstant.Voucher.GetAccountMasterLookup(this.accountCode)).subscribe(response => {
            let acCodeName = response.Data[0];
            if (!isNullOrUndefined(acCodeName)) {
                this.accountName = acCodeName.Name;
            }
        })
    }

    // method for form init
    initForm() {
        this.bankVoucherForm = this.fb.group({
            VoucherDocNo: [{ value: '', disabled: true }],
            DocDate: [{ value: this.commonService.convertDateToString(), disabled: true }],
            DocTime: [{ value: this.commonService.getCurrentTime(), disabled: true }],
            VoucherType: [],
            VoucherDate: [new Date()],
            GenerateVoucherNo: [false],
            // VoucherNo: [],
            VoucherNo: [{ value: '', disabled: true }],
            Narration: [],
            BankAcCodeName: [],
            BankAccName: [],
            ChequeDate: [new Date()],
            ChequeNo: [],
            UserId: [localStorage.getItem("UserName")],
            VoucherDetails: this.fb.array([]),
            TotalDebitAmount: [0.00],
            TotalCreditAmount: [0.00],
            DocType: [this.docType]
        });



    }

    initVoucher(vouchers?: any): any {
        if (isNullOrUndefined(vouchers)) {
            return this.fb.group({
                AcCode: [''],
                AcDesc: [''],
                CCCode: [''],
                CCDesc: [''],
                DebitAmount: ['0.00'],
                CreditAmount: ['0.00'],
                SubAcCode: [''],
                SubAcName: [''],
                TNarration: [''],
                CtrlAcFlag: ['N'],
                DrOrCr: [''],
            })
        }
        else {
            let isDisable = this.action === "view";
            this.isView = isDisable;
            return this.fb.group({
                AcCode: [{ value: vouchers.AcCode, disabled: isDisable }],
                AcDesc: [{ value: vouchers.AcDesc, disabled: isDisable }],
                CCCode: [{ value: vouchers.CCCode, disabled: isDisable }],
                CCDesc: [{ value: vouchers.CCDesc, disabled: isDisable }],
                DebitAmount: [{ value: parseFloat(vouchers.DebitAmount).toFixed(2), disabled: isDisable }],
                CreditAmount: [{ value: parseFloat(vouchers.CreditAmount).toFixed(2), disabled: isDisable }],
                SubAcCode: [{ value: vouchers.SubAcCode, disabled: isDisable }],
                SubAcName: [{ value: vouchers.SubAcName, disabled: isDisable }],
                TNarration: [{ value: vouchers.TNarration, disabled: isDisable }],
                CtrlAcFlag: [{ value: vouchers.CtrlAcFlag, disabled: isDisable }],
                DrOrCr: [{ value: vouchers.DrOrCr, disabled: isDisable }]
            })
        }
    }

    // method get all form control values
    get f() { return this.bankVoucherForm.controls; }

    get VoucherArray(): FormArray {
        return this.bankVoucherForm.get('VoucherDetails') as FormArray;
    }

    voucherControl(index: number) {
        return this.VoucherArray.controls[index]["controls"];
    }

    setFormData() {
        // this.loader.spin.next(true);
        this.http.Get(urlConstant.Voucher.GetVoucherDetails(this.docNo, this.docType)).subscribe(response => {
            if (response.Status === 200) {
                this.f.VoucherDocNo.setValue(this.docNo);
                this.f.DocDate.setValue(response.Data.DocDate);
                this.f.DocTime.setValue(response.Data.DocTime);
                this.f.VoucherType.setValue(response.Data.VoucherType);
                this.f.VoucherDate.setValue(this.commonService.convertStringToDate(response.Data.VoucherDate));
                this.f.VoucherNo.setValue(response.Data.VoucherNo);
                this.f.Narration.setValue(response.Data.Narration);
                this.f.ChequeDate.setValue(this.commonService.convertStringToDate(response.Data.ChequeDate));
                this.f.ChequeNo.setValue(response.Data.ChequeNo);
                this.f.BankAcCodeName.setValue(response.Data.BankAcCodeName);
                if (this.f.BankAcCodeName.value === "1-06-206")
                    this.isNarrationRequired = true;

                if (this.commonService.isValidStringValue(response.Data.BankAcCodeName) && this.isBankVoucher) {
                    this.f.BankAccName.setValue(response.Data.BankAccName);
                    this.accountMaster.inputValue.setValue(`${response.Data.BankAcCodeName} ${response.Data.BankAccName}`);
                }

                this.displayViewBtn = false;
                this.f.VoucherType.disable();
                this.f.VoucherNo.disable();
                for (let i = 0; i < response.Data.VoucherDetails.length; i++) {
                    let currentRow = response.Data.VoucherDetails[i];
                    this.addVoucher(1, currentRow);
                    setTimeout(() => {
                        this.acLookups.toArray()[i].inputValue.setValue(currentRow.AcCode + " " + currentRow.AcDesc);
                        if (this.commonService.isValidStringValue(currentRow.CCCode))
                            this.ccLookups.toArray()[i].inputValue.setValue(currentRow.CCCode + " " + currentRow.CCDesc);
                        if (this.commonService.isValidStringValue(currentRow.SubAcCode))
                            this.subGrpLookups.toArray()[i].inputValue.setValue(currentRow.SubAcCode + " " + currentRow.SubAcName);

                        if (this.action === "view") {
                            this.acLookups.toArray()[i].disableEvent();
                            this.ccLookups.toArray()[i].disableEvent();
                            this.subGrpLookups.toArray()[i].disableEvent();
                        }
                    }, 1000);
                }

                // if (this.action !== 'view') {
                //     this.addVoucher(1);
                // }

                if (this.action === 'new') {
                    this.addVoucher(1);
                }
                else if (this.isBankVoucher)
                    this.accountMaster.disableEvent();

                this.f.TotalDebitAmount.setValue(response.Data.VoucherDetails.map(x => x.DebitAmount).reduce((prev, next) => parseFloat(prev) + parseFloat(next)));
                this.f.TotalCreditAmount.setValue(response.Data.VoucherDetails.map(x => x.CreditAmount).reduce((prev, next) => parseFloat(prev) + parseFloat(next)));
                // this.loader.spin.next(false);
            }
        })
    }

    setBankAcCodeName(event: any) {

        this.isNarrationRequired = false;
        if (!isNullOrUndefined(event)) {
            if (event.Type !== "B" && this.isBankVoucher) {
                this.accountMaster.inputValue.setValue('');
                this.commonService.openSnackBar("Bank Voucher", "Account is not set as bank account in master !");
                return;
            }


            this.f.BankAcCodeName.setValue(event.Code);
            this.f.BankAccName.setValue(event.Name);

            if (this.f.BankAcCodeName.value === "1-06-206")
                this.isNarrationRequired = true;


        }
        else {
            this.f.BankAcCodeName.setValue('');
            this.f.BankAccName.setValue('');
        }

        // this.getVoucherTemplate();

    }

    getVoucherTypes() {
        this.http.Get(urlConstant.VoucherTypeMaster.GetVoucherTypeListUrl).subscribe(response => {
            if (response.Status == 200 && response.Data.length > 0) {
                this.voucherTypeList = response.Data;
                if (this.isBankVoucher)
                    this.voucherTypeList = this.voucherTypeList.filter(x => x.VoucherType === "BR" || x.VoucherType === "BP")
            }
        })
    }

    getAcCodeName(index: number, account: any) {
        // if (!this.commonService.isValidStringValue(this.VoucherArray.value[index].AcCode))
        //     return;

        // this.http.Get(urlConstant.Voucher.GetAccountMasterLookup(this.VoucherArray.value[index].AcCode)).subscribe(response => {
        //     let acCodeName = response.Data[0];
        //     if (!isNullOrUndefined(acCodeName)) {
        //         this.voucherControl(index).AcDesc.setValue(acCodeName.Name);

        //     }
        // });

        let code = ""; let name = "";

        if (!isNullOrUndefined(account)) {
            code = account.Code; name = account.Name;
        }

        this.voucherControl(index).AcCode.setValue(code);
        this.voucherControl(index).AcDesc.setValue(name);

    }

    removeAcCodeName(index: number) {
        if (this.action === 'view'
            || (!this.commonService.isValidStringValue(this.VoucherArray.value[index].AcCode)
                && this.VoucherArray.value.length - 1 === index)) {
            return;
        }

        if (!this.commonService.isValidStringValue(this.VoucherArray.value[index].AcDesc)) {
            return;
        }

        let tempVouchers = this.voucherList.data;
        let updatedVouchers = [];

        for (let i = 0; i < tempVouchers.length; i++) {
            if (i !== index) {
                updatedVouchers.push(tempVouchers[i]);
            }
        }

        this.voucherList = new MatTableDataSource(updatedVouchers);
        this.VoucherArray.removeAt(index);

        if (this.VoucherArray.length === 0) {
            this.addVoucher(1);
        }

        this.calculateTotalDebit();
        this.calculateTotalCredit();

    }

    getCCCodeName(index: number, cc: any) {
        // if (!this.commonService.isValidStringValue(this.VoucherArray.value[index].CCCode))
        //     return;

        // this.http.Get(urlConstant.Voucher.GetCostCenterLookup(this.VoucherArray.value[index].CCCode)).subscribe(response => {
        //     let ccCodeName = response.Data[0];
        //     if (!isNullOrUndefined(ccCodeName)) {
        //         this.voucherControl(index).CCDesc.setValue(ccCodeName.Name);
        //         // this.addVoucher(1);
        //     }
        // })

        let code = ""; let name = "";

        if (!isNullOrUndefined(cc)) {
            code = cc.Code; name = cc.Name;
        }

        this.voucherControl(index).CCCode.setValue(code);
        this.voucherControl(index).CCDesc.setValue(name);
    }

    addVoucher(count: number = 1, newVoucher?: any) {
        let vouchers = this.voucherList.data;
        for (let i = 0; i < count; i++) {
            this.VoucherArray.push(this.initVoucher(newVoucher));
            vouchers.push({});
        }

        this.voucherList = new MatTableDataSource(vouchers);
    }

    //cancel button click method
    cancel() {
        this.router.navigate(['/financial-account/voucher/' + this.docType]);
    }

    // method get all form control values
    clearForm() {
        window.location.reload();
    }

    saveVoucher() {
        if (!this.validateData()) return;


        this.commonService.confirmAction(this.voucherTypeName, "Do you want to save the voucher?")
            .subscribe(response => {
                if (response) {
                    this.loader.spin.next(true);
                    let formValue = this.bankVoucherForm.getRawValue()
                    formValue.VoucherDate = this.commonService.convertDateToString(formValue.VoucherDate);
                    formValue.ChequeDate = this.commonService.convertDateToString(formValue.ChequeDate);
                    formValue.VoucherDetails = formValue.VoucherDetails.filter(f => this.commonService.isValidStringValue(f.AcCode));
                    formValue.DocType = this.docType;
                    formValue.VoucherType = !this.isBankVoucher ? "JV" : formValue.VoucherType;
                    let isExisting = this.commonService.isValidStringValue(this.f.VoucherDocNo.value);
                    let url = isExisting ? urlConstant.Voucher.UpdateVoucher : urlConstant.Voucher.SaveVoucher;
                    this.http.Post(url, formValue).subscribe(resp => {
                        if (resp.Status === 200) {
                            if (isExisting) {
                                this.commonService.displayPromptMessage(this.voucherTypeName, "Voucher updated successfully").subscribe(s => {
                                    this.cancel();
                                });
                            }
                            else {
                                this.commonService.displayPromptMessage(this.voucherTypeName, "Voucher saved successfully").subscribe(s => {
                                    window.location.reload();
                                });
                            }
                        }
                    });
                }
            });
    }

    validateData(): boolean {
        if (!this.commonService.isValidStringValue(this.f.VoucherType.value) && this.isBankVoucher) {
            this.commonService.displayPromptMessage(this.voucherTypeName, "Voucher Type cannot be blank");
            this.VoucherType.focus();
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.VoucherNo.value)) {
            this.commonService.displayPromptMessage(this.voucherTypeName, "Voucher number cannot be blank");
            this.VoucherNo.nativeElement.focus();
            return false;
        }

        if (this.f.VoucherNo.value.trim().length > 30) {
            this.commonService.displayPromptMessage(this.voucherTypeName, "Voucher Number cannot be greater than 30 characters!");
            this.VoucherNo.nativeElement.focus();
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.BankAcCodeName.value) && this.action === 'new' && this.isBankVoucher) {
            this.commonService.displayPromptMessage(this.voucherTypeName, "Bank account code cannot be blank");
            return false;
        }

        if (this.f.BankAcCodeName.value === "1-06-206") {
            if (!this.commonService.isValidStringValue(this.f.Narration.value)) {
                this.commonService.displayPromptMessage(this.voucherTypeName, "Narration cannot be blank.");
                this.Narration.nativeElement.focus();
                return false;
            }
        }

        if (this.commonService.isValidStringValue(this.f.Narration.value) && this.f.Narration.value.trim().length > 40) {
            this.commonService.displayPromptMessage(this.voucherTypeName, "Narration cannot be greater than 40 characters!");
            this.Narration.nativeElement.focus();
            return false;
        }

        if (this.commonService.isValidStringValue(this.f.ChequeNo.value) && this.f.ChequeNo.value.trim().length > 25) {
            this.commonService.displayPromptMessage(this.voucherTypeName, "Cheque Number cannot be greater than 25 characters!");
            return false;
        }


        if (parseFloat(this.f.TotalDebitAmount.value) === 0 && parseFloat(this.f.TotalCreditAmount.value) === 0) {
            this.commonService.displayPromptMessage(this.voucherTypeName, "Add some credit debit data before saving.");
            return false;
        }

        if (this.f.TotalDebitAmount.value != this.f.TotalCreditAmount.value) {
            this.commonService.displayPromptMessage(this.voucherTypeName, "Debit and Credit Amount are not equal.");
            return false;
        }

        for (let i = 0; i < this.VoucherArray.length; i++) {

            let currentVoucher = this.VoucherArray.value[i];
            if (this.commonService.isValidStringValue(currentVoucher.AcCode)) {
                if (parseFloat(currentVoucher.DebitAmount) === 0 && parseFloat(currentVoucher.CreditAmount) === 0) {
                    this.commonService.displayPromptMessage(this.voucherTypeName, "No Debit/Credit Amount given for record.");
                    return false;
                }

                if ((currentVoucher.AcCode.startsWith("1") || currentVoucher.AcCode.startsWith("2") || currentVoucher.AcCode.startsWith("3") || currentVoucher.AcCode.startsWith("4"))
                    && !this.commonService.isValidStringValue(currentVoucher.CCCode)) {
                    this.commonService.displayPromptMessage(this.voucherTypeName, "Cost centre code is required for account " + currentVoucher.AcCode);
                    return false;
                }
            }
        }

        return true;
    }

    // To highlight selected row
    highlightSelectedRow(index, rowDetails) {
        this.selectedRowData = rowDetails;

        if (this.selectedRowIndex == index) {
            this.selectedRowIndex = -1;
            this.selectedRowData = null;
        } else {
            this.selectedRowIndex = index;
        }

    }

    checkDebitAmount(index: number) {

        if (parseFloat(this.voucherControl(index).CreditAmount.value) > 0) {
            this.voucherControl(index).DebitAmount.setValue("0.00");
            this.commonService.displayPromptMessage(this.voucherTypeName, "Already entered credit amount for the record!");
            return;
        }
        this.voucherControl(index).DebitAmount.setValue(parseFloat(this.voucherControl(index).DebitAmount.value).toFixed(2));
        this.calculateTotalDebit();
        this.voucherControl(index).DrOrCr.setValue("D");
        this.addVoucher(1);
    }

    checkCreditAmount(index: number) {
        if (parseFloat(this.voucherControl(index).DebitAmount.value) > 0) {
            this.voucherControl(index).CreditAmount.setValue(parseFloat(this.voucherControl(index).CreditAmount.value).toFixed(2));
            this.commonService.displayPromptMessage(this.voucherTypeName, "Already entered debit amount for the record!");
            return;
        }
        this.voucherControl(index).CreditAmount.setValue(parseFloat(this.voucherControl(index).CreditAmount.value).toFixed(2));
        this.calculateTotalCredit();
        this.voucherControl(index).DrOrCr.setValue("C");
        this.addVoucher(1);
    }

    calculateTotalDebit() {
        this.f.TotalDebitAmount.setValue(this.f.VoucherDetails.value.filter(v => this.commonService.isValidStringValue(v.AcCode))
            .map(v => parseFloat(v.DebitAmount))
            .reduce((accumulator, currentValue) => accumulator + currentValue, 0));
    }

    calculateTotalCredit() {
        this.f.TotalCreditAmount.setValue(this.f.VoucherDetails.value.filter(v => this.commonService.isValidStringValue(v.AcCode))
            .map(v => parseFloat(v.CreditAmount))
            .reduce((accumulator, currentValue) => accumulator + currentValue, 0));
    }


    generateVoucherNumber(event: any) {

        if (event.checked) {
            this.f.BankAcCodeName.setValue(this.accountCode);
            this.f.BankAccName.setValue(this.accountName);
            this.accountMaster.inputValue.setValue(`${this.accountCode} ${this.accountName}`);
            this.isNarrationRequired = true;
        }

        else {
            this.f.BankAcCodeName.setValue('');
            this.f.BankAccName.setValue('');
            this.accountMaster.inputValue.setValue('');
            this.isNarrationRequired = false;
        }
    }

    checkVoucherNumber(event: any) {
        this.http.Get(urlConstant.Voucher.CheckVoucherNumber(this.f.VoucherNo.value, this.docType))
            .subscribe(response => {
                if (response.Data) {
                    this.commonService.displayPromptMessage(this.voucherTypeName, "Voucher number already exists !");
                    this.f.VoucherNo.setValue("");
                    return;
                }
            });
    }

    getSubAcCodeName(index: number, account: any) {
        let code = ""; let name = "";

        if (!isNullOrUndefined(account)) {
            code = account.Code; name = account.Name;
        }

        this.voucherControl(index).SubAcCode.setValue(code);
        this.voucherControl(index).SubAcName.setValue(name);
    }

    getVoucherTemplate() {

        let accountCode = "";
        let type = this.isBankVoucher ? "B" : "J";
        // if (this.isBankVoucher && !this.commonService.isValidStringValue(this.f.BankAcCodeName.value))
        //     this.f.VoucherNo.setValue("");

        this.http.Get(urlConstant.Voucher.GetTemplate(accountCode, type))
            .subscribe(resp => {
                if (resp && resp.Data)
                    this.f.VoucherNo.setValue(resp.Data + "XXXX");
                else {
                    this.f.VoucherNo.setValue("");
                    this.commonService.displayPromptMessage(this.voucherTypeName, "Voucher number series not present. Please add one");
                }
            });
    }

}
