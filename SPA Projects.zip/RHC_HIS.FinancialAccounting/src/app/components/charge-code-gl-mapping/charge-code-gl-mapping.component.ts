import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MatSort, MatTableDataSource } from '@angular/material';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { CommonService } from 'src/app/services/common.service';
import { isNullOrUndefined } from 'util';
import { urlConstant } from 'src/app/constants/urlConstants';
import { ChargeCodeGLMappingActionDialog } from './charge-code-gl-mapping-action.component';

@Component({
    selector: 'charge-code-gl-mapping',
    templateUrl: 'charge-code-gl-mapping.component.html',
    styleUrls: ['./charge-code-gl-mapping.component.css'],
    host: { 'class': 'section__main' }
})
export class ChargeCodeGLMapping {
    @ViewChild(MatSort) sort: MatSort;
    selectedRowData: any;
    selectedRowIndex: number = -1;
    chargeCodeGlMappingList: MatTableDataSource<any> = new MatTableDataSource();
    displayedColumns = ['SrNo', 'ChargeCode', 'ChargeCodeDescription', 'GLAccountCode', 'GLAccountDescription', 'CostCentreCode', 'CostCentreDescription', 'ModifiedBy', 'EditDate', 'Remarks'];
    constructor(@Inject(MAT_DIALOG_DATA) public data: any,
        private dialog: MatDialog,
        private formBuilder: FormBuilder,
        private activateroute: ActivatedRoute,
        private http: HttpService,
        private loader: LoaderService,
        private commonService: CommonService) { }

    ngOnInit() {
        this.getChargeCodeGLMappingList();
    }

    //method to load all charge code  list 
    getChargeCodeGLMappingList() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.ChargeCodeGLMapping.GetChargeCodeGLMappingList()).subscribe(response => {
            if (response.Status === 200) {
                this.chargeCodeGlMappingList = new MatTableDataSource(response.Data);
                this.chargeCodeGlMappingList.sort = this.sort;
            }
            this.loader.spin.next(false);
        })

    }

    // filters the table 
    public filterList = (value: string) => {
        this.chargeCodeGlMappingList.filter = value.trim().toLocaleLowerCase();
    }

    // Method for export to excel
    exportToExcel() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.ChargeCodeGLMapping.ExportToExcel()).subscribe(response => {
            if (response.Status === 200 && !isNullOrUndefined(response.Data)) {
                this.http.openFile(response.Data);
            }
            else {
                this.commonService.openSnackBar("Error in export to excel", "Ok");
            }
            this.loader.spin.next(false);
        });
    }

    // Method to open deactivate modal
    openDiactivateModal(action: string) {
        if (!this.validateData(action)) return;
        this.commonService.deactivateAction("Deactivate Cost Centre Code", `Reason For Deactivate ${this.selectedRowData.ChargeCode}`, "").subscribe(response => {
            if (response.Status) {
                this.selectedRowData.Remarks = response.Remarks;
                this.selectedRowData.UserId = localStorage.getItem("UserName");
                this.commonService.confirmAction("Deactivate Charge Code", `Do you want to deactivate ${this.selectedRowData.ChargeCode} Charge Code ?`).subscribe(response => {
                    if (response) {
                        this.loader.spin.next(true);
                        this.http.Post(urlConstant.ChargeCodeGLMapping.DeactivateChargeCodeGLMapping(), this.selectedRowData).subscribe(response => {
                            if (response.Data) {
                                this.commonService.displayPromptMessage("Deactivate Charge Code", `${this.selectedRowData.ChargeCode} deactivated successfully!`).subscribe(() => {
                                    window.location.reload();
                                    //this.getChargeCodeGLMappingList();
                                })
                            }
                            else {
                                this.loader.spin.next(false);
                                this.commonService.openSnackBar("Deactivation failed!", "Ok");
                            }
                        })
                    }
                })
            }
        });

    }

    // Method to open action modal(edit/new)
    openActionModal(action: string) {
        if (!this.validateData(action)) return;
        const dialogRef = this.dialog.open(ChargeCodeGLMappingActionDialog);
        dialogRef.componentInstance.action = action;
        dialogRef.componentInstance.rowdetails = this.selectedRowData;

    }

    // Validations
    validateData(action: string): boolean {
        if (action === 'edit' || action === 'deactivate') {
            if (isNullOrUndefined(this.selectedRowData)) {
                this.commonService.openSnackBar(`Please select row first`, "Ok");
                return false;
            }
        }

        if (action === 'edit' || action === 'deactivate') {
            if (this.selectedRowData.Status === 'C') {
                this.commonService.openSnackBar("Charge Code is deactivate", "Ok");
                return false;
            }
        }

        return true;
    }

    // To highlight selected row
    highlightSelectedRow(index, rowDetails) {
        this.selectedRowData = rowDetails;

        if (this.selectedRowIndex == index) {
            this.selectedRowIndex = -1;
            this.selectedRowData = null;
        } else {
            this.selectedRowIndex = index;
        }
    }

}