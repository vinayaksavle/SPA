import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { pipe } from 'rxjs';
import { isNullOrUndefined } from 'util';
import { AcMasterLibComponent } from 'ac-master-lib';
import { CostCentreLibComponent } from 'cost-centre-lib';

@Component({
    selector: 'charge-code-gl-mapping-action-modal',
    templateUrl: 'charge-code-gl-mapping-action.component.html',
    styleUrls: ['./charge-code-gl-mapping.component.css'],
})
export class ChargeCodeGLMappingActionDialog {
    @ViewChild('acCodeName') acCodeName: AcMasterLibComponent;
    @ViewChild('ccCodeName') ccCodeName: CostCentreLibComponent;

    action: string;
    rowdetails: any;
    chargeCodeGlMappingForm: FormGroup;

    constructor(private dialogRef: MatDialogRef<ChargeCodeGLMappingActionDialog>, private http: HttpService, private commonService: CommonService, private fb: FormBuilder, private loader: LoaderService) { }

    ngOnInit() {
        this.initForm();
        // setting values using library
        if (this.action === 'new') {
            this.acCodeName.inputValue.setValue('');
            this.ccCodeName.inputValue.setValue('');
        }
        else {
            this.acCodeName.inputValue.setValue(this.rowdetails.GLAccountCode + ' ' + this.rowdetails.GLAccountDescription);
            this.ccCodeName.inputValue.setValue(this.rowdetails.CostCentreCode + ' ' + this.rowdetails.CostCentreDescription);
        }
    }


    initForm() {
        this.chargeCodeGlMappingForm = this.fb.group({
            ChargeCode: [{ value: this.action === 'edit' ? this.rowdetails.ChargeCode : '', disabled: this.action === 'edit' ? true : false }, Validators.compose([
                Validators.required, Validators.maxLength(2)
            ])],
            ChargeCodeDescription: [this.action === 'edit' ? this.rowdetails.ChargeCodeDescription : '', Validators.compose([
                Validators.required, Validators.maxLength(20)
            ])],
            UserId: [localStorage.getItem("UserName")],
            AcCode: [this.action === 'edit' ? this.rowdetails.GLAccountCode : '', Validators.required],
            CcCode: [this.action === 'edit' ? this.rowdetails.CostCentreCode : '', Validators.required]
        });
    }

    // method get all form control values
    get f() { return this.chargeCodeGlMappingForm.controls; }

    // set Account Code
    setAcCodeName(event: any) {
        if (!isNullOrUndefined(event))
            this.f.AcCode.setValue(event.Code);
        else
            this.f.AcCode.setValue('');
    }

    // set Cost Centre Code
    setCCCodeName(event: any) {
        if (!isNullOrUndefined(event))
            this.f.CcCode.setValue(event.Code);
        else
            this.f.CcCode.setValue('');
    }

    // Save or Edit Charge Centre Code
    saveEditChargeCode() {
        if (!this.validateData()) return;

        const inputParam = this.chargeCodeGlMappingForm.getRawValue();

        if (this.action === 'edit') {
            this.commonService.confirmAction("Edit Cost Centre Code", `Do you want to update ${inputParam.ChargeCode} Charge code ?`).subscribe(response => {
                if (response) {
                    this.loader.spin.next(true);
                    this.http.Post(urlConstant.ChargeCodeGLMapping.UpdateChargeCodeGL(), inputParam).subscribe(response => {
                        if (response.Data) {
                            this.commonService.displayPromptMessage("Edit Charge Code", `${inputParam.ChargeCode} code updated successfully!`).subscribe(response => {
                                window.location.reload();
                            });
                        }
                        else {
                            this.loader.spin.next(false);
                            this.commonService.openSnackBar("Record with same Description already exists!", "Ok");
                        }
                    })
                }
                else {
                    this.cancel();
                }
            })
        }
        // if the action is new
        else {
            this.commonService.confirmAction("New Charge Code", `Do you want to save ${inputParam.ChargeCode} Charge Code ?`).subscribe(response => {
                if (response) {
                    this.loader.spin.next(true);
                    this.http.Post(urlConstant.ChargeCodeGLMapping.InsetNewChargeCodeGL(), inputParam).subscribe(response => {
                        if (response.Data) {
                            this.commonService.displayPromptMessage("New Charge Code", `${inputParam.ChargeCode} code created successfully!`).subscribe(response => {
                                window.location.reload();
                            });
                        }
                        else {
                            this.loader.spin.next(false);
                            this.commonService.displayPromptMessage("New Charge Code", "Record with same Charge Code/Description already exists!");
                        }
                    })
                }
                else {
                    this.cancel();
                }
            })
        }
    }

    // Validations
    validateData(): boolean {
        if (!this.commonService.isValidStringValue(this.f.ChargeCode.value)) {
            this.commonService.openSnackBar("Charge Code should not be empty", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.ChargeCodeDescription.value)) {
            this.commonService.openSnackBar("Charge Code Description should not be empty", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.AcCode.value)) {
            this.commonService.openSnackBar("GL Ac Code is not valid", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.CcCode.value)) {
            this.commonService.openSnackBar("Cost Centre code is not valid", "Ok");
            return false;
        }

        if (this.f.ChargeCode.value.length > 2) {
            this.commonService.openSnackBar("Charge Code length should not be greater than 2", "Ok");
            return false;
        }

        if (this.f.ChargeCodeDescription.value.length > 20) {
            this.commonService.openSnackBar("Charge Code Description length should not be greater than 20", "Ok");
            return false;
        }

        return true;
    }

    // method for closing dialog
    cancel() {
        this.dialogRef.close();
    }
}