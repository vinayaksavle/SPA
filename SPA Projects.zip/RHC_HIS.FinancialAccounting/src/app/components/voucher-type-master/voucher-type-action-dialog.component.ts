import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
  selector: 'app-voucher-type-action-dialog',
  templateUrl: './voucher-type-action-dialog.component.html',
  styleUrls: ['./voucher-type-master.component.css']
})
export class VoucherTypeActionDialogComponent implements OnInit {

  action: string;
  rowdetails: any;
  voucherTypeForm: FormGroup;

  constructor(private dialogRef: MatDialogRef<VoucherTypeActionDialogComponent>, private http: HttpService, private commonService: CommonService, private fb: FormBuilder, private loader: LoaderService) { }

  ngOnInit() {
    this.initForm();
    if (this.action == 'edit') {
      this.setFormData();
    } else {
      return;
    }
  }
  
  // Method to initialize Form.
  initForm(){
    this.voucherTypeForm=this.fb.group({
      VoucherType:['', [Validators.required, Validators.maxLength(2)]],
      Description:['', [Validators.required, Validators.maxLength(20)]],
      VoucherNature:['D',Validators.required],
      UserId:[localStorage.getItem("UserName")]
    });
  }

   // Function to return form controls
   get f() {
    return this.voucherTypeForm.controls;
  }

  // Function to set Form Values.
  setFormData() {
    this.voucherTypeForm.patchValue({
      'VoucherType':this.rowdetails.VoucherType,
      'Description':this.rowdetails.Description,
      'VoucherNature':this.rowdetails.VoucherNature=='DEBIT' ? 'D' : 'C'
    });
    this.f.VoucherType.disable();
  }

  // Method to post voucher type details
  saveVoucherTypeDetails() {
    let obj = this.voucherTypeForm.getRawValue();
    console.log(obj);
    if (!this.validateForm(obj)) {
      return;
    } else {
      // url configuration according to action
      let url: string;
      url = this.action == 'new' ? urlConstant.VoucherTypeMaster.SaveVoucherTypeDetailsUrl : urlConstant.VoucherTypeMaster.UpdateVoucherTypeDetailsUrl

      this.commonService.confirmAction("Confirmation", "Do you want to save this Voucher Type?").subscribe(
        response => {
          if (response) {
            this.loader.spin.next(true);
            this.http.Post(url, obj).subscribe(
              res => {
                if (res.Status == 200 && res.Data) {
                  this.loader.spin.next(false);
                  this.commonService.displayPromptMessage(`${this.action == 'new' ? 'New' : 'Edit'} Voucher Type`, "Details saved successfully!");
                  window.location.reload();
                  this.initForm();
                } else {
                  this.loader.spin.next(false);
                  this.commonService.displayPromptMessage("Error", "Duplicate Voucher Type or Description");
                }
              });
          } else {
            return;
          }
        });
    }
  }

  // Function to validate Form Data.
  validateForm(obj: any): boolean {
    if (this.voucherTypeForm.invalid) {
      const controls = this.voucherTypeForm.controls;
      for (const name in controls) {
        if (controls[name].invalid) {
          if (
            name === "VoucherType" ||
            name === "Description" ||
            name === "VoucherNature" 
          ) {
            (<any>this.f[name]).nativeElement.focus();
            this.commonService.openSnackBar(name + " is invalid", "Ok");
            return false;
          }
        }
      }
    } else {
      return true;
    }
  }

  // method for closing dialog
  cancel() {
    this.dialogRef.close();
  }

}
