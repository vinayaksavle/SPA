import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatSort, MatTableDataSource } from '@angular/material';
import { Router } from '@angular/router';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';
import { VoucherTypeActionDialogComponent } from './voucher-type-action-dialog.component';

@Component({
  selector: 'app-voucher-type-master',
  templateUrl: './voucher-type-master.component.html',
  styleUrls: ['./voucher-type-master.component.css'],
  host: { 'class': 'section__main' }
})
export class VoucherTypeMasterComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  selectedRowData: any;
  selectedRowIndex: number = -1;
  voucherTypeList: MatTableDataSource<any> = new MatTableDataSource();

  displayedColumns = ["SrNo", "VoucherType", "Description", "VoucherNature", "Status", "LastUpdatedBy", "LastUpdatedDateTime", "DeactivatedRemarks"];

  constructor(private http: HttpService, private loader: LoaderService, private commonService: CommonService,
    private router: Router,private dialog:MatDialog) { }

  ngOnInit() {
    this.getVoucherTypesList();
  }

  // Get the initial list of voucher types
  getVoucherTypesList() {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.VoucherTypeMaster.GetVoucherTypeListUrl).subscribe(res => {
      if (res.Status == 200 && res.Data.length > 0) {
        this.voucherTypeList = new MatTableDataSource(res.Data);
        this.voucherTypeList.sort = this.sort;
        this.loader.spin.next(false);
      }
      else {
        this.loader.spin.next(false);
        this.commonService.displayPromptMessage("Error", "No record found");
      }
    }, (error) => {
      console.log(error);
    })
  }

  // filters the table 
  public filterList = (value: string) => {
    this.voucherTypeList.filter = value.trim().toLocaleLowerCase();
  }

  // To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }

  // export to excel
  exportToExcel() {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.VoucherTypeMaster.ExportToExcelUrl).subscribe(res => {
      if (res.Status == 200 && res.Data.length > 0) {
        this.http.openFile(res.Data);
        this.loader.spin.next(false);
      }
      else {
        this.loader.spin.next(false);
        this.commonService.displayPromptMessage("Error", "No record found");
      }
    }, (error) => {
      console.log(error);
    })
  }

  // Method to open dialog modal(edit/new)
  openActionModal(action: string) {
    if (!this.validateData(action)) return;
    const dialogRef = this.dialog.open(VoucherTypeActionDialogComponent);
    dialogRef.componentInstance.action = action;
    dialogRef.componentInstance.rowdetails = this.selectedRowData;
    dialogRef.updateSize("800px","300px")
  }

  // Method to open deactivate modal
  openDeactivateModal(action: string) {
    if (!this.validateData(action)) return;

    this.commonService.deactivateAction("Deactivate Voucher Type", `Reason For Deactivate ${this.selectedRowData.VoucherType}`, "").subscribe(response => {
      if (response.Status) {
        this.selectedRowData.DeactivatedRemarks = response.Remarks;
        this.selectedRowData.UserId = localStorage.getItem("UserName");
        this.commonService.confirmAction("Deactivate Voucher Type", `Do you want to deactivate ${this.selectedRowData.VoucherType} Voucher Type?`).subscribe(response => {
          if (response) {
            this.loader.spin.next(true);
            this.http.Post(urlConstant.VoucherTypeMaster.DeactivateVoucherTypeUrl, this.selectedRowData).subscribe(response => {
              if (response.Data) {
                this.commonService.displayPromptMessage("Deactivate Department GL Mapping ", `${this.selectedRowData.VoucherType} deactivated successfully!`).subscribe(() => {
                  window.location.reload();
                })
              }
              else {
                this.loader.spin.next(false);
                this.commonService.openSnackBar("Deactivation failed!", "Ok");
              }
            })
          }
        })
      }
    });

  }

  // Method to Validate actions on row select
  validateData(action: string): boolean {
    if (action === 'edit' || action === 'deactivate') {
      if (isNullOrUndefined(this.selectedRowData)) {
        this.commonService.openSnackBar(`Please select row first`, "Ok");
        return false;
      }
    }
    if (action === 'edit' || action === 'deactivate') {
      if (this.selectedRowData.Status === 'C') {
        this.commonService.openSnackBar("Department Code GL Mapping is already deactivated", "Ok");
        return false;
      }
    }
    return true;
  }

}
