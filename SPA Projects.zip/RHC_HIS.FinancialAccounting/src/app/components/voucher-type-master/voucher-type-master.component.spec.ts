import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VoucherTypeMasterComponent } from './voucher-type-master.component';

describe('VoucherTypeMasterComponent', () => {
  let component: VoucherTypeMasterComponent;
  let fixture: ComponentFixture<VoucherTypeMasterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VoucherTypeMasterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VoucherTypeMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
