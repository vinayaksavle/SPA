import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { FromDateToDateComponent } from 'from-date-to-date';
import { ParseDate } from 'shared-utility';
import { urlConstant } from 'src/app/constants/urlConstants';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-unposted-transactions',
  templateUrl: './unposted-transactions.component.html',
  styleUrls: ['./unposted-transactions.component.css'],
  host: { 'class': 'section__main' }
})
export class UnpostedTransactionsComponent implements OnInit {
  @ViewChild('dates') dates: FromDateToDateComponent;
  totalAmount: number = 0.00;
  TransactionsType: FormControl;
  transactionsTypeList: any = [{ value: 'SP', viewValue: 'SUPPLIER PAYMENTS' },
  { value: 'NGB', viewValue: 'NON GRN BILLS' }, { value: 'CCP', viewValue: 'CASH COUNTER RECEIPTS' },
  { value: 'CP', viewValue: 'CASH COUNTER PAYMENTS' }, { value: 'BV', viewValue: 'BANK/CASH VOUCHERS' },
  { value: 'PG', viewValue: 'PHARMACY GRN`S' }, { value: 'MG', viewValue: 'MMS GRN`s' }];
  displayedColumns: any = ['SerialNo', 'VoucherNo', 'VoucherDate', 'Amount'];
  listOfTransactions: MatTableDataSource<any>;

  constructor(private http: HttpService, private loader: LoaderService) { }

  ngOnInit() {
    this.init();
  }

  init(date?) {
    if (date) {
      date.FromDate.setValue(new Date());
      date.ToDate.setValue(new Date());
    }
    this.TransactionsType = new FormControl('SP');
    this.getDate();
    this.totalAmount = 0.00;
  }

  getDate() {
    this.loader.spin.next(true);
    this.listOfTransactions = new MatTableDataSource();
    this.http.Get(urlConstant.reports.GetUnpostedData(new ParseDate().transform(this.dates.FromDate.value), new ParseDate().transform(this.dates.ToDate.value), this.TransactionsType.value)).subscribe(result => {
      if (result.Status === 200 && result.Data.length > 0) {
        this.listOfTransactions = new MatTableDataSource(result.Data);
        this.totalAmount = result.Data.filter((d) => d.VoucherNo).map((d) => !isNullOrUndefined(d.Amount) ? parseFloat(d.Amount) : 0).reduce((prev, curr) => prev + curr, 0).toFixed(2);
        this.loader.spin.next(false);
      } else {
        this.listOfTransactions = new MatTableDataSource([]);
        this.totalAmount = 0;
        this.loader.spin.next(false);
      }
    });
  }
}