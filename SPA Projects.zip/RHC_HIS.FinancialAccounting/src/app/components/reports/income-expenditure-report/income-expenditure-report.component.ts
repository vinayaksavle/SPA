import { Component, OnInit, ViewChild, Inject, ChangeDetectorRef } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { isNullOrUndefined } from 'util';
import { ParseDate } from 'shared-utility';

@Component({
    selector: 'app-income-expenditure-report',
    templateUrl: 'income-expenditure-report.component.html',
    styleUrls: ['./income-expenditure-report.component.css'],
    host: { 'class': 'section__main' },
})

export class IncomeExpenditureReport {
    @ViewChild(MatSort) sort: MatSort;
    selectedRowData: any;
    selectedRowIndex: number = -1;
    filteredData: MatTableDataSource<any> = new MatTableDataSource();
    action: string;
    rowdetails: any;
    incomeExpForm: FormGroup;

    ViewType = [
        { value: 'detail', viewValue: 'DETAIL' },
        { value: 'maingroup', viewValue: 'MAIN GROUP' },
        { value: 'subgroup', viewValue: 'SUB GROUP' },
    ];

    ReportType = [
        { value: 'yop', viewValue: 'YOP' },
        { value: 'ondate', viewValue: 'AS ON DATE' },
        { value: 'onmonth', viewValue: 'AS ON MONTH' },
        { value: 'period', viewValue: 'FOR A PERIOD' },
    ];

    displayedColumns = ["SrNo", "Action", "AccountCode", "AccountName", "Expenditure", "Income"];

    secondcolumn = ["SrNo", "Action", "AccountCode", "AccountName", "Expenditure", "Income"];

    thirdColumn = ["SrNo", "Action", "AccountCode", "AccountName", "Expenditure", "Income"];

    expandedElement;
    subExpandedElement;

    constructor(private http: HttpService, private commonService: CommonService,
        private fb: FormBuilder, private loader: LoaderService,
        private activateRoute: ActivatedRoute, private router: Router, private cd: ChangeDetectorRef) { }

    ngOnInit() {
        this.initForm();
    }

    //method to initialize seatrch form
    initForm() {
        this.incomeExpForm = this.fb.group({
            FromDate: [new Date(), Validators.required],
            ToDate: [new Date(), Validators.required],
            View: [Validators.required],
            ReportType: [],
            Month: [],
            Year: [],
        })
    }

    //method to set date
    selectFromToDate(event) {
        console.log(event);
        if (!isNullOrUndefined(event)) {
            this.f.FromDate.setValue(new Date(event.FromDate.value));
            this.f.ToDate.setValue(new Date(event.ToDate.value));
        }

    }


    // method for search results
    searchResults() {
        console.log(this.incomeExpForm.value);
        this.loader.spin.next(true);
        console.log(this.incomeExpForm.value.ReportType)
        console.log(this.incomeExpForm.value.Year)
        console.log(this.incomeExpForm.value.
            Month)
        this.http.Get(urlConstant.reports.GetIncomeExpenditure(new ParseDate().transform(this.incomeExpForm.value.FromDate), new ParseDate().transform(this.incomeExpForm.value.ToDate), this.incomeExpForm.value.View, this.incomeExpForm.value.ReportType, this.incomeExpForm.value.
            Month, this.incomeExpForm.value.Year)).subscribe(response => {
                if (response.Status === 200) {
                    console.log(response);
                    this.filteredData = new MatTableDataSource(response.Data);
                    this.loader.spin.next(false);
                } else {
                    this.loader.spin.next(false);
                }
            })

    }

    // method fod export to Excel
    exportToExcel() {
    }

    // method fod export to pdf
    exportToPdf() {

    }

    // method get all form control values
    get f() { return this.incomeExpForm.controls; }

    // method get expanding nested table
    expandRow() {

    }

    //method to clear form
    clear() {

    }

    // method to get sublist
    getSubDetails(element) {

        // this code is temporary , added to check nested tree.
        // this code needs to be changed, api calls needs to be added
        element.MainAccounts = new MatTableDataSource<any>([{ "key": "value" }]);
        this.expandedElement = this.expandedElement === element ? null : element;
        console.log(element.MainAccount);

        element.MainAccounts.data[0].SubAccounts = new MatTableDataSource<any>([1]);
        // this.subExpandedElement = this.subExpandedElement === element ? null : element;

        element.IsOpen = !element.IsOpen;
        this.cd.detectChanges();

    }

    // method to toggle list and sublist
    getSubGroup(element) {
        element.IsOpen = !element.IsOpen;
    }

}