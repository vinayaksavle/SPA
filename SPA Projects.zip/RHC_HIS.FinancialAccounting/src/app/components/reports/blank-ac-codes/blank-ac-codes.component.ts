import { ParseDate } from 'shared-utility';
import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { isNullOrUndefined } from 'util';

@Component({
    selector: 'app-blank-ac-codes',
    templateUrl: './blank-ac-codes.component.html',
    styleUrls: ['./blank-ac-codes.component.css'],
    host: { 'class': 'section__main' }
})



export class BlankAcCodesComponent {
    @ViewChild(MatSort) sort: MatSort;

    blankAccCodesList: MatTableDataSource<any> = new MatTableDataSource();
    ControlAcTransForm: FormGroup;

    displayedColumns = ["SrNo", "VoucherNo", "VoucherDate", "VoucherType", "Amount"];

    constructor(private http: HttpService, private commonService: CommonService,
        private fb: FormBuilder, private loader: LoaderService,) { }

    ngOnInit() {
        this.init();
    }

    //method to initialize search form
    init() {
        this.ControlAcTransForm = this.fb.group({
            FromDate: [new Date()],
            ToDate: [new Date()]
        })
        this.getBlankAcCodeList();
    }


    //method to set date
    setFromToDate(event: any) {
        if (!isNullOrUndefined(event)) {
            this.f.FromDate.setValue(new Date(event.FromDate.value));
            this.f.ToDate.setValue(new Date(event.ToDate.value));
        }
    }

    // method to get Blank Account Code list
    getBlankAcCodeList() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.reports.GetBlankAcCodes(new ParseDate().transform(this.f.FromDate.value), new ParseDate().transform(this.f.ToDate.value))).subscribe(response => {
            if (response.Status === 200 && response.Data.length > 0) {
                this.blankAccCodesList = new MatTableDataSource(response.Data);
                this.blankAccCodesList.sort = this.sort;
                this.loader.spin.next(false);
            } else {
                this.loader.spin.next(false);
                this.blankAccCodesList = new MatTableDataSource([]);
            }
        })
    }

    // method for clear method
    clear() { }

    // method for export to Excel
    exportToExcel() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.reports.ExportBlankAcCodesToExcel(new ParseDate().transform(this.f.FromDate.value), new ParseDate().transform(this.f.ToDate.value))).subscribe(response => {
            if (response.Status == 200 && response.Data.length > 0) {
                this.http.openFile(response.Data);
                this.loader.spin.next(false);
            }
            else {
                this.loader.spin.next(false);
            }
        }, (error) => {
            console.log(error);
        })
    }

    // method get all form control values
    get f() { return this.ControlAcTransForm.controls; }


}