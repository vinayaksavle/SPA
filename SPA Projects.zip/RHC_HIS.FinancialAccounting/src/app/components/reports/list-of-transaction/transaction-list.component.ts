import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { ParseDate } from 'shared-utility';
import { FromDateToDateComponent } from 'from-date-to-date';
import { isNullOrUndefined } from 'util';

@Component({
    selector: 'app-transaction-list',
    templateUrl: 'transaction-list.component.html',
    styleUrls: ['./transaction-list.component.css'],
    host: { 'class': 'section__main' }
})

export class ListOfTransaction {
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('fromDateToDateTrans') fromDateToDateTrans: FromDateToDateComponent;
    @ViewChild('fromDateToDateEntry') fromDateToDateEntry: FromDateToDateComponent;
    selectedRowData: any;
    selectedRowIndex: number = -1;
    filteredData: MatTableDataSource<any> = new MatTableDataSource();
    action: string;
    totalCAmount: number = 0.00;
    totalDAmount: number = 0.00;
    rowdetails: any
    GeneralLedgerAcForm: FormGroup;
    VoucherTypes = [
        { value: 'journal', viewValue: 'JOURNAL' },
        { value: 'cashbank', viewValue: 'CASH/BANK' },
        { value: 'both', viewValue: 'BOTH' },
    ];

    VoucherStatus = [
        { value: 'all', viewValue: 'ALL' },
        { value: 'posted', viewValue: 'POSTED' },
        { value: 'unposted', viewValue: 'NOT POSTED' },
    ];
    displayedColumns = ["SrNo", "VoucherType", "VoucherNumber","VoucherDate","AccountDesc","CcCode","DebitAmount","CreditAmount"];
    object: any;

    constructor(private http: HttpService, private commonService: CommonService,
        private fb: FormBuilder, private loader: LoaderService,
        private activateRoute: ActivatedRoute, private router: Router) { }

    ngOnInit() {
        this.initForm();
    }

    
    //method to initialize seatrch form
    initForm() {
        this.GeneralLedgerAcForm = this.fb.group({
            TransactionDate: [true],
            EntryDate: [],
            VoucherType: [],
            status: []
        });
        this.filteredData = new MatTableDataSource();

    }

    // method for search results
    searchResults(){
        if (!this.f.TransactionDate.value && !this.f.EntryDate.value) {
            this.commonService.openSnackBar("Select Date", "Ok");
            return;
        }
        this.loader.spin.next(true);
        this.object = this.GeneralLedgerAcForm.getRawValue();
        this.object.TFromDate = new ParseDate().transform(this.fromDateToDateTrans.FromDate.value);
        this.object.TToDate = new ParseDate().transform(this.fromDateToDateTrans.ToDate.value);
        this.object.EFromDate = new ParseDate().transform(this.fromDateToDateEntry.FromDate.value);
        this.object.EToDate = new ParseDate().transform(this.fromDateToDateEntry.ToDate.value);
        if (this.object.status === "POSTED")
            this.object.VoucherStatus = "P";
        if (this.object.status === "NOTPOSTED")
            this.object.VoucherStatus = "N";
        console.log(this.object);
        this.filteredData = new MatTableDataSource();
        this.http.Post(urlConstant.reports.GetListOfTrans(), this.object).subscribe(response => {
            if (response && response.Status === 200) {
                this.filteredData = new MatTableDataSource(response.Data);
                this.totalCAmount = response.Data[0].CAmountTotal;
                this.totalDAmount = response.Data[0].DAmountTotal;
                this.loader.spin.next(false);
            } else {
                this.loader.spin.next(false);
            }
        })
    }

    // method fod export to Excel
    exportToExcel() {
        this.loader.spin.next(true);
        this.http.Post(urlConstant.reports.ExcelListOfTrans(), this.object).subscribe(response => {
            if (response && response.Status === 200) {
              this.http.openFile(response.Data);
              this.loader.spin.next(false);
            } else {
              this.loader.spin.next(false);
            }
          });
    }

    // method get all form control values
    get f() { return this.GeneralLedgerAcForm.controls; }


}