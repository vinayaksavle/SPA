import { ParseDate } from 'shared-utility';
import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { AcMasterLibComponent } from 'ac-master-lib';
import { FromDateToDateComponent } from 'from-date-to-date';
import { isNullOrUndefined } from 'util';

@Component({
    selector: 'app-control-ac-transaction',
    templateUrl: 'control-ac-transaction.component.html',
    styleUrls: ['./control-ac-transaction.component.css'],
    host: { 'class': 'section__main' }
})

export class ControlACTransaction {
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('acCodeName') acCodeName: AcMasterLibComponent;
    filteredData: MatTableDataSource<any> = new MatTableDataSource();
    ControlAcTransForm: FormGroup;
    displayedColumns = ["SrNo", "VouchrNo", "VouchrDt", "VchrType", "Amount"];

    constructor(private http: HttpService, private commonService: CommonService,
        private fb: FormBuilder, private loader: LoaderService,
        private activateRoute: ActivatedRoute, private router: Router) { }

    ngOnInit() {
        console.log('Testing purpose UAT 1-05-106');
        this.initForm();
    }

    //method to initialize seatrch form
    initForm() {
        this.ControlAcTransForm = this.fb.group({
            FromDate: [new Date()],
            ToDate: [new Date()],
            AcCode: [''],
        })
    }

    // method get all form control values
    get f() { return this.ControlAcTransForm.controls; }

    //method to set date
    setDate(event) {
        this.f.FromDate.setValue(new Date(event.FromDate.value));
        this.f.ToDate.setValue(new Date(event.ToDate.value));
    }

    //method for setting lookupvalue
    setAcCodeName(event) {
        if (!isNullOrUndefined(event))
            this.f.AcCode.setValue(event.Code);
        else
            this.f.AcCode.setValue('');
    }

    // method for search results
    searchResults() {
        if (this.commonService.isValidStringValue(this.f.AcCode.value)) {
            this.loader.spin.next(true);
            this.http.Get(urlConstant.reports.GetVoucherDetails(this.f.AcCode.value, new ParseDate().transform(this.f.FromDate.value), new ParseDate().transform(this.f.ToDate.value))).subscribe(response => {
                if (response.Status === 200 && response.Data.length > 0) {
                    this.filteredData = new MatTableDataSource(response.Data);
                    this.filteredData.sort = this.sort;
                    this.loader.spin.next(false);
                } else {
                    this.filteredData = new MatTableDataSource([]);
                    this.loader.spin.next(false);
                }
            })
        } else {
            this.loader.spin.next(false);
            this.commonService.displayPromptMessage("Check For Control A/C And Trans.", "Please Enter A/C Code.");
        }
    }

    // method for export to Excel
    exportToExcel() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.reports.ExportToExcel(this.f.AcCode.value, new ParseDate().transform(this.f.FromDate.value), new ParseDate().transform(this.f.ToDate.value))).subscribe(res => {
            if (res.Status == 200 && res.Data.length > 0) {
                this.http.openFile(res.Data);
                this.loader.spin.next(false);
            }
            else {
                this.loader.spin.next(false);
            }
        }, (error) => {
            console.log(error);
        })
    }

    // method for clear method
    clear() {
        this.initForm();
        this.acCodeName.inputValue.setValue("");
    }
}