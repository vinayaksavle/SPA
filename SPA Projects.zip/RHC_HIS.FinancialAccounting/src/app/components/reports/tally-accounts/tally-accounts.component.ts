import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { FromDateToDateComponent } from 'from-date-to-date';
import { ParseDate } from 'shared-utility';

@Component({
    selector: 'app-tally-accounts',
    templateUrl: 'tally-accounts.component.html',
    styleUrls: ['./tally-accounts.component.css'],
    host: { 'class': 'section__main' }
})

export class TallyAccounts {
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('dates') dates: FromDateToDateComponent;
    filteredData: MatTableDataSource<any> = new MatTableDataSource();
    TallyAcForm: FormGroup;
    displayedColumns = ["SrNo", "AccountCode", "DebitAmount", "CreditAmount", "DifferenceAmount"];

    constructor(private http: HttpService, private commonService: CommonService,
        private fb: FormBuilder, private loader: LoaderService,
        private activateRoute: ActivatedRoute, private router: Router) { }

    ngOnInit() {
        this.initForm();
        this.searchResults();
    }

    //method to initialize seatrch form
    initForm() {
        this.TallyAcForm = this.fb.group({
            FromDate: [new Date()],
            ToDate: [new Date()]
        })
    }

    // method get all form control values
    get f() { return this.TallyAcForm.controls; }

    // method for search results
    searchResults() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.reports.GetTallyAccounts(new ParseDate().transform(this.f.FromDate.value), new ParseDate().transform(this.f.ToDate.value))).subscribe(response => {
            if (response.Status === 200 && response.Data.length > 0) {
                console.log(response);
                this.filteredData = new MatTableDataSource(response.Data);
                this.filteredData.sort = this.sort;
                this.loader.spin.next(false);
            } else {
                this.filteredData = new MatTableDataSource([]);
                this.loader.spin.next(false);
            }
        })
    }

    setDate(event) {
        this.f.FromDate.setValue(new Date(event.FromDate.value));
        this.f.ToDate.setValue(new Date(event.ToDate.value));
    }

    // method fod export to Excel
    exportToExcel() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.reports.ExportTallyAccounts(new ParseDate().transform(this.f.FromDate.value), new ParseDate().transform(this.f.ToDate.value))).subscribe(res => {
            if (res.Status == 200 && res.Data.length > 0) {
                this.http.openFile(res.Data);
                this.loader.spin.next(false);
            }
            else {
                this.loader.spin.next(false);
            }
        }, (error) => {
            console.log(error);
        })
    }
}