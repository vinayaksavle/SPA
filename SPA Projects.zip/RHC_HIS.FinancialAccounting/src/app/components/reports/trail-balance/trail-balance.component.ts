import { ChangeDetectorRef, Component, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatSort, MatTable, MatTableDataSource } from '@angular/material';
import { FromDateToDateComponent } from 'from-date-to-date';
import { ParseDate } from 'shared-utility';
import { dataConstant } from '../../../constants/dataConstants';
import { urlConstant } from 'src/app/constants/urlConstants';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { isNull } from '@angular/compiler/src/output/output_ast';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-trail-balance',
  templateUrl: './trail-balance.component.html',
  styleUrls: ['./trail-balance.component.css'],
  host: { 'class': 'section__main' }
})
export class TrailBalanceComponent implements OnInit {

  @ViewChild('dates') dates: FromDateToDateComponent;

  trialBalanceForm: FormGroup;
  public viewList: any = [];
  public reportTypeList: any = [];
  public months: any = [];
  public years: any = [];

  public displayedColumns: any = ['serialNo', 'Action', 'ACCode', 'ACName', 'DebitAmount', 'CreditAmount'];
  public listOfAccount = new MatTableDataSource([]);
  public totalDebit = 0.00;
  public totalCredit = 0.00;

  columns: any[];
  // displayedColumns: string[];
  groupByColumns: string[] = [];
  allData: any[];
  _allGroup: any[];
  currentYear: number;
  currentMonth: string;


  /// dummy data starts here 

  @ViewChild('outerSort') sort: MatSort;
  @ViewChildren('innerSort') innerSort: QueryList<MatSort>;
  @ViewChildren('innerTables') innerTables: QueryList<MatTable<Address>>;

  dataSource: MatTableDataSource<User>;
  usersData = [
    {
      Code: "1-10-201",
      Description: "mason@test.com",
      DebitAmount: "100.00"

    },
    {
      Code: "2-10-201",
      Description: "eugene@test.com",
      DebitAmount: "200.00"
    },
    {
      Code: "3-10-201",
      Description: "jason@test.com",
      DebitAmount: "300.00"
    }
  ];
  columnsToDisplay = ['sno', 'name', 'email', 'phone'];
  secondcolumn = ['serialNo', 'Action', 'ACCode', 'ACName', 'DebitAmount', 'CreditAmount'];
  thirdColumn = ['serialNo', 'Action', 'ACCode', 'ACName', 'DebitAmount', 'CreditAmount'];
  expandedElement: User | null;
  subExpandedElement: User | null;



  constructor(private http: HttpService, private loader: LoaderService, private cd: ChangeDetectorRef, private fb: FormBuilder) {
  }

  get f() {
    return this.trialBalanceForm.controls;
  }


  ngOnInit() {
    this.init();
  }

  init(date?) {

    this.currentYear = new Date().getFullYear();
    this.months = dataConstant.MonthList;
    let month = (new Date().getMonth() + 1).toString();
    this.currentMonth = month.length == 1 ? '0' + month : month;

    this.trialBalanceForm = this.fb.group({
      FromDate: [new Date()],
      ToDate: [new Date()],
      View: 'MG',
      ReportType: 'AOP',
      Year: this.currentYear,
      Month: this.currentMonth
    })


    if (date) {
      date.FromDate.setValue(new Date());
      date.ToDate.setValue(new Date());
    }

    this.getConfigurationData();

    for (var year = this.currentYear; year > 1990; year--)
      this.years.push(year);
  }

  private getConfigurationData() {
    this.http.Get(urlConstant.JSON)
      .subscribe(Response => {
        this.reportTypeList = Response.ReportType;
        this.viewList = Response.View;
      });
  }

  getDataOnPeriod() {
    this.loader.spin.next(true);
    this.listOfAccount = new MatTableDataSource();
    this.http.Get(urlConstant.reports.GetDataOnPeriod(new ParseDate().transform(this.dates.FromDate.value),
      new ParseDate().transform(this.dates.ToDate.value))).subscribe(result => {
        if (result && result.Status === 200) {

          let data = result.Data;
          console.log(data);
          this.listOfAccount = new MatTableDataSource(data);
          let firstRecord = this.listOfAccount.data[0];
          if (!isNullOrUndefined(firstRecord)) {
            this.totalCredit = this.listOfAccount.data[0].TotalCreditAmount;
            this.totalDebit = this.listOfAccount.data[0].TotalDebitAmount;
          }

        }
        this.loader.spin.next(false);
      });

  }

  getDataOnMonth() {
    this.loader.spin.next(true);
    this.listOfAccount = new MatTableDataSource();
    this.http.Get(urlConstant.reports.GetDataAsOnMonth()).subscribe(result => {
      if (result.Status === 200) {
        this.listOfAccount = new MatTableDataSource(result.Data);
        this.loader.spin.next(false);
      } else {
        this.loader.spin.next(false);
      }
    });
  }

  getYOP() {
    this.loader.spin.next(true);
    this.listOfAccount = new MatTableDataSource();
    this.http.Get(urlConstant.reports.GetDataOnYOP('')).subscribe(result => {
      if (result.Status === 200) {
        this.listOfAccount = new MatTableDataSource(result.Data);
        this.loader.spin.next(false);
      } else {
        this.loader.spin.next(false);
      }
    });
  }

  onSubmit() {
    if (this.f.ReportType.value === 'AOP') {
      this.getDataOnPeriod();
    } else if (this.f.ReportType.value === 'AOM') {
      this.getDataOnMonth();
    } else {
      this.getYOP();
    }
  }


  getSubDetails(element) {

    this.http.Get(urlConstant.reports.GetGroups(element.Code))
    .subscribe(response=>{
      if(response.Data)
      {
        element.MainAccounts = new MatTableDataSource<any>(response.Data);
        this.expandedElement = this.expandedElement === element ? null : element;
        if(!isNullOrUndefined(response.Data[0]) && !isNullOrUndefined(response.Data[0].SubAccounts) )
        {
          element.MainAccounts.data[0].SubAccounts = new MatTableDataSource<any>(response.Data[0].SubAccounts);
          // this.subExpandedElement = this.subExpandedElement === element ? null : element;
        }
        element.IsOpen = !element.IsOpen;
         this.cd.detectChanges();

      }
    })

  }

  getSubGroup(element) {
    element.IsOpen = !element.IsOpen;
  }


  applyFilter(filterValue: string) {
    this.innerTables.forEach((table, index) => (table.dataSource as MatTableDataSource<Address>).filter = filterValue.trim().toLowerCase());
  }




}


export interface User {
  name: string;
  email: string;
  phone: string;
  addresses?: Address[] | MatTableDataSource<Address>;
}

export interface Address {
  street: string;
  zipCode: string;
  city: string;
}

export interface UserDataSource {
  name: string;
  email: string;
  phone: string;
  addresses?: MatTableDataSource<Address>;
}



