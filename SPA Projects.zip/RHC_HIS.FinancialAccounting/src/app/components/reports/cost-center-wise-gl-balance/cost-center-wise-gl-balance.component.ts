import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { FromDateToDateComponent } from 'from-date-to-date';
import { from, pipe } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { ParseDate } from 'shared-utility';
import { dataConstant } from 'src/app/constants/dataConstants';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-cost-center-wise-gl-balance',
  templateUrl: './cost-center-wise-gl-balance.component.html',
  styleUrls: ['./cost-center-wise-gl-balance.component.css'],
  host: { 'class': 'section__main' }
})

export class CostCenterWiseGlBalanceComponent implements OnInit {

  @ViewChild('date') date: FromDateToDateComponent;
  public months: any = [];
  public Year: any = '';
  public filteredOptionsCode: any[];
  public displayedColumns: any = ['serialNo', 'ACCode', 'ACName', 'OpeningBal', 'DebitAmount', 'CreditAmount', 'Balance'];
  public glBalanceList: MatTableDataSource<any>;
  public totalDebit = 0.00;
  public totalCredit = 0.00;
  public totalBal = 0.00;
  exclude: string = '0';
  reportType = [
    { value: 'asOnMonth', viewValue: 'AS ON MONTH' },
    { value: 'forAPeriod', viewValue: 'FOR A PERIOD' },
    { value: 'forAMonth', viewValue: 'FOR A MONTH' }
  ];
  costCenterWiseForm: FormGroup;
  fromDate: any;
  toDate: any;
  deficit: any;
  footer: string = '';
  object: any;

  constructor(private http: HttpService, private loader: LoaderService, private fb: FormBuilder,
    private commonService: CommonService) { }

  ngOnInit() {
    this.init();
  }

  init() {
    this.costCenterWiseForm = this.fb.group({
      ReportType: ['forAPeriod'],
      Month: '', Year: '',
      CCCode: [''], Exclude: [false]
    });

    this.setDateOnInit();
    const waitTime = pipe(debounceTime(200));
    const distinct = pipe(distinctUntilChanged());

    this.glBalanceList = new MatTableDataSource();

    this.f.CCCode.valueChanges.pipe(waitTime).pipe(distinct).pipe(switchMap(text =>
      !isNullOrUndefined(text) && text.toString().trim() !== ''
        ? this.http.Get(urlConstant.reports.GetCostCenterCodeName(text.toString())) : this.filteredOptionsCode = []))
      .subscribe(result => {
        this.filteredOptionsCode = result.Data;
      });

    this.f.Exclude.valueChanges.subscribe(result => {
      if (result) {
        this.exclude = '1';
      } else {
        this.exclude = '0';
      }
    })

    this.months = dataConstant.MonthList;
  }

  get f() { return this.costCenterWiseForm.controls }

  setDateOnInit() {
    let FromDate = new Date();
    FromDate.setMonth(3);
    FromDate.setDate(1);

    let ToDate = new Date();
    ToDate.setMonth(2);
    ToDate.setDate(31);
    ToDate.setFullYear(new Date().getFullYear() + 1);

    this.date.FromDate.setValue(new ParseDate().transform(FromDate));
    this.date.ToDate.setValue(new ParseDate().transform(ToDate));
    this.fromDate = new ParseDate().transform(FromDate);
    this.toDate = new ParseDate().transform(ToDate);
  }

  setDate(event) {
    this.fromDate = '';
    this.toDate = '';
  }

  getData() {
    if (!this.validations()) { return; }

    this.ccwiseObject();

    if (this.f.ReportType.value === 'forAPeriod') {
      this.loader.spin.next(true);
      this.http.Post(urlConstant.reports.GetGLWiseOnDate(), this.object).subscribe(result => {
        if (result.Status === 200) {
          this.glBalanceList = new MatTableDataSource(result.Data);
          this.totalCredit = result.Data[0].TotalCreditAmount;
          this.totalDebit = result.Data[0].TotalDebitAmount;
          this.deficit = result.Data[0].Deficit;
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
        }
      });
    } else {
      this.loader.spin.next(true);
      this.http.Get(urlConstant.reports.GetGLWiseData(this.f.CCCode.value, this.exclude, this.f.ReportType.value)).subscribe(result => {
        if (result.Status === 200) {
          this.glBalanceList = new MatTableDataSource(result.Data);
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
        }
      });
    }

    if (this.totalDebit > this.totalCredit) {
      this.footer = "Deficit";
    } else if (this.totalDebit < this.totalCredit) {
      this.footer = "Surplus";
    } else {
      this.footer = "Total";
    }
  }

  ccwiseObject() {
    if (this.f.ReportType.value === 'forAPeriod') {
      this.fromDate = isNullOrUndefined(this.fromDate) ? new ParseDate().transform(this.date.FromDate.value) : this.fromDate;
      this.toDate = isNullOrUndefined(this.toDate) ? new ParseDate().transform(this.date.ToDate.value) : this.toDate;

      this.object.CCCode = this.f.CCCode.value;
      this.object.ReportType = this.f.ReportType.value;
      this.object.FromDate = this.fromDate;
      this.object.ToDate = this.toDate;
      this.object.Exclude = this.exclude;
    } else {
      // this is used for RPG
      this.object.CCCode = this.f.CCCode.value;
      this.object.FromDate = localStorage.getItem("AcBegin").substring(0, 6);
      this.object.ToDate = this.f.Year.value + this.f.Month.value;
      this.object.Exclude = this.exclude;
      this.object.ReportType = this.f.ReportType.value;
    }
  }

  // function to validate using date and report combinations.
  validations(): boolean {
    if (this.f.ReportType.value !== "forAPeriod" && isNullOrUndefined(this.f.Month.value) && isNullOrUndefined(this.Year)) {
      this.commonService.openSnackBar("Enetr Month and Year Information", "Ok");
      return false;
    }

    if (!this.commonService.isValidStringValue(this.f.CCCode.value)) { // for Account code / name
      this.commonService.openSnackBar("Enter CC Code/Name", "Ok");
      return false;
    }
    return true;
  }

  checkYear(event) {
    if (event.value.length > 4 ) {
      this.commonService.openSnackBar("Year cannot exceed 4 digits", "Ok");
      return;
    }
  }
}