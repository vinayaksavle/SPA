import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { AcMasterLibComponent } from 'ac-master-lib';
import { ParseDate } from 'shared-utility';
import { FromDateToDateComponent } from 'from-date-to-date';
import { ServiceTabFieldComponent } from 'service-tab-field';
import { isNullOrUndefined } from 'util';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { pipe } from 'rxjs';
@Component({
    selector: 'app-dept-wise-service',
    templateUrl: 'dept-wise-service.component.html',
    styleUrls: ['./dept-wise-service.component.css'],
    host: { 'class': 'section__main' }
})

export class DeptWiseService {
    @ViewChild('serviceComponent') serviceComponent: ServiceTabFieldComponent;
    @ViewChild('date') date;
    @ViewChild('patsrc') patsrc;
    fromDate: string;
    toDate: string;
    totalCount: number = 0
    totalAmount: string = "0.00";
    deptList: any;
    servList: any;
    options: string[] = ['IP', 'OP', 'Both', 'Health Checkup'];
    DeptWiseServiceForm: FormGroup;
    deptListDetails: MatTableDataSource<any> = new MatTableDataSource<any>();
    patientList: MatTableDataSource<any> = new MatTableDataSource<any>();
    displayedSummaryColumns = ["Test Code", "Test Name", "OPD Cases", "OPD Amount",
        "IP Cases", "IP Amount", "Total Cases", "Total Amount"];
    displayedColumns = ["RegNo", "Name", "BedNo", "Service", "Qty", "Amount", "VoucherNumber", "UserId", "DiscountAmount"];
    serviceData: any = {
        'DepartmentCode': '', 'ServiceCode': '',
        'PatientCategoryCode': '',
    };

    constructor(private fb: FormBuilder, private commonService: CommonService, private loaderService: LoaderService,
        private httpService: HttpService) {
    }

    ngOnInit(): void {
        this.DeptWiseServiceForm = this.fb.group({
            FromDate: [new Date(), Validators.required],
            ToDate: [new Date(), Validators.required],
            Type: ['I'],
            DisplaySummary: [true],
            DeptCodeName: [''],
            DeptCode: [''],
            ServiceCodeName: [''],
            ServiceCode: [''],
        });
        this.deptListDetails = new MatTableDataSource([]);

        this.fromDate = new Date().toString();
        this.toDate = new Date().toString();
        this.initializeDepartmentLookup();
        this.initializeServiceLookup();
    }

    get f() {
        return this.DeptWiseServiceForm.controls;
    }

    initializeDepartmentLookup() {
        const waitTime = pipe(debounceTime(500));
        const distinct = pipe(distinctUntilChanged());

        this.f.DeptCodeName.valueChanges.pipe(waitTime).pipe(distinct).pipe(switchMap(text => !isNullOrUndefined(text) && text.toString().trim() !== '' ? this.httpService.Get(urlConstant.reports.GetDepartments(text))
            : [])).subscribe(result => {
                if (result.Status === 200 && result.Data.length > 0) {
                    this.deptList = result.Data;
                } else {
                    this.deptList = [];
                    return;
                }
            })
    }

    initializeServiceLookup() {
        const waitTime = pipe(debounceTime(500));
        const distinct = pipe(distinctUntilChanged());

        this.f.ServiceCodeName.valueChanges.pipe(waitTime).pipe(distinct).pipe(switchMap(text => !isNullOrUndefined(text) && text.toString().trim() !== '' ? this.httpService.Get(urlConstant.reports.GetService(text, this.f.DeptCode.value))
            : [])).subscribe(result => {
                if (result.Status === 200 && result.Data.length > 0) {
                    this.servList = result.Data;
                } else {
                    this.servList = [];
                    return;
                }
            })
    }

    onDeptSelection(event: any) {
        if (!isNullOrUndefined(event))
            this.f.DeptCode.setValue(event.DepartmentCode);
        else
            this.f.DeptCode.setValue("");
    }

    onServiceSelection(event: any) {
        if (!isNullOrUndefined(event))
            this.f.ServiceCode.setValue(event.ServiceCode);
        else
            this.f.ServiceCode.setValue("");
    }

    getDate() {
        this.fromDate = this.date.FromDate.value;
        this.toDate = this.date.ToDate.value;
    }

    // getSetValue(event, component) {
    //     if (component === 'PatSrc') {
    //         // this.f.PatientCategory.setValue(event.Code);
    //     } else if (component === 'Dept') {
    //         this.serviceData.DepartmentCode = event.DepartmentCode;
    //         this.f.DeptCode.setValue(event.DepartmentCode);
    //     }
    // }

    onSubmit() {
        // if (this.f.DisplaySummary.value && this.f.PpnBilled.value) {
        //     this.f.DisplaySummary.setValue(false);
        // }

        // if (!this.f.PpnBilled.value && !this.commonService.isValidStringValue(this.f.DeptCode.value)) {
        //     this.commonService.displayPromptMessage("Department Wise Service", "Please select department first !");
        //     return;
        // }
        if (!this.commonService.isValidStringValue(this.f.DeptCode.value)) {
            this.commonService.displayPromptMessage("Department Wise Service", "Please select department first !");
            return;
        }

        this.loaderService.spin.next(true);
        if (this.f.DisplaySummary.value) {
            this.httpService.Post(urlConstant.reports.GetTestDetails, this.getPayload()).subscribe(response => {
                if (response.Status === 200 && response.Data.length > 0) {
                    this.deptListDetails = new MatTableDataSource(response.Data);
                    this.totalCount = response.Data.length;
                    this.totalAmount = response.Data.map(a => parseFloat(a.TotalAmount)).reduce((a, b) => a + b);
                    this.loaderService.spin.next(false);
                }
            });
        } else {
            this.httpService.Post(urlConstant.reports.DeptWiseServiceReport, this.getPayload()).subscribe(response => {
                if (response.Status === 200 && response.Data.length > 0) {
                    this.patientList = new MatTableDataSource(response.Data);
                    this.totalCount = response.Data.length;
                    this.totalAmount = response.Data.map(a => parseFloat(a.ServiceAmount)).reduce((a, b) => a + b);
                    this.loaderService.spin.next(false);
                }
            });
        }
        this.loaderService.spin.next(false);
    }

    // Export to Excel
    exportToExcel() {
        this.loaderService.spin.next(true);
        this.httpService.Post(urlConstant.reports.ExportDeptWiseServiceReport, this.getPayload()).subscribe(response => {
            if (response.Status === 200) {
                this.httpService.openFile(response.Data);
                this.loaderService.spin.next(false);
            }
        });
    }

    // setServiceData(service, isValid) {
    //     if (!isNullOrUndefined(service))
    //         this.f.ServiceCode.setValue(service.ServiceCode);
    //     else
    //         this.f.ServiceCode.setValue('');
    // }

    getPayload() {
        let obj = this.DeptWiseServiceForm.getRawValue();

        obj.FromDate = new ParseDate().transform(this.date.FromDate.value);
        obj.ToDate = new ParseDate().transform(this.date.ToDate.value);
        return obj;
    }

    // sets emmitted service data from service help to service tab field
    setEmittedService(service: any) {
        if (service !== undefined && this.commonService.isValidStringValue(service.ServiceCode)) {
            setTimeout(() => {
                this.serviceComponent.service = service.ServiceCode;
                this.serviceComponent.getService(service.ServiceCode);
            }, 100);
        }
    }

    clearDeptLookupSearch() {
        this.f.DeptCodeName.setValue("");
        this.f.DeptCode.setValue("");
        this.deptList = [];
    }

    clearServiceLookupSearch() {
        this.f.ServiceCodeName.setValue("");
        this.f.ServiceCode.setValue("");
        this.servList = [];
    }

    onClear() {
        this.ngOnInit();
    }
}