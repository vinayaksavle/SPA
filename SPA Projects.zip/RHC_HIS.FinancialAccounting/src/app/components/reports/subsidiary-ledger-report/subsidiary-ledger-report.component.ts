import { Component, OnInit, ViewChild, Inject, ChangeDetectorRef } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { AcMasterLibComponent } from 'ac-master-lib';
import { ParseDate } from 'shared-utility';
import { FromDateToDateComponent } from 'from-date-to-date';
import { isNullOrUndefined } from 'util';

@Component({
    selector: 'app-subsidiary-ledger-report',
    templateUrl: 'subsidiary-ledger-report.component.html',
    styleUrls: ['./subsidiary-ledger-report.component.css'],
    host: { 'class': 'section__main' }
})

export class SubsidiaryLedgerReport {
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('fromDateToDate') fromDateToDate: FromDateToDateComponent;
    @ViewChild('bankAccountComp') bankAccountComp: AcMasterLibComponent;
    @ViewChild('supplierCode') supplierCode: AcMasterLibComponent 
    selectedRowData: any;
    selectedRowIndex: number = -1;

    //dummy datat

    dummyData = [
    {
      VouchrNo: "1-10-201",
      VouchrDt: "20210101",
    },
    {
      VouchrNo: "2-10-201",
      VouchrDt: "20200202",
    },
    {
      VouchrNo: "3-10-201",
      VouchrDt: "20200303",
    }
    ];

    dummyData_1 = [
    {
      VouchrNo: "1.1",
      VouchrDt: "20210101",
    }
    ];

    dummyData_2 = [
    {
      VouchrNo: "1.1.1",
      VouchrDt: "20210101",
    }
    ];

    filteredData: MatTableDataSource<any> = new MatTableDataSource(this.dummyData);
    action: string;
    rowdetails: any;
    subLedgerReportForm: FormGroup;

    secondcolumn = ["SrNo","Action", "VoucherNo", "VoucherDate", "VoucherType",
        "Invoice", "DebitAmount", "CreditAmount", "TaxableAmount", "CGST", "SGST", "IGST", "Cess"];
    thirdColumn = ["SrNo","Action", "VoucherNo", "VoucherDate", "VoucherType",
        "Invoice", "DebitAmount", "CreditAmount", "TaxableAmount", "CGST", "SGST", "IGST", "Cess"];
    expandedElement: User | null;
    subExpandedElement: User | null;

    displayedColumns : any = ["SrNo","Action", "VoucherNo", "VoucherDate", "VoucherType",
        "Invoice", "DebitAmount", "CreditAmount", "TaxableAmount", "CGST", "SGST", "IGST", "Cess"];

    constructor(private http: HttpService,private cd: ChangeDetectorRef, private commonService: CommonService,
        private fb: FormBuilder, private loader: LoaderService,
        private activateRoute: ActivatedRoute, private router: Router) { }

    ngOnInit() {
        this.initForm();
    }

    //method to initialize seatrch form
    initForm() {
        this.subLedgerReportForm = this.fb.group({
            FromDateToDate: [],
            ControlAc: [],
            SupplierCode: []
        })
    }

    //method to set date
    setFromDateToDate(event) {

    }

    //method to set control Account
    selectControlAccount(event) {

    }

    //method to set supplier code
    selectSupplierCode(event) {

    }

    // method for search results
    searchResults() {
        this.loader.spin.next(true);
         this.http.Get(urlConstant.reports.GetSubLedgerReports(this.supplierCode.inputValue.value,this.bankAccountComp.inputValue.value,new ParseDate().transform(this.fromDateToDate.FromDate.value), new ParseDate().transform(this.fromDateToDate.ToDate.value))).subscribe(response => {
             if (response.Status === 200) {
                 console.log(response);
                 this.filteredData = new MatTableDataSource(response.Data);
                 this.loader.spin.next(false);
             } else {
                 this.loader.spin.next(false);
             }
         })
    }

    // method fod export to Excel
    exportToExcel() {
    }

    // method fod export to pdf
    exportToPdf() {

    }

    getSubDetails(element) {
    // this.http.Get(urlConstant.reports.GetGroups(element.Code))
    // .subscribe(response=>{
    //   if(response.Data)
    //   {
    //     element.MainAccounts = new MatTableDataSource<any>(response.Data);
    //     this.expandedElement = this.expandedElement === element ? null : element;
    //     if(!isNullOrUndefined(response.Data[0]) && !isNullOrUndefined(response.Data[0].SubAccounts) )
    //     {
    //       element.MainAccounts.data[0].SubAccounts = new MatTableDataSource<any>(response.Data[0].SubAccounts);
    //       // this.subExpandedElement = this.subExpandedElement === element ? null : element;
    //     }
    //     element.IsOpen = !element.IsOpen;
    //      this.cd.detectChanges();

    //   }
    // })
        element.MainAccounts = new MatTableDataSource<any>(this.dummyData_1);
        this.expandedElement = this.expandedElement === element ? null : element;
        console.log(this.expandedElement);
        element.MainAccounts.data[0].SubAccounts = new MatTableDataSource<any>(this.dummyData_2);
        element.IsOpen = !element.IsOpen;
        this.cd.detectChanges();
  }

  getSubGroup(element) {
    element.IsOpen = !element.IsOpen;
  }

    // method get all form control values
    get f() { return this.subLedgerReportForm.controls; }

    // method get expanding nested table
    expandRow() {

    }

    // method to send email
    sendMail() {

    }
   
    clear(){
        
    }

}
export interface User {
  SrNo: string;
  Action: string;
  VoucherNo: string;
  VoucherDate: string;
  VoucherType: string;
  Invoice: string;
  DebitAmount: string;
  CreditAmount: string;
  TaxableAmount: string;
  CGST: string;
  SGST: string;
  IGST: string;
  Cess: string;
}

