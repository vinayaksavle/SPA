import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { AcMasterLibComponent } from 'ac-master-lib';
import { isNullOrUndefined } from 'util';

@Component({
    selector: 'app-subsidiary-ledger-account-balance',
    templateUrl: 'general-ledger-ac-balance.component.html',
    styleUrls: ['./general-ledger-ac-balance.component.css'],
    host: { 'class': 'section__main' }
})

export class GeneralLedgerAccountBalance {
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('acCodeName') acCodeName: AcMasterLibComponent;
    years: any;
    totalDebitAmount: number = 0;
    totalCreditAmount: number = 0;
    totalBalanceAmount: number = 0;
    totalLastYearBalAmount: number = 0;
    filteredData: MatTableDataSource<any> = new MatTableDataSource();
    GeneralLedgerAcForm: FormGroup;
    displayedColumns = ["SrNo", "MonthYear", "DebitAmount", "CreditAmount", "BalanceAmt", "LastYearBal"];

    constructor(private http: HttpService, private commonService: CommonService,
        private fb: FormBuilder, private loader: LoaderService,
        private activateRoute: ActivatedRoute, private router: Router) { }

    ngOnInit() {
        this.initForm();
        this.getAcYears();
        this.setDefaultAcCode();
        this.getGLAcBalance();
    }

    //method to initialize seatrch form
    initForm() {
        this.GeneralLedgerAcForm = this.fb.group({
            AcYear: [this.commonService.isValidStringValue(localStorage.getItem("AcYear")) ? localStorage.getItem("AcYear") : (new Date().getFullYear() - 1).toString() + '-' + new Date().getFullYear().toString()],
            AcCode: [],
            FromYear: [this.commonService.isValidStringValue(localStorage.getItem("AcBegin")) ? localStorage.getItem("AcBegin").substring(0, 4) : (new Date().getFullYear() - 1).toString()],
            FromMonth: [this.commonService.isValidStringValue(localStorage.getItem("AcBegin")) ? localStorage.getItem("AcBegin").substring(4, 6) : "04"],
            // ToYear: [this.commonService.isValidStringValue(localStorage.getItem("AcEnd")) ? localStorage.getItem("AcEnd").substring(0, 4) : new Date().getFullYear().toString()],
            // ToMonth: [this.commonService.isValidStringValue(localStorage.getItem("AcEnd")) ? localStorage.getItem("AcEnd").substring(4, 6) : "03"]
        })
    }

    // method get all form control values
    get f() { return this.GeneralLedgerAcForm.controls; }

    setDefaultAcCode() {
        let facilityId = localStorage.getItem('Facility');

        if (facilityId === "001")
            this.f.AcCode.setValue('1-06-205');
        else if (facilityId === "002")
            this.f.AcCode.setValue('1-06-207');
        else
            this.f.AcCode.setValue('1-06-209');

        // Fetch Bank A/C Name on the basis of A/C Code and Facility
        this.http.Get(urlConstant.Voucher.GetAccountMasterLookup(this.f.AcCode.value)).subscribe(response => {
            if (response.Status === 200) {
                this.acCodeName.inputValue.setValue(this.f.AcCode.value + ' ' + response.Data[0].Name);
            }
        })
    }

    getAcYears() {
        this.loader.spin.next(true);
        this.filteredData = new MatTableDataSource();
        this.http.Get(urlConstant.GetAccYearData()).subscribe(result => {
            if (result && result.Status === 200) {
                this.years = result.Data;
                this.loader.spin.next(false);
            }
        })
    }

    setAcCodeName(event: any) {
        if (!isNullOrUndefined(event))
            this.f.AcCode.setValue(event.Code);
        else
            this.f.AcCode.setValue('');
    }

    // method for search results
    getGLAcBalance() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.reports.GetGLAcBalance(this.f.AcYear.value, this.f.AcCode.value, this.f.FromYear.value, this.f.FromMonth.value)).subscribe(response => {
            if (response.Status === 200 && response.Data.length > 0) {
                this.filteredData = new MatTableDataSource(response.Data);
                this.filteredData.sort = this.sort;
                this.totalDebitAmount = response.Data[0].TotalDebitAmount;
                this.totalCreditAmount = response.Data[0].TotalCreditAmount;
                this.totalBalanceAmount = response.Data[0].TotalBalanceAmount;
                this.totalLastYearBalAmount = response.Data[0].TotalLastYearBalAmount;
                this.loader.spin.next(false);
            } else {
                this.filteredData = new MatTableDataSource([]);
                this.loader.spin.next(false);
            }
        })
    }

    // method fod export to Excel
    exportToExcel() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.reports.GetGLAcExcel(this.f.AcYear.value, this.f.AcCode.value, this.f.FromYear.value, this.f.FromMonth.value)).subscribe(res => {
            if (res.Status == 200 && res.Data.length > 0) {
                this.http.openFile(res.Data);
                this.loader.spin.next(false);
            }
            else {
                this.loader.spin.next(false);
            }
        }, (error) => {
            console.log(error);
        })
    }

    // method for clearing form
    clear() {
        window.location.reload();
    }
}