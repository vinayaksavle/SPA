import { Component, OnInit, ViewChild, Inject, ChangeDetectorRef } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { AcMasterLibComponent } from 'ac-master-lib';
import { ParseDate } from 'shared-utility';
import { FromDateToDateComponent } from 'from-date-to-date';
import { isNullOrUndefined } from 'util';

@Component({
    selector: 'app-ledger-report',
    templateUrl: 'ledger-report.component.html',
    styleUrls: ['./ledger-report.component.css'],
    host: { 'class': 'section__main' }
})

export class LedgerReport {
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('fromDateToDate') fromDateToDate: FromDateToDateComponent;
    @ViewChild('bankAcCodeName') bankAcCodeName: AcMasterLibComponent;
    ledgerReportList: MatTableDataSource<any> = new MatTableDataSource();
    LedgerReportForm: FormGroup;
    ReportType = [
        { value: 'detail', viewValue: 'DETAIL' },
        { value: 'day', viewValue: 'DAY' },
        { value: 'month', viewValue: 'MONTH' }
    ];

    type = true;
    totalDebitAmt: number = 0;
    totalCreditAmt: number = 0;
    totalOpenDebitAmt: number = 0;
    totalOpenCreditAmt: number = 0;
    rptType = "";
    openingBalace: number = 0;
    closingBalance: number = 0;

    displayedColumns = ["SrNo", "Action", "VoucherNo", "VoucherDate", "CostCenter",
        "Invoice", "DebitAmount", "CreditAmount"];

    secondcolumn = ["SrNo", "Action", "VoucherNo", "VoucherDate", "CostCenter",
        "Invoice", "DebitAmount", "CreditAmount"];

    thirdColumn = ["SrNo", "Action", "VoucherNo", "VoucherDate", "CostCenter",
        "Invoice", "DebitAmount", "CreditAmount"];

    expandedElement;
    subExpandedElement;

    constructor(private http: HttpService, private commonService: CommonService,
        private fb: FormBuilder, private loader: LoaderService,
        private activateRoute: ActivatedRoute, private router: Router, private cd: ChangeDetectorRef) { }

    ngOnInit() {
        this.initForm();
    }

    //method to initialize seatrch form
    initForm() {
        this.LedgerReportForm = this.fb.group({
            FromDate: [new Date()],
            ToDate: [new Date()],
            BankAcCode: [''],
            Account: [],
            ReportType: [],
            AcBegin: [this.commonService.isValidStringValue(localStorage.getItem("AcBegin")) ? localStorage.getItem("AcBegin") : (new Date().getFullYear() - 1).toString() + '0401'],
            AcYear: [this.commonService.isValidStringValue(localStorage.getItem("AcYear")) ? localStorage.getItem("AcYear") : (new Date().getFullYear() - 1).toString() + '-' + new Date().getFullYear().toString()]
        })
    }

    // method get all form control values
    get f() { return this.LedgerReportForm.controls; }

    //method to set date
    setFromDateToDate(event: any) {
        if (!isNullOrUndefined(event)) {
            this.f.FromDate.setValue(new Date(event.FromDate.value));
            this.f.ToDate.setValue(new Date(event.ToDate.value));
        }
    }

    //method to set account code
    setBankAcCodeName(event: any) {
        if (!isNullOrUndefined(event))
            this.f.BankAcCode.setValue(event.Code);
        else
            this.f.BankAcCode.setValue('');
    }

    // method for search results
    getLedgerReports() {
        this.loader.spin.next(true);
        const inputParam = this.LedgerReportForm.getRawValue();
        inputParam.FromDate = new ParseDate().transform(inputParam.FromDate);
        inputParam.ToDate = new ParseDate().transform(inputParam.ToDate);
        this.http.Post(urlConstant.reports.GetLedgerReports, inputParam).subscribe(response => {
            console.log(response.Data);
            if (response.Status === 200 && response.Data.length > 0) {
                this.ledgerReportList = new MatTableDataSource(response.Data);
                this.totalDebitAmt = response.Data[0].TotalDebitAmt;
                this.totalCreditAmt = response.Data[0].TotalCreditAmt;
                this.totalOpenDebitAmt = response.Data[0].TotalOpenDebitAmt;
                this.totalOpenCreditAmt = response.Data[0].TotalOpenCreditAmt;
                this.openingBalace = response.Data[0].OpenDebitBalance;
                this.closingBalance = response.Data[0].CloseCreditBalance;
                this.loader.spin.next(false);
            } else {
                this.ledgerReportList = new MatTableDataSource([]);
                this.loader.spin.next(false);
            }
        })
    }

    // method fod export to Excel
    exportToExcel() {
        this.loader.spin.next(true);
        const inputParam = this.LedgerReportForm.getRawValue();
        inputParam.FromDate = new ParseDate().transform(inputParam.FromDate);
        inputParam.ToDate = new ParseDate().transform(inputParam.ToDate);
        this.http.Post(urlConstant.reports.ExportLedgerReportToExcel, inputParam).subscribe(response => {
            if (response.Status == 200 && response.Data.length > 0) {
                this.http.openFile(response.Data);
                this.loader.spin.next(false);
            }
            else {
                this.loader.spin.next(false);
            }
        }, (error) => {
            console.log(error);
        })
    }

    // method fod export to pdf
    exportToPdf() {


    }

    changeType(value) {
        if (value == "detail") {
            this.rptType = value;
            console.log(value)
            this.type = false;
        }
        else {
            this.type = true;
        }
    }

    // method get expanding nested table
    expandRow() {

    }

    // method to clear
    clear() {
        this.initForm();
        this.fromDateToDate.FromDate.setValue(new Date());
        this.fromDateToDate.ToDate.setValue(new Date());
        this.bankAcCodeName.clearLookupSearch();
        this.ledgerReportList = new MatTableDataSource<any>([]);
    }

    // method get sub table details
    getSubDetails(element) {
        // this code is temporary , added to check nested tree.
        // this code needs to be changed, api calls needs to be added
        element.MainAccounts = new MatTableDataSource<any>([{ "key": "value" }]);
        this.expandedElement = this.expandedElement === element ? null : element;
        element.MainAccounts.data[0].SubAccounts = new MatTableDataSource<any>();
        element.IsOpen = !element.IsOpen;
        this.cd.detectChanges();
    }

    // method toggle between show more / show less 
    getSubGroup(element) {
        element.IsOpen = !element.IsOpen;
    }
}