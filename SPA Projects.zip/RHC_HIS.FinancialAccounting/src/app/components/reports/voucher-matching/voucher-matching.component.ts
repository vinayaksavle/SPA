import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { ParseDate } from 'shared-utility';
import { FromDateToDateComponent } from 'from-date-to-date';
import { isNullOrUndefined } from 'util';

@Component({
    selector: 'app-voucher-matching',
    templateUrl: 'voucher-matching.component.html',
    styleUrls: ['./voucher-matching.component.css'],
    host: { 'class': 'section__main' }
})

export class VoucherMatching {
    @ViewChild(MatSort) sort: MatSort;
    voucherMatchingList: MatTableDataSource<any> = new MatTableDataSource();
    voucherMatchForm: FormGroup;
    displayedColumns = ["SrNo", "VchrType", "VouchrNo", "VouchrDt", "DebitAmount", "CreditAmount", "Difference"];

    constructor(private http: HttpService, private commonService: CommonService,
        private fb: FormBuilder, private loader: LoaderService) { }

    ngOnInit() {
        this.init();
    }


    //method to initialize search form
    init() {
        this.voucherMatchForm = this.fb.group({
            FromDate: [new Date()],
            ToDate: [new Date()]
        })
        this.getVoucherMatchingsList();
    }


    //method to set date
    setFromToDate(event: any) {
        if (!isNullOrUndefined(event)) {
            this.f.FromDate.setValue(new Date(event.FromDate.value));
            this.f.ToDate.setValue(new Date(event.ToDate.value));
        }
    }

    // method for search results
    getVoucherMatchingsList() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.reports.GetVoucherMatchings(new ParseDate().transform(this.f.FromDate.value), new ParseDate().transform(this.f.ToDate.value))).subscribe(response => {
            if (response.Status === 200 && response.Data.length > 0) {
                console.log(response);
                this.voucherMatchingList = new MatTableDataSource(response.Data);
                this.voucherMatchingList.sort = this.sort;
                this.loader.spin.next(false);
            } else {
                this.loader.spin.next(false);
                this.voucherMatchingList = new MatTableDataSource([]);
            }
        })
    }

    // method for export to Excel
    exportToExcel() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.reports.ExportVoucherMatchingToExcel(new ParseDate().transform(this.f.FromDate.value), new ParseDate().transform(this.f.ToDate.value))).subscribe(response => {
            if (response.Status == 200 && response.Data.length > 0) {
                this.http.openFile(response.Data);
                this.loader.spin.next(false);
            }
            else {
                this.loader.spin.next(false);
            }
        }, (error) => {
            console.log(error);
        })
    }

    // method get all form control values
    get f() { return this.voucherMatchForm.controls; }

}