import { Component, OnInit, ViewChild, Inject, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { MainGroupLookupComponent } from 'main-group-lookup';
import { urlConstant } from 'src/app/constants/urlConstants';
@Component({
    selector: 'app-gl-charts-ac',
    templateUrl: './gl-charts-ac.component.html',
    styleUrls: ['./gl-charts-ac.component.css'],
    host: { 'class': 'section__main' }
})
export class GlChartsAcComponent implements OnInit {
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('mainGroupCodeName') mainGroupCodeName: MainGroupLookupComponent;

    ControlAcTransForm: FormGroup;
    displayedColumns = ["SrNo", "Action", "Main Group A/C Code/Name"];
    secondcolumn = ["SrNo", "Action", "Main Group A/C Code/Name"];
    thirdColumn = ["SrNo", "Action", "Main Group A/C Code/Name"];
    expandedElement;
    subExpandedElement;
    ChartOfAcList: MatTableDataSource<any> = new MatTableDataSource();

    constructor(private http: HttpService, private fb: FormBuilder, private loader: LoaderService, private cd: ChangeDetectorRef) { }

    ngOnInit() {
        this.initForm();
        this.init();
    }

    //method to initialize seatrch form
    initForm() {
        this.ControlAcTransForm = this.fb.group({
            FromDateToDate: [],
            ACCode: [],
        })
    }

    init() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.reports.GetGLChartOfAc(" ")).subscribe(response => {
            if (response.Status === 200 && response.Data.length > 0) {
                console.log(response);
                this.ChartOfAcList = new MatTableDataSource(response.Data);
                this.ChartOfAcList.sort = this.sort;
                this.loader.spin.next(false);
            } else {
                this.ChartOfAcList = new MatTableDataSource([]);
                this.loader.spin.next(false);
            }
        })
    }

    // method for search results
    getGLChartOfAc() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.reports.GetGLChartOfAc(this.mainGroupCodeName.inputValue.value)).subscribe(response => {
            if (response.Status === 200 && response.Data.length > 0) {
                console.log(response);
                this.ChartOfAcList = new MatTableDataSource(response.Data);
                this.ChartOfAcList.sort = this.sort;
                this.loader.spin.next(false);
            } else {
                this.ChartOfAcList = new MatTableDataSource([]);
                this.loader.spin.next(false);
            }
        })
    }

    // method for export to Excel
    exportToExcel() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.reports.GLChartOfActToExcel(this.mainGroupCodeName.inputValue.value)).subscribe(response => {
            if (response.Status == 200 && response.Data.length > 0) {
                this.http.openFile(response.Data);
                this.loader.spin.next(false);
            }
            else {
                this.loader.spin.next(false);
            }
        }, (error) => {
            console.log(error);
        })
    }

    // method get all form control values
    get f() { return this.ControlAcTransForm.controls; }

    getSubDetails(element) {
        // this code is temporary , added to check nested tree.
        // this code needs to be changed, api calls needs to be added 
        element.MainAccounts = new MatTableDataSource<any>([{ "key": "value" }]);
        this.expandedElement = this.expandedElement === element ? null : element;
        console.log(element.MainAccount);

        element.MainAccounts.data[0].SubAccounts = new MatTableDataSource<any>([1]);
        // this.subExpandedElement = this.subExpandedElement === element ? null : element;

        element.IsOpen = !element.IsOpen;
        this.cd.detectChanges();
    }

    getSubGroup(element) {
        element.IsOpen = !element.IsOpen;
    }

}
