import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GlChartsAcComponent } from './gl-charts-ac.component';

describe('GlChartsAcComponent', () => {
  let component: GlChartsAcComponent;
  let fixture: ComponentFixture<GlChartsAcComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GlChartsAcComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GlChartsAcComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
