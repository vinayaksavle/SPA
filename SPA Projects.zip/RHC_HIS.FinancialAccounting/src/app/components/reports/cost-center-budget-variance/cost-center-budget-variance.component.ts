import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { pipe } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { urlConstant } from 'src/app/constants/urlConstants';
import { HttpService } from 'src/app/services/http.service';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-cost-center-budget-variance',
  templateUrl: './cost-center-budget-variance.component.html',
  styleUrls: ['./cost-center-budget-variance.component.css'],
  host: { 'class': 'section__main' }
})
export class CostCenterBudgetVarianceComponent implements OnInit {

  public CCCode: FormControl;
  public filteredOptionsCode: any[];
  public displayedColumns: any = ['serialNo', 'MonthYear', 'Actuals', 'Budget', 'Variance', '%Variance'];
  public listOfBudget: MatTableDataSource<any>;

  constructor(private http: HttpService) { }

  ngOnInit() {
    this.init();
  }

  init() {
    const waitTime = pipe(debounceTime(200));
    const distinct = pipe(distinctUntilChanged());

    this.CCCode = new FormControl('');
    this.listOfBudget = new MatTableDataSource([]);

    this.CCCode.valueChanges.pipe(waitTime).pipe(distinct).pipe(switchMap(text =>
      !isNullOrUndefined(text) && text.toString().trim() !== ''
        ? this.http.Get(urlConstant.reports.GetCostCenterCodeName(text.toString())) : this.filteredOptionsCode = []))
      .subscribe(result => {
        this.filteredOptionsCode = result.Data;
      });
  }

  clearLookupSearch() {
    this.CCCode.setValue('');
  }

}
