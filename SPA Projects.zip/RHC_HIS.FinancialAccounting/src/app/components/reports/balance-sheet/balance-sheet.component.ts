import { Component, OnInit, ViewChild, Inject, ChangeDetectorRef } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'app-balance-sheet',
    templateUrl: 'balance-sheet.component.html',
    styleUrls: ['./balance-sheet.component.css'],
    host: { 'class': 'section__main' }
})

export class BalanceSheet {
    @ViewChild(MatSort) sort: MatSort;
    selectedRowData: any;
    selectedRowIndex: number = -1;
    action: string;
    rowdetails: any;
    BalSheetForm: FormGroup;
   
    ViewType = [
        { value: 'detail', viewValue: 'DETAIL' },
        { value: 'maingroup', viewValue: 'MAIN GROUP' },
        { value: 'subgroup', viewValue: 'SUB GROUP' },
    ];

    ReportType = [
        { value: 'yop', viewValue: 'YOP' },
        { value: 'ondate', viewValue: 'AS ON DATE' },
        { value: 'onmonth', viewValue: 'AS ON MONTH' },
        { value: 'period', viewValue: 'FOR A PERIOD' },
    ];

    //dummy datat

    dummyData = [
    {
      ACCode: "1-10-201",
      ACDesc: "20210101",
    },
    {
      ACCode: "2-10-201",
      ACDesc: "20200202",
    },
    {
      ACCode: "3-10-201",
      ACDesc: "20200303",
    }
    ];

    dummyData_1 = [
    {
      ACCode: "1.1",
      ACDesc: "20210101",
    }
    ];

    dummyData_2 = [
    {
      ACCode: "1.1.1",
      ACDesc: "20210101",
    }
    ];

    filteredData: MatTableDataSource<any> = new MatTableDataSource(this.dummyData);

    secondcolumn = ["SrNo","Action", "AccountCode", "AccountName", "Asset", "Liability"];
    thirdColumn = ["SrNo","Action", "AccountCode", "AccountName", "Asset", "Liability"];
    expandedElement: User | null;
    subExpandedElement: User | null;


    displayedColumns = ["SrNo","Action", "AccountCode", "AccountName", "Asset", "Liability"];

    constructor(private http: HttpService, private commonService: CommonService,
        private fb: FormBuilder,private cd: ChangeDetectorRef, private loader: LoaderService,
        private activateRoute: ActivatedRoute, private router: Router) { }

    ngOnInit() {
        this.initForm();
    }

    //method to initialize seatrch form
    initForm() {
        this.BalSheetForm = this.fb.group({
            FromDateToDate: [],
            View :[],
            ReportType :[],
            Month : [],
            Year : []
        })
    }

    getSubDetails(element) {
    // this.http.Get(urlConstant.reports.GetGroups(element.Code))
    // .subscribe(response=>{
    //   if(response.Data)
    //   {
    //     element.MainAccounts = new MatTableDataSource<any>(response.Data);
    //     this.expandedElement = this.expandedElement === element ? null : element;
    //     if(!isNullOrUndefined(response.Data[0]) && !isNullOrUndefined(response.Data[0].SubAccounts) )
    //     {
    //       element.MainAccounts.data[0].SubAccounts = new MatTableDataSource<any>(response.Data[0].SubAccounts);
    //       // this.subExpandedElement = this.subExpandedElement === element ? null : element;
    //     }
    //     element.IsOpen = !element.IsOpen;
    //      this.cd.detectChanges();

    //   }
    // })
        element.MainAccounts = new MatTableDataSource<any>(this.dummyData_1);
        this.expandedElement = this.expandedElement === element ? null : element;
        console.log(this.expandedElement);
        element.MainAccounts.data[0].SubAccounts = new MatTableDataSource<any>(this.dummyData_2);
        element.IsOpen = !element.IsOpen;
        this.cd.detectChanges();
    }

    getSubGroup(element) {
    element.IsOpen = !element.IsOpen;
    }

    //method to set date
    selectFromToDate(event) {

    }

    // method for search results
    searchResults() { }

    // method fod export to Excel
    exportToExcel() {
    }

    // method fod export to pdf
    exportToPdf(){

    }

    // method get all form control values
    get f() { return this.BalSheetForm.controls; }

    // method get expanding nested table
    expandRow(){

    }

    clear(){
        
    }

}
export interface User {
  SrNo: string;
  Action: string;
  AccountCode: string;
  AccountName: string;
  Asset: string;
  Liability: string;
  
}