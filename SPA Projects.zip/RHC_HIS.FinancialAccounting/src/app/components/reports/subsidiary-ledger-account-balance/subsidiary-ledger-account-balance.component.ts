import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { ParseDate } from 'shared-utility';
import { FromDateToDateComponent } from 'from-date-to-date';
import { AcMasterLibComponent } from 'ac-master-lib';
import { isNullOrUndefined } from 'util';
import { dataConstant } from 'src/app/constants/dataConstants';

@Component({
    selector: 'app-subsidiary-ledger-account-balance',
    templateUrl: 'subsidiary-ledger-account-balance.component.html',
    styleUrls: ['./subsidiary-ledger-account-balance.component.css'],
    host: { 'class': 'section__main' }
})

export class SubsidiaryLedgerAccount {
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('fromDateToDate') fromDateToDate: FromDateToDateComponent;
    @ViewChild('acCodeName') acCodeName: AcMasterLibComponent;
    selectedRowData: any;
    fromDate: any;
    year: string = '';
    toDate: any;
    selectedRowIndex: number = -1;
    filteredData: MatTableDataSource<any> = new MatTableDataSource();
    action: string;
    rowdetails: any
    SubledgerAcForm: FormGroup;
    reportType = [
        { value: 'yop', viewValue: 'YOP' },
        { value: 'asOnDate', viewValue: 'AS ON DATE' },
        { value: 'forAPeriod', viewValue: 'FOR A PERIOD' },
        { value: 'asOnMonth', viewValue: 'AS ON MONTH' }
    ];
    displayedColumns = ["SrNo", "SubAcCode", "SubAcName", "DebitAmount", "CreditAmount"];
    AcCode: any;
    totalCreditAmount: number = 0;
    totalDebitAmount: number = 0;
    object: any;
    monthList: { Key: string; Value: string; }[];

    constructor(private http: HttpService, private commonService: CommonService,
        private fb: FormBuilder, private loader: LoaderService,
        private activateRoute: ActivatedRoute, private router: Router) { }

    ngOnInit() {
        this.initForm();
    }

    //method to initialize seatrch form
    initForm() {
        this.SubledgerAcForm = this.fb.group({
            ReportType: ['forAPeriod'],
            Month: [{value: '', disabled: true}]
        });
        this.setDate();
        this.monthList = dataConstant.MonthList;
    }

    setDate() {
        let FromDate = new Date();
        FromDate.setMonth(3);
        FromDate.setDate(1);

        let ToDate = new Date();
        ToDate.setMonth(2);
        ToDate.setDate(31);
        ToDate.setFullYear(new Date().getFullYear() + 1);

        if (!isNullOrUndefined(localStorage.getItem("AcBegin")) && !isNullOrUndefined(localStorage.getItem("AcEnd"))) {
            this.fromDateToDate.FromDate.setValue(localStorage.getItem("AcBegin"));
            this.fromDateToDate.ToDate.setValue(localStorage.getItem("AcEnd"));
        } else {
            this.fromDateToDate.FromDate.setValue(new ParseDate().transform(FromDate));
            this.fromDateToDate.ToDate.setValue(new ParseDate().transform(ToDate));
        }
    }

    disableDate(event) {
        if (event.value === 'yop') {
            this.fromDateToDate.FromDate.disable();
            this.fromDateToDate.ToDate.disable();
            this.f.Month.disable();
        } else if (event.value === 'asOnMonth') {
            this.fromDateToDate.FromDate.disable();
            this.fromDateToDate.ToDate.disable();
            this.f.Month.enable();
        } else {
            this.fromDateToDate.FromDate.enable();
            this.fromDateToDate.ToDate.enable();
            this.f.Month.disable();
        }
    }

    // method for search results
    searchResults() {
        if (!this.validations()) { // to validate
            return;
        }
        this.loader.spin.next(true);
        this.createObject(); // to create sub acc object
        this.http.Post(urlConstant.reports.GetSubLedgerACBal(), this.object).subscribe(response => {
            if (response && response.Status === 200 && response.Data.length > 0) {
                this.filteredData = new MatTableDataSource(response.Data);
                this.totalCreditAmount = response.Data[0].TotalCreditAmount;
                this.totalDebitAmount = response.Data[0].TotalCreditAmount;
                this.loader.spin.next(false);
            } else {
                this.loader.spin.next(false);
            }
        });
    }

    createObject() {
        this.object = {};
        this.object = this.SubledgerAcForm.getRawValue();
        this.object.FromDate =  new ParseDate().transform(this.fromDateToDate.FromDate.value);
        this.object.ToDate =  new ParseDate().transform(this.fromDateToDate.ToDate.value);
        this.object.Year = this.year;
        this.object.Accode = this.AcCode;
    }

    // method fod export to Excel
    exportToExcel() {
        this.loader.spin.next(true);
        this.http.Post(urlConstant.reports.ExcelSubLedgerACBal(), this.object).subscribe(response => {
            if (response && response.Status === 200) {
              this.http.openFile(response.Data);
              this.loader.spin.next(false);
            } else {
              this.loader.spin.next(false);
            }
          });
    }

    // function to validate using date and report combinations.
    validations(): boolean {
        if (this.f.ReportType.value === "forAPeriod") {
            if (!this.checkAccountDates(this.fromDateToDate.FromDate.value, "From Date")) { return false; } // to check From Date
            if (!this.checkAccountDates(this.fromDateToDate.ToDate.value, "To Date")) { return false; } // to check To Date
        } 
        if (this.f.ReportType.value === "asOnMonth" && isNullOrUndefined(this.f.Month.value)) { // to validate if month is selected
            this.commonService.openSnackBar("Select Month", "Ok");
            return false;
        }
        if (this.f.ReportType.value === "yop" && isNullOrUndefined(this.year)) { // to validate if year is specified
            this.commonService.openSnackBar("Specify Year", "Ok");
            return false;
        }
        if (!this.commonService.isValidStringValue(this.AcCode)) { // for Account code / name
            this.commonService.openSnackBar("Enter Account Code/Name", "Ok");
            return false;
        } else { return true; }
    }
    // method get all form control values
    get f() { return this.SubledgerAcForm.controls; }

    setAcCodeName(event) {
        this.AcCode = event.Code;
    }

    checkAccountDates(date: Date, type: string): boolean {
        // From date to compare with selected from date
        let accFromDate = new Date();
        accFromDate.setMonth(3);
        accFromDate.setDate(1);

        // To date to compare with selected from date
        let accToDate = new Date();
        accToDate.setMonth(2);
        accToDate.setDate(31);

        // Compare if month is greater than April.
        if ((new Date().getMonth() + 1) > 4) {
            accToDate.setFullYear(new Date().getFullYear() + 1); // add 1 year in selected year
            if (date < accFromDate || date > accToDate) {
                this.commonService.openSnackBar(type + " Is Not In Accounting Range", "Ok");
                return false;
            } else { return true; }
        } else {
            accFromDate.setFullYear(new Date().getFullYear() - 1); // add 1 year in selected year
            if (date < accFromDate || date > accToDate) {
                this.commonService.openSnackBar(type + " Is Not In Accounting Range", "Ok");
                return false;
            } else { return true; }
        }
    }
}