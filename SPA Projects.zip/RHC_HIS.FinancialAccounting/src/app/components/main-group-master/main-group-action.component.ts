import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
    selector: 'main-group-action-dialog',
    templateUrl: 'main-group-action.component.html',
    styleUrls: ['./main-group-master.component.css'],
})
export class MainGroupActionDialog {

    action: string;
    rowdetails: any;
    mainGroupForm: FormGroup;
    facility = [
        { value: 'A', viewValue: 'Assets' },
        { value: 'L', viewValue: 'Liabilities' },
        { value: 'E', viewValue: 'Expenditures' },
        { value: 'I', viewValue: 'Income' }
    ];
    constructor(private dialogRef: MatDialogRef<MainGroupActionDialog>, private http: HttpService, private commonService: CommonService, private fb: FormBuilder, private loader: LoaderService) { }

    ngOnInit() {
        this.initForm();
    }

    initForm() {
        this.mainGroupForm = this.fb.group({
            MainGroupCode: [{ value: this.action === 'edit' ? this.rowdetails.MainGroupCode : '', disabled: this.action === 'edit' ? true : false }, Validators.required],
            MainGroupName: [this.action === 'edit' ? this.rowdetails.MainGroupName : '', Validators.required],
            AccountType: [this.rowdetails.AccountType,Validators.required],
            UserId: [localStorage.getItem("UserName")]
        });
    }

    // method get all form control values
    get f() { return this.mainGroupForm.controls; }


    // Save or Edit Main Group Code
    saveEditMainGroupCode() {
        if (!this.validateData()) return;

        const inputParam = this.mainGroupForm.getRawValue();
        if (this.action === 'edit') {
            this.commonService.confirmAction("Edit Main Group Code", `Do you want to update ${inputParam.MainGroupCode} Main Group Code ?`).subscribe(response => {
                if (response) {
                    this.loader.spin.next(true);
                    this.http.Post(urlConstant.MainGroupMaster.UpdateMainGroup(), inputParam).subscribe(response => {
                        if (response.Data) {
                            this.commonService.displayPromptMessage("Edit Main Group Code", `${inputParam.MainGroupCode} code updated successfully!`).subscribe(response => {
                                window.location.reload();
                            });
                        }
                        else {
                            this.loader.spin.next(false);
                            this.commonService.openSnackBar("Record already exists!", "Ok");
                        }
                    })
                }
                else {
                    this.cancel();
                }
            })
        }
        // if the action is new
        else {
            this.commonService.confirmAction("New Main Group Code", `Do you want to save ${inputParam.MainGroupCode} Main Group Code ?`).subscribe(response => {
                if (response) {
                    this.loader.spin.next(true);
                    this.http.Post(urlConstant.MainGroupMaster.InsertNewMainGroup(), inputParam).subscribe(response => {
                        if (response.Data) {
                            this.commonService.displayPromptMessage("New Main Group Code", `${inputParam.MainGroupCode} code created successfully!`).subscribe(response => {
                                window.location.reload();
                            });
                        }
                        else {
                            this.loader.spin.next(false);
                            this.commonService.displayPromptMessage("New Main Group", "Record with same Main Group Code already exists!");
                        }
                    })
                }
                else {
                    this.cancel();
                }
            })
        }
    }

    // Validations
    validateData(): boolean {
        if (!this.commonService.isValidStringValue(this.f.MainGroupCode.value)) {
            this.commonService.openSnackBar("Main Group Code should not be empty", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.MainGroupName.value)) {
            this.commonService.openSnackBar("Description should not be empty", "Ok");
            return false;
        }

        if (this.f.MainGroupCode.value.length > 2) {
            this.commonService.openSnackBar("Code length should not be greater than 2", "Ok");
            return false;
        }

        if (this.f.MainGroupName.value.length > 30) {
            this.commonService.openSnackBar("Description length should not be greater than 30", "Ok");
            return false;
        }

        return true;
    }

    // method for closing dialog
    cancel() {
        this.dialogRef.close();
    }
}