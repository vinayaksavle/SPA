import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { isNullOrUndefined } from 'util';
import { ParseDate } from 'shared-utility';

@Component({
    selector: 'app-account-year-setup',
    templateUrl: 'account-year-setup.component.html',
    styleUrls: ['./account-year-setup.component.css'],
    host: { 'class': 'section__main' }
})
export class AccountYearSetup {
    @ViewChild(MatSort) sort: MatSort;
    selectedRowData: any;
    selectedRowIndex: number = -1;
    acYearSetupForm: FormGroup;
    filteredData: MatTableDataSource<any> = new MatTableDataSource();
    rowdetails: any;
    accountingYear = "";
    permissions: any[];
    canViewList: boolean;
    canSave: boolean;
    displayedColumns = ["SrNo", "ACYear", "FromYear", "ToYear", "FromMonth", "ToMonth", "FromDate", "ToDate"];
    constructor(private http: HttpService, private commonService: CommonService, private loader: LoaderService, private fb: FormBuilder) {
        this.permissions = JSON.parse(localStorage.getItem('Permission'));
        if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
            this.canViewList = this.permissions.includes('3305F') ? true : false;
            this.canSave = this.permissions.includes('3306F') ? true : false;
        }
    }

    ngOnInit() {
        this.selectedRowIndex = -1;
        this.getAcYearData();
        this.initForm();
    }

    initForm() {
        this.acYearSetupForm = this.fb.group({
            AccountYear: [],
            FromYear: [],
            FromMonth: [],
            ToYear: [],
            ToMonth: [],
            FromDate: [new Date()],
            ToDate: [new Date()]
        });
    }

    get f() { return this.acYearSetupForm.controls; }

    getAcYearData() {
        this.loader.spin.next(true);
        this.filteredData = new MatTableDataSource();
        this.http.Get(urlConstant.GetAccYearData()).subscribe(result => {
            if (result && result.Status === 200) {
                this.filteredData = new MatTableDataSource(result.Data);
                this.filteredData.sort = this.sort;
                this.loader.spin.next(false);
            } else {
                this.loader.spin.next(false);
            }
        })
    }

    // export to pdf method
    exportToPdf() {

    }

    // export to excel method
    exportToExcel() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.GetAccYearExcel()).subscribe(res => {
            if (res.Status == 200 && res.Data.length > 0) {
                this.http.openFile(res.Data);
                this.loader.spin.next(false);
            }
            else {
                this.loader.spin.next(false);
            }
        }, (error) => {
            console.log(error);
        })
    }

    // To highlight selected row
    highlightSelectedRow(index, rowDetails) {
        this.selectedRowData = rowDetails;

        if (this.selectedRowIndex == index) {
            this.selectedRowIndex = -1;
            this.selectedRowData = null;
        } else {
            this.selectedRowIndex = index;
            this.accountingYear = rowDetails.AccountYear;
        }
    }

    setAcYear() {
        if (!isNullOrUndefined(this.selectedRowData)) {
            localStorage.setItem('AcYear', this.selectedRowData.AccountYear);
            localStorage.setItem('AcBegin', this.selectedRowData.FromDate);
            localStorage.setItem('AcEnd', this.selectedRowData.ToDate);
            console.log(this.selectedRowData.AccountYear);
            console.log(this.selectedRowData.FromDate);
            console.log(this.selectedRowData.ToDate);
        }
    }

    setFromToDate(event: any) {
        if (!isNullOrUndefined(event)) {
            this.f.FromDate.setValue(new Date(event.FromDate.value));
            this.f.ToDate.setValue(new Date(event.ToDate.value));
        }
    }

    addNewAcYear() {
        if (!this.validateForm())
            return;

        const inputParam = this.acYearSetupForm.getRawValue();
        inputParam.FromDate = new ParseDate().transform(this.f.FromDate.value);
        inputParam.ToDate = new ParseDate().transform(this.f.ToDate.value);
        console.log(inputParam);
        this.commonService.confirmAction("Ac Year Setup", "Do you want to save new Account Year ?").subscribe(response => {
            if (response) {
                this.http.Post(urlConstant.AddNewAcYear(), inputParam).subscribe(response => {
                    if (response.Data && response.Status === 200) {
                        this.getAcYearData();
                        this.initForm();
                    } else
                        this.commonService.displayPromptMessage("Ac Year Setup", "Error while saving!");
                })
            }
        })
    }

    validateForm(): boolean {
        if (!this.commonService.isValidStringValue(this.f.AccountYear.value)) {
            this.commonService.displayPromptMessage("Ac Year Setup", "Please enter Year Code!");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.FromYear.value)) {
            this.commonService.displayPromptMessage("Ac Year Setup", "Please enter From Year!");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.FromMonth.value)) {
            this.commonService.displayPromptMessage("Ac Year Setup", "Please enter From Month!");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.ToYear.value)) {
            this.commonService.displayPromptMessage("Ac Year Setup", "Please enter To Year!");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.ToMonth.value)) {
            this.commonService.displayPromptMessage("Ac Year Setup", "Please enter To Month!");
            return false;
        }

        return true;
    }
}