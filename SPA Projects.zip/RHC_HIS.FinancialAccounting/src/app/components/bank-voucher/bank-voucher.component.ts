import { Component, OnInit, ViewChild, Inject, AfterViewInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSort, MatTableDataSource } from '@angular/material';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { CommonService } from 'src/app/services/common.service';
import { isNullOrUndefined } from 'util';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CreditToAccountModal } from '../credit-to-account-modal/credittoaccount.component';
import { FromDateToDateComponent } from 'from-date-to-date';


@Component({
  selector: 'app-voucher',
  templateUrl: 'bank-voucher.component.html',
  styleUrls: ['./bank-voucher.component.css'],
  host: { 'class': 'section__main' }
})
export class BankVoucherComponent implements OnInit, AfterViewInit {
  @ViewChild('fromDateToDateTrans') fromDateToDateTrans: FromDateToDateComponent;
  @ViewChild('fromDateToDateEntry') fromDateToDateEntry: FromDateToDateComponent;
  @ViewChild(MatSort) sort: MatSort;
  selectedRowData: any;
  selectedRowIndex: number = -1;
  bankVoucherList: MatTableDataSource<any> = new MatTableDataSource([]);
  displayedColumns = ["SrNo", "VoucherNo", "VoucherDate", "Narration", "Status", "PostFlag", "DocType", "DocNo", "Amount", "ModifiedBy", "ModifiedOn",
    "CancelledBy", "CancelledOn", "Remarks"];
  bankVoucherForm: FormGroup;
  docType: string = "";
  isBankVoucher: boolean = true;
  permissions: any[];
  canViewList: boolean;
  canCreateNew: boolean;
  canEdit: boolean;
  canCancel: boolean;
  canView: boolean;
  canCreditToAccount: boolean;

  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private dialog: MatDialog,
    private activateRoute: ActivatedRoute,
    private http: HttpService,
    private loader: LoaderService,
    private commonService: CommonService,
    private router: Router,
    private fb: FormBuilder) {
    this.permissions = JSON.parse(localStorage.getItem('Permission'));
    if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
      this.canViewList = this.permissions.includes('3301T') || this.permissions.includes('3307T') ? true : false;
      this.canCreateNew = this.permissions.includes('3302T') || this.permissions.includes('3308T') ? true : false;
      this.canEdit = this.permissions.includes('3303T') || this.permissions.includes('3309T') ? true : false;
      this.canCancel = this.permissions.includes('3304T') || this.permissions.includes('3310T') ? true : false;
      this.canView = this.permissions.includes('3305T') || this.permissions.includes('3311T') ? true : false;
      this.canCreditToAccount = this.permissions.includes('3306T') ? true : false;
    }
  }

  ngOnInit() {

    this.activateRoute.params.subscribe(params => {
      this.docType = params['voucherType'];
      this.initForm();
    });

    this.getBankVoucherList();
  }


  ngAfterViewInit() {
    let futureDate = new Date();

    futureDate = new Date(futureDate.getFullYear() + 1, futureDate.getMonth(), futureDate.getDate());
    this.fromDateToDateEntry.maxDate = futureDate;
    // this.fromDateToDateTrans.maxDate = futureDate;
  }

  // method to initialize seatrch form
  initForm() {
    this.bankVoucherForm = this.fb.group({
      IsTransDate: [true],
      IsEntryDate: [true],
      DocType: [this.docType],
      TransFromDate: [new Date()],
      TransToDate: [new Date()],
      EntryFromDate: [new Date()],
      EntryToDate: [new Date()]
    });
    this.isBankVoucher = this.docType === "02";
  }

  // method get all form control values
  get f() { return this.bankVoucherForm.controls; }

  getBankVoucherList() {

    this.loader.spin.next(true);
    this.http.Post(urlConstant.Voucher.GetVoucherList(), this.getPayload()).subscribe(response => {
      if (response.Status === 200) {
        this.bankVoucherList = new MatTableDataSource(response.Data);
        this.loader.spin.next(false);
      }
    })
  }


  getPayload() {
    let inputParam = this.bankVoucherForm.getRawValue();
    inputParam.TransFromDate = this.commonService.convertDateToString(inputParam.TransFromDate);
    inputParam.TransToDate = this.commonService.convertDateToString(inputParam.TransToDate);
    inputParam.EntryFromDate = this.commonService.convertDateToString(inputParam.EntryFromDate);
    inputParam.EntryToDate = this.commonService.convertDateToString(inputParam.EntryToDate);

    return inputParam;
  }

  //method for canceling voucher modal
  openDeactivateModal(action) {

    if (isNullOrUndefined(this.selectedRowData)) {
      this.commonService.displayPromptMessage("Deactivate Voucher", "Please select a row first");
      return;
    }

    if (this.selectedRowData.Status === "C") {
      this.commonService.displayPromptMessage("Deactivate Voucher", "Voucher is already cancelled");
      return;
    }

    if (this.selectedRowData.Status === "P") {
      this.commonService.displayPromptMessage("Deactivate Voucher", "Voucher is already Posted, cannot cancel it");
      return;
    }

    let voucherType = this.isBankVoucher ? "Bank Voucher" : "Journal Voucher";


    this.commonService.deactivateAction("Cancel " + voucherType, `Reason For Cancellation Voucher ${this.selectedRowData.VoucherNo}`, "", "Cancel").subscribe(response => {
      if (response.Status) {
        this.commonService.confirmAction("Cancel " + voucherType, `Do you want to cancel ${voucherType} ?`).subscribe(Confresponse => {
          if (Confresponse) {
            this.loader.spin.next(true);
            this.selectedRowData.Remark = response.Remarks;
            this.selectedRowData.UserId = localStorage.getItem("UserName");
            this.http.Post(urlConstant.Voucher.DeactivateVoucher, this.selectedRowData).subscribe(apiresponse => {
              if (apiresponse.Data) {
                this.commonService.displayPromptMessage("Cancel Voucher", `${this.selectedRowData.VoucherNo} canceled successfully!`).subscribe(() => {
                  window.location.reload();
                })
              }
              else {
                this.loader.spin.next(false);
                this.commonService.displayPromptMessage("Cancel Bank Voucher", "Cancellation failed!");
              }
            })
          }
        })
      }
    });
  }

  //method for bank voucher add/edit action
  bankVoucherAction(action) {
    if (action == 'edit') {

      if (isNullOrUndefined(this.selectedRowData)) {
        this.commonService.displayPromptMessage("Voucher Edit", "Please select a row first");
        return;
      }


      if (this.selectedRowData.Status === "C") {
        this.commonService.displayPromptMessage("Voucher Edit", "Voucher is already cancelled");
        return;
      }

      if (this.selectedRowData.Status === "P") {
        this.commonService.displayPromptMessage("Voucher Edit", "Voucher is already Posted, cannot cancel it");
        return;
      }

      this.router.navigate(['/financial-account/voucher', this.docType, action, this.selectedRowData.VoucherDocNo]);
    }
    else {
      this.router.navigate(['/financial-account/voucher', this.docType, action]);
    }
  }

  // method for export to excel
  exportToExcel() {
    this.loader.spin.next(true);
    this.http.Post(urlConstant.Voucher.ExportVoucherList, this.getPayload()).subscribe(response => {
      if (response.Status === 200 && !isNullOrUndefined(response.Data)) {
        this.http.openFile(response.Data);
      }
      else {
        this.commonService.displayPromptMessage("Voucher list export", "Error in export to excel");
      }
      this.loader.spin.next(false);
    });
  }

  // method for opening creditToAccount modal
  openCreditToAccount() {
    const dialogRef = this.dialog.open(CreditToAccountModal);
    dialogRef.componentInstance.inputParam = this.getPayload();
  }

  // method for setting from to trasaction date
  setTransDate(event) {
    if (!isNullOrUndefined(event)) {
      this.f.TransFromDate.setValue(new Date(event.FromDate.value));
      this.f.TransToDate.setValue(new Date(event.ToDate.value));
    }
  }

  // method for setting from to entry date
  setEntryDate(event) {
    if (!isNullOrUndefined(event)) {
      this.f.EntryFromDate.setValue(new Date(event.FromDate.value));
      this.f.EntryToDate.setValue(new Date(event.ToDate.value));
    }
  }

  enableTransDate() {
    if (this.f.IsTransDate.value) {
      this.fromDateToDateTrans.FromDate.enable();
      this.fromDateToDateTrans.ToDate.enable();
    }
    else {
      this.fromDateToDateTrans.FromDate.disable();
      this.fromDateToDateTrans.ToDate.disable();
    }
  }

  enableEntryDate() {
    if (this.f.IsEntryDate.value) {
      this.fromDateToDateEntry.FromDate.enable();
      this.fromDateToDateEntry.ToDate.enable();
    }
    else {
      this.fromDateToDateEntry.FromDate.disable();
      this.fromDateToDateEntry.ToDate.disable();
    }
  }

  redirectToView(docNo: string) {
    this.router.navigate(['/financial-account/voucher', this.docType, 'view', docNo]);
  }

  // To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }


}
