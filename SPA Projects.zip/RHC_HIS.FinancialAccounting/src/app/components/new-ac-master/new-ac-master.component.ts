import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { pipe } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { isNullOrUndefined } from 'util';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';

@Component({
    selector: 'new-ac-master-action-dialog',
    templateUrl: 'new-ac-master.component.html',
    styleUrls: ['./new-ac-master.component.css'],
    host: { 'class': 'section__main' }
})
export class NewAccountMasterAction {

    accountMasterForm: FormGroup;
    sourceType: string = '';
    selectedRowItem: any;
    acCodeDetails: any;
    subGroupList: any;
    acCode: string;
    transactions = [
        { value: '1-', viewValue: 'Assets' },
        { value: '2-', viewValue: 'Liabilities' },
        { value: '3-', viewValue: 'Expenditures' },
        { value: '4-', viewValue: 'Income' }
    ];

    constructor(@Inject(MAT_DIALOG_DATA) public data: any,
        private dialogRef: MatDialogRef<any>,
        private formBuilder: FormBuilder, private activateroute: ActivatedRoute,
        private router: Router, private httpService: HttpService, private loader: LoaderService,
        private commonService: CommonService) { }

    ngOnInit() {
        // gets value from params
        this.activateroute.params.subscribe(params => {
            this.sourceType = params['actionType'];
            this.acCode = params['acCode'];
        });

        this.initForm();

        if (this.sourceType == 'edit')
            this.setFormData()
        else if (this.sourceType == 'view') {
            this.setFormData()
            this.accountMasterForm.disable();
        }

        this.initializeSubGroupLookup();
    }

    // init form method
    initForm() {
        this.accountMasterForm = this.formBuilder.group({
            AcCode: [{ value: (this.sourceType === 'edit' || this.sourceType === 'view') ? this.acCode : '', disabled: this.sourceType === 'edit' || this.sourceType === 'view' ? true : false }, Validators.compose([
                Validators.required, Validators.maxLength(8)
            ])],
            AcDescription: ['', Validators.compose([Validators.required, Validators.maxLength(40)])],
            ShortDescription: [, Validators.compose([Validators.required, Validators.maxLength(10)])],
            TransactionType: [''],
            AcGroupCode: [''],
            SubGroupCodeName: [''],
            MainGroupCodeName: [''],
            CashBank: ['N', Validators.required],
            AcSummary: ['S', Validators.required],
            RetainYTDTransactions: ['N', Validators.required],
            SeparateLedger: ['N', Validators.required],
            NormalBalance: ['D', Validators.required],
            CashFlowUsage: ['N', Validators.required],
            FundsApplied: ['A', Validators.required],
            ControlAccounts: ['N', Validators.required],
            UserId: [localStorage.getItem("UserName")],
            Action: [this.sourceType]
        });
    }

    // method get all form control values
    get f() { return this.accountMasterForm.controls; }

    // method to set data in form
    setFormData() {
        this.loader.spin.next(true);
        this.httpService.Get(urlConstant.AccountMaster.GetAcCodeDetails(this.acCode)).subscribe(response => {
            if (response.Status === 200 && response.Data) {
                this.acCodeDetails = response.Data[0];
                this.f.AcCode.setValue(this.acCodeDetails.AcCode);
                this.f.AcDescription.setValue(this.acCodeDetails.AcDescription);
                this.f.ShortDescription.setValue(this.acCodeDetails.ShortDescription);
                this.f.TransactionType.setValue(this.acCodeDetails.TransactionType);
                this.f.AcGroupCode.setValue(this.acCodeDetails.AcGroupCode);
                this.f.SubGroupCodeName.setValue(this.acCodeDetails.SubGroupCode + ' ' + this.acCodeDetails.SubGroupName);
                this.f.MainGroupCodeName.setValue(this.acCodeDetails.GroupCode + ' ' + this.acCodeDetails.GroupName);
                this.f.CashBank.setValue(this.acCodeDetails.CashBank);
                this.f.AcSummary.setValue(this.acCodeDetails.AcSummary);
                this.f.RetainYTDTransactions.setValue(this.acCodeDetails.RetainYTDTransactions);
                this.f.SeparateLedger.setValue(this.acCodeDetails.SeparateLedger);
                this.f.NormalBalance.setValue(this.acCodeDetails.NormalBalance);
                this.f.CashFlowUsage.setValue(this.acCodeDetails.CashFlowUsage);
                this.f.FundsApplied.setValue(this.acCodeDetails.FundsApplied);
                this.f.ControlAccounts.setValue(this.acCodeDetails.ControlAccounts);
            }
        })
        this.loader.spin.next(false);
    }

    // method for clearing main group lookup
    clearLookupSearch() {
        this.f.MainGroupCodeName.setValue("");
        this.f.SubGroupCodeName.setValue("");
    }

    // methods for initialization of sub group lookup
    initializeSubGroupLookup() {
        const waitTime = pipe(debounceTime(500));
        const distinct = pipe(distinctUntilChanged());
        this.f.SubGroupCodeName.valueChanges
            .pipe(waitTime)
            .pipe(distinct)
            .pipe(
                switchMap(text =>
                    !isNullOrUndefined(text) && text.toString().trim() !== ''
                        ? this.httpService.Get(urlConstant.AccountMaster.GetSubGroupData(text))
                        : []
                )
            )
            .subscribe(result => {
                if (result.Status === 200 && result.Data.length > 0) {
                    this.subGroupList = result.Data;
                } else {
                    this.subGroupList = [];
                    return;
                }
            });
    }

    // method for clearing sub group lookup
    clearSubGroupLookupSearch() {
        this.f.AcGroupCode.setValue("");
        this.f.SubGroupCodeName.setValue("");
        this.f.MainGroupCodeName.setValue("");
        this.subGroupList = [];
    }

    // sub group selection method setting values
    onSubGroupOptionselect(data) {
        this.f.AcGroupCode.setValue(data.SubGroupCode);
        this.f.SubGroupCodeName.setValue(data.SubGroupCode + ' ' + data.SubGroupName);
        this.f.MainGroupCodeName.setValue(data.GroupCode + ' ' + data.GroupName);
    }

    // Method for saving and editing entry
    // Author - Vinayak Savle
    saveEditAcMaster() {
        if (!this.validateData()) return;

        const inputParam = this.accountMasterForm.getRawValue();
        if (this.sourceType === 'edit') {
            this.commonService.confirmAction("Edit Account Mastser", `Do you want to update ${inputParam.AcCode} Account Master?`).subscribe(response => {
                if (response) {
                    this.loader.spin.next(true);
                    this.httpService.Post(urlConstant.AccountMaster.UpdateAcMaster(), inputParam).subscribe(response => {
                        if (response.Data) {
                            this.commonService.displayPromptMessage("Edit Account Mastser", `${inputParam.AcCode} code updated successfully!`).subscribe(response => {
                                this.loader.spin.next(false);
                                this.router.navigate(['/financial-account/ac-master']);
                            });
                        }
                        else {
                            this.loader.spin.next(false);
                            this.commonService.displayPromptMessage("New Account Master", "Record with same description already present!");
                        }
                    })
                }
            })
        }
        // if the action is new
        else {
            this.commonService.confirmAction("New Account Master", `Do you want to save ${inputParam.AcCode} Account Master ?`).subscribe(response => {
                if (response) {
                    this.loader.spin.next(true);
                    this.httpService.Post(urlConstant.AccountMaster.InsertNewAcMaster(), inputParam).subscribe(response => {
                        if (response.Data) {
                            this.commonService.displayPromptMessage("New Account Master", `${inputParam.AcCode} code created successfully!`).subscribe(response => {
                                this.router.navigate(['/financial-account/ac-master']);
                            });
                        }
                        else {
                            this.loader.spin.next(false);
                            this.commonService.displayPromptMessage("New Account Master", "Record with same code/description already present!");
                        }
                    })
                }
            })
        }
    }

    validateData(): boolean {
        if (!this.commonService.isValidStringValue(this.f.AcGroupCode.value)) {
            this.commonService.displayPromptMessage("New Account Master", "SubGroup A/C Code/Name is not valid");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.AcCode.value)) {
            this.commonService.displayPromptMessage("New Account Master", "Account Code should not be empty");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.AcDescription.value)) {
            this.commonService.displayPromptMessage("New Account Master", "Account Name should not be empty");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.ShortDescription.value)) {
            this.commonService.displayPromptMessage("New Account Master", "Short Description should not be empty");
            return false;
        }

        return true;
    }

    // reset
    cancel() {
        this.commonService.confirmAction("New Account Master", "Do you want to reset all the details?")
            .subscribe(res => {
                if (res) {
                    window.location.reload();
                } else {
                    return;
                }
            });
    }

    // method to go back to list page
    backToList() {
        this.router.navigate(['financial-account/ac-master']);
    }

}