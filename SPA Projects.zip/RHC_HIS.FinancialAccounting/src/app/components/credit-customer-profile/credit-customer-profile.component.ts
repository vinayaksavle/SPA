import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { MatDialog, MatSort, MatTableDataSource } from '@angular/material';
import { FromDateToDateComponent } from 'from-date-to-date';
import { debounceTime, distinctUntilChanged, retryWhen } from 'rxjs/operators';
import { pipe } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { isNullOrUndefined } from 'util';
import { urlConstant } from 'src/app/constants/urlConstants';
import { ParseDate } from 'shared-utility';
import { CreditCustomerProfilePopUp, DialogModel } from './credit-customer-profile-popup.component';

@Component({
    selector: 'app-credit-customer-profile',
    templateUrl: 'credit-customer-profile.component.html',
    styleUrls: ['./credit-customer-profile.component.css'],
    host: { 'class': 'section__main' }
})

export class CreditCustomerProfile {
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('fromDateToDate') fromDateToDate: FromDateToDateComponent;
    selectedRowData: any;
    selectedRowIndex: number = -1;
    filteredDataBill: MatTableDataSource<any> = new MatTableDataSource();
    filteredDataReceipt: MatTableDataSource<any> = new MatTableDataSource();
    filteredDataPending: MatTableDataSource<any> = new MatTableDataSource();
    action: string;
    rowdetails: any;
    voucherCode;
    CCProfile: FormControl;
    ViewType: FormControl;
    View = [
        { value: 'all', viewValue: 'ALL' },
        { value: 'bill', viewValue: 'BILLS' },
        { value: 'pending', viewValue: 'PENDING' },
        { value: 'recp', viewValue: 'RECIPITS' }
    ];
    filteredOptionsCcP = [];
    pendingAmount = 0.00;
    pendingBillAmount = 0.00;
    periodAmount = 0.00;
    periodReceiptAmount = 0.00;
    displayedColumnsForBill = ["SrNo", "BillNo", "BillDate", "RegNo", "PatientName", "BillAmount", "ReceivedAmount"];
    displayedColumnsForPending = ["SrNo", "BillNo", "BillDate", "RegNo", "PatientName", "BillAmount", "ReceivedAmount", "Concession", "PendingAmount"];
    displayedColumnsForReceipt = ["SrNo", "ReceiptNo", "ReceiptDate", "ChequeNo", "ChequeDate", "Amount", "BillNo", "BillDate"];
    code: any;
    index = -1;
    constructor(private http: HttpService, private commonService: CommonService, private fb: FormBuilder, private loader: LoaderService, private dialog: MatDialog) { }

    ngOnInit() {
        this.init(this.fromDateToDate);
    }

    init(fromDateToDate) {

        this.filteredDataBill = new MatTableDataSource([]);
        this.filteredDataReceipt = new MatTableDataSource([]);
        this.filteredDataPending = new MatTableDataSource([]);
        this.CCProfile = new FormControl();
        this.ViewType = new FormControl('all');
        fromDateToDate.FromDate.setValue(new Date());
        fromDateToDate.ToDate.setValue(new Date());

        const waitTime = pipe(debounceTime(200));
        const distinct = pipe(distinctUntilChanged());

        this.CCProfile.valueChanges.pipe(waitTime).pipe(distinct).pipe(switchMap(text =>
            !isNullOrUndefined(text) && text.toString().trim() !== ''
                ? this.http.Get(urlConstant.GetCreditCustProfile(text)) : this.filteredOptionsCcP = []))
            .subscribe(result => {
                this.filteredOptionsCcP = result.Data;
            });
    }

    setAmountToBlank() {
        this.pendingAmount = 0.00;
        this.pendingBillAmount = 0.00;
        this.periodAmount = 0.00;
        this.periodReceiptAmount = 0.00;
    }

    // method for search results
    billResults(fromDateToDate) {
        this.loader.spin.next(true);
        this.setAmountToBlank();
        this.filteredDataBill = new MatTableDataSource();
        this.http.Get(urlConstant.GetCustomerBillDetail(new ParseDate().transform(fromDateToDate.FromDate.value), new ParseDate().transform(fromDateToDate.ToDate.value), this.code)).subscribe(result => {
            if (result && result.Status === 200 && result.Data.length > 0) {
                this.filteredDataBill = new MatTableDataSource(result.Data);
                this.pendingBillAmount = result.Data[0].PendingNETAmount;
                this.loader.spin.next(false);
            } else {
                this.loader.spin.next(false);
            }
        });
    }

    receiptResults(fromDateToDate) {
        this.index = -1;
        this.loader.spin.next(true);
        this.setAmountToBlank();
        this.filteredDataReceipt = new MatTableDataSource();
        this.http.Get(urlConstant.GetCustomerReceiptDetail(new ParseDate().transform(fromDateToDate.FromDate.value), new ParseDate().transform(fromDateToDate.ToDate.value), this.code)).subscribe(result => {
            if (result && result.Status === 200 && result.Data.length > 0) {
                this.filteredDataReceipt = new MatTableDataSource(result.Data);
                this.periodReceiptAmount = result.Data[0].PendingNETAmount;
                this.loader.spin.next(false);
            } else {
                this.loader.spin.next(false);
            }
        });
    }

    pendingResults() {
        this.loader.spin.next(true);
        this.setAmountToBlank();
        this.filteredDataPending = new MatTableDataSource();
        this.http.Get(urlConstant.GetCustomerPendingBillDetail(this.code)).subscribe(result => {
            if (result && result.Status === 200 && result.Data.length > 0) {
                this.filteredDataPending = new MatTableDataSource(result.Data);
                this.periodAmount = result.Data[0].PendingNETAmount;
                this.loader.spin.next(false);
            } else {
                this.loader.spin.next(false);
            }
        });
    }

    getCCProfileList(fromDateToDate) {

        if (!this.commonService.isValidStringValue(this.CCProfile.value)) {
            this.commonService.displayPromptMessage("Credit Customer Profile", "Please enter Company Code!");
            return;
        }

        if (this.ViewType.value === 'all' && this.commonService.isValidStringValue(this.CCProfile.value)) {
            this.billResults(fromDateToDate);
            this.receiptResults(fromDateToDate);
            this.pendingResults();
        } else if (this.ViewType.value === 'bill' && this.commonService.isValidStringValue(this.CCProfile.value)) {
            this.billResults(fromDateToDate);
        } else if (this.ViewType.value === 'recp' && this.commonService.isValidStringValue(this.CCProfile.value)) {
            this.receiptResults(fromDateToDate);
        } else if (this.ViewType.value === 'pending' && this.commonService.isValidStringValue(this.CCProfile.value)) {
            this.pendingResults();
        } else {
            document.getElementById('ccp').focus();
            this.commonService.openSnackBar('Invalid Form', 'Ok');
            return;
        }
    }

    // method for export to Excel
    exportToExcel(fromDateToDate) {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.CreditCustomerProfileExcel(new ParseDate().transform(fromDateToDate.FromDate.value), new ParseDate().transform(fromDateToDate.ToDate.value), this.code, this.ViewType.value)).subscribe(res => {
            if (res.Status == 200 && res.Data.length > 0) {
                res.Data.forEach(
                    x => {
                        this.http.openFile(x);
                    }
                )
                this.loader.spin.next(false);
            }
            else {
                this.loader.spin.next(false);
                this.commonService.displayPromptMessage("Error", "No record found");
            }
        }, (error) => {
            console.log(error);
        });
    }

    setActiveServiceRow(index, row) {
        if (this.index === index) {
            this.index = -1;
        } else {
            this.index = index;
            const dialogData = new DialogModel(
                row.ReceiptNo
            );
            const dialogRef = this.dialog.open(CreditCustomerProfilePopUp, {
                width: '1200px',
                data: dialogData,
                disableClose: false
            });
            return dialogRef.afterClosed();
        }
    }

    // method for setting control code
    setCustomerCode(event) {
        this.code = event.Code;
    }

    setValueOnTab() {
        setTimeout(() => {
            let firstValue = this.filteredOptionsCcP[0];
            if (!isNullOrUndefined(firstValue)) {
                this.CCProfile.setValue(firstValue.Code + ' ' + firstValue.Name);
                this.code = firstValue.Code;
            }
        }, 500);
    }

    clearLookupSearch() {
        this.CCProfile.setValue('');
    }
}