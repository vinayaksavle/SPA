import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
    selector: 'app-credit-customer-profile-popup',
    templateUrl: 'credit-customer-profile-popup.component.html',
    styleUrls: ['./credit-customer-profile.component.css'],
})
export class CreditCustomerProfilePopUp {
    @ViewChild(MatSort) sort: MatSort;
    selectedRowData: any;
    selectedRowIndex: number = -1;
    filteredData: MatTableDataSource<any> = new MatTableDataSource();
    action: string;
    rowdetails: any;

    displayedColumns = ["SrNo", "BillNo", "BillDate", "RegNo", "BillAmount", "ReceivedAmount"];
    pendingBillAmount = 0.00;
    Net = 0.00;

    constructor(private http: HttpService, private commonService: CommonService,
        @Inject(MAT_DIALOG_DATA) public data: DialogModel,
        private loader: LoaderService, private dialogRef: MatDialogRef<CreditCustomerProfilePopUp>) { }

    ngOnInit() {
        this.getData();
    }

    getData() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.GetReceiptNoData(this.data.receiptNo)).subscribe(result => {
            if (result && result.Status === 200 && result.Data.length > 0) {
                this.filteredData = new MatTableDataSource(result.Data);
                this.Net = result.Data[0].TotalBillAmount;
                this.pendingBillAmount = result.Data[0].PendingNETAmount;
                this.loader.spin.next(false);
            } else {
                this.loader.spin.next(false);
            }
        });
    }

    close() {
        this.dialogRef.close();
    }


}


export class DialogModel {

    constructor(public receiptNo: string) {
    }
}