import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-not-authorized',
  templateUrl: './not-authorized.component.html',
  styleUrls: ['./not-authorized.component.css'],
  host: { 'class': 'section__main' }
})
export class NotAuthorizedComponent implements OnInit {

  constructor(private router: Router ) { }

  ngOnInit() {
  }

  backButton() {
    this.router.navigate(['/dashboard']);
  }

}
