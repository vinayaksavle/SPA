import { Component, OnInit, ɵChangeDetectorStatus } from '@angular/core';
import { DataTranferService } from '../../../services/data-transfer.service';
import { Router } from '@angular/router';
import { isNullOrUndefined } from 'util';

import { MatDialog, MatSnackBar } from '@angular/material';
import { AuthService } from '../../../security/auth.service';
import { HttpService } from '../../../services/http.service';
import { CommonService } from '../../../services/common.service';
import { CommonPopupService } from '../../../services/common-popup.service';
import { ConfirmDialogModel, ConfirmDialogComponent } from '../../confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  showMenu = 'true';
  OPDChangePermission: boolean;
  IPDChangePermission: boolean;
  hasOPDMOduleAccess: boolean = false;
  hasIPDMOduleAccess: boolean = false;
  hasPrinterSetupPermission: boolean = false;
  moduleId: string = "";

  constructor(public dataTransferService: DataTranferService, public dialog: MatDialog, public snackBar: MatSnackBar,
    public auth: AuthService, public _httpService: HttpService, public commonService: CommonService, public popupService: CommonPopupService) { }

  ngOnInit(): void {
    let modules = JSON.parse(localStorage.getItem('moduleId'));
    this.hasOPDMOduleAccess = modules.indexOf("02") > -1;
    this.hasIPDMOduleAccess = modules.indexOf("01") > -1;
    // this.hasPrinterSetupPermission = this.dataTransferService.checkAccessRights('0215');
    this.hasPrinterSetupPermission = true;
  }

  logout(): void {
    localStorage.clear();
    this.dataTransferService.setlogin(false);
    this.dataTransferService.Logout();
    this.auth.logout();
  }

  getUserName(): string {
    return localStorage.getItem('UserName');
  }

  getFacilityName(): string {
    const facilityId = localStorage.getItem('Facility');
    let facilityName = '';
    if (facilityId === '001') {
      facilityName = 'Ruby Hall Clinic Main';
    } else if (facilityId === '002') {
      facilityName = 'Ruby Hall Clinic Wanowrie';
    } else if (facilityId === '003') {
      facilityName = 'Ruby Hall Clinic Hinjewadi';
    }
    return facilityName;
  }

  toggleLeftNav() {
    this.showMenu = sessionStorage.getItem('showMenu');
    if (this.showMenu === 'true') {
      sessionStorage.setItem('showMenu', 'false');
      document.querySelector('.section__sidenav').classList.add('show');
      document.querySelector('.section__main').classList.add('full');
    } else if (this.showMenu === 'false') {
      sessionStorage.setItem('showMenu', 'true');
      document.querySelector('.section__sidenav').classList.remove('show');
      document.querySelector('.section__main').classList.remove('full');
    }
  }


  Download() {
    this._httpService.openFile("Downloads\\Installer_V_0.bat");
  }


  // call change opd component
  changeOPD() {
    // User Permissions
    // this.popupService.changeOPD("R");
  }

  // call change ipd component
  changeIPD() {
    // User Permissions
    // this.popupService.changeIPD("R");
  }


  // opens snack bar
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 5000,
    });
  }


  // Common method for form confirm dialog box
  confirmAction(actionName: string, actionDescription: string) {
    const dialogData = new ConfirmDialogModel(actionName, actionDescription, "Yes", "No");

    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      width: "400px",
      data: dialogData,
      disableClose: true

    });
    return dialogRef.afterClosed()
  }


  changeModule() {
    window.location.href = location.origin + '/#/dashboard';
  }


}
