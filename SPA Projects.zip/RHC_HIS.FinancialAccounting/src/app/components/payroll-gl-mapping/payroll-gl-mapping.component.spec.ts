import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayrollGlMappingComponent } from './payroll-gl-mapping.component';

describe('PayrollGlMappingComponent', () => {
  let component: PayrollGlMappingComponent;
  let fixture: ComponentFixture<PayrollGlMappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayrollGlMappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayrollGlMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
