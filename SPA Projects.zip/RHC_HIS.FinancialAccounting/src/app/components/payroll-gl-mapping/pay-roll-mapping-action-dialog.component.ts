import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material';
import { AcMasterLibComponent } from 'ac-master-lib';
import { CostCentreLibComponent, CostCentreLibModule } from 'cost-centre-lib';
import { pipe } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';
import { CostCenterActionDialog } from '../cost-center/cost-center-action.component';

@Component({
  selector: 'app-pay-roll-mapping-action-dialog',
  templateUrl: './pay-roll-mapping-action-dialog.component.html',
  styleUrls: ['./payroll-gl-mapping.component.css']
})
export class PayRollMappingActionDialogComponent implements OnInit {

  action: string;
  rowdetails: any;
  payRollGLMapForm: FormGroup;
  costCenterList: any[];
  @ViewChild('libGLCode') libGLCode: AcMasterLibComponent;
  @ViewChild('libCostCenter') libCostCenter: CostCentreLibComponent
  waitTime = pipe(debounceTime(200));
  distinct = pipe(distinctUntilChanged());
  constructor(private dialogRef: MatDialogRef<CostCenterActionDialog>, private http: HttpService, private commonService: CommonService, private fb: FormBuilder, private loader: LoaderService) {

  }

  ngOnInit() {
    this.initForm();
    if (this.action == 'edit') {
      this.setFormData();
    } else {
      return;
    }
  }

  initForm() {
    this.payRollGLMapForm = this.fb.group({
      DepartmentCode: ['', [Validators.required, Validators.maxLength(4)]],
      DepartmentDesc: ['', [Validators.required, Validators.maxLength(40)]],
      UserId: [localStorage.getItem("UserName")],
      CostCenterCode: ['', Validators.required],
      GLCode: ['', Validators.required]
    });
    this.libGLCode.clearLookupSearch();
  }

  // Function to return form controls
  get f() {
    return this.payRollGLMapForm.controls;
  }

  setGLCodeValue(event) {
    this.f.GLCode.setValue(event.Code);
  }
  setCostCenterCodeValue(event) {
    this.f.CostCenterCode.setValue(event.Code);
  }

  setFormData() {
    this.payRollGLMapForm.patchValue({
      'DepartmentCode': this.rowdetails.DepartmentCode,
      'DepartmentDesc': this.rowdetails.DepartmentDesc,
      'CostCenterCode': this.rowdetails.CostCenterCode,
      'GLCode': this.rowdetails.GLCode
    });
    this.libGLCode.inputValue.setValue(this.rowdetails.GLCode + ' ' + this.rowdetails.GLDescription);
    this.libCostCenter.inputValue.setValue(this.rowdetails.CostCenterCode + ' ' + this.rowdetails.CostCenterDesc);
    this.f.DepartmentCode.disable();    
    //this.libGLCode.disableEvent();
  }

  // method to post the pay roll gl map details
  savePayrollDetails() {
    let obj = this.payRollGLMapForm.getRawValue();
    console.log(obj);
    if (!this.validateForm(obj)) {
      return;
    } else {
      // url configuration according to action
      let url: string;
      url = this.action == 'new' ? urlConstant.PayrollGLMappingMaster.SavePayrollDetails : urlConstant.PayrollGLMappingMaster.EditPayrollDetails

      this.commonService.confirmAction("Confirmation", "Do you want to save this Pay Roll GL Mapping?").subscribe(
        response => {
          if (response) {
            this.loader.spin.next(true);
            this.http.Post(url, obj).subscribe(
              res => {
                if (res.Status == 200 && res.Data) {
                  this.loader.spin.next(false);
                  this.commonService.displayPromptMessage(`${this.action == 'new' ? 'New' : 'Edit'} Pay Roll Gl Mapping`, "Details saved successfully!").subscribe(res => {
                    if (res) {
                      this.initForm();
                      this.dialogRef.close(true);
                    }
                  });

                } else {
                  this.loader.spin.next(false);
                  this.commonService.displayPromptMessage("Error", "Duplicate Department Code or Description");
                }
              });
          } else {
            return;
          }
        });
    }
  }
  validateForm(obj: any): boolean {
    if (this.payRollGLMapForm.invalid) {
      const controls = this.payRollGLMapForm.controls;
      for (const name in controls) {
        if (controls[name].invalid) {
          if (
            name === "DepartmentCode" ||
            name === "DepartmentDesc" ||
            name === "CostCenterCode" ||
            name === "GLCode"
          ) {
            (<any>this.f[name]).nativeElement.focus();
            this.commonService.openSnackBar(name + " is invalid", "Ok");
            return false;
          }
        }
      }
    } else {
      return true;
    }
  }

  // method for closing dialog
  cancel() {
    this.dialogRef.close();
  }

}
