import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatSort, MatTableDataSource } from '@angular/material';
import { Router } from '@angular/router';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';
import { PayRollMappingActionDialogComponent } from './pay-roll-mapping-action-dialog.component';

@Component({
  selector: 'app-payroll-gl-mapping',
  templateUrl: './payroll-gl-mapping.component.html',
  styleUrls: ['./payroll-gl-mapping.component.css'],
  host: { 'class': 'section__main' }

})
export class PayrollGlMappingComponent {

  @ViewChild(MatSort) sort: MatSort;
  selectedRowData: any;
  selectedRowIndex: number = -1;
  payrollGLMappingList: MatTableDataSource<any> = new MatTableDataSource();
  displayedColumns = ["SrNo", "DepartmentCode", "DepartmentDesc", "GLCode", "GLDescription",  "CostCenterCode", "CostCenterDesc", "LastUpdatedBy", "LastUpdatedDateTime"];

  constructor(private http: HttpService, private loader: LoaderService, private commonService: CommonService,
    private router: Router,private dialog:MatDialog) {
    this.getPayrollGLMappingList();
  }

  // Get the initial list of payroll gl mapping
  getPayrollGLMappingList() {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.PayrollGLMappingMaster.GetPayrollGLMappingListUrl).subscribe(res => {
      if (res.Status == 200 && res.Data.length > 0) {
        this.payrollGLMappingList = new MatTableDataSource(res.Data);
        this.payrollGLMappingList.sort = this.sort;
        this.loader.spin.next(false);
      }
      else {
        this.loader.spin.next(false);
        this.commonService.displayPromptMessage("Error", "No record found");
      }
    }, (error) => {
      console.log(error);
    })
  }

  // filters the table 
  public filterList = (value: string) => {
    this.payrollGLMappingList.filter = value.trim().toLocaleLowerCase();
  }

  // To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }

  // export to excel
  exportToExcel() {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.PayrollGLMappingMaster.ExportToExcelUrl).subscribe(res => {
      if (res.Status == 200 && res.Data.length > 0) {
        this.http.openFile(res.Data);
        this.loader.spin.next(false);
      }
      else {
        this.loader.spin.next(false);
        this.commonService.displayPromptMessage("Error", "No record found");
      }
    }, (error) => {
      console.log(error);
    })
  }

  // Validations
  validateData(action: string): boolean {
    if (action === 'edit' ) {
      if (isNullOrUndefined(this.selectedRowData)) {
        this.commonService.openSnackBar(`Please select row first`, "Ok");
        return false;
      }
    }
    return true; 
  }

  // Method to open dialog modal(edit/new)
  openActionModal(action: string) {
    if (!this.validateData(action)) return;
    const dialogRef = this.dialog.open(PayRollMappingActionDialogComponent);
    dialogRef.componentInstance.action = action;
    dialogRef.componentInstance.rowdetails = this.selectedRowData;
    dialogRef.updateSize("1024px","300px");
    dialogRef.afterClosed().subscribe(res=>{
      if(res){
        this.getPayrollGLMappingList();
      } else{
        return;
      }
    })
  }
  // navigate to Deduction Code GL Mapping Component
  navigateToDeductionCode(){
    this.router.navigate(["/financial-account/deduction-code-gl-mapping"]);
  }

}
