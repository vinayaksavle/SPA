import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { pipe } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { isNullOrUndefined } from 'util';
import { MainGroupLookupComponent } from 'main-group-lookup';

@Component({
    selector: 'sub-group-action-dialog',
    templateUrl: 'sub-group-action.component.html',
    styleUrls: ['./sub-group-master.component.css'],
})
export class SubGroupActionDialog {
    @ViewChild('mainGroupCodeName') mainGroupCodeName: MainGroupLookupComponent;
    action: string;
    rowdetails: any;
    mainGroupList: any;
    subGroupForm: FormGroup;

    constructor(private dialogRef: MatDialogRef<SubGroupActionDialog>, private http: HttpService, private commonService: CommonService, private fb: FormBuilder, private loader: LoaderService) { }

    ngOnInit() {
        this.initForm();
        // setting values using library
        if (this.action === 'new')
            this.mainGroupCodeName.inputValue.setValue('');
        else
            this.mainGroupCodeName.inputValue.setValue(this.rowdetails.MainGroupCode + ' ' + this.rowdetails.MainGroupName);

        //this.initializeSubGroupLookup();
    }

    initForm() {
        this.subGroupForm = this.fb.group({
            SubGroupCode: [{ value: this.action === 'edit' ? this.rowdetails.SubGroupCode : '', disabled: this.action === 'edit' ? true : false }, [Validators.required, Validators.maxLength(2)]],
            SubGroupName: [this.action === 'edit' ? this.rowdetails.SubGroupName : '', Validators.required],
            MainGroupCode: [this.action === 'edit' ? this.rowdetails.MainGroupCode : '', Validators.required],
            UserId: [localStorage.getItem("UserName")]
        });
    }

    // method get all form control values
    get f() { return this.subGroupForm.controls; }

    // Save or Edit Sub Group Code
    saveEditSubGroupCode() {
        if (!this.validateData()) return;

        const inputParam = this.subGroupForm.getRawValue();
        if (this.action === 'edit') {
            this.commonService.confirmAction("Edit Sub Group Code", `Do you want to update ${inputParam.SubGroupCode} Sub Group Code?`).subscribe(response => {
                if (response) {
                    this.loader.spin.next(true);
                    this.http.Post(urlConstant.SubGroupMaster.UpdateSubGroup(), inputParam).subscribe(response => {
                        if (response.Data) {
                            this.commonService.displayPromptMessage("Edit Sub Group Code", `${inputParam.SubGroupCode} code updated successfully!`).subscribe(response => {
                                window.location.reload();
                            });
                        }
                        else {
                            this.loader.spin.next(false);
                            this.commonService.openSnackBar("Record with same Description already exists!", "Ok");
                        }
                    })
                }
                else {
                    this.cancel();
                }
            })
        }
        // if the action is new
        else {
            this.commonService.confirmAction("New Sub Group Code", `Do you want to save ${inputParam.SubGroupCode} Sub Group Code ?`).subscribe(response => {
                if (response) {
                    this.loader.spin.next(true);
                    this.http.Post(urlConstant.SubGroupMaster.InsertNewSubGroup(), inputParam).subscribe(response => {
                        if (response.Data) {
                            this.commonService.displayPromptMessage("New Sub Group Code", `${inputParam.SubGroupCode} code created successfully!`).subscribe(response => {
                                window.location.reload();
                            });
                        }
                        else {
                            this.loader.spin.next(false);
                            this.commonService.displayPromptMessage("New Sub Group Code", "Record with same code/name already exists!");
                        }
                    })
                }
                else {
                    this.cancel();
                }
            })
        }
    }

    // Validations
    validateData(): boolean {
        if (!this.commonService.isValidStringValue(this.f.SubGroupCode.value)) {
            this.commonService.openSnackBar("Sub Group Code should not be empty", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.SubGroupName.value)) {
            this.commonService.openSnackBar("Description should not be empty", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.MainGroupCode.value)) {
            this.commonService.openSnackBar("Main Code should not be empty", "Ok");
            return false;
        }
        return true;
    }

    // method for closing dialog
    cancel() {
        this.dialogRef.close();
    }

    setMainGroupCodeName(event: any) {
        this.f.MainGroupCode.setValue(event.Code);
    }

}