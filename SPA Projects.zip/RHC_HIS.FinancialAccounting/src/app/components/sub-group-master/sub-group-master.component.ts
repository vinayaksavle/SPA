import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MatSort, MatTableDataSource } from '@angular/material';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { CommonService } from 'src/app/services/common.service';
import { isNullOrUndefined } from 'util';
import { urlConstant } from 'src/app/constants/urlConstants';
import { SubGroupActionDialog } from './sub-group-action.component';

@Component({
  selector: 'app-sub-group-master',
  templateUrl: 'sub-group-master.component.html',
  styleUrls: ['./sub-group-master.component.css'],
  host: { 'class': 'section__main' }
})
export class SubGroupMaster {
  @ViewChild(MatSort) sort: MatSort;
  selectedRowData: any;
  selectedRowIndex: number = -1;
  subGroupList: MatTableDataSource<any> = new MatTableDataSource();
  displayedColumns = ['SrNo', 'SubGroupCode', 'SubGroupName', 'MainGroupCode', 'MainGroupName', 'ModifiedBy', 'ModifiedOn', 'Remarks'];

  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private dialog: MatDialog,
    private formBuilder: FormBuilder,
    private activateroute: ActivatedRoute,
    private http: HttpService,
    private loader: LoaderService,
    private commonService: CommonService) { }

  ngOnInit() {
    this.getSubGroupList();
  }

  // method for getting sub group code list
  getSubGroupList() {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.SubGroupMaster.GetSubGroupList()).subscribe(response => {
      if (response.Status === 200) {
        this.subGroupList = new MatTableDataSource(response.Data);
        this.subGroupList.sort = this.sort;
      }
      this.loader.spin.next(false);
    })
  }

  // method for export to excel
  exportToExcel() {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.SubGroupMaster.ExportToExcel()).subscribe(response => {
      if (response.Status === 200 && !isNullOrUndefined(response.Data)) {
        this.http.openFile(response.Data);
      }
      else {
        this.commonService.openSnackBar("Error in export to excel", "Ok");
      }
      this.loader.spin.next(false);
    });
  }

  // general filter method
  filterList(value) {
    this.subGroupList.filter = value.trim().toLocaleLowerCase();
  }

  // Method to open deactivate modal
  openDeactivateModal(action: string) {
    if (!this.validateData(action)) return;

    this.commonService.deactivateAction("Deactivate Sub Group Code", `Reason For Deactivate ${this.selectedRowData.SubGroupCode}`, "").subscribe(response => {
      if (response.Status) {
        this.selectedRowData.Remarks = response.Remarks;
        this.selectedRowData.UserId = localStorage.getItem("UserName");
        this.commonService.confirmAction("Deactivate Sub Group Code", `Do you want to deactivate ${this.selectedRowData.SubGroupCode} Sub Group Code ?`).subscribe(response => {
          if (response) {
            this.loader.spin.next(true);
            this.http.Post(urlConstant.SubGroupMaster.DeactivateSubGroupCode(), this.selectedRowData).subscribe(response => {
              if (response.Data) {
                this.commonService.displayPromptMessage("Deactivate Sub Group Code", `${this.selectedRowData.SubGroupCode} deactivated successfully!`).subscribe(() => {
                  window.location.reload();
                })
              }
              else {
                this.loader.spin.next(false);
                this.commonService.displayPromptMessage("Deactivate Sub Group Code", `${this.selectedRowData.SubGroupCode} Sub Group Code already in use, cannot deactivate!`);
              }
            })
          }
        })
      }
    });

  }

  // Method to open action modal(edit/new)
  openActionModal(action: string) {
    if (action == 'edit')
      if (!this.validateData(action)) return;

    const dialogRef = this.dialog.open(SubGroupActionDialog);

    dialogRef.componentInstance.action = action;
    dialogRef.componentInstance.rowdetails = this.selectedRowData;
  }

  // Validations
  validateData(action: string): boolean {
    if (action === 'edit') {
      if (isNullOrUndefined(this.selectedRowData)) {
        this.commonService.openSnackBar(`Please select row first`, "Ok");
        return false;
      }
    }

    if (action === 'edit' || action === 'deactivate') {
      if (this.selectedRowData.Status === 'C') {
        this.commonService.openSnackBar("Sub Group Code is deactivate", "Ok");
        return false;
      }
    }

    return true;
  }

  // To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;
    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }
}