import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { AcMasterLibComponent } from 'ac-master-lib';
import { error } from 'protractor';
import { pipe } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';

@Component({
    selector: 'app-new-store-gl-mapping',
    templateUrl: './new-store-code-gl-mapping.component.html',
    styleUrls: ['./new-store-code-gl-mapping.component.css'],
    host: { 'class': 'section__main' }
})
export class NewStoreGlMappingComponent implements OnInit {
    @ViewChild('salesAcCode') salesAcCode: AcMasterLibComponent;
    @ViewChild('purchaseAcCode') purchaseAcCode: AcMasterLibComponent;
    @ViewChild('cashAcCode') cashAcCode: AcMasterLibComponent;
    @ViewChild('drugRefundAcCode') drugRefundAcCode: AcMasterLibComponent;
    @ViewChild('billInProcessAcCode') billInProcessAcCode: AcMasterLibComponent;
    @ViewChild('staffChargeAcCode') staffChargeAcCode: AcMasterLibComponent;
    @ViewChild('staffNonChargeAcCode') staffNonChargeAcCode: AcMasterLibComponent;
    sourceType: string;
    storeId: string;
    newStoreGlForm: FormGroup;

    constructor(private http: HttpService, private commonService: CommonService,
        private fb: FormBuilder, private loader: LoaderService, private router: Router,
        private activateroute: ActivatedRoute) { }

    ngOnInit() {
        this.activateroute.params.subscribe(params => {
            this.sourceType = params['actionType'];
            this.storeId = params['storeCode'];
        });
        this.initForm();
        this.getDetailsById();
    }

    // method to init form
    initForm() {
        this.newStoreGlForm = this.fb.group({
            StoreCode: [{ value: '', disabled: true }, Validators.compose([
                Validators.required, Validators.maxLength(2)])],
            StoreCodeDescription: [{ value: '', disabled: true }, Validators.compose([
                Validators.required, Validators.maxLength(10)])],
            SalesAcCode: ['', Validators.required],
            PurchaseAcCode: ['', Validators.required],
            CashAcCode: ['', Validators.required],
            DrugRefundAcCode: ['', Validators.required],
            BillInProcessAcCode: ['', Validators.required],
            StaffChargeAcCode: ['', Validators.required],
            StaffNonChargeAcCode: ['', Validators.required],
            UserId: [localStorage.getItem("UserName")],
            Action: [this.sourceType]
        });
    }

    // method get all form control values
    get f() { return this.newStoreGlForm.controls; }

    // method to get store code details by store code
    getDetailsById() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.StoreCode.GetStoreCodeDetails(this.storeId)).subscribe(response => {
            if (response.Status === 200 && response.Data) {
                console.log(response.Data[0]);
                this.setStoreCodeDetails(response.Data[0]);
                this.loader.spin.next(false);
            }
        })
    }

    // set store code details
    setStoreCodeDetails(store: any) {
        this.f.StoreCode.setValue(store.StoreCode);
        this.f.StoreCodeDescription.setValue(store.StoreCodeDescription);
        this.f.SalesAcCode.setValue(store.SalesAcCode);
        this.salesAcCode.inputValue.setValue(store.SalesAcCode + ' ' + store.SalesAcDescription);
        this.f.PurchaseAcCode.setValue(store.PurchaseAcCode);
        this.purchaseAcCode.inputValue.setValue(store.PurchaseAcCode + ' ' + store.PurchaseAcDescription);
        this.f.CashAcCode.setValue(store.CashAcCode);
        this.cashAcCode.inputValue.setValue(store.CashAcCode + ' ' + store.CashAcDescription);
        this.f.DrugRefundAcCode.setValue(store.DrugRefundAcCode);
        this.drugRefundAcCode.inputValue.setValue(store.DrugRefundAcCode + ' ' + store.DrugRefundAcDescription);
        this.f.BillInProcessAcCode.setValue(store.BillInProcessAcCode);
        this.billInProcessAcCode.inputValue.setValue(store.BillInProcessAcCode + ' ' + store.BillInProcessAcDescription);
        this.f.StaffChargeAcCode.setValue(store.StaffChargeAcCode);
        this.staffChargeAcCode.inputValue.setValue(store.StaffChargeAcCode + ' ' + store.StaffChargeAcDescription);
        this.f.StaffNonChargeAcCode.setValue(store.StaffNonChargeAcCode);
        this.staffNonChargeAcCode.inputValue.setValue(store.StaffNonChargeAcCode + ' ' + store.StaffNonChargeAcDescription);

        if (this.sourceType === 'view') {
            this.salesAcCode.disableEvent();
            this.purchaseAcCode.disableEvent();
            this.cashAcCode.disableEvent();
            this.drugRefundAcCode.disableEvent();
            this.billInProcessAcCode.disableEvent();
            this.staffChargeAcCode.disableEvent();
            this.staffNonChargeAcCode.disableEvent();
        }
    }

    // method to redirect back to list page
    backToList() {
        this.router.navigate(['financial-account/store-code-gl-mapping']);
    }

    // method to set SalesAcCode
    setSalesAcCode(event) {
        this.f.SalesAcCode.setValue(event.Code);
    }

    // method to set PurchaseAcCode
    setPurchaseAcCode(event) {
        this.f.PurchaseAcCode.setValue(event.Code);
    }

    // method to set CashAcCode
    setCashAcCode(event) {
        this.f.CashAcCode.setValue(event.Code);
    }

    // method to set DrugRefundAcCode
    setDrugRefundAcCode(event) {
        this.f.DrugRefundAcCode.setValue(event.Code);
    }

    // method to set BillInProcessAcCode
    setBillInProcessAcCode(event) {
        this.f.BillInProcessAcCode.setValue(event.Code);
    }

    // method to set StaffChargeAcCode
    setStaffChargeAcCode(event) {
        this.f.StaffChargeAcCode.setValue(event.Code);
    }

    // method to set StaffNonChargeAcCode
    setStaffNonChargeAcCode(event) {
        this.f.StaffNonChargeAcCode.setValue(event.Code);
    }

    // method to save edited store code 
    saveEditAcMaster() {
        if (!this.validateData()) return;

        const inputParam = this.newStoreGlForm.getRawValue();
        if (this.sourceType === 'edit') {
            this.commonService.confirmAction("Edit Store Code", `Do you want to update ${inputParam.StoreCode} Store Code?`).subscribe(response => {
                if (response) {
                    this.loader.spin.next(true);
                    this.http.Post(urlConstant.StoreCode.UpdateStoreCode(), inputParam).subscribe(response => {
                        if (response.Data) {
                            this.commonService.displayPromptMessage("Edit Store Code", `${inputParam.StoreCode} code updated successfully!`).subscribe(response => {
                                this.loader.spin.next(false);
                                this.router.navigate(['/financial-account/store-code-gl-mapping']);
                            });
                        }
                        else {
                            this.loader.spin.next(false);
                            this.commonService.openSnackBar("Error while updating!", "Ok");
                        }
                    })
                }
            })
        }

    }

    // method for validating
    validateData(): boolean {
        if (!this.commonService.isValidStringValue(this.f.StoreCode.value)) {
            this.commonService.openSnackBar("Store Code is not valid", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.PurchaseAcCode.value)) {
            this.commonService.openSnackBar("Purchase Ac Code is not valid", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.CashAcCode.value)) {
            this.commonService.openSnackBar("Cash Ac Code is not valid", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.DrugRefundAcCode.value)) {
            this.commonService.openSnackBar("Drug Refund Ac Code is not valid", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.BillInProcessAcCode.value)) {
            this.commonService.openSnackBar("Bill In Process Ac Code is not valid", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.StaffChargeAcCode.value)) {
            this.commonService.openSnackBar("Staff Charge Ac Code is not valid", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.StaffNonChargeAcCode.value)) {
            this.commonService.openSnackBar("Staff Non Charge Ac Code is not valid", "Ok");
            return false;
        }

        return true;
    }

    // reset
    cancel() {
        this.initForm();
        this.getDetailsById();
    }
}