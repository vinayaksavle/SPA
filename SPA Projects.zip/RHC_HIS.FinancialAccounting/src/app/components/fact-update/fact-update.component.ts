import { Component, OnInit, ViewChild, Inject, AfterViewInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { isNullOrUndefined } from 'util';

@Component({
    selector: 'app-fact-update',
    templateUrl: 'fact-update.component.html',
    styleUrls: ['./fact-update.component.css'],
    host: { 'class': 'section__main' }
})

export class FactUpdate implements OnInit,AfterViewInit {
    @ViewChild(MatSort) sort: MatSort;
    selectedRowData: any;
    selectedRowIndex: number = -1;
    filteredData: MatTableDataSource<any> = new MatTableDataSource();
    action: string;
    rowdetails: any;
    sourceType: string;
    voucherCode;
    permissions: any[];
    canSearch: boolean;
    canUpdate: boolean;
    TableName: FormControl;
    VoucherNo: FormControl;
    Amount: FormControl;
    displayedColumns = ["SrNo", "VoucherNo", "AccountCode", "ChargeCentreCode", "DRCR", "Amount", "Narration"];
    data: any = {};
    types = [
        { value: 'ac-code', viewValue: 'ACCOUNT CODE' },
        { value: 'cc-code', viewValue: 'CC CODE' },
        { value: 'de-cr', viewValue: 'DEBIT/CREDIT & AMOUNT' },
    ];

    DrCr = [
        { value: 'D', viewValue: 'DR' },
        { value: 'C', viewValue: 'CR' }
    ];
    CrDr: FormControl;
    Type: FormControl;
    constructor(private http: HttpService, private commonService: CommonService, private loader: LoaderService,
        private activateRoute: ActivatedRoute, private router: Router) {
        this.permissions = JSON.parse(localStorage.getItem('Permission'));
        if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
            this.canSearch = this.permissions.includes('3325T') ? true : false;
            this.canUpdate = this.permissions.includes('3326T') ? true : false;
        }
    }
    ngAfterViewInit(): void {
    }

    ngOnInit() {
        this.initForm(false);
    }

    //method to initialize seatrch form
    initForm(afterUpdate) {
        if (!afterUpdate) {
            this.TableName = new FormControl('');
            this.VoucherNo = new FormControl('');
        }
        this.Amount = new FormControl('');
        this.CrDr = new FormControl('');
        this.Type = new FormControl('');
        this.data = {};
       
        this.CrDr.disable();
    }

    // method for setting account code name
    setAccountCodeName(event) {
        this.data.NewCCCode = '';
        this.data.NewAccountCode = event.Code;
    }

    // method for setting account code name
    setCCCodeName(event) {
        this.data.NewAccountCode = '';
        this.data.NewCCCode = event.Code;
    }

    // method for cancel
    cancel() {
        this.initForm(false);
        this.data = {};
    }

    // method for updating entry
    updateEntry() {
        if (this.Type.invalid) {
            this.commonService.openSnackBar('Select Type', 'Ok');
            return;
        } else if (this.Type.value === 'ac-code' && (!this.commonService.isValidStringValue(this.data.NewAccountCode))) {
            this.commonService.openSnackBar('Select ACCode/Name', 'Ok');
            return;
        } else if (this.Type.value === 'cc-code' && (!this.commonService.isValidStringValue(this.data.NewCCCode))) {
            this.commonService.openSnackBar('Select CC Code/Name', 'Ok');
            return;
        } else if (this.Type.value === 'de-cr' && (this.CrDr.invalid || this.Amount.invalid)) {
            this.commonService.openSnackBar('Invalid amount value', 'Ok');
            return;
        } else {
            if (this.Type.value === 'de-cr') {
                this.data.NewAmount = this.Amount.value;
            }
            this.data.Type = this.Type.value;
            // this.data.NewDrCr = this.CrDr.value;
            this.data.NewDrCr = this.data.OldDrCr;
            this.data.VoucherNo = this.VoucherNo.value;
            this.data.TableName = this.TableName.value;
            this.data.UserId = localStorage.getItem("UserName");
            this.commonService.confirmAction('Fact Update', 'Do you want to update the data ?').subscribe(response => {
                if (response) {
                    this.loader.spin.next(true);
                    this.http.Post(urlConstant.UpdateAndInsertFactUpdate, this.data).subscribe(result => {
                        if (result.Data && result.Status === 200) {
                            this.loader.spin.next(false);
                            this.commonService.displayPromptMessage('Fact Update', 'Data Updated Successfully').subscribe(() => {
                                this.selectedRowIndex = -1;
                                this.searchResults();
                                this.initForm(true);
                                return;
                            });
                        }
                        else {
                            this.commonService.displayPromptMessage("Fact Update", "Error while saving!");
                            this.loader.spin.next(false);
                        }
                    });
                } else {
                    this.loader.spin.next(false);
                }
            });
        }
    }

    // method for searching results
    searchResults() {
        if (this.TableName.invalid || this.VoucherNo.invalid) {
            this.commonService.displayPromptMessage("Fact Update", "Invalid Voucher No./Table name!")
            return;
        }
        this.loader.spin.next(true);
        this.filteredData = new MatTableDataSource();
        this.http.Get(urlConstant.GetVoucherData(this.TableName.value, this.VoucherNo.value)).subscribe(result => {
            if (result.Data.length > 0) {
                this.filteredData = new MatTableDataSource(result.Data);
                this.data = result.Data[0];
                this.loader.spin.next(false);
            } else {
                this.data = {};
                this.loader.spin.next(false);
            }
        });
    }

    highlightSelectedRow(index, rowDetails) {
        this.data = rowDetails;
        if (this.selectedRowIndex == index) {
            this.selectedRowIndex = -1;
            this.data = {};
        } else {
            this.selectedRowIndex = index;
            this.CrDr.setValue(this.data.OldDrCr);
        }
    }
}