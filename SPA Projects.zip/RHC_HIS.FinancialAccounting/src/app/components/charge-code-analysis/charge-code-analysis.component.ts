import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { ParseDate } from 'shared-utility';
import { isNullOrUndefined } from 'util';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { pipe } from 'rxjs';

@Component({
    selector: 'app-charge-code-analysis',
    templateUrl: 'charge-code-analysis.component.html',
    styleUrls: ['./charge-code-analysis.component.css'],
    host: { 'class': 'section__main' }
})
export class ChargeCodeAnalysis {
    @ViewChild(MatSort) sort: MatSort;
    selectedRowData: any;
    selectedRowIndex: number = -1;
    filteredData: MatTableDataSource<any> = new MatTableDataSource();
    rowdetails: any;
    displayedColumns = ["SrNo", "ChargeCode", "ChargeCodeDesc", "Amount"];
    amount = 0.00;
    totalAmount = 0.00;
    CCODE: FormControl;
    code: any;
    chargeCode: any;
    filteredOptionsCode: any;

    constructor(private http: HttpService, private loader: LoaderService, private common: CommonService) { }

    ngOnInit() {
        this.CCODE = new FormControl('');
        this.initializeChargeCodeLookup();
    }

    initializeChargeCodeLookup() {
        const waitTime = pipe(debounceTime(200));
        const distinct = pipe(distinctUntilChanged());

        this.CCODE.valueChanges.pipe(waitTime).pipe(distinct).pipe(switchMap(text =>
            !isNullOrUndefined(text) && text.toString().trim() !== ''
                ? this.http.Get(urlConstant.GetChargeCode(text)) : this.filteredOptionsCode = [])).subscribe(result => {
                    if (result.Status === 200 && result.Data.length > 0) {
                        this.filteredOptionsCode = result.Data;
                    }
                });
    }

    // method for search 
    getChargeCodeAnalysis(date) {
        if (!isNullOrUndefined(this.code)) {
            this.loader.spin.next(true);
            // this.selectedRowIndex = -1;
            this.http.Get(urlConstant.ChargeCodeData(new ParseDate().transform(date.FromDate.value), new ParseDate().transform(date.ToDate.value), this.code, this.chargeCode)).subscribe(result => {
                if (result.Data.length > 0 && result.Status === 200) {
                    this.filteredData = new MatTableDataSource(result.Data);
                    this.totalAmount = result.Data[0].TotalAmount;
                    this.amount = result.Data[0].TotalChargeAmount;
                    this.loader.spin.next(false);
                } else {
                    this.filteredData = new MatTableDataSource([]);
                    this.loader.spin.next(false);
                }
            }, (error) => {
                console.log(error);
            });
        } else { this.common.openSnackBar('Select Charge Code/Name', 'Ok'); return; }
    }

    // method for clear
    clear(date) {
        date.FromDate.setValue(new Date());
        date.ToDate.setValue(new Date());
        this.CCODE.setValue('');
        this.amount = 0.00;
        this.filteredData = new MatTableDataSource([]);
    }

    setValue(items) {
        this.code = items.CCCode;
        this.chargeCode = items.Code;
    }

    setValueOnTab() {
        setTimeout(() => {
            let firstValue = this.filteredOptionsCode[0];
            if (!isNullOrUndefined(firstValue)) {
                this.CCODE.setValue(firstValue.Code + ' ' + firstValue.Name);
                this.code = firstValue.CCCode;
                this.chargeCode = firstValue.Code;
            }
            else {
                this.CCODE.setValue('');
            }
        }, 500);
    }

    clearLookupSearch() {
        this.CCODE.setValue('');
        this.code = '';
    }

    // method for cancel
    cancel() {

    }

    // method for print
    print() {

    }

    // method for print
    exportToExcel(date) {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.ChargeCodeExcel(new ParseDate().transform(date.FromDate.value), new ParseDate().transform(date.ToDate.value), this.code, this.chargeCode)).subscribe(res => {
            if (res.Status == 200 && res.Data.length > 0) {
                this.http.openFile(res.Data);
                this.loader.spin.next(false);
            }
            else {
                this.loader.spin.next(false);
            }
        }, (error) => {
            console.log(error);
        })
    }
}