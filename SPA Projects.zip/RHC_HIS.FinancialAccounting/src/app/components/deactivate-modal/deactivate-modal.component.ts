import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { isNullOrUndefined } from 'util';

@Component({
    selector: 'deactivate-modal',
    templateUrl: 'deactivate-modal.component.html',
    styleUrls: ['./deactivate-modal.component.css'],
})
export class DeactivateDialogComponent {
    title: string;
    message: string;
    remarks: string = "";
    positiveButton: string;
    negativeButton: string;

    constructor(public dialogRef: MatDialogRef<DeactivateDialogComponent>, @Inject(MAT_DIALOG_DATA) public data: DeactivateDialogModel, private snackbar: MatSnackBar) {
        this.title = data.title;
        this.message = data.message;
        this.remarks = data.remarks;
        this.positiveButton = data.positiveButton;
        this.negativeButton = data.negativeButton;
        dialogRef.disableClose = true;
    }

    ngOnInit() {
    }

    onConfirm(): void {
        // Close the dialog, return true
        console.log("deactivate  clicked");
        if (isNullOrUndefined(this.remarks) || this.remarks == '') {
            this.snackbar.open("Please enter remarks for deactivation", "OK");
            return;
        }
        else if (this.remarks.length > 40) {
            this.snackbar.open("Length of the remarks cannot be greater than 40", "Ok");
            return;
        }
        else {
            this.dialogRef.close({
                Status: true,
                Remarks: this.remarks
            });
        }
    }

    onDismiss(): void {
        // Close the dialog, return false
        console.log("close clicked");
        this.dialogRef.close({ Status: false });
    }

    onMayBe(): void {
        // Close the dialog, return false
        this.dialogRef.close({ Status: false });
    }
}

export class DeactivateDialogModel {
    constructor(public title: string, public message: string, public remarks: string, public positiveButton: string, public negativeButton?: string, public mayBeButton?: string) { }
}