import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DepartmentGlMappingComponent } from './department-gl-mapping.component';

describe('DepartmentGlMappingComponent', () => {
  let component: DepartmentGlMappingComponent;
  let fixture: ComponentFixture<DepartmentGlMappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DepartmentGlMappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DepartmentGlMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
