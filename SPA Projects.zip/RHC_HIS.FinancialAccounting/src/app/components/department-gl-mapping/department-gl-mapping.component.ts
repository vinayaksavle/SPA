import { Component, ViewChild } from '@angular/core';
import { MatSort, MatTableDataSource, MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-department-gl-mapping',
  templateUrl: './department-gl-mapping.component.html',
  styleUrls: ['./department-gl-mapping.component.css'],
  host: { 'class': 'section__main' }
})
export class DepartmentGlMappingComponent {

  @ViewChild(MatSort) sort: MatSort;
  selectedRowData: any;
  selectedRowIndex: number = -1;
  deptGLMappingList: MatTableDataSource<any> = new MatTableDataSource();
  displayedColumns = ["SrNo", "DepartmentCode", "DepartmentDesc", "GeneralStoreGlCode", "GeneralStoreGlDesc", "DrugStoreGlCode"
    , "DrugStoreGlDesc", "MmsCostCenterCode", "MmsCostCenterDesc", "CostCenterCode", "CostCenterDesc", "LastUpdatedBy", "LastUpdatedDateTime", "Remarks"];

  constructor(private http: HttpService, private loader: LoaderService, private commonService: CommonService,
    private router: Router) {
    this.getDeptGLMappingList();
  }

  // Get the initial list of departments gl mapping
  getDeptGLMappingList() {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.DeptGLMappingMaster.GetDeptGLMappingListUrl).subscribe(res => {
      if (res.Status == 200 && res.Data.length > 0) {
        this.deptGLMappingList = new MatTableDataSource(res.Data);
        this.deptGLMappingList.sort = this.sort;
        this.loader.spin.next(false);
      }
      else {
        this.loader.spin.next(false);
        this.commonService.displayPromptMessage("Error", "No record found");
      }
    }, (error) => {
      console.log(error);
    })
  }

  // filters the table 
  public filterList = (value: string) => {
    this.deptGLMappingList.filter = value.trim().toLocaleLowerCase();
  }

  // To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }

  // export to excel
  exportToExcel() {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.DeptGLMappingMaster.ExportToExcelUrl).subscribe(res => {
      if (res.Status == 200 && res.Data.length > 0) {
        this.http.openFile(res.Data);
        this.loader.spin.next(false);
      }
      else {
        this.loader.spin.next(false);
        this.commonService.displayPromptMessage("Error", "No record found");
      }
    }, (error) => {
      console.log(error);
    })
  }

  //method to open action modal(edit/new)
  openActionModal(action: string) {
    if (action == 'edit') {
      if (!this.validateData(action)) {
        return;
      } else {
        this.router.navigate(['/financial-account/new-dept-gl-mapping', action, this.selectedRowData.DepartmentCode]);
      }
    } else {
      this.router.navigate(['/financial-account/new-dept-gl-mapping', action,'0']);
    }
  }

  // Method to open deactivate modal
  openDeactivateModal(action: string) {
    if (!this.validateData(action)) return;

    this.commonService.deactivateAction("Deactivate Department GL Mapping", `Reason For Deactivate ${this.selectedRowData.DepartmentCode}`, "").subscribe(response => {
      if (response.Status) {
        this.selectedRowData.Remarks = response.Remarks;
        this.selectedRowData.UserId = localStorage.getItem("UserName");
        this.commonService.confirmAction("Deactivate Department GL Mapping", `Do you want to deactivate ${this.selectedRowData.DepartmentCode} Department Code GL Mapping ?`).subscribe(response => {
          if (response) {
            this.loader.spin.next(true);
            this.http.Post(urlConstant.DeptGLMappingMaster.DeactivateDeptGLMapping, this.selectedRowData).subscribe(response => {
              if (response.Data) {
                this.commonService.displayPromptMessage("Deactivate Department GL Mapping ", `${this.selectedRowData.DepartmentCode} deactivated successfully!`).subscribe(() => {
                  window.location.reload();
                })
              }
              else {
                this.loader.spin.next(false);
                this.commonService.openSnackBar("Deactivation failed!", "Ok");
              }
            })
          }
        })
      }
    });

  }


  // Validations
  validateData(action: string): boolean {
    if (action === 'edit' || action === 'deactivate') {
      if (isNullOrUndefined(this.selectedRowData)) {
        this.commonService.openSnackBar(`Please select row first`, "Ok");
        return false;
      }
    }

    if (action === 'edit' || action === 'deactivate') {
      if (this.selectedRowData.Status === 'C') {
        this.commonService.openSnackBar("Department Code GL Mapping is already deactivated", "Ok");
        return false;
      }
    }
    return true;
  }

  viewRecord(deptCode:any){
    if(this.commonService.isValidStringValue(deptCode)){
    this.router.navigate(['/financial-account/new-dept-gl-mapping', 'view', deptCode]);
    } else{
      return;
    }
  }

}
