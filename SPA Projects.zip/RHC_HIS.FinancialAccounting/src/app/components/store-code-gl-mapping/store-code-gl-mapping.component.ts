import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { pipe } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { isNullOrUndefined } from 'util';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { MatSort, MatTableDataSource } from '@angular/material';

@Component({
  selector: 'store-code-gl-map',
  templateUrl: 'store-code-gl-mapping.component.html',
  styleUrls: ['./store-code-gl-mapping.component.css'],
  host: { 'class': 'section__main' }
})
export class StoreCodeGLMapping {
  @ViewChild(MatSort) sort: MatSort;

  storeCodeMasterList: MatTableDataSource<any> = new MatTableDataSource([]);
  displayedColumns = ['SrNo', 'StoreCode', 'StoreCodeDescription', 'SalesAcCode', 'PurchaseAcCode', 'CashAcCode', 'DrugRefundAcCode', 'BillInProcessAcCode',
    'StaffChargeAcCode', 'StaffNonChargeAcCode', 'ModifiedBy', 'EditDate'];
  selectedRowData: any;
  selectedRowIndex: number = -1;
  constructor(private http: HttpService, private commonService: CommonService,
    private fb: FormBuilder, private loader: LoaderService, private router: Router) { this.getStoreCodesList() }

  // Author - Vinayak Savle
  // Get Store Code List
  getStoreCodesList() {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.StoreCode.GetStoreCodesList()).subscribe(response => {
      if (response.Status === 200) {
        console.log(response.Data);
        this.storeCodeMasterList = new MatTableDataSource(response.Data);
        this.storeCodeMasterList.sort = this.sort;
        this.loader.spin.next(false);
      }
    })
  }

  // method for export to excel
  exportToExcel() {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.StoreCode.ExportToExcel()).subscribe(response => {
      if (response.Status === 200 && !isNullOrUndefined(response.Data)) {
        this.http.openFile(response.Data);
      }
      else {
        this.loader.spin.next(false);
        this.commonService.openSnackBar("Error in export to excel", "Ok");
      }
      this.loader.spin.next(false);
    });
  }

  // redirection to edit page
  redirectToEdit(action) {
    if (!this.validateData()) return;
    this.router.navigate(['/financial-account/store-code-gl-mapping', action, this.selectedRowData.StoreCode]);
  }

  // Validations
  validateData(): boolean {

    if (isNullOrUndefined(this.selectedRowData)) {
      this.commonService.openSnackBar(`Please select row first`, "Ok");
      return false;
    }

    return true;
  }

  // general filter method
  filterList(value) {
    this.storeCodeMasterList.filter = value.trim().toLocaleLowerCase();
  }

  // redirect to view page
  redirectToView(storeCode, action) {
    this.router.navigate(['/financial-account/store-code-gl-mapping', action, storeCode]);
  }

  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }
}
