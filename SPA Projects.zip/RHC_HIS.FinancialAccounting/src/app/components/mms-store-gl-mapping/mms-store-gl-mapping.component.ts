import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MatSort, MatTableDataSource } from '@angular/material';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { CommonService } from 'src/app/services/common.service';
import { isNullOrUndefined } from 'util';
import { urlConstant } from 'src/app/constants/urlConstants';
import { MMSCodeGLMappingActionDialog } from './mms-store-gl-mapping-action.component';

@Component({
    selector: 'app-mms-store-gl-mapping',
    templateUrl: 'mms-store-gl-mapping.component.html',
    styleUrls: ['./mms-store-gl-mapping.component.css'],
    host: { 'class': 'section__main' }
})
export class MMSCodeGLMapping {
    @ViewChild(MatSort) sort: MatSort;
    selectedRowData: any;
    selectedRowIndex: number = -1;
    filteredData: MatTableDataSource<any> = new MatTableDataSource();
    mmsStoreList: MatTableDataSource<any> = new MatTableDataSource();
    displayedColumns = ['SrNo', 'StoreCode', 'StoreName', 'PurchaseAcCode', 'PurchaseAcDescription', 'ModifiedBy', 'ModifiedOn'];
    constructor(@Inject(MAT_DIALOG_DATA) public data: any,
        private dialog: MatDialog,
        private formBuilder: FormBuilder,
        private activateroute: ActivatedRoute,
        private http: HttpService,
        private loader: LoaderService,
        private commonService: CommonService) { }

    ngOnInit() {
        this.getMMSGLMappingList();
    }

    // method for getting mms list
    getMMSGLMappingList() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.MMSStoreGlMapping.GetMMSStoreList()).subscribe(response => {
            if (response.Status === 200) {
                this.mmsStoreList = new MatTableDataSource(response.Data);
                this.filteredData = new MatTableDataSource(response.Data);
                this.filteredData.sort = this.sort;
            }
            this.loader.spin.next(false);
        })

    }

    // method for export to excel
    exportToExcel() {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.MMSStoreGlMapping.ExportToExcel()).subscribe(response => {
            if (response.Status === 200 && !isNullOrUndefined(response.Data)) {
                this.http.openFile(response.Data);
            }
            else {
                this.commonService.openSnackBar("Error in export to excel", "Ok");
            }
            this.loader.spin.next(false);
        });
    }

    //general filter method
    filterList(value) {
        this.filteredData.filter = value.trim().toLocaleLowerCase();
    }

    //method to open action modal
    openActionModal(action) {
        if (!this.validateData(action)) return;
        const dialogRef = this.dialog.open(MMSCodeGLMappingActionDialog);
        dialogRef.componentInstance.action = action;
        dialogRef.componentInstance.rowdetails = this.selectedRowData;
    }

    // Validations
    validateData(action: string): boolean {
        if (action === 'edit') {
            if (isNullOrUndefined(this.selectedRowData)) {
                this.commonService.openSnackBar(`Please select row first`, "Ok");
                return false;
            }
        }
        return true;
    }

    // To highlight selected row
    highlightSelectedRow(index, rowDetails) {
        this.selectedRowData = rowDetails;
        if (this.selectedRowIndex == index) {
            this.selectedRowIndex = -1;
            this.selectedRowData = null;
        } else {
            this.selectedRowIndex = index;
        }
    }

}