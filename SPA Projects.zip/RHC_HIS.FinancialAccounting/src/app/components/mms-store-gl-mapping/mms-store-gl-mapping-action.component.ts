import { Component, OnInit, ViewChild, Inject, ElementRef, Renderer2 } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MatSort, MatTableDataSource } from '@angular/material';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { CommonService } from 'src/app/services/common.service';
import { isNullOrUndefined } from 'util';
import { urlConstant } from 'src/app/constants/urlConstants';
import { AcMasterLibComponent } from 'ac-master-lib';

@Component({
    selector: 'app-mms-store-gl-mapping-action',
    templateUrl: 'mms-store-gl-mapping-action.component.html',
    styleUrls: ['./mms-store-gl-mapping.component.css'],

})
export class MMSCodeGLMappingActionDialog {
    action: string;
    rowdetails: any;
    mmsStoreActionForm: FormGroup;
    @ViewChild('libAcntPurchase') libAcntPurchase: AcMasterLibComponent;
    placeHolderPurchase = "Purchase A/C Code/Name";
    labelValuePurchase = "Purchase A/C Code/Name";
    constructor(private dialogRef: MatDialogRef<MMSCodeGLMappingActionDialog>,
         private http: HttpService,private commonService: CommonService, private fb: FormBuilder,
          private loader: LoaderService,private renderer: Renderer2) { }
    ngOnInit() {
        this.initForm();
    }
    
    
    // method for from initialization
    initForm() {
        console.log(this.rowdetails);
        this.mmsStoreActionForm = this.fb.group({
            StoreCode: [{ value: this.rowdetails.StoreCode , disabled:true}, Validators.compose([
                Validators.required, Validators.maxLength(2)
            ])],
            StoreName: [{ value: this.rowdetails.StoreName ,  disabled:  true  }, Validators.compose([
                Validators.required, Validators.maxLength(20)
            ])],
            UserId: [localStorage.getItem("UserName")],
            PurchaseCode: [this.rowdetails.PurchaseAcCode],
        });   
        this.libAcntPurchase.inputValue.setValue(this.rowdetails.PurchaseAcCode + ' ' + this.rowdetails.PurchaseAcDescription.trim());
        // this.getPurchaseDetails(this.rowdetails.PurchaseAcCode);
    }

    // method get all form control values
    get f() { return this.mmsStoreActionForm.controls; }

    //method to save edited element
    saveEditedMMSCode(){
        const inputParam = this.mmsStoreActionForm.getRawValue();
        console.log(inputParam);
        
        if (this.action === 'edit') {
            this.commonService.confirmAction("Edit MMS Store Code", `Do you want to update ${inputParam.StoreCode} MMS Store Code ?`).subscribe(response => {
                if (response) {
                    this.loader.spin.next(true);
                    this.http.Post(urlConstant.MMSStoreGlMapping.UpdateMMSStoreCode(), inputParam).subscribe(response => {
                        if (response.Data) {
                            this.commonService.displayPromptMessage("Edit MMS Store Code", `${inputParam.StoreCode} code updated successfully!`).subscribe(response => {
                                window.location.reload();
                            });
                        }
                        else {
                            this.loader.spin.next(false);
                            this.commonService.openSnackBar("Record already exists!", "Ok");
                        }
                    })
                }
                else {
                    this.cancel();
                }
            })
        }
    }

    // method to close dialog
    cancel(){
        this.dialogRef.close();
    }

    // method to get lookup value
    getPurchaseDetails(event){
      console.log(event);
      this.f.PurchaseCode.setValue(event.Code);
    }
}