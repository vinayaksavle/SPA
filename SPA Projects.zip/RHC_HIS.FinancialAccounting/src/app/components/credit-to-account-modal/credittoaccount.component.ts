import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MatSort, MatTableDataSource } from '@angular/material';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { CommonService } from 'src/app/services/common.service';
import { isNullOrUndefined } from 'util';
import { urlConstant } from 'src/app/constants/urlConstants';


@Component({
  selector: 'app-credit-to-account',
  templateUrl: 'credittoaccount.component.html',
  styleUrls: ['./credittoaccount.component.css'],

})
export class CreditToAccountModal {
  @ViewChild(MatSort) sort: MatSort;
  inputParam: any;
  selectedRowIndex: number = -1;
  bankCreditAcList: MatTableDataSource<any> = new MatTableDataSource([]);
  displayedColumns = ["SrNo", "VoucherNo", "Narration", "VoucherDate", "ChequeNo", "ChequeDate", "Amount", "AcCode"];


  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private dialog: MatDialog,
    private http: HttpService,
    private loader: LoaderService,
    private commonService: CommonService,
    private dialogRef: MatDialogRef<CreditToAccountModal>) { }

  ngOnInit() {
    this.getBankCreditVoucherList();
  }

  //method for setting lookup value
  setBankCreditAcCode(event) {
    this.inputParam.BankCreditAcCode = event.Code;
  }

  getBankCreditVoucherList() {
    if (!this.validateData()) return;
    this.loader.spin.next(true);
    this.http.Post(urlConstant.Voucher.GetBankCreditVoucherList(), this.inputParam).subscribe(response => {
      if (response.Status === 200) {
        this.bankCreditAcList = new MatTableDataSource(response.Data);
        this.bankCreditAcList.sort = this.sort;
        this.loader.spin.next(false);
      }
    })
  }

  validateData() {
    if (!this.commonService.isValidStringValue(this.inputParam.BankCreditAcCode)) {
      this.commonService.openSnackBar("Bank Credit Account Code is required", "Ok");
      return false;
    }

    return true;
  }



  //method to print details
  printDetails() {

  }

  // method for export to excel
  exportToExcel() {
    this.loader.spin.next(true);
    this.http.Post(urlConstant.Voucher.ExportCreditList, this.inputParam).subscribe(response => {
      if (response.Status === 200 && !isNullOrUndefined(response.Data)) {
        this.http.openFile(response.Data);
      }
      else {
        this.commonService.openSnackBar("Error in export to excel", "Ok");
      }
      this.loader.spin.next(false);
    });
  }

  // method to close dialog
  closedialog() {
    this.dialogRef.close();
  }
}
