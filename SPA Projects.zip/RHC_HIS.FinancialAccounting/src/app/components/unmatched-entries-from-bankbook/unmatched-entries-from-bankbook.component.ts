import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { ParseDate } from 'shared-utility';
import { from } from 'rxjs';
import { FromDateToDateComponent } from 'from-date-to-date';
import { AcMasterLibComponent } from 'ac-master-lib';
import { isNullOrUndefined } from 'util';

@Component({
    selector: 'app-unmatched-entries-bankbook',
    templateUrl: 'unmatched-entries-from-bankbook.component.html',
    styleUrls: ['./unmatched-entries-from-bankbook.component.css'],
    host: { 'class': 'section__main' }
})
export class UnMatchedEntriesBankbook {
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('fromDateToDateComp') fromDateToDateComp: FromDateToDateComponent;
    @ViewChild('bankAccount') bankAccountComp: AcMasterLibComponent;
    currentDate: any = new Date();
    selectedRowData: any;
    selectedRowIndex: number = -1;
    permissions: any[];
    canViewList: boolean;
    canMatchEntry: boolean;
    canUnMatchEntry: boolean;
    bankBookListDetails: MatTableDataSource<any> = new MatTableDataSource();
    rowdetails: any;
    totalAmount: Number = 0.00;
    unmatchedEntriesForm: FormGroup;
    displayedColumns = ["SrNo", "VoucherNo", "VoucherType", "VoucherDate", "Narration", "Amount", "ChequeNo", "BankNo", "ChequeDate"];
    options = [
        { value: 'D', viewValue: 'RECEIPT' },
        { value: 'C', viewValue: 'PAYMENT' }
    ];

    Status = [
        { value: 'M', viewValue: 'MATCHED' },
        { value: 'U', viewValue: 'UNMATCHED' }
    ];
    constructor(private http: HttpService, private commonService: CommonService,
        private fb: FormBuilder, private loader: LoaderService,
        private activateRoute: ActivatedRoute, private router: Router) {
        this.permissions = JSON.parse(localStorage.getItem('Permission'));
        if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
            this.canViewList = this.permissions.includes('3322T') ? true : false;
            this.canMatchEntry = this.permissions.includes('3323T') ? true : false;
            this.canUnMatchEntry = this.permissions.includes('3324T') ? true : false;
        }
    }

    ngOnInit() {
        this.initForm();
        this.setDefaultBankAcCode();
    }

    //method to initialize seatrch form
    initForm() {
        this.unmatchedEntriesForm = this.fb.group({
            AsOnDateCheck: [false],
            AsOnDate: [{ value: '', disabled: true }],
            FromDate: [new ParseDate().transform(new Date())],
            ToDate: [new ParseDate().transform(new Date())],
            DebitCreditFlag: [''],
            Status: [''],
            BankAccountCode: ['', Validators.required],
            ChequeRefNo: [],
        });
    }

    // method get all form control values
    get f() { return this.unmatchedEntriesForm.controls; }

    //search button click method
    onSearch(isExcel: boolean) {
        let obj = this.unmatchedEntriesForm.getRawValue();
        if (!this.commonService.isValidStringValue(obj.BankAccountCode)) {
            this.commonService.openSnackBar("Invalid Bank Account Code", "OK");
            return;
        } else {
            obj.AsOnDate = this.commonService.isValidStringValue(obj.AsOnDate) ? new ParseDate().transform(obj.AsOnDate) : "";
            console.log(obj);
            let url = "";
            // url configuration as per the isExcel flag
            url = !isExcel ? urlConstant.UnmatchedEntriesFromBankBook.GetUnmatchedListUrl : urlConstant.UnmatchedEntriesFromBankBook.ExportToExcelUrl;
            if (!isExcel) {
                this.bankBookListDetails = new MatTableDataSource();
            }
            this.loader.spin.next(true);
            this.http.Post(url, obj).subscribe(
                res => {
                    if (res.Status == 200 && res.Data.length > 0) {
                        if (!isExcel) {
                            this.bankBookListDetails = new MatTableDataSource(res.Data);
                            this.bankBookListDetails.sort = this.sort;
                            this.totalAmount = this.bankBookListDetails.data[0].TotalAmount;
                            this.loader.spin.next(false);
                        } else {
                            this.http.openFile(res.Data);
                            this.loader.spin.next(false);
                        }
                    }
                    else {
                        this.loader.spin.next(false);
                    }
                });
        }
    }

    setDefaultBankAcCode() {
        let facilityId = localStorage.getItem('Facility');

        if (facilityId === "001")
            this.f.BankAccountCode.setValue('1-06-205');
        else if (facilityId === "002")
            this.f.BankAccountCode.setValue('1-06-207');
        else
            this.f.BankAccountCode.setValue('1-06-209');

        // Fetch Bank A/C Name on the basis of A/C Code and Facility
        this.http.Get(urlConstant.Voucher.GetAccountMasterLookup(this.f.BankAccountCode.value)).subscribe(response => {
            if (response.Status === 200) {
                this.bankAccountComp.inputValue.setValue(this.f.BankAccountCode.value + ' ' + response.Data[0].Name);
            }
        })
    }

    // method to clear form
    clearForm() {
        this.initForm();
        this.totalAmount = 0.00;
        this.fromDateToDateComp.FromDate.setValue(new Date());
        this.fromDateToDateComp.ToDate.setValue(new Date());
        this.bankAccountComp.inputValue.setValue("");
        this.bankBookListDetails = new MatTableDataSource();
    }

    // method to set AsOnDate on the basis of checkBox
    enableAsOnDate(event) {
        if (event.checked) {
            this.f.AsOnDate.enable();
            this.f.AsOnDate.setValue(new Date());
        } else {
            this.f.AsOnDate.setValue('');
            this.f.AsOnDate.disable();
        }
    }
    // method to set From Date and To Date Form controls value
    setFromToDateControls(event) {
        if (event != null || event != undefined) {
            this.f.FromDate.setValue(new ParseDate().transform(this.fromDateToDateComp.FromDate.value));
            this.f.ToDate.setValue(new ParseDate().transform(this.fromDateToDateComp.ToDate.value));
        }
    }

    // method for export to pdf
    exportToPdf() {

    }

    // method for setting lookup value
    setBankAccountCode(event) {
        if (event != null) {
            this.f.BankAccountCode.setValue(event.Code);
        }
    }

    // To highlight selected row
    highlightSelectedRow(index, rowDetails) {
        this.selectedRowData = rowDetails;

        if (this.selectedRowIndex == index) {
            this.selectedRowIndex = -1;
            this.selectedRowData = null;
        } else {
            this.selectedRowIndex = index;
        }
    }

    // method for match entry
    matchUnmatchEntryClick(entryType: string) {

        if (this.selectedRowIndex === -1) {
            this.commonService.openSnackBar("Please select row a first !", "Ok");
            return;
        }

        this.commonService.confirmAction("Unmatched Entries from Bankbook", `Do you to ${this.commonService.isValidStringValue(entryType) ? 'match' : 'unmatch'} this record ?`).subscribe(response => {
            if (response) {
                this.loader.spin.next(true);
                let param = { "VoucherNo": this.selectedRowData.VoucherNo, "VoucherType": this.selectedRowData.VoucherType, "Narration": entryType };
                this.http.Post(urlConstant.UnmatchedEntriesFromBankBook.UpdateBankBook, param).subscribe(response => {
                    if (response.Status === 200 && response.Data) {
                        this.commonService.displayPromptMessage("Bank Book", "Entry done successfully !");
                    }
                    else {
                        this.commonService.displayPromptMessage("Bank Book", "Error in saving data !");
                    }
                    this.loader.spin.next(false);
                },
                    error => {
                        this.commonService.displayPromptMessage("Bank Book", " Error in saving data !")
                            .subscribe(resp => {
                                window.location.reload();
                            });
                    });
            }
        })
    }


}