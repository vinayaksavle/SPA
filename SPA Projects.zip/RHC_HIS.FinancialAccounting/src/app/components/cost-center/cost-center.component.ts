import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatSort, MatTableDataSource } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpService } from 'src/app/services/http.service';
import { ParseDate } from 'shared-utility';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';
import { CostCenterActionDialog } from './cost-center-action.component';
import { DeactivateDialogComponent } from '../deactivate-modal/deactivate-modal.component';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { InputConfirmDialogComponent } from '../input-confirm-dialog/input-confirm-dialog.component';

@Component({
  selector: 'app-cost-center',
  templateUrl: './cost-center.component.html',
  styleUrls: ['./cost-center.component.css'],
  host: { 'class': 'section__main' }
})

export class CostCenterComponent {
  @ViewChild(MatSort) sort: MatSort;
  selectedRowData: any;
  selectedRowIndex: number = -1;
  costCentreMasterList: MatTableDataSource<any> = new MatTableDataSource();
  displayedColumns = ["SrNo", "CCCode", "CCDescription", "CreatedBy", "EditDate", "Remarks"];

  constructor(private dialog: MatDialog, private http: HttpService, private loader: LoaderService, private commonService: CommonService) {
    this.getCostCentresList();
  }

  // Author - Vinayak Savle
  // Get Cost Centres List
  getCostCentresList() {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.CostCentre.GetCostCentresList()).subscribe(response => {
      if (response.Status === 200) {
        this.costCentreMasterList = new MatTableDataSource(response.Data);
        this.costCentreMasterList.sort = this.sort;
      }
      this.loader.spin.next(false);
    })
  }

  // Method for export to excel
  exportToExcel() {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.CostCentre.ExportToExcel()).subscribe(response => {
      if (response.Status === 200 && !isNullOrUndefined(response.Data)) {
        this.http.openFile(response.Data);
      }
      else {
        this.commonService.openSnackBar("Error in export to excel", "Ok");
      }
      this.loader.spin.next(false);
    });
  }

  // To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }

  // Method to open deactivate modal
  openDeactivateModal(action: string) {
    if (!this.validateData(action)) return;

    this.commonService.deactivateAction("Deactivate Cost Centre Code", `Reason For Deactivate ${this.selectedRowData.CCCode}`, "").subscribe(response => {
      if (response.Status) {
        this.selectedRowData.Remarks = response.Remarks;
        this.selectedRowData.UserId = localStorage.getItem("UserName");
        this.commonService.confirmAction("Deactivate Cost Centre Code", `Do you want to deactivate ${this.selectedRowData.CCCode} Cost Centre Code ?`).subscribe(response => {
          if (response) {
            this.loader.spin.next(true);
            this.http.Post(urlConstant.CostCentre.DeactivateCostCentreCode(), this.selectedRowData).subscribe(response => {
              if (response.Data) {
                this.commonService.displayPromptMessage("Deactivate Cost Centre Code", `${this.selectedRowData.CCCode} deactivated successfully!`).subscribe(() => {
                  window.location.reload();
                })
              }
              else {
                this.loader.spin.next(false);
                this.commonService.displayPromptMessage("Deactivate Cost Centre Code", `${this.selectedRowData.CCCode} Cost Centre Code already in use, cannot deactivate!`);
              }
            })
          }
        })
      }
    });

  }

  // Method to open action modal(edit/new)
  openActionModal(action: string) {
    if (!this.validateData(action)) return;

    const dialogRef = this.dialog.open(CostCenterActionDialog);
    dialogRef.componentInstance.action = action;
    dialogRef.componentInstance.rowdetails = this.selectedRowData;

     
  }

  // Validations
  validateData(action: string): boolean {
    if (action === 'edit' || action === 'deactivate') {
      if (isNullOrUndefined(this.selectedRowData)) {
        this.commonService.openSnackBar(`Please select row first`, "Ok");
        return false;
      }
    }

    if (action === 'edit' || action === 'deactivate') {
      if (this.selectedRowData.Status === 'C') {
        this.commonService.openSnackBar("Cost Centre Code is deactivate", "Ok");
        return false;
      }
    }

    return true;
  }

  // filters the table
  public filterList = (value: string) => {
    this.costCentreMasterList.filter = value.trim().toLocaleLowerCase();
  }

}
