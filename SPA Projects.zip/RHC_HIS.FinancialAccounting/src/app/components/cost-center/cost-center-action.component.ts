import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
    selector: 'cost-center-action-dialog',
    templateUrl: 'cost-center-action.component.html',
    styleUrls: ['./cost-center.component.css'],
})
export class CostCenterActionDialog {

    action: string;
    rowdetails: any;
    costCentreForm: FormGroup;
    constructor(private dialogRef: MatDialogRef<CostCenterActionDialog>, private http: HttpService, private commonService: CommonService, private fb: FormBuilder, private loader: LoaderService) { }

    ngOnInit() {
        this.initForm();
    }

    initForm() {
        this.costCentreForm = this.fb.group({
            CCCode: [{ value: this.action === 'edit' ? this.rowdetails.CCCode : '', disabled: this.action === 'edit' ? true : false }, Validators.required],
            CCDescription: [this.action === 'edit' ? this.rowdetails.CCDescription : '', Validators.required],
            UserId: [localStorage.getItem("UserName")]
        });
    }

    // method get all form control values
    get f() { return this.costCentreForm.controls; }

    // Author - Vinayak Savle
    // Save or Edit Cost Centre Code
    saveEditCCCode() {
        if (!this.validateData()) return;

        const inputParam = this.costCentreForm.getRawValue();
        if (this.action === 'edit') {
            this.commonService.confirmAction("Edit Cost Centre Code", `Do you want to update ${inputParam.CCCode} Cost Centre ?`).subscribe(response => {
                if (response) {
                    this.loader.spin.next(true);
                    this.http.Post(urlConstant.CostCentre.UpdateCostCentre(), inputParam).subscribe(response => {
                        if (response.Data) {
                            this.commonService.displayPromptMessage("Edit Cost Centre Code", `${inputParam.CCCode} code updated successfully!`).subscribe(response => {
                                window.location.reload();
                            });
                        }
                        else {
                            this.loader.spin.next(false);
                            this.commonService.openSnackBar("Record with same CCDescription already exists!", "Ok");
                        }
                    })
                }
                else {
                    this.cancel();
                }
            })
        }
        // if the action is new
        else {
            this.commonService.confirmAction("New Cost Centre Code", `Do you want to save ${inputParam.CCCode} Cost Centre ?`).subscribe(response => {
                if (response) {
                    this.loader.spin.next(true);
                    this.http.Post(urlConstant.CostCentre.InsertNewCostCentre(), inputParam).subscribe(response => {
                        if (response.Data) {
                            this.commonService.displayPromptMessage("New Cost Centre Code", `${inputParam.CCCode} code created successfully!`).subscribe(response => {
                                window.location.reload();
                            });
                        }
                        else {
                            this.loader.spin.next(false);
                            this.commonService.displayPromptMessage("New Cost Centre Code","Record with same CCCode/CCDescription already exists!");
                        }
                    })
                }
                else {
                    this.cancel();
                }
            })
        }
    }

    // Validations
    validateData(): boolean {
        if (!this.commonService.isValidStringValue(this.f.CCCode.value)) {
            this.commonService.openSnackBar("Cost Centre Code should not be empty", "Ok");
            return false;
        }

        if (!this.commonService.isValidStringValue(this.f.CCDescription.value)) {
            this.commonService.openSnackBar("Cost Centre Description should not be empty", "Ok");
            return false;
        }

        if (this.f.CCCode.value.length > 2) {
            this.commonService.openSnackBar("Cost Centre Code length should not be greater than 2", "Ok");
            return false;
        }

        if (this.f.CCDescription.value.length > 30) {
            this.commonService.openSnackBar("Cost Centre Description length should not be greater than 30", "Ok");
            return false;
        }

        return true;
    }

    // method for closing dialog
    cancel() {
        this.dialogRef.close();
    }
}