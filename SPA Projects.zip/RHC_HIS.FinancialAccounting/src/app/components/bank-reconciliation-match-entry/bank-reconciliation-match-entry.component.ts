import { Component, OnInit, ViewChild, Inject, ElementRef } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSort, MatTableDataSource } from '@angular/material';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { CommonService } from 'src/app/services/common.service';
import { isNullOrUndefined } from 'util';
import { urlConstant } from 'src/app/constants/urlConstants';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { ParseDate } from 'shared-utility';
import { FromDateToDateComponent } from 'from-date-to-date';

@Component({
  selector: 'app-bank-reconciliation-match-entry',
  templateUrl: 'bank-reconciliation-match-entry.component.html',
  styleUrls: ['./bank-reconciliation-match-entry.component.css'],
})

export class BankReconciliationMatchEntry {
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('fromDateToDate') fromDateToDate: FromDateToDateComponent;

  isPopup: boolean = false;
  toDate: any;
  selectedRowData: any;
  selectedRowIndex: number = -1;
  transNoLength: number;
  reader1: string;
  reader2: string;
  rowData: any = {};
  permissions: any[];
  canSearch: boolean;
  canFind: boolean;
  canCheckForMatch: boolean;
  canSave: boolean;
  bankReconciliationMatchForm: FormGroup;
  matchEntryDetails: MatTableDataSource<any> = new MatTableDataSource();
  filteredData_2: MatTableDataSource<any> = new MatTableDataSource();
  displayedColumns_1 = ["SrNo", "IsActive", "ChequeDate", "TransactionNo", "Type", "DebitAmount", "CreditAmount", "Narration", "BankTransactionNo", "TransactionType"];
  displayedColumns_2 = ["TransactionNo", "Amount", "Difference", "D"];
  transactionTypeList = [
    { value: '', viewValue: 'ALL' },
    { value: 'D', viewValue: 'DEBIT' },
    { value: 'C', viewValue: 'CREDIT' }
  ];

  typeList = [
    { value: '', viewValue: 'ALL' },
    { value: 'M', viewValue: 'MATCHED' },
    { value: 'U', viewValue: 'UNMATCHED' }
  ];

  constructor(
    private fb: FormBuilder,
    private http: HttpService,
    private loader: LoaderService,
    private commonService: CommonService, private dataTransfer: DataTranferService, private dialogRef: MatDialogRef<BankReconciliationMatchEntry>) {
    this.permissions = JSON.parse(localStorage.getItem('Permission'));
    if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
      this.canSearch = this.permissions.includes('3317T') ? true : false;
      this.canFind = this.permissions.includes('3318T') ? true : false;
      this.canCheckForMatch = this.permissions.includes('3319T') ? true : false;
      this.canSave = this.permissions.includes('3320T') ? true : false;
    }
  }

  ngOnInit() {
    this.initForm();
    this.setFacilityInfo();
    this.rowData = this.dataTransfer.getObject("rowData");
    console.log('Localstorage data ' + this.rowData);
    if (this.rowData != "undefined") {
      this.setFormData(JSON.parse(this.rowData));
      //localStorage.removeItem("rowData");
    }
    this.getMatchEntryDetails();
    this.addTransactionEntry(false);
  }

  initForm() {
    this.bankReconciliationMatchForm = this.fb.group({
      ChequeDate: [{ value: '', disabled: true }],
      ChequeNo: [{ value: '', disabled: true }],
      Description: [{ value: '', disabled: true }],
      CreditAmount: [{ value: '', disabled: true }],
      DebitAmount: [{ value: '', disabled: true }],
      BankTransactionNo: [{ value: '', disabled: true }],
      ChequeSeqNo: [{ value: '', disabled: true }],
      FromDate: [new ParseDate().transform(new Date())],
      ToDate: [new ParseDate().transform(new Date())],
      TransactionType: [''],
      FromAmount: [{ value: 0, disabled: true }],
      ToAmount: [{ value: 0, disabled: true }],
      Type: ['U'],
      TransDetails: this.fb.array([]),
      MatchEntryDetails: this.fb.array([]),
      SelectedTotal: [0],
      Facility: [localStorage.getItem('Facility')]
    })
  }

  // set details based on Facility
  setFacilityInfo() {
    let facilityId = localStorage.getItem('Facility');

    if (facilityId === "001") {
      this.transNoLength = 8;
      this.reader1 = "EDC";
      this.reader2 = "AMERICAN";
    }
    else if (facilityId === "002") {
      this.transNoLength = 8;
      this.reader1 = "TERMINAL";
      this.reader2 = "AMERICAN";
    }
    else {
      this.transNoLength = 8;
      this.reader1 = "EDC";
      this.reader2 = "AMERICAN";
    }
  }

  get f() {
    return this.bankReconciliationMatchForm.controls;
  }

  get TransArray(): FormArray {
    return this.bankReconciliationMatchForm.get('TransDetails') as FormArray;
  }

  get MatchEntryArray(): FormArray {
    return this.bankReconciliationMatchForm.get('MatchEntryDetails') as FormArray;
  }

  transControl(index: number) {
    return this.TransArray.controls[index]["controls"];
  }

  matchEntryControl(index: number) {
    return this.MatchEntryArray.controls[index]["controls"];
  }

  setFormData(data: any) {
    let fromDate = new Date(this.commonService.convertStringToDate(data.BankDate));
    fromDate.setDate(fromDate.getDate() - 5);
    let toDate = new Date(this.toDate);
    toDate.setDate(toDate.getDate() + 5);
    this.bankReconciliationMatchForm.patchValue({
      "ChequeDate": this.commonService.convertStringToDate(data.BankDate),
      "ChequeNo": data.ChequeNo,
      "Description": data.Description,
      "CreditAmount": data.CreditAmount,
      "DebitAmount": data.DebitAmount,
      "TransactionType": data.CreditAmount > 0 ? "D" : (data.DebitAmount > 0 ? "C" : ""),
      "BankTransactionNo": data.BankTransactionNo,
      "ChequeSeqNo": data.ChequeSeqNo,
      "FromAmount": (data.CreditAmount > 0 && (data.Description.indexOf(this.reader1) === -1 && data.Description.indexOf(this.reader2) === -1)) ? data.CreditAmount : ((data.DebitAmount > 0 && (data.Description.indexOf(this.reader1) === -1 && data.Description.indexOf(this.reader2) === -1)) ? data.DebitAmount : 0),
      "ToAmount": (data.CreditAmount > 0 && (data.Description.indexOf(this.reader1) === -1 && data.Description.indexOf(this.reader2) === -1)) ? data.CreditAmount : ((data.DebitAmount > 0 && (data.Description.indexOf(this.reader1) === -1 && data.Description.indexOf(this.reader2) === -1)) ? data.DebitAmount : 0),
      "FromDate": fromDate,
      "ToDate": toDate
    });
    console.log('Cheque Date ' + data.BankDate, this.commonService.convertStringToDate(data.BankDate));
    console.log('From Date: ' + fromDate);
    console.log('To Date: ' + toDate);

    this.fromDateToDate.FromDate.setValue(fromDate);
    this.fromDateToDate.ToDate.setValue(toDate);
  }

  // method for search result
  getMatchEntryDetails() {
    let inputParam = this.bankReconciliationMatchForm.getRawValue();
    this.loader.spin.next(true);
    this.matchEntryDetails = new MatTableDataSource();
    this.http.Post(urlConstant.BankReconciliation.GetBankReconciliationMatchEntries, inputParam).subscribe(
      res => {
        if (res.Status == 200 && res.Data.length > 0) {
          for (let i = 0; i < res.Data.length; i++) {
            let currentRow = res.Data[i];
            this.addMatchEntry(1, currentRow);
          }
          this.matchEntryDetails = new MatTableDataSource(res.Data);
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
        }
      });
  }

  // Author - Vinayak Savle
  // Method for save match entries
  saveMatchEntries() {
    let inputParam = this.bankReconciliationMatchForm.getRawValue();
    inputParam.MatchEntries = this.MatchEntryArray.value.filter(x => x.IsActive === true).map(x => {
      if (this.commonService.isValidStringValue(x.ChequeDate)) {
        x.ChequeDate = new ParseDate().transform(new Date(x.ChequeDate));
        return x;
      }
    });
    inputParam.ChequeDate = new ParseDate().transform(this.f.ChequeDate.value);
    inputParam.FromDate = new ParseDate().transform(this.f.FromDate.value);
    inputParam.ToDate = new ParseDate().transform(this.f.ToDate.value);

    if (inputParam.MatchEntries.length > 0) {
      this.commonService.confirmAction("Bank Reconciliation - Match Entry", "Do you want to save the Match entries ?").subscribe(response => {
        if (response) {
          this.loader.spin.next(true);
          console.log(inputParam);
          this.http.Post(urlConstant.BankReconciliation.SaveMatchEntries, inputParam).subscribe(response => {
            if (response.Data) {
              this.commonService.displayPromptMessage("Bank Reconciliation - Match Entry", "Data saved successfully!").subscribe(response => {
                if (response)
                  window.location.reload();
              });
            }
          })
        }
      })
    } else {
      this.commonService.displayPromptMessage("Bank Reconciliation - Match Entry", "Please select transactions to match.");
      this.loader.spin.next(false);
    }
  }

  setFromToDates(event: any) {
    this.f.FromDate.setValue(new Date(event.FromDate.value));
    this.f.ToDate.setValue(new Date(event.ToDate.value));
  }

  initTransArray(data?: any): any {
    if (isNullOrUndefined(data)) {
      return this.fb.group({
        TransactionNo: [''],
        Amount: [''],
        Difference: [''],
        D: ['']
      })
    } else {
      return this.fb.group({
        TransactionNo: [data.VoucherNo.trim().slice(-6)],
        Amount: [data.DebitAmount],
        Difference: [0],
        D: ['M']
      })
    }
  }

  initMatchEntryArray(data?: any): any {
    if (isNullOrUndefined(data)) {
      return this.fb.group({
        IsActive: [false],
        ChequeDate: [''],
        TransactionNo: [''],
        Type: [''],
        DebitAmount: [''],
        CreditAmount: [''],
        Narration: [''],
        BankTransactionNo: [''],
        TransactionType: ['']
      })
    } else {
      return this.fb.group({
        IsActive: [false],
        ChequeDate: [this.commonService.convertStringToDate(data.VoucherDate).toLocaleDateString()],
        TransactionNo: [data.VoucherNo],
        Type: [data.VoucherType],
        DebitAmount: [data.DebitAmount],
        CreditAmount: [data.CreditAmount],
        Narration: [data.Narration],
        BankTransactionNo: [data.BankTransactionNo],
        TransactionType: [data.DebitCreditFlag]
      })
    }
  }

  addTransactionEntry(isActive: any, data?: any) {
    let trans = this.filteredData_2.data;
    if (!isActive) {

      this.TransArray.push(this.initTransArray(data));
      trans.push({});
      console.log(this.TransArray.value.length);
    }
    // this.filteredData_2 = new MatTableDataSource(this.TransArray.value);
    this.filteredData_2 = new MatTableDataSource(trans);
  }

  calculateSelectedTotal() {
    if (this.MatchEntryArray.value.filter(x => x.IsActive === true).length > 0) {
      this.f.SelectedTotal.setValue(this.MatchEntryArray.value.filter(x => x.IsActive === true).map(item => (item.CreditAmount > 0 ? item.CreditAmount : item.DebitAmount)).reduce((prev, next) => parseFloat(prev) + parseFloat(next)));
    }
    else
      this.f.SelectedTotal.setValue('0');
  }

  addMatchEntry(count: number = 1, data?: any) {
    let matchEntries = this.matchEntryDetails.data;
    for (let i = 0; i < count; i++) {
      this.MatchEntryArray.push(this.initMatchEntryArray(data));
      matchEntries.push({});
    }

    this.matchEntryDetails = new MatTableDataSource(matchEntries);
  }

  // method for match check
  checkForMatch() {
    for (let i = 0; i < this.TransArray.length; i++) {
      this.transControl(i).Difference.setValue(this.transControl(i).Amount.value * -1);
    }
  }

  // To highlight selected row
  highlightSelectedRow(index, rowDetails?) {
    this.selectedRowData = rowDetails;
    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }

  findRow() {
    console.log(this.transControl(0).TransactionNo.value);
    if (this.commonService.isValidStringValue(this.transControl(0).TransactionNo.value)) {
      let data = this.MatchEntryArray.value.filter(x => x.TransactionNo.substring(x.TransactionNo.length - 8) === this.transControl(0).TransactionNo.value);
      if (data.length > 0)
        this.highlightSelectedRow(this.MatchEntryArray.value.findIndex(x => x.TransactionNo === data[0].TransactionNo));
      else
        this.commonService.openSnackBar("Transaction No not found.", "Ok")
    }
  }

  exportToExcel() {
    this.loader.spin.next(true);
    if (this.TransArray.value.length > 0) {
      this.http.Post(urlConstant.BankReconciliation.ExportToExcel, this.TransArray.value).subscribe(response => {
        if (response.Status === 200 && !isNullOrUndefined(response.Data)) {
          this.http.openFile(response.Data);
        }
        else {
          this.commonService.displayPromptMessage("Bank Reconciliation - Match Entry", "Error in export to excel");
        }
        this.loader.spin.next(false);
      });
    } else {
      this.commonService.displayPromptMessage("Bank Reconciliation - Match Entry", "Add transactions first!");
      this.loader.spin.next(false);
    }

  }

  //close dialog box
  closeDialog() {
    this.dialogRef.close();
  }
}