import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { ParseDate } from 'shared-utility';
import { FromDateToDateComponent } from 'from-date-to-date';

@Component({
  selector: 'app-negative-entries',
  templateUrl: 'negative-entries.component.html',
  styleUrls: ['./negative-entries.component.css'],
  host: { 'class': 'section__main' }
})
export class NegativeEntries {
  @ViewChild('fromDateToDate') fromDateToDate: FromDateToDateComponent;
  @ViewChild(MatSort) sort: MatSort;
  selectedRowData: any;
  selectedRowIndex: number = -1;
  filteredData: MatTableDataSource<any> = new MatTableDataSource();
  filteredDataDetails: MatTableDataSource<any> = new MatTableDataSource();
  rowdetails: any;
  displayedColumns = ["SrNo", "RegistrationNo", "PatientName", "BillAmount", "NegativeAmount", "UserId"];
  detailsdisplayedColumns = ["SrNo", "DeptCode", "DeptName", "ServiceCode", "ServiceName", "NegativeAmount", "UserId"];
  totalNegativeAmount = 0.00;
  totalBillAmount = 0.00;
  totalDifference = 0.00;

  constructor(private http: HttpService, private commonService: CommonService, private loader: LoaderService) { }

  ngOnInit() {
    this.searchResults(this.fromDateToDate);
  }

  //method to clear form
  clear(fromDateToDate?) {
    fromDateToDate.FromDate.setValue(new Date());
    fromDateToDate.ToDate.setValue(new Date());
    this.searchResults(fromDateToDate);
    this.totalBillAmount = 0
    this.totalNegativeAmount = 0
    this.totalDifference = 0
  }

  // method for search results
  searchResults(fromDateToDate?) {
    this.loader.spin.next(true);
    this.selectedRowIndex = -1;
    this.filteredData = new MatTableDataSource();
    this.http.Get(urlConstant.GetNegativeEntryPatient(new ParseDate().transform(fromDateToDate.FromDate.value), new ParseDate().transform(fromDateToDate.ToDate.value)))
      .subscribe(results => {
        if (results && results.Status === 200 && results.Data.length > 0) {
          this.filteredData = new MatTableDataSource(results.Data);
          this.totalBillAmount = results.Data[0].TotalBill
          this.totalNegativeAmount = results.Data[0].TotalNegative
          this.totalDifference = results.Data[0].TotalDifference
          this.loader.spin.next(false);
        } else {
          this.filteredData = new MatTableDataSource([]);
          this.loader.spin.next(false);
        }
      })
  }

  // method for export to Excel
  exportToExcel(date) {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.GetNegativeEntryExcel(new ParseDate().transform(date.FromDate.value), new ParseDate().transform(date.ToDate.value))).subscribe(res => {
      if (res.Status == 200 && res.Data.length > 0) {
        this.http.openFile(res.Data);
        this.loader.spin.next(false);
      }
      else {
        this.loader.spin.next(false);
      }
    }, (error) => {
      console.log(error);
    })
  }

  exportToExcelDetails() {
    this.loader.spin.next(true);
    this.http.Post(urlConstant.GetNegativeEntryDetailsExcel(), this.filteredDataDetails.data).subscribe(res => {
      if (res.Status == 200 && res.Data.length > 0) {
        this.http.openFile(res.Data);
        this.loader.spin.next(false);
      }
      else {
        this.loader.spin.next(false);
      }
    }, (error) => {
      console.log(error);
    })
  }

  // To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;
    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
      this.getDataOnDblClick(rowDetails);
    }
  }

  getDataOnDblClick(row) {
    this.loader.spin.next(true);
    this.filteredDataDetails = new MatTableDataSource();
    this.http.Get(urlConstant.GetNegativeEntryDetail(row.RegNo, row.FolioNo)).subscribe(result => {
      if (result && result.Status) {
        this.filteredDataDetails = new MatTableDataSource(result.Data);
        this.loader.spin.next(false);
      } else {
        this.loader.spin.next(false);
      }
    });
  }

}