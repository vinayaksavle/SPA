import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { isNullOrUndefined } from 'util';
import { CommonService } from 'src/app/services/common.service';

@Component({
    selector: 'app-card-payments',
    templateUrl: 'card-payments.component.html',
    styleUrls: ['./card-payments.component.css'],
    host: { 'class': 'section__main' }
})
export class CardPayments {
    @ViewChild(MatSort) sort: MatSort;
    selectedRowData: any;
    selectedRowIndex: number = -1;
    permissions: any[];
    canViewList: boolean;
    canSave: boolean;
    //for table 1
    receipts: MatTableDataSource<any> = new MatTableDataSource();
    //for table 2
    receiptsData: MatTableDataSource<any> = new MatTableDataSource();
    //for table 3
    receiptsSummary: MatTableDataSource<any> = new MatTableDataSource();

    displayedColumns1 = ["SrNo", "ReceiptNo", "ReceiptDate", "CardAmount", "CardNo"];
    displayedColumns2 = ["SrNo", "ReceiptNo", "ReceiptDate", "CardNo", "CardAmount"];
    displayedColumns3 = ["SrNo", "ReceiptNo", "ReceiptDate", "CardAmount", "CardNo"];

    receiptNo: string = "";
    receiptDate: any = new Date();
    enteredToday: boolean = true;

    constructor(private httpService: HttpService, private loaderService: LoaderService, private commonService: CommonService) {
        this.permissions = JSON.parse(localStorage.getItem('Permission'));
        if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
            this.canViewList = this.permissions.includes('3307F') ? true : false;
            this.canSave = this.permissions.includes('3308F') ? true : false;
        }
    }

    // method for marking todays date checkbox
    includeTodaysDate() {

    }

    //method for searching result
    searchReceipt() {
        this.loaderService.spin.next(true);
        let param = { "EnteredToday": this.enteredToday, "ReceiptDate": this.commonService.convertDateToString(this.receiptDate), "IsReceipt": false }
        this.httpService.Post(urlConstant.CardPayment.GetEnteries, param)
            .subscribe(resp => {
                if (resp.Status === 200 && resp.Data) {
                    console.log(resp.Data);
                    this.receiptsSummary = new MatTableDataSource(resp.Data.ReceiptSummary);
                    this.receiptsData = new MatTableDataSource(resp.Data.Receipts);
                }
                else {
                    this.commonService.displayPromptMessage("Card Payment", "No receipts found!");
                }
                this.loaderService.spin.next(false);

            });


    }

    // method for checking receipt
    checkReceipt() {

        if (!this.commonService.isValidStringValue(this.receiptNo)) {
            this.commonService.displayPromptMessage("Card Payment", "Enter receipt number!");
            return;
        }

        this.loaderService.spin.next(true);
        let param = { "ReceiptNo": this.receiptNo, "IsReceipt": true }
        this.httpService.Post(urlConstant.CardPayment.GetReceipts, param)
            .subscribe(resp => {
                if (resp.Status === 200 && resp.Data) {
                    console.log(resp.Data);
                    this.receipts = new MatTableDataSource(resp.Data);
                }
                else {
                    this.commonService.displayPromptMessage("Card Payment", "Invalid receipt number selected!");
                }
                this.loaderService.spin.next(false);

            });

        // api calls and data set for grids
    }

    //method for clearing form
    clearForm() {
        window.location.reload();
    }

    // method for receipt number
    clear() { }

    //methethod for export to excel
    exportToExcel() {
        this.httpService.Post(urlConstant.CardPayment.ExportExcel, this.getPayload())
            .subscribe(resp => {
                if (resp.Status === 200 && resp.Data)
                    this.httpService.openFile(resp.Data);;
            });
    }

    //method for adding row
    addRow() {
        let data = this.receipts.data;
        if (isNullOrUndefined(data) || data.length > 0) {
            let lastElement = data[data.length - 1];
            if (!this.commonService.isValidStringValue(lastElement.CardAmount) || !this.commonService.isValidStringValue(lastElement.CardNo)) {
                this.commonService.displayPromptMessage("Card Payment", "Enter previous row details first");
                return;
            }

            let receipt = { ReceiptNo: data[0].ReceiptNo, ReceiptDate: data[0].ReceiptDate, CardAmount: "", CardNo: "", IsEditable: true };
            data.push(receipt);
            this.receipts = new MatTableDataSource(data);
        }

    }

    //method for saving 
    save() {

        this.commonService.confirmAction("Card payment", "Save card payment details?")
            .subscribe(response => {
                if (response) {
                    this.loaderService.spin.next(true);

                    this.httpService.Post(urlConstant.CardPayment.SaveReceipts, this.getPayload())
                        .subscribe(resp => {
                            if (resp.Status === 200 && resp.Data) {
                                this.commonService.displayPromptMessage("Card Payment", resp.Data.ReceiptMsg)
                                    .subscribe(res => {
                                        let receiptData = resp.Data.ReceiptData;
                                        this.receipts = new MatTableDataSource([]);
                                        this.receiptsSummary = new MatTableDataSource(receiptData.ReceiptSummary);
                                        this.receiptsData = new MatTableDataSource(receiptData.Receipts);
                                    });
                            }
                            this.loaderService.spin.next(false);

                        });
                }
            })


    }

    getPayload() {
        let obj = { "ReceiptNo": this.receiptNo, "ReceiptDate": this.commonService.convertDateToString(this.receiptDate), "EnteredToday": this.enteredToday };
        obj["Transactions"] = this.receipts.data;
        return obj;
    }

    //method for print
    print() {

    }



}