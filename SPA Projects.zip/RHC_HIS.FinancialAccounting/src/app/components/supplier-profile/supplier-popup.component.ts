import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MatTableDataSource, MAT_DIALOG_DATA } from '@angular/material';
import { urlConstant } from 'src/app/constants/urlConstants';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';

@Component({
  selector: 'app-supplier-popup',
  templateUrl: './supplier-popup.component.html',
  styleUrls: ['./supplier-profile.component.css']
})
export class SupplierPopupComponent implements OnInit {
  selectedRowData: any;
  selectedRowIndex: number = -1;
  pendingNetAmount = 0.00;
  filteredData: MatTableDataSource<any> = new MatTableDataSource();

  displayedColumns = ["SrNo", "VoucherNo", "VoucherDate", "InvoiceNo", "PaidAmount"];

  constructor(@Inject(MAT_DIALOG_DATA) public data: SDialogModel, private http: HttpService,
    private loader: LoaderService, private dialogRef: MatDialogRef<SupplierPopupComponent>) { }

  ngOnInit() {
    this.getData();
  }

  getData() {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.GetSupplierReceiptData(this.data.voucherNo, this.data.docType)).subscribe(result => {
      if (result && result.Status === 200 && result.Data.length > 0) {
        this.filteredData = new MatTableDataSource(result.Data);
        this.pendingNetAmount = result.Data[0].PendingNETAmount;
        this.loader.spin.next(false);
      } else {
        this.loader.spin.next(false);
      }
    });
  }

  close() {
    this.dialogRef.close();
  }

}


export class SDialogModel {

  constructor(public voucherNo: string, public docType: string) {
  }
}