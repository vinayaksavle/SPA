import { Component, OnInit, ViewChild, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { LoaderService } from 'src/app/services/loader.service';
import { MatSort, MatTableDataSource } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { FromDateToDateComponent } from 'from-date-to-date';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { pipe } from 'rxjs';
import { isNullOrUndefined } from 'util';
import { ParseDate } from 'shared-utility';
import { SDialogModel, SupplierPopupComponent } from './supplier-popup.component';
import { AcMasterLibComponent } from 'ac-master-lib';
import { runInThisContext } from 'vm';

@Component({
    selector: 'app-supplier-profile',
    templateUrl: 'supplier-profile.component.html',
    styleUrls: ['./supplier-profile.component.css'],
    host: { 'class': 'section__main' }
})
export class SupplierProfile {
    @ViewChild(MatSort) sort: MatSort;
    @ViewChild('fromDateToDate') fromDateToDate: FromDateToDateComponent;
    @ViewChild('generalStoreGlCode') generalStoreGlCode: AcMasterLibComponent;
    selectedRowData: any;
    selectedRowIndex: number = -1;
    filteredPaymentDetails: MatTableDataSource<any> = new MatTableDataSource();
    filteredDueDetails: MatTableDataSource<any> = new MatTableDataSource();
    filteredBillDetails: MatTableDataSource<any> = new MatTableDataSource();
    action: string;
    rowdetails: any;
    CCProfile: FormControl;
    ViewType: FormControl;
    filteredOptionsCcP: any;
    sourceType: string;
    voucherCode;
    View = [
        { value: 'all', viewValue: 'ALL' },
        { value: 'bill', viewValue: 'BILLS' },
        { value: 'payment', viewValue: 'PAYMENT' },
        { value: 'due', viewValue: 'DUE' },
    ];
    displayedBillColumns = ["SrNo", "VoucherNo", "VoucherDate", "InvoiceNo", "GRNNo", "BillAmount"];
    displayedDueColumns = ["SrNo", "VoucherNo", "VoucherDate", "InvoiceNo", "GRNNo", "BillAmount", "PaidAmount", "DueAmount"];
    displayedPaymentColumns = ["SrNo", "VoucherType", "VoucherNo", "VoucherDate", "ChequeNo", "ChequeDate", "Amount", "TDSAmount", "DocType"];
    sCode: any;
    code: any;
    pendingAmount = 0.00;
    pendingBillAmount = 0.00;
    periodAmount = 0.00;
    periodReceiptAmount = 0.00;
    index: number = -1;
    NetAmount2 = 0.00;
    NetAmount = 0.00;

    constructor(private http: HttpService, private commonService: CommonService, private loader: LoaderService, private dialog: MatDialog) { }

    ngOnInit() {
        this.init(this.fromDateToDate);
    }

    init(fromDateToDate) {

        this.filteredPaymentDetails = new MatTableDataSource([]);
        this.filteredDueDetails = new MatTableDataSource([]);
        this.filteredBillDetails = new MatTableDataSource([]);
        this.CCProfile = new FormControl();
        this.ViewType = new FormControl('all');
        fromDateToDate.FromDate.setValue(new Date());
        fromDateToDate.ToDate.setValue(new Date());

        const waitTime = pipe(debounceTime(200));
        const distinct = pipe(distinctUntilChanged());

        this.CCProfile.valueChanges.pipe(waitTime).pipe(distinct).pipe(switchMap(text =>
            !isNullOrUndefined(text) && text.toString().trim() !== ''
                ? this.http.Get(urlConstant.GetSuppierCompany(text)) : this.filteredOptionsCcP = []))
            .subscribe(result => {
                this.filteredOptionsCcP = result.Data;
            });

        this.generalStoreGlCode.clearLookupSearch();
    }


    billResults(fromDateToDate) {
        this.loader.spin.next(true);
        this.setAmountToBlank();
        this.filteredBillDetails = new MatTableDataSource();
        this.http.Get(urlConstant.GetBillDetails(new ParseDate().transform(fromDateToDate.FromDate.value), new ParseDate().transform(fromDateToDate.ToDate.value), this.sCode, this.code)).subscribe(result => {
            if (result && result.Status === 200 && result.Data.length > 0) {
                this.filteredBillDetails = new MatTableDataSource(result.Data);
                this.pendingBillAmount = result.Data[0].PendingNETAmount;
                this.loader.spin.next(false);
            } else {
                this.filteredBillDetails = new MatTableDataSource([]);
                this.loader.spin.next(false);
            }
        });
    }

    setAmountToBlank() {
        this.periodReceiptAmount = 0.00;
        this.NetAmount = 0.00;
        this.NetAmount2 = 0.00;
        this.periodAmount = 0.00;
        this.pendingBillAmount = 0.00;
        this.periodAmount = 0.00; this.periodReceiptAmount = 0.00;
        this.NetAmount = 0.00;
        this.NetAmount2 = 0.00;
        this.periodAmount = 0.00;
        this.pendingBillAmount = 0.00;
        this.periodAmount = 0.00;
    }

    receiptResults(fromDateToDate) {
        this.index = -1;
        this.setAmountToBlank();
        this.loader.spin.next(true);
        this.filteredPaymentDetails = new MatTableDataSource();
        this.http.Get(urlConstant.GetPaymentDetails(new ParseDate().transform(fromDateToDate.FromDate.value), new ParseDate().transform(fromDateToDate.ToDate.value), this.code, this.sCode)).subscribe(result => {
            if (result && result.Status === 200 && result.Data.length > 0) {
                this.filteredPaymentDetails = new MatTableDataSource(result.Data);
                this.periodReceiptAmount = result.Data[0].PendingNETAmount;
                this.NetAmount = result.Data[0].NetAmount;
                this.NetAmount2 = result.Data[0].NetAmount_2;
                this.loader.spin.next(false);
            } else {
                this.loader.spin.next(false);
            }
        });
    }

    pendingResults() {
        this.loader.spin.next(true);
        this.setAmountToBlank();
        this.filteredDueDetails = new MatTableDataSource();
        this.http.Get(urlConstant.GetDueDetails(this.sCode, this.code)).subscribe(result => {
            if (result && result.Status === 200 && result.Data.length > 0) {
                this.filteredDueDetails = new MatTableDataSource(result.Data);
                this.periodAmount = result.Data[0].PendingNETAmount;
                this.loader.spin.next(false);
            } else {
                this.loader.spin.next(false);
            }
        });
    }

    searchResults(fromDateToDate) {
        if (this.ViewType.value === 'all' && this.commonService.isValidStringValue(this.CCProfile.value) && this.commonService.isValidStringValue(this.code)) {
            this.billResults(fromDateToDate);
            this.receiptResults(fromDateToDate);
            this.pendingResults();
        } else if (this.ViewType.value === 'bill' && this.commonService.isValidStringValue(this.CCProfile.value) && this.commonService.isValidStringValue(this.code)) {
            this.billResults(fromDateToDate);
        } else if (this.ViewType.value === 'payment' && this.commonService.isValidStringValue(this.CCProfile.value) && this.commonService.isValidStringValue(this.code)) {
            this.receiptResults(fromDateToDate);
        } else if (this.ViewType.value === 'due' && this.commonService.isValidStringValue(this.CCProfile.value) && this.commonService.isValidStringValue(this.code)) {
            this.pendingResults();
        } else {
            document.getElementById('ccp').focus();
            this.commonService.openSnackBar('Invalid Form', 'Ok');
            return;
        }
    }

    // method for export to Excel
    exportToExcel(fromDateToDate) {
        this.loader.spin.next(true);
        this.http.Get(urlConstant.SupplierExcelSheet(new ParseDate().transform(fromDateToDate.FromDate.value), new ParseDate().transform(fromDateToDate.ToDate.value), this.code, this.sCode, this.ViewType.value)).subscribe(res => {
            if (res.Status == 200 && res.Data.length > 0) {
                res.Data.forEach(
                    x => {
                        this.http.openFile(x);
                    }
                )
                this.loader.spin.next(false);
            }
            else {
                this.loader.spin.next(false);
                this.commonService.displayPromptMessage("Error", "No record found");
            }
        }, (error) => {
            console.log(error);
        });
    }

    // method to set control account code
    setControlCode(event) {
        this.code = event.Code;
    }

    // method to set value of supplier code
    setSupplierCode(event) {
        this.sCode = event.Code;
    }

    setValueOnTab() {
        setTimeout(() => {
            let firstValue = this.filteredOptionsCcP[0];
            if (!isNullOrUndefined(firstValue)) {
                this.CCProfile.setValue(firstValue.Code + ' ' + firstValue.Name);
                this.sCode = firstValue.Code;
            }
        }, 500);
    }

    clearLookupSearch() {
        this.CCProfile.setValue('');
        this.sCode = '';
    }

    setActiveServiceRow(index, row) {
        if (this.index === index) {
            this.index = -1;
        } else {
            this.index = index;
            const dialogData = new SDialogModel(
                row.VoucherNo, row.DocType
            );
            const dialogRef = this.dialog.open(SupplierPopupComponent, {
                width: '1200px',
                data: dialogData,
                disableClose: false
            });
            return dialogRef.afterClosed();
        }
    }
}