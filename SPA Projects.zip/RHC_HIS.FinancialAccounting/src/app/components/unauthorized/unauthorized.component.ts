import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unauthorized-balance',
  templateUrl: './unauthorized.component.html',
  styleUrls: ['./unauthorized.component.css'],
  host: { 'class': 'section__main' }
})
export class UnauthorizedComponent implements OnInit {

    
    ngOnInit(): void {
    }
}