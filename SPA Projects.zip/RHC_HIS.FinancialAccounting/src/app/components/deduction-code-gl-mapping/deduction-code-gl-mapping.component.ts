import { Component, ViewChild } from '@angular/core';
import { MatDialog, MatSort, MatTableDataSource } from '@angular/material';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { DeductionCodeActionDialogComponent } from './deduction-code-action-dialog.component';

@Component({
  selector: 'app-deduction-code-gl-mapping',
  templateUrl: './deduction-code-gl-mapping.component.html',
  styleUrls: ['./deduction-code-gl-mapping.component.css'],
  host: { 'class': 'section__main' }
})
export class DeductionCodeGlMappingComponent {
  
  @ViewChild(MatSort) sort: MatSort;
  selectedRowData: any;
  selectedRowIndex: number = -1;
  deductionCodeGLMapList: MatTableDataSource<any> = new MatTableDataSource<any>();

  displayedColumns = ["SrNo", "Deduction","GeneralLedgerCode", "LastUpdatedBy", "LastUpdatedDateTime"];

  constructor(private httpService: HttpService, private loader: LoaderService
    ,private dialog:MatDialog,private common:CommonService) {
    this.getDeductionSetupDetails();
  }

  // Get deduction setup master details
  getDeductionSetupDetails() {
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.DeductionCodeGLMapping.GetDeductionSetupDetails)
      .subscribe(res => {
        if (res.Status == 200 && res.Data) {
          this.deductionCodeGLMapList=new MatTableDataSource(res.Data);
          this.deductionCodeGLMapList.sort=this.sort;
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
        }
      }, (error) => {
        console.log(error);
        this.loader.spin.next(false);
      });
  }

  // To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }

  // filters the table 
  public filterList = (value: string) => {
    this.deductionCodeGLMapList.filter = value.trim().toLocaleLowerCase();
  }

  openActionDialog(action:string){
    if(action=='edit' && this.selectedRowIndex==-1){
      this.common.openSnackBar("Please select a row to edit","OK");
      return;
    }
    const dialogRef = this.dialog.open(DeductionCodeActionDialogComponent);
    dialogRef.componentInstance.action = action;
    dialogRef.componentInstance.rowdetails = this.selectedRowData;
    dialogRef.updateSize("800px","300px");
  }
}
