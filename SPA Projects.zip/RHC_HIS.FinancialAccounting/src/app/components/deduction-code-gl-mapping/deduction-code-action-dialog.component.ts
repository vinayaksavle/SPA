import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material';
import { AcMasterLibComponent } from 'ac-master-lib';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-deduction-code-action-dialog',
  templateUrl: './deduction-code-action-dialog.component.html',
  styleUrls: ['./deduction-code-gl-mapping.component.css'],
})
export class DeductionCodeActionDialogComponent implements OnInit {
  
  action: string;
  rowdetails: any;
  deductionCodeGLForm: FormGroup;
  @ViewChild('generalStoreGlCode') generalStoreGlCodeComp: AcMasterLibComponent;
  constructor(private dialogRef: MatDialogRef<DeductionCodeActionDialogComponent>, public fb: FormBuilder, private http: HttpService, private loader: LoaderService,
    private common: CommonService) { }

  ngOnInit() {
    this.initForm();
    if (this.action == 'edit') {
      this.setFormData();
    } else {
      return;
    }
  }
  // Function to set the Form Details while action is Edit.
  setFormData() {
    this.deductionCodeGLForm.patchValue({
      'Deduction':this.rowdetails.Deduction,
      'AccountCode':this.rowdetails.GeneralLedgerCode
    });
    this.f.Deduction.disable();
    this.generalStoreGlCodeComp.inputValue.setValue(this.rowdetails.GeneralLedgerCode+' '+ this.rowdetails.GeneralLedgerName);
  }

  // Function to initialize form.
  initForm() {
    this.deductionCodeGLForm = this.fb.group({
      Deduction: ['', [Validators.required, Validators.maxLength(100)]],
      AccountCode: ['', [Validators.required]],
    })
  }

  // Function to return the form controls.
  get f() {
    return this.deductionCodeGLForm.controls;
  }

  // Function to set the Account Code on lookup select.
  setGeneralStoreGlCode(item: any) {
    if (!isNullOrUndefined(item)) {
      this.f.AccountCode.setValue(item.Code);
    } else {
      this.f.AccountCode.setValue('');
    }
  }

  // Function to save the Deduction details according to action.
  saveDeductionCodeDetails() {
    if (!this.validateForm()) {
      return;
    }
    else {
      let obj = this.deductionCodeGLForm.getRawValue();
      // Url configuration according to action.
      let url=this.action=='new' ? urlConstant.DeductionCodeGLMapping.SaveNewDeduction(obj) : urlConstant.DeductionCodeGLMapping.UpdateDeductionDetails(obj)
      this.common.confirmAction(`${this.action=='new' ? 'New' :'Edit'} Deduction Code GL Mapping`, "Do you want to save the details?").subscribe(
        res => {
          if (res) {
            this.loader.spin.next(true);
            this.http.Get(url).subscribe(
              res => {
                if (res.Status == 200 && res.Data) {
                  this.loader.spin.next(false);
                  this.common.displayPromptMessage(`${this.action=='new' ? 'New' :'Edit'} Deduction Code GL Mapping`, "Details saved successfully!").subscribe(res=>{
                    if(res){
                      window.location.reload();
                    }
                  })
                } else {
                  this.loader.spin.next(false);
                  this.common.displayPromptMessage(`${this.action=='new' ? 'New' :'Edit'} Deduction Code GL Mapping`, "Something went wrong!").subscribe(res=>{
                    if(res){
                      window.location.reload();
                    }
                  });
                }
              });
          } else {
            return;
          }
        });
    }
  }

  // Function to validate form.
  validateForm(): boolean {
    if (!this.common.isValidStringValue(this.f.Deduction.value)) {
      this.common.openSnackBar("Deduction is invalid", "OK");
      return false;
    } else if (!this.common.isValidStringValue(this.generalStoreGlCodeComp.inputValue.value)
      || !this.common.isValidStringValue(this.f.AccountCode.value)) {
      this.common.openSnackBar("General Store GL Code/Name is invalid", "OK");
      return false;
    } else {
      return true;
    }
  }
  // function to close the dialog
  cancel() {
    this.dialogRef.close();
  }

}
