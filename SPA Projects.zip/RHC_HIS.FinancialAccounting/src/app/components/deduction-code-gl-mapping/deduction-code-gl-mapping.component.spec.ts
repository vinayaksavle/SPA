import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeductionCodeGlMappingComponent } from './deduction-code-gl-mapping.component';

describe('DeductionCodeGlMappingComponent', () => {
  let component: DeductionCodeGlMappingComponent;
  let fixture: ComponentFixture<DeductionCodeGlMappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeductionCodeGlMappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeductionCodeGlMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
