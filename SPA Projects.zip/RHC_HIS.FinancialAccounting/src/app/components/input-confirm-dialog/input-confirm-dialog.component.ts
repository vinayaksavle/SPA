import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MatSnackBar, MAT_DIALOG_DATA } from '@angular/material';
import { CommonService } from 'src/app/services/common.service';
import { isNullOrUndefined } from 'util';

@Component({
    selector: 'app-input-confirm-dialog',
    templateUrl: './input-confirm-dialog.component.html',
    styleUrls: ['./input-confirm-dialog.component.css']
})

export class InputConfirmDialogComponent implements OnInit {
    title: string;
    message: string;
    remarks: string = "";
    positiveButton: string;
    negativeButton: string;
    mayBeButton: string;

    constructor(public dialogRef: MatDialogRef<InputConfirmDialogComponent>,
        @Inject(MAT_DIALOG_DATA) public data: InputConfirmDialogModel, private snackbar: MatSnackBar) {
        // Update view with given values
        this.title = data.title;
        this.message = data.message;
        this.remarks = data.remarks;
        this.positiveButton = data.positiveButton;
        this.negativeButton = data.negativeButton;
        this.mayBeButton = data.mayBeButton;
        dialogRef.disableClose = true;
    }

    ngOnInit() {
    }

    onConfirm(): void {
        // Close the dialog, return true
        if (isNullOrUndefined(this.remarks) || this.remarks == '') {
            this.snackbar.open("Please enter remarks", "OK");
            return;
        } else {
            this.dialogRef.close({
                Status: true,
                Remarks: this.remarks
            });
        }
    }

    onDismiss(): void {
        // Close the dialog, return false
        this.dialogRef.close({ Status: false });
    }

    onMayBe(): void {
        // Close the dialog, return false
        this.dialogRef.close({ Status: false });
    }
}

export class InputConfirmDialogModel {
    constructor(public title: string, public message: string, public remarks: string, public positiveButton: string, public negativeButton?: string, public mayBeButton?: string) { }
}