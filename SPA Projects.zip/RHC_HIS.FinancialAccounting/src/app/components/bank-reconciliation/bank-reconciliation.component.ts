import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatSort, MatTableDataSource } from '@angular/material';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { CommonService } from 'src/app/services/common.service';
import { urlConstant } from 'src/app/constants/urlConstants';
import { FromDateToDateComponent } from 'from-date-to-date';
import { AcMasterLibComponent } from 'ac-master-lib';
import { DataTranferService } from 'src/app/services/data-transfer.service';
import { isNullOrUndefined } from 'util';
import { BankReconciliationMatchEntry } from '../bank-reconciliation-match-entry/bank-reconciliation-match-entry.component';

@Component({
  selector: 'app-bank-reconciliation',
  templateUrl: 'bank-reconciliation.component.html',
  styleUrls: ['./bank-reconciliation.component.css'],
  host: { 'class': 'section__main' }
})

export class BankReconciliation {
  @ViewChild('fromDateToDate') fromDateToDate: FromDateToDateComponent;
  @ViewChild('bankAcCodeName') bankAcCodeName: AcMasterLibComponent;
  @ViewChild(MatSort) sort: MatSort;
  selectedRowData: any;
  selectedRowIndex: number = -1;
  permissions: any[];
  canViewList: boolean;
  canMatchEntry: boolean;
  canUnMatchEntry: boolean;
  canContraMatching: boolean;
  canAutoReconciliation: boolean;
  bankReconciliationForm: FormGroup;
  bankReconciliationList: MatTableDataSource<any> = new MatTableDataSource<any>();
  displayedColumns = ["SrNo", "BankDate", "ChequeNo", "Description", "CreditAmount", "DebitAmount", "TransactionAmount", "DifferenceAmount", "TransactionType", "VoucherNo", "VoucherDate", "Narration", "BankTransactionNo", "ChequeSeqNo"];
  vouchers = [
    { value: '', viewValue: 'ALL' },
    { value: 'M', viewValue: 'MATCHED' },
    { value: 'U', viewValue: 'UNMATCHED' }
  ];
  totalCreditAmount: string = "0.00";
  totalDebitAmount: string = "0.00";
  totalMatchedCreditAmount: string = "0.00";
  totalMatchedDebitAmount: string = "0.00";
  totalPrevMonthCheqCreditAmount: string = "0.00";
  totalPrevMonthCheqDebitAmount: string = "0.00";
  totalUnMatchedCreditAmount: string = "0.00";
  totalUnMatchedDebitAmount: string = "0.00";

  constructor(private http: HttpService, private loader: LoaderService, private commonService: CommonService, 
    private dataTransferService: DataTranferService, private fb: FormBuilder, private dialog: MatDialog) {
    this.permissions = JSON.parse(localStorage.getItem('Permission'));
    if (!isNullOrUndefined(this.permissions) && this.permissions.length > 0) {
      this.canViewList = this.permissions.includes('3312T') ? true : false;
      this.canMatchEntry = this.permissions.includes('3313T') ? true : false;
      this.canUnMatchEntry = this.permissions.includes('3314T') ? true : false;
      this.canContraMatching = this.permissions.includes('3315T') ? true : false;
      this.canAutoReconciliation = this.permissions.includes('3316T') ? true : false;
    }
  }

  ngOnInit() {
    this.initForm();
    this.setDefaultBankAcCode();
  }

  ngAfterViewInit(): void {
    //Called after ngAfterContentInit when the component's view has been initialized. Applies to components only.
    if (localStorage.getItem("rowData") != null || localStorage.getItem("rowData") != "") {
      localStorage.removeItem("rowData");
    }
  }

  initForm() {
    this.bankReconciliationForm = this.fb.group({
      FromDate: [new Date()],
      ToDate: [new Date()],
      Status: [''],
      BankAcCode: [''],
      ChequeRefNo: ['']
    })
  }

  get f() {
    return this.bankReconciliationForm.controls;
  }

  setFromToDate(event: any) {
    if (!isNullOrUndefined(event)) {
      this.f.FromDate.setValue(new Date(event.FromDate.value).toLocaleDateString());
      this.f.ToDate.setValue(new Date(event.ToDate.value).toLocaleDateString());
    }
  }

  setBankAcCodeName(event: any) {
    if (!isNullOrUndefined(event))
      this.f.BankAcCode.setValue(event.Code);
    else
      this.f.BankAcCode.setValue('');
  }

  setDefaultBankAcCode() {
    let facilityId = localStorage.getItem('Facility');

    if (facilityId === "001")
      this.f.BankAcCode.setValue('1-06-205');
    else if (facilityId === "002")
      this.f.BankAcCode.setValue('1-06-207');
    else
      this.f.BankAcCode.setValue('1-06-209');

    // Fetch Bank A/C Name on the basis of A/C Code and Facility
    this.http.Get(urlConstant.Voucher.GetAccountMasterLookup(this.f.BankAcCode.value)).subscribe(response => {
      if (response.Status === 200) {
        this.bankAcCodeName.inputValue.setValue(this.f.BankAcCode.value + ' ' + response.Data[0].Name);
      }
    })
  }

  // Method to Get Bank Reconciliation List
  getBankReconciliationList() {
    // Validation Check for Bank Ac Code
    if (!this.commonService.isValidStringValue(this.bankAcCodeName.inputValue.value)) {
      this.commonService.openSnackBar("Enter the Bank A/C Code", "OK");
      return;
    } else {
      this.loader.spin.next(true);
      const inputParam = this.bankReconciliationForm.getRawValue();
      this.http.Post(urlConstant.BankReconciliation.GetBankReconciliationList, inputParam).subscribe(
        res => {
          if (res.Status == 200 && res.Data.length > 0) {
            this.bankReconciliationList = new MatTableDataSource(res.Data);
            this.bankReconciliationList.sort = this.sort;
            // totalCalulated Values assignment.
            this.totalCreditAmount = parseFloat(this.bankReconciliationList.data[0].TotalCreditAmount).toFixed(2);
            this.totalDebitAmount = parseFloat(this.bankReconciliationList.data[0].TotalDebitAmount).toFixed(2);
            this.totalMatchedCreditAmount = parseFloat(this.bankReconciliationList.data[0].TotalMatchedCreditAmount).toFixed(2);
            this.totalMatchedDebitAmount = parseFloat(this.bankReconciliationList.data[0].TotalMatchedDebitAmount).toFixed(2);
            this.totalPrevMonthCheqCreditAmount = parseFloat(this.bankReconciliationList.data[0].TotalPrevMonthCheqCreditAmount).toFixed(2);
            this.totalPrevMonthCheqDebitAmount = parseFloat(this.bankReconciliationList.data[0].TotalPrevMonthCheqDebitAmount).toFixed(2);
            this.totalUnMatchedCreditAmount = parseFloat(this.bankReconciliationList.data[0].TotalUnMatchedCreditAmount).toFixed(2);
            this.totalUnMatchedDebitAmount = parseFloat(this.bankReconciliationList.data[0].TotalUnMatchedDebitAmount).toFixed(2);
            this.loader.spin.next(false);
          } else {
            this.loader.spin.next(false);
          }
        });
    }
  }

  // To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;
    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }

  // Method for clear search details
  clearSearch() {
    this.initForm();
    this.setDefaultBankAcCode();
    this.fromDateToDate.FromDate.setValue(new Date());
    this.fromDateToDate.ToDate.setValue(new Date());
    this.bankReconciliationList = new MatTableDataSource<any>([]);
    this.totalCreditAmount = "0.00";
    this.totalDebitAmount = "0.00";
    this.totalMatchedCreditAmount = "0.00";
    this.totalMatchedDebitAmount = "0.00";
    this.totalUnMatchedCreditAmount = "0.00";
    this.totalUnMatchedDebitAmount = "0.00";
    this.totalPrevMonthCheqCreditAmount = "0.00";
    this.totalPrevMonthCheqDebitAmount = "0.00";
  }

  //Method for unMatch entry button Click
  unMatchEntryClick() {
    if (this.selectedRowIndex == -1) {
      this.commonService.openSnackBar("Please select a row", "OK");
      return;
    } else {
      if (!this.commonService.isValidStringValue(this.selectedRowData.BankTransactionNo)) {
        this.commonService.openSnackBar("Invalid Bank Transaction No", "OK");
        return;
      } else {
        this.commonService.confirmAction("Confirmation", "Do you want to unmatch the respective entry?").subscribe(
          res => {
            if (res) {
              this.loader.spin.next(true);
              this.http.Get(urlConstant.BankReconciliation.UnmatchTransactionEntry(this.selectedRowData.BankTransactionNo)).subscribe(
                res => {
                  if (res.Status == 200 && res.Data) {
                    this.commonService.displayPromptMessage("Bank Reconciliation", "Record un-matched successfully");
                    this.loader.spin.next(false);
                    this.getBankReconciliationList();
                  } else {
                    this.commonService.displayPromptMessage("Bank Reconciliation", "Record could not be un-matched");
                    this.loader.spin.next(false);
                  }
                });
            } else {
              return;
            }
          });
      }
    }
  }

  //method for match entry button Click
  openMatchEntry() {
    this.dataTransferService.setValueInLocalStorage("rowData", JSON.stringify(this.selectedRowData));

    if (this.selectedRowData) {
      const dialogRef = this.dialog.open(BankReconciliationMatchEntry, { 
        disableClose: true
      });

      dialogRef.componentInstance.isPopup = true;
      dialogRef.componentInstance.toDate = this.f.ToDate.value;
    }
    else {
      this.commonService.openSnackBar("Select a Transaction for Matching", "Ok");
    }
  }

  //method for contra match button Click
  contraMatchClick() {
    if (this.selectedRowIndex == -1) {
      this.commonService.openSnackBar("Please select a row", "OK");
      return;
    } else {
      if (!this.commonService.isValidStringValue(this.selectedRowData.BankTransactionNo)) {
        this.commonService.openSnackBar("Invalid Bank Transaction No", "OK");
        return;
      } else {
        this.commonService.confirmAction("Confirmation", "Do you want to contra match the respective entry?").subscribe(
          res => {
            if (res) {
              this.loader.spin.next(true);
              this.http.Post(urlConstant.BankReconciliation.ContraMatchTransactionEntryUrl, this.selectedRowData).subscribe(
                res => {
                  if (res.Status == 200 && res.Data) {
                    this.commonService.displayPromptMessage("Bank Reconciliation", "Record contra-matched successfully");
                    this.loader.spin.next(false);
                    this.getBankReconciliationList();
                  } else {
                    this.commonService.displayPromptMessage("Bank Reconciliation", "Record could not be contra-matched");
                    this.loader.spin.next(false);
                  }
                });
            } else {
              return;
            }
          });
      }
    }
  }

  // method for autoReconcilitaion button Click  
  autoReconcilitaionClick() {

  }
}