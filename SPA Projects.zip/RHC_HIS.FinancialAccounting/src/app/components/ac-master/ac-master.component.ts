import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog, MatSort, MatTableDataSource } from '@angular/material';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpService } from 'src/app/services/http.service';
import { ParseDate } from 'shared-utility';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';
import { CommonService } from 'src/app/services/common.service';
import { MatRadioChange } from '@angular/material';
import { NavigationExtras, Router } from '@angular/router';
import { urlConstant } from 'src/app/constants/urlConstants';
import { Subscription } from 'rxjs';


export interface TrasactionType {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-cost-center',
  templateUrl: './ac-master.component.html',
  styleUrls: ['./ac-master.component.css'],
  host: { 'class': 'section__main' }
})

export class AccountMasterComponent implements OnInit {
  @ViewChild(MatSort) sort: MatSort;
  filteredData: MatTableDataSource<any> = new MatTableDataSource();
  accountMasterList: MatTableDataSource<any> = new MatTableDataSource();
  displayedColumns = ["SrNo", "AcCode", "AcDescription", "TransactionType", "Status", "AddUId",
    "EditDate", "DRemarks"];
  selectedRowData: any;
  selectedRowIndex: number = -1;
  selectedTransactionType: string = 'ALL';
  transactions: TrasactionType[] = [
    { value: 'ALL', viewValue: 'All' },
    { value: 'ASSETS', viewValue: 'Assets' },
    { value: 'LIABILITIES', viewValue: 'Liabilities' },
    { value: 'EXPENDITURES', viewValue: 'Expenditures' },
    { value: 'INCOME', viewValue: 'Income' }
  ];
  subscription: Subscription
  constructor(public dialog: MatDialog, private commonService: CommonService, private http: HttpService,
    private loader: LoaderService, private router: Router,) { }

  ngOnInit() {
    this.getAccountMaterList();
  }

  //method to get all account mater list
  getAccountMaterList() {
    this.loader.spin.next(true);
    this.http.Get(urlConstant.AccountMaster.GetAccountMasterList()).subscribe(response => {
      if (response.Status === 200) {
        this.accountMasterList = new MatTableDataSource(response.Data);
        this.filteredData = new MatTableDataSource(this.selectedTransactionType !== "ALL" ? response.Data.filter(x => x.TransactionType === this.selectedTransactionType) : response.Data);
        this.filteredData.sort = this.sort;
      }
      this.loader.spin.next(false);
    })
  }

  //method for export to excel
  exportToExcel() {
    this.loader.spin.next(true);
    this.http.Post(urlConstant.AccountMaster.ExportToExcel(), this.filteredData.data).subscribe(response => {
      if (response.Status === 200 && !isNullOrUndefined(response.Data)) {
        this.http.openFile(response.Data);
      }
      else {
        this.commonService.openSnackBar("Error in export to excel", "Ok");
      }
      this.loader.spin.next(false);
    });

  }

  // To highlight selected row
  highlightSelectedRow(index, rowDetails) {
    this.selectedRowData = rowDetails;

    if (this.selectedRowIndex == index) {
      this.selectedRowIndex = -1;
      this.selectedRowData = null;
    } else {
      this.selectedRowIndex = index;
    }
  }

  //method to open deactivate modal
  openDeactivateModal(source: string) {
    if (!this.validateData(source)) return;

    this.commonService.deactivateAction("Deactivate Account master", `Reason For Deactivate ${this.selectedRowData.AcCode}`, "").subscribe(response => {
      if (response.Status) {
        this.selectedRowData.DRemarks = response.Remarks;
        this.selectedRowData.UserId = localStorage.getItem("UserName");
        this.commonService.confirmAction("Deactivate Account master", `Do you want to deactivate ${this.selectedRowData.AcCode} Account master ?`).subscribe(response => {
          if (response) {
            this.loader.spin.next(true);
            this.http.Post(urlConstant.AccountMaster.DeactivateAccountMaster(), this.selectedRowData).subscribe(response => {
              if (response.Data) {
                this.commonService.displayPromptMessage("Deactivate Account master", `${this.selectedRowData.AcCode} deactivated successfully!`).subscribe(() => {
                  window.location.reload();
                })
              }
              else {
                this.loader.spin.next(false);
                this.commonService.displayPromptMessage("Deactivate Account master", `${this.selectedRowData.AcCode} Account Code already in use, cannot deactivate!`);
              }
            })
          }
        })
      }
    });

  }

  // Validations
  validateData(action: string): boolean {

    if (isNullOrUndefined(this.selectedRowData)) {
      this.commonService.openSnackBar(`Please select row first`, "Ok");
      return false;
    }

    if (action === 'edit' || action === 'deactivate') {
      if (this.selectedRowData.Status === 'C') {
        this.commonService.openSnackBar("Account Code is deactivate", "Ok");
        return false;
      }
    }

    return true;
  }

  //method to open action modal(edit/new)
  openActionModal(action: string) {

    if (action == 'edit') {
      if (!this.validateData(action)) return;
      this.router.navigate(['/financial-account/ac-master', action, this.selectedRowData.AcCode]);
    }
    else {
      this.router.navigate(['/financial-account/ac-master', action, 0]);
    }

  }

  // filters the table 
  public filterList = (value: string) => {
    this.filteredData.filter = value.trim().toLocaleLowerCase();
  }

  // method for change in radio button group  and discuss whether this is required
  onChangeTransaction(event: MatRadioChange) {
    if (event.value == 'ALL')
      this.filteredData.data = this.accountMasterList.data;
    else
      this.filteredData.data = this.accountMasterList.data.filter(x => x.TransactionType === event.value);
  }

  redirectToView(acCode: string) {
    this.router.navigate(['/financial-account/ac-master', 'view', acCode]);
  }
}