import { ViewChild } from '@angular/core';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ActivatedRoute, Router } from '@angular/router';
import { AcMasterLibComponent } from 'ac-master-lib';
import { CostCentreLibComponent } from 'cost-centre-lib';
import { error } from 'protractor';
import { pipe } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { urlConstant } from 'src/app/constants/urlConstants';
import { CommonService } from 'src/app/services/common.service';
import { HttpService } from 'src/app/services/http.service';
import { LoaderService } from 'src/app/services/loader.service';
import { isNullOrUndefined } from 'util';

@Component({
  selector: 'app-new-department-gl-mapping',
  templateUrl: './new-department-gl-mapping.component.html',
  styleUrls: ['./new-department-gl-mapping.component.css'],
  host: { 'class': 'section__main' }
})
export class NewDepartmentGlMappingComponent implements OnInit {
  @ViewChild('generalStoreGlCode') generalStoreGlCode: AcMasterLibComponent;
  @ViewChild('drugStoreGlCode') drugStoreGlCode: AcMasterLibComponent;
  @ViewChild('mmsCostCenterCode') mmsCostCenterCode: CostCentreLibComponent;
  @ViewChild('costCenterCode') costCenterCode: CostCentreLibComponent;

  sourceType: string = '';
  deptGLMapForm: FormGroup;
  waitTime = pipe(debounceTime(200));
  distinct = pipe(distinctUntilChanged());
  generalStoreCodeList: any[];
  costCenterList: any[];
  mmsList: any[];
  subGroupList: any[];
  drugList: any[]
  deptCode: any;
  deptCodeDetails: any;

  constructor(@Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<any>, private activateroute: ActivatedRoute,
    private formBuilder: FormBuilder, private loader: LoaderService,
    private router: Router, private httpService: HttpService, private commonService: CommonService) { }

  ngOnInit() {
    this.initForm();

    this.activateroute.params.subscribe(params => {
      this.sourceType = params['actionType'];
      this.deptCode = params['deptCode']
    });

    if (this.sourceType == 'edit') {
      this.setFormData();
    } else if (this.sourceType == 'view') {
      this.setFormData();
      this.deptGLMapForm.disable();
      this.generalStoreGlCode.disableEvent();
      this.drugStoreGlCode.disableEvent();
      this.mmsCostCenterCode.disableEvent();
      this.costCenterCode.disableEvent();
    }
  }

  // function to initialize form
  initForm() {
    this.deptGLMapForm = this.formBuilder.group({
      DepartmentCode: ['', [Validators.required, Validators.maxLength(4)]],
      DepartmentDesc: ['', [Validators.required, Validators.maxLength(20)]],
      UserId: [localStorage.getItem("UserName")],
      GeneralStoreGlCode: ['', Validators.required],
      DrugStoreGlCode: ['', Validators.required],
      MmsCostCenterCode: ['', Validators.required],
      CostCenterCode: ['', Validators.required]
    });
  }

  // Function to return form controls
  get f() {
    return this.deptGLMapForm.controls;
  }

  setFormData() {
    this.loader.spin.next(true);
    this.httpService.Get(urlConstant.DeptGLMappingMaster.GetDeptGLMappingDetails(this.deptCode))
      .subscribe(res => {
        if (res.Status == 200 && res.Data) {
          this.deptCodeDetails = res.Data;

          // setting all lookup values
          this.generalStoreGlCode.inputValue.setValue(this.deptCodeDetails.GeneralStoreGlCode + ' ' + this.deptCodeDetails.GeneralStoreGlDesc);
          this.drugStoreGlCode.inputValue.setValue(this.deptCodeDetails.DrugStoreGlCode + ' ' + this.deptCodeDetails.DrugStoreGlDesc);
          this.mmsCostCenterCode.inputValue.setValue(this.deptCodeDetails.MmsCostCenterCode + ' ' + this.deptCodeDetails.MmsCostCenterDesc);
          this.costCenterCode.inputValue.setValue(this.deptCodeDetails.CostCenterCode + ' ' + this.deptCodeDetails.CostCenterDesc);

          this.deptGLMapForm.patchValue({
            'DepartmentCode': this.deptCodeDetails.DepartmentCode,
            'DepartmentDesc': this.deptCodeDetails.DepartmentDesc,
            'GeneralStoreGlCode': this.deptCodeDetails.GeneralStoreGlCode,
            'DrugStoreGlCode': this.deptCodeDetails.DrugStoreGlCode,
            'MmsCostCenterCode': this.deptCodeDetails.MmsCostCenterCode,
            'CostCenterCode': this.deptCodeDetails.CostCenterCode,
          })

          this.f.DepartmentCode.disable();
          this.costCenterCode.disableEvent();
          this.loader.spin.next(false);
        } else {
          this.loader.spin.next(false);
        }
      });
  }

  // set General Store Gl Code
  setGeneralStoreGlCode(event: any) {
    if (!isNullOrUndefined(event))
      this.f.GeneralStoreGlCode.setValue(event.Code);
    else
      this.f.GeneralStoreGlCode.setValue('');
  }

  // set Drug Store Gl Code
  setDrugStoreGlCode(event: any) {
    if (!isNullOrUndefined(event))
      this.f.DrugStoreGlCode.setValue(event.Code);
    else
      this.f.DrugStoreGlCode.setValue('');
  }

  // set Mms Cost Center Code
  setMmsCostCenterCode(event: any) {
    if (!isNullOrUndefined(event))
      this.f.MmsCostCenterCode.setValue(event.Code);
    else
      this.f.MmsCostCenterCode.setValue('');
  }

  // set Cost Center Code
  setCostCenterCode(event: any) {
    if (!isNullOrUndefined(event))
      this.f.CostCenterCode.setValue(event.Code);
    else
      this.f.CostCenterCode.setValue('');
  }

  backToList() {
    this.router.navigate(['financial-account/ac-code-mapping/department-gl-mapping']);
  }

  // Function to save the form
  saveForm() {
    // validate form
    if (!this.validateForm()) {
      return;
    } else {
      // create object
      const inputParam = this.deptGLMapForm.getRawValue();
      this.commonService.confirmAction("Confirmation", "Do you want to save this Department GL Mapping?")
        .subscribe(res => {
          if (res) {
            this.loader.spin.next(true);
            let url = '';
            url = this.sourceType == 'new' ? urlConstant.DeptGLMappingMaster.SaveNewDeptGLMapUrl : urlConstant.DeptGLMappingMaster.UpdateDeptGLMapUrl;

            this.httpService.Post(url, inputParam)
              .subscribe(response => {
                if (response.Status == 200 && response.Data) {
                  this.loader.spin.next(false);
                  this.commonService.displayPromptMessage("New Department GL Mapping", "Data Saved Successfully !");
                  this.clearForm();
                  this.backToList();
                } else if (this.sourceType == 'new') {
                  this.loader.spin.next(false);
                  this.commonService.displayPromptMessage("Error", "Duplicate Department Code or Description");
                } else {
                  this.loader.spin.next(false);
                  this.commonService.displayPromptMessage("Error", `Department Description (${inputParam.DepartmentDesc}) is already present`);
                }
              }, (error) => {
                console.log(error);
              });
          } else {
            return;
          }
        })

    }
  }

  // Function to validate the form
  validateForm(): boolean {

    if (!this.commonService.isValidStringValue(this.f.DepartmentCode.value)) {
      this.commonService.openSnackBar("Department Code is invalid", "Ok");
      return false;
    }
    if (!this.commonService.isValidStringValue(this.f.DepartmentDesc.value)) {
      this.commonService.openSnackBar("Department Description is invalid", "Ok");
      return false;
    }
    if (!this.commonService.isValidStringValue(this.generalStoreGlCode.inputValue.value)) {
      this.commonService.openSnackBar("General Store Gl Code is invalid", "Ok");
      return false;
    }
    if (!this.commonService.isValidStringValue(this.drugStoreGlCode.inputValue.value)) {
      this.commonService.openSnackBar("Drug Store Gl Code is invalid", "Ok");
      return false;
    }
    if (!this.commonService.isValidStringValue(this.mmsCostCenterCode.inputValue.value)) {
      this.commonService.openSnackBar("Mms Cost Center Code is invalid", "Ok");
      return false;
    }
    if (!this.commonService.isValidStringValue(this.costCenterCode.inputValue.value)) {
      this.commonService.openSnackBar("Cost Center Code is invalid", "Ok");
      return false;
    }
    return true;
    
  }

  // function to clear form
  clearForm() {
    this.deptGLMapForm.reset();
    this.generalStoreGlCode.inputValue.setValue('');
    this.drugStoreGlCode.inputValue.setValue('');
    this.mmsCostCenterCode.inputValue.setValue('');
    this.costCenterCode.inputValue.setValue('');
  }

}
