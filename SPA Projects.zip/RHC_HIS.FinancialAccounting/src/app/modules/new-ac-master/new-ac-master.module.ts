import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { NewAccountMasterAction } from 'src/app/components/new-ac-master/new-ac-master.component';
import { DeactivateModalModule } from '../deactivate-modal/decativate-modal.module';

const routes: Routes = [
  { path: '', component: NewAccountMasterAction }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    DeactivateModalModule,
    ReactiveFormsModule,
    FormsModule
  ],
  declarations: [
    NewAccountMasterAction,    
  ],
  entryComponents:[]
})

export class NewAccountMasterModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: NewAccountMasterModule
    };
  }
}
