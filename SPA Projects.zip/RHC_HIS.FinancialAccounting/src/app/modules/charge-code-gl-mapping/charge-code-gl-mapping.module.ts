import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AcMasterLibModule } from 'ac-master-lib';
import { CostCentreLibModule } from 'cost-centre-lib';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { ChargeCodeGLMappingActionDialog } from 'src/app/components/charge-code-gl-mapping/charge-code-gl-mapping-action.component';
import { ChargeCodeGLMapping } from 'src/app/components/charge-code-gl-mapping/charge-code-gl-mapping.component';
import { environment } from 'src/environments/environment';
import { DeactivateModalModule } from '../deactivate-modal/decativate-modal.module';

const routes: Routes = [
  { path: '', component: ChargeCodeGLMapping }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    DeactivateModalModule,
    ReactiveFormsModule,
    FormsModule,
    AcMasterLibModule.forRoot({ Url: environment.libURL }),
    CostCentreLibModule.forRoot({ Url: environment.libURL }),
  ],
  declarations: [
    ChargeCodeGLMapping,
    ChargeCodeGLMappingActionDialog
  ],
  entryComponents:[ChargeCodeGLMappingActionDialog]
})

export class ChargeCodeGlMappingModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: ChargeCodeGlMappingModule
    };
  }
}
