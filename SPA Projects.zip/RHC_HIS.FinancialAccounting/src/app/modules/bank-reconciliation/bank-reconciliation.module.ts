import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDividerModule } from '@angular/material';
import { Routes, RouterModule } from '@angular/router';
import { AcMasterLibModule } from 'ac-master-lib';
import { FromDateToDateModule } from 'from-date-to-date';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { BankReconciliationMatchEntry } from 'src/app/components/bank-reconciliation-match-entry/bank-reconciliation-match-entry.component';
import { BankReconciliation } from 'src/app/components/bank-reconciliation/bank-reconciliation.component';
import { MainGroupActionDialog } from 'src/app/components/main-group-master/main-group-action.component';
import { MainGroupMaster } from 'src/app/components/main-group-master/main-group-master.component';
import { environment } from 'src/environments/environment';
import { BankReconciliationMatchEntryModule } from '../bank-reconciliation-match-entry/bank-reconciliation-match-entry.module';
import { DeactivateModalModule } from '../deactivate-modal/decativate-modal.module';

const routes: Routes = [
  { path: '', component: BankReconciliation }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    DeactivateModalModule,
    ReactiveFormsModule,
    FormsModule,
    FromDateToDateModule,
    MatDividerModule,
    BankReconciliationMatchEntryModule,
    AcMasterLibModule.forRoot({ Url: environment.libURL }),
  ],
  declarations: [
    BankReconciliation,
  ],
  entryComponents: [BankReconciliationMatchEntry]
})

export class BankReconciliationModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: BankReconciliationModule
    };
  }
}