import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { AcMasterLibModule } from "ac-master-lib";
import { AppMatModule, SharedUtilityModule } from "shared-utility";
import { BillingCashCounterComponent } from "src/app/components/billing-cash-counter/billing-cash-counter.component";
import { environment } from "src/environments/environment";

const routes: Routes = [{ path: '', component: BillingCashCounterComponent }];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        AppMatModule,
        SharedUtilityModule,
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        AcMasterLibModule.forRoot({ Url: environment.libURL }),
    ],
    declarations: [BillingCashCounterComponent]
})

export class BillingCashCounterModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: BillingCashCounterModule
        }
    }
}