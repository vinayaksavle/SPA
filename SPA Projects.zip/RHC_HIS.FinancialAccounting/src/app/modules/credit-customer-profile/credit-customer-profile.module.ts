import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { AcMasterLibModule } from "ac-master-lib";
import { AppMatModule, SharedUtilityModule } from "shared-utility";
import { environment } from "src/environments/environment";
import { FromDateToDateModule } from 'from-date-to-date';
import { CreditCustomerProfile } from 'src/app/components/credit-customer-profile/credit-customer-profile.component';
import { CreditCustomerProfilePopUp } from "src/app/components/credit-customer-profile/credit-customer-profile-popup.component";

const routes: Routes = [{ path: '', component: CreditCustomerProfile }];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        AppMatModule,
        SharedUtilityModule,
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        AcMasterLibModule.forRoot({ Url: environment.libURL }),
        FromDateToDateModule
    ],
    declarations: [CreditCustomerProfile, CreditCustomerProfilePopUp],
    entryComponents : [CreditCustomerProfilePopUp ]
})

export class  CreditCustomerProfileModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: CreditCustomerProfileModule
        }
    }
}