import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders, OnInit } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
//import { DeactivateDialogComponent } from 'src/app/components/deactivate-modal/deactivate-modal.component';



@NgModule({
  imports: [
    // RouterModule.forChild(routes)
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
  ],
  declarations: [
  //  DeactivateDialogComponent
  ]
})

export class DeactivateModalModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: DeactivateModalModule
    };
  }
}
