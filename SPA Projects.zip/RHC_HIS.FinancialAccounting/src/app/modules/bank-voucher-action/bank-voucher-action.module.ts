import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { AcMasterLibModule } from "ac-master-lib";
import { AppMatModule, SharedUtilityModule } from "shared-utility"; 
import { environment } from "src/environments/environment";
import { FromDateToDateModule } from 'from-date-to-date';
import { BankVoucherAction } from 'src/app/components/bank-voucher-action/bank-voucher-action.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { SubGroupLibModule } from "sub-group-lib";
import { CostCentreLibModule } from "cost-centre-lib";


const routes: Routes = [{ path: '', component: BankVoucherAction }];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        AppMatModule,
        SharedUtilityModule,
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        AcMasterLibModule.forRoot({ Url: environment.libURL }),
        SubGroupLibModule.forRoot({ Url: environment.libURL }),
        CostCentreLibModule.forRoot({ Url: environment.libURL }),
        FromDateToDateModule,
        MatDatepickerModule
    ],
    declarations: [BankVoucherAction],
    entryComponents : [ ]
})

export class BankVoucherActionModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: BankVoucherActionModule
        }
    }
}