import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AcMasterLibModule } from 'ac-master-lib';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { MMSCodeGLMappingActionDialog } from 'src/app/components/mms-store-gl-mapping/mms-store-gl-mapping-action.component';
import { MMSCodeGLMapping } from 'src/app/components/mms-store-gl-mapping/mms-store-gl-mapping.component';
import { environment } from 'src/environments/environment';

const routes: Routes = [
  { path: '', component: MMSCodeGLMapping }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    AcMasterLibModule.forRoot({ Url: environment.libURL }),
  ],
  declarations: [
    MMSCodeGLMapping,
    MMSCodeGLMappingActionDialog
  ],
  entryComponents: [MMSCodeGLMappingActionDialog]
})

export class MMSGlMappingModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: MMSGlMappingModule
    };
  }
}
