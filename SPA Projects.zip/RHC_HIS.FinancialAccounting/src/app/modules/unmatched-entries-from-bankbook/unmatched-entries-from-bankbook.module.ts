import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDividerModule } from '@angular/material';
import { Routes, RouterModule } from '@angular/router';
import { AcMasterLibModule } from 'ac-master-lib';
import { FromDateToDateModule } from 'from-date-to-date';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { UnMatchedEntriesBankbook } from 'src/app/components/unmatched-entries-from-bankbook/unmatched-entries-from-bankbook.component';
import { environment } from 'src/environments/environment';
import { DeactivateModalModule } from '../deactivate-modal/decativate-modal.module';

const routes: Routes = [
  { path: '', component: UnMatchedEntriesBankbook }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    DeactivateModalModule,
    ReactiveFormsModule,
    FormsModule,
    FromDateToDateModule,
    MatDividerModule,
    AcMasterLibModule.forRoot({ Url: environment.libURL }),
  ],
  declarations: [
    UnMatchedEntriesBankbook,  
      
  ],
  entryComponents:[]
})

export class UnMatchedEntiresBankbookModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: UnMatchedEntiresBankbookModule
    };
  }
}