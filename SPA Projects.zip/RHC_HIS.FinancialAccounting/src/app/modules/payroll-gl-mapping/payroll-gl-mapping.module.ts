import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { PayrollGlMappingComponent } from 'src/app/components/payroll-gl-mapping/payroll-gl-mapping.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { PayRollMappingActionDialogComponent } from 'src/app/components/payroll-gl-mapping/pay-roll-mapping-action-dialog.component';
import { AcMasterLibModule } from 'ac-master-lib';
import { CostCentreLibModule } from 'cost-centre-lib';
import { environment } from 'src/environments/environment';

const routes: Routes = [
  { path: '', component: PayrollGlMappingComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    AcMasterLibModule.forRoot({ Url: environment.libURL }),
    CostCentreLibModule.forRoot({ Url: environment.libURL }),
  ],
  declarations: [
    PayrollGlMappingComponent,
    PayRollMappingActionDialogComponent,
  ],
  entryComponents: [PayRollMappingActionDialogComponent]
})
export class PayrollGlMappingModule { 
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: PayrollGlMappingModule
    };
  }
}
