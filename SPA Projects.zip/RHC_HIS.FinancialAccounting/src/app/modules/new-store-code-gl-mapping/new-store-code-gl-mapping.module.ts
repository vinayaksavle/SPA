import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { NewStoreGlMappingComponent } from 'src/app/components/new-store-code-gl-mapping/new-store-code-gl-mapping.component';
import { AcMasterLibModule } from 'ac-master-lib';
import { environment } from 'src/environments/environment';
const routes: Routes = [
  { path: '', component: NewStoreGlMappingComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    AcMasterLibModule.forRoot({ Url: environment.libURL }),
  ],
  declarations: [
    NewStoreGlMappingComponent
  ],
  entryComponents: []
})

export class NewStoreCodeGlMappingModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: NewStoreCodeGlMappingModule
    };
  }
}
