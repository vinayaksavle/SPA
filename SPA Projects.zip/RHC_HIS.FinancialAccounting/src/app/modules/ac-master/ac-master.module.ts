import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { AccountMasterComponent } from 'src/app/components/ac-master/ac-master.component';
import { CostCenterActionDialog } from 'src/app/components/cost-center/cost-center-action.component';
import { CostCenterComponent } from 'src/app/components/cost-center/cost-center.component';
import { DeactivateModalModule } from '../deactivate-modal/decativate-modal.module';

const routes: Routes = [
  { path: '', component: AccountMasterComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    DeactivateModalModule,
    ReactiveFormsModule,
    FormsModule
  ],
  declarations: [
    AccountMasterComponent,
  ],
  entryComponents:[]
})

export class AccountMasterModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: AccountMasterModule
    };
  }
}
