import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { ChargeCodeGLMappingActionDialog } from 'src/app/components/charge-code-gl-mapping/charge-code-gl-mapping-action.component';
import { ChargeCodeGLMapping } from 'src/app/components/charge-code-gl-mapping/charge-code-gl-mapping.component';
import { StoreCodeGLMapping } from 'src/app/components/store-code-gl-mapping/store-code-gl-mapping.component';
import { DeactivateModalModule } from '../deactivate-modal/decativate-modal.module';

const routes: Routes = [
  { path: '', component: StoreCodeGLMapping }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    DeactivateModalModule,
    ReactiveFormsModule,
    FormsModule
  ],
  declarations: [
    StoreCodeGLMapping,
    
  ],
  entryComponents:[]
})

export class StoreCodeGlMappingModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: StoreCodeGlMappingModule
    };
  }
}
