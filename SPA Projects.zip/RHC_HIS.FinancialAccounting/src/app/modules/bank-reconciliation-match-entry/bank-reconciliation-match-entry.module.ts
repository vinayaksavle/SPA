import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AcMasterLibModule } from 'ac-master-lib';
import { FromDateToDateModule } from 'from-date-to-date';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { BankReconciliationMatchEntry } from 'src/app/components/bank-reconciliation-match-entry/bank-reconciliation-match-entry.component';
import { environment } from 'src/environments/environment';
import { DeactivateModalModule } from '../deactivate-modal/decativate-modal.module';

@NgModule({
  imports: [
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    DeactivateModalModule,
    ReactiveFormsModule,
    FormsModule,
    FromDateToDateModule,
    AcMasterLibModule.forRoot({ Url: environment.libURL }),
  ],
  declarations: [
    BankReconciliationMatchEntry
  ],
  providers: [
    { provide: MAT_DIALOG_DATA, useValue: {} },
    { provide: MatDialogRef, useValue: {} }
  ]
})

export class BankReconciliationMatchEntryModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: BankReconciliationMatchEntryModule
    };
  }
}