import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { UnmatchedEntriesFromPassbookComponent } from 'src/app/components/unmatched-entries-from-passbook/unmatched-entries-from-passbook.component';
import { FromDateToDateModule } from 'from-date-to-date';
import { AcMasterLibModule } from 'ac-master-lib';
import { environment } from 'src/environments/environment';

const routes: Routes = [
  { path: '', component: UnmatchedEntriesFromPassbookComponent }
];

@NgModule({
  declarations: [UnmatchedEntriesFromPassbookComponent],
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    FromDateToDateModule,
    AcMasterLibModule.forRoot({Url:environment.apiURL})
  ],
})
export class UnmatchedEntriesFromPassbookModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: UnmatchedEntriesFromPassbookModule
    };
  }
 }
