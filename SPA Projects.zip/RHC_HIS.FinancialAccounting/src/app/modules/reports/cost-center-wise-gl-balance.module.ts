import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CostCenterWiseGlBalanceComponent } from '../../components/reports/cost-center-wise-gl-balance/cost-center-wise-gl-balance.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { FromDateToDateModule } from 'from-date-to-date';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';

const routes: Routes = [
  { path: '', component: CostCenterWiseGlBalanceComponent }
];

@NgModule({
  declarations: [CostCenterWiseGlBalanceComponent],
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    FromDateToDateModule,
  ]
})
export class CostCenterWiseGlBalanceModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: CostCenterWiseGlBalanceModule
    };
  }
}
