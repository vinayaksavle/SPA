import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { AcMasterLibModule } from "ac-master-lib";
import { AppMatModule, SharedUtilityModule } from "shared-utility";
import { environment } from "src/environments/environment";
import { FromDateToDateModule } from 'from-date-to-date';
import { LedgerReport } from "src/app/components/reports/ledger-report/ledger-report.component";


const routes: Routes = [{ path: '', component: LedgerReport }];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        AppMatModule,
        SharedUtilityModule,
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        AcMasterLibModule.forRoot({ Url: environment.libURL }),
        FromDateToDateModule,

    ],
    declarations: [LedgerReport],
    entryComponents : [ ]
})

export class LedgerReportModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: LedgerReportModule
        }
    }
}