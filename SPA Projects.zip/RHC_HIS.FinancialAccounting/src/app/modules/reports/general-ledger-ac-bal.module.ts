import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { AcMasterLibModule } from "ac-master-lib";
import { AppMatModule, SharedUtilityModule } from "shared-utility";
import { environment } from "src/environments/environment";
import { FromDateToDateModule } from 'from-date-to-date';
import { GeneralLedgerAccountBalance } from "src/app/components/reports/general-ledger-ac-balance/general-ledger-ac-balance.component";

const routes: Routes = [{ path: '', component: GeneralLedgerAccountBalance }];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        AppMatModule,
        SharedUtilityModule,
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        AcMasterLibModule.forRoot({ Url: environment.libURL }),
        FromDateToDateModule,

    ],
    declarations: [GeneralLedgerAccountBalance],
    entryComponents : [ ]
})

export class GeneralLedgerAcBalModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: GeneralLedgerAcBalModule
        }
    }
}