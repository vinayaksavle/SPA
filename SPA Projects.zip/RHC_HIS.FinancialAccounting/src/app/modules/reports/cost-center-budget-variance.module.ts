import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { CostCenterBudgetVarianceComponent } from 'src/app/components/reports/cost-center-budget-variance/cost-center-budget-variance.component';
import { FromDateToDateModule } from 'from-date-to-date';

const routes: Routes = [
  { path: '', component: CostCenterBudgetVarianceComponent }
];

@NgModule({
  declarations: [CostCenterBudgetVarianceComponent],
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
  ]
})
export class CostCenterBudgetVarianceModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: CostCenterBudgetVarianceModule
    };
  }
}
