import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { AcMasterLibModule } from "ac-master-lib";
import { AppMatModule, SharedUtilityModule } from "shared-utility";
import { environment } from "src/environments/environment";
import { FromDateToDateModule } from 'from-date-to-date';
import { ListOfTransaction } from "src/app/components/reports/list-of-transaction/transaction-list.component";
const routes: Routes = [{ path: '', component: ListOfTransaction }];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        AppMatModule,
        SharedUtilityModule,
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        AcMasterLibModule.forRoot({ Url: environment.libURL }),
        FromDateToDateModule,

    ],
    declarations: [ListOfTransaction],
    entryComponents : [ ]
})

export class ListOfTransactionModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: ListOfTransactionModule
        }
    }
}