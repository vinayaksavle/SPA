import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { AcMasterLibModule } from "ac-master-lib";
import { AppMatModule, SharedUtilityModule } from "shared-utility";
import { environment } from "src/environments/environment";
import { FromDateToDateModule } from 'from-date-to-date';
import { ControlACTransaction } from 'src/app/components/reports/control-ac-transaction/control-ac-transaction.component';
//import {NgxDataTableModule } from 'ngx-nested-data-table';
const routes: Routes = [{ path: '', component: ControlACTransaction }];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        AppMatModule,
        SharedUtilityModule,
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        AcMasterLibModule.forRoot({ Url: environment.libURL }),
        FromDateToDateModule,
       // NgxDataTableModule
    ], 
    declarations: [ControlACTransaction],
    entryComponents : [ ]
})

export class ControlACTransactionModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: ControlACTransactionModule
        }
    }
}