import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TrailBalanceComponent } from 'src/app/components/reports/trail-balance/trail-balance.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { FromDateToDateModule } from 'from-date-to-date';

const routes: Routes = [
  { path: '', component: TrailBalanceComponent }
];

@NgModule({
  declarations: [TrailBalanceComponent],
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    FromDateToDateModule,
  ],
})

export class TrailBalanceModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: TrailBalanceModule
    };
  }
}