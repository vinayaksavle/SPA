import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { AcMasterLibModule } from "ac-master-lib";
import { AppMatModule, SharedUtilityModule } from "shared-utility";
import { environment } from "src/environments/environment";
import { FromDateToDateModule } from 'from-date-to-date';
import { GlChartsAcComponent } from "../../components/reports/gl-charts-ac/gl-charts-ac.component";
import { MainGroupLookupModule } from 'main-group-lookup';

const routes: Routes = [{ path: '', component: GlChartsAcComponent }];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        AppMatModule,
        SharedUtilityModule,
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        AcMasterLibModule.forRoot({ Url: environment.libURL }),
        FromDateToDateModule,
        MainGroupLookupModule.forRoot({ Url: environment.apiURL }),
    ],
    declarations: [GlChartsAcComponent],
    entryComponents : [ ]
})

export class GlChartsAcModule { 
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: GlChartsAcModule
        }
    }
}