import { ModuleWithProviders, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UnpostedTransactionsComponent } from 'src/app/components/reports/unposted-transactions/unposted-transactions.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { FromDateToDateModule } from 'from-date-to-date';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';

const routes: Routes = [
  { path: '', component: UnpostedTransactionsComponent }
];

@NgModule({
  declarations: [UnpostedTransactionsComponent],
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    FromDateToDateModule,
  ]
})

export class UnpostedTransactionsModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: UnpostedTransactionsModule
    };
  }
}