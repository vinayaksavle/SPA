import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { AcMasterLibModule } from "ac-master-lib";
import { AppMatModule, SharedUtilityModule } from "shared-utility";
import { environment } from "src/environments/environment";
import { FromDateToDateModule } from 'from-date-to-date';
import { DeptWiseService } from "src/app/components/reports/dept-wise-service/dept-wise-service.component";
import { CreditCompanyLookupModule } from "credit-company-lookup";
import { DepartmentLookupModule } from "department-lookup";
import { PatientSourceDropdownModule } from "patient-source-dropdown";
import { ServiceHelpModule } from "service-help";
import { ServiceTabFieldModule } from "service-tab-field";
const routes: Routes = [{ path: '', component: DeptWiseService }];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        AppMatModule,
        SharedUtilityModule,
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        CreditCompanyLookupModule.forRoot({ Url: environment.apiURL }),
        FromDateToDateModule,
        DepartmentLookupModule.forRoot({ Url: environment.apiURL }),
        ServiceHelpModule.forRoot({ Url: environment.apiURL }),
        PatientSourceDropdownModule.forRoot({ Url: environment.apiURL }),
        ServiceTabFieldModule.forRoot({ Url: environment.apiURL })
    ],
    declarations: [DeptWiseService],
    entryComponents: []
})

export class DeptWiseServiceModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: DeptWiseServiceModule
        }
    }
}