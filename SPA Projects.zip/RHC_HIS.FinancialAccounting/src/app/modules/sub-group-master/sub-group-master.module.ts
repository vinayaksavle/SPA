import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { MainGroupLookupModule } from 'main-group-lookup';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { SubGroupActionDialog } from 'src/app/components/sub-group-master/sub-group-action.component';
import { SubGroupMaster } from 'src/app/components/sub-group-master/sub-group-master.component';
import { environment } from 'src/environments/environment';
import { DeactivateModalModule } from '../deactivate-modal/decativate-modal.module';

const routes: Routes = [
  { path: '', component: SubGroupMaster }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    DeactivateModalModule,
    ReactiveFormsModule,
    FormsModule,
    MainGroupLookupModule.forRoot({ Url: environment.apiURL })
  ],
  declarations: [
    SubGroupMaster,
    SubGroupActionDialog
  ],
  entryComponents: [SubGroupActionDialog]
})

export class SubGroupMasterModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SubGroupMasterModule
    };
  }
}
