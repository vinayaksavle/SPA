import { ElementRef, NgModule, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeductionCodeGlMappingComponent } from 'src/app/components/deduction-code-gl-mapping/deduction-code-gl-mapping.component';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { AcMasterLibModule } from 'ac-master-lib';
import { environment } from 'src/environments/environment';
import { DeductionCodeActionDialogComponent } from 'src/app/components/deduction-code-gl-mapping/deduction-code-action-dialog.component';

const routes: Routes = [
  { path: '', component: DeductionCodeGlMappingComponent }
];

@NgModule({
  declarations: [DeductionCodeGlMappingComponent,DeductionCodeActionDialogComponent],
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    ReactiveFormsModule,
    AcMasterLibModule.forRoot({Url:environment.apiURL})
  ],
  entryComponents: [DeductionCodeActionDialogComponent]
})

export class DeductionCodeGlMappingModule {
  
 }
