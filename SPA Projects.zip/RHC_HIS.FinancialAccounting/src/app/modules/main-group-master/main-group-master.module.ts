import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { MainGroupActionDialog } from 'src/app/components/main-group-master/main-group-action.component';
import { MainGroupMaster } from 'src/app/components/main-group-master/main-group-master.component';
import { DeactivateModalModule } from '../deactivate-modal/decativate-modal.module';

const routes: Routes = [
  { path: '', component: MainGroupMaster }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    DeactivateModalModule,
    ReactiveFormsModule,
    FormsModule
  ],
  declarations: [
    MainGroupMaster,  
    MainGroupActionDialog  
  ],
  entryComponents:[MainGroupActionDialog]
})

export class MainGroupMasterModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: MainGroupMasterModule
    };
  }
}
