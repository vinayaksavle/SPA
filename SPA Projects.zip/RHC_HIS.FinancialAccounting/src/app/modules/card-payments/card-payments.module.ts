import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { AcMasterLibModule } from "ac-master-lib";
import { AppMatModule, SharedUtilityModule } from "shared-utility";
import { environment } from "src/environments/environment";
import { FromDateToDateModule } from 'from-date-to-date';
import { CardPayments } from 'src/app/components/card-payments/card-payments.component';

const routes: Routes = [{ path: '', component: CardPayments }];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        AppMatModule,
        SharedUtilityModule,
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        AcMasterLibModule.forRoot({ Url: environment.libURL }),
        FromDateToDateModule
    ],
    declarations: [CardPayments],
    entryComponents : [ ]
})

export class CardPaymentsModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: CardPaymentsModule
        }
    }
}