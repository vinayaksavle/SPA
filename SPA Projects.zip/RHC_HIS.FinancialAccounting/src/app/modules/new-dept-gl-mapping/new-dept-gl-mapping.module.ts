import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NewDepartmentGlMappingComponent } from 'src/app/components/new-department-gl-mapping/new-department-gl-mapping.component';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { AcMasterLibModule } from 'ac-master-lib';
import { CostCentreLibModule } from 'cost-centre-lib';
import { environment } from 'src/environments/environment';

const routes: Routes = [
  { path: '', component: NewDepartmentGlMappingComponent }
];

@NgModule({
  declarations: [
    NewDepartmentGlMappingComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    ReactiveFormsModule,
    AcMasterLibModule.forRoot({ Url: environment.libURL }),
    CostCentreLibModule.forRoot({ Url: environment.libURL }),
  ],
  entryComponents: []
})
export class NewDeptGlMappingModule { }
