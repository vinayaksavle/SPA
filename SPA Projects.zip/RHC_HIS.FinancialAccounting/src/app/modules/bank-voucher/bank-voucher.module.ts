import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { AcMasterLibModule } from "ac-master-lib";
import { AppMatModule, SharedUtilityModule } from "shared-utility";
import { BankVoucherComponent } from 'src/app/components/bank-voucher/bank-voucher.component';
import { BillingCashCounterComponent } from "src/app/components/billing-cash-counter/billing-cash-counter.component";
import { environment } from "src/environments/environment";
import { FromDateToDateModule } from 'from-date-to-date';
import { CreditToAccountModal } from 'src/app/components/credit-to-account-modal/credittoaccount.component';


const routes: Routes = [{ path: '', component: BankVoucherComponent }];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        AppMatModule,
        SharedUtilityModule,
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        AcMasterLibModule.forRoot({ Url: environment.libURL }),
        FromDateToDateModule
    ],
    declarations: [BankVoucherComponent,CreditToAccountModal],
    entryComponents : [CreditToAccountModal ]
})

export class BankVoucherModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: BankVoucherModule
        }
    }
}