import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { DepartmentGlMappingComponent } from 'src/app/components/department-gl-mapping/department-gl-mapping.component';
import { ReactiveFormsModule } from '@angular/forms';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';

const routes: Routes = [
  { path: '', component: DepartmentGlMappingComponent }
];

@NgModule({
  declarations: [
    DepartmentGlMappingComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    ReactiveFormsModule
  ],
  entryComponents: []
})
export class DepartmentGlMappingModule { }
