import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { AcMasterLibModule } from "ac-master-lib";
import { AppMatModule, SharedUtilityModule } from "shared-utility";
import { environment } from "src/environments/environment";
import { FromDateToDateModule } from 'from-date-to-date';
import { VoucherNumber } from 'src/app/components/voucher-number/voucher-number.component';
import { VoucherNumberActionDialog } from 'src/app/components/voucher-number/voucher-number-action-dialog.component';

const routes: Routes = [{ path: '', component: VoucherNumber }];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        AppMatModule,
        SharedUtilityModule,
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        AcMasterLibModule.forRoot({ Url: environment.libURL }),
        FromDateToDateModule
    ],
    declarations: [VoucherNumber,VoucherNumberActionDialog],
    entryComponents : [ VoucherNumberActionDialog ]
})

export class VoucherNumberModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: VoucherNumberModule
        }
    }
}