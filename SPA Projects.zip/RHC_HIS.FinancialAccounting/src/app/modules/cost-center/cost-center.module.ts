import { CommonModule } from '@angular/common';
import { NgModule, ModuleWithProviders, OnInit } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { CostCenterActionDialog } from 'src/app/components/cost-center/cost-center-action.component';
import { CostCenterComponent } from 'src/app/components/cost-center/cost-center.component';
import { DeactivateDialogComponent } from 'src/app/components/deactivate-modal/deactivate-modal.component';
import { DeactivateModalModule } from '../deactivate-modal/decativate-modal.module';

const routes: Routes = [
  { path: '', component: CostCenterComponent }
];

@NgModule({
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    ReactiveFormsModule
  ],
  declarations: [
    CostCenterComponent,
    CostCenterActionDialog,
  ],
  entryComponents: [CostCenterActionDialog]
})

export class CostCenterModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: CostCenterModule
    };
  }
}
