import { NgModule ,ModuleWithProviders} from '@angular/core';
import { CommonModule } from '@angular/common';
import { VoucherTypeMasterComponent } from 'src/app/components/voucher-type-master/voucher-type-master.component';
import { RouterModule, Routes } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { AppMatModule, SharedUtilityModule } from 'shared-utility';
import { VoucherTypeActionDialogComponent } from 'src/app/components/voucher-type-master/voucher-type-action-dialog.component';
const routes: Routes = [
  { path: '', component: VoucherTypeMasterComponent }
];
@NgModule({
  imports: [
    RouterModule.forChild(routes),
    AppMatModule,
    SharedUtilityModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
  ],
  declarations: [
    VoucherTypeMasterComponent,
    VoucherTypeActionDialogComponent
  ],
  entryComponents: [VoucherTypeActionDialogComponent]
})
export class VoucherTypeModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: VoucherTypeModule
    };
  }
 }
