import { CommonModule } from "@angular/common";
import { ModuleWithProviders, NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { RouterModule, Routes } from "@angular/router";
import { AcMasterLibModule } from "ac-master-lib";
import { AppMatModule, SharedUtilityModule } from "shared-utility";
import { BillingCashCounterComponent } from "src/app/components/billing-cash-counter/billing-cash-counter.component";
import { environment } from "src/environments/environment";
import { FromDateToDateModule } from 'from-date-to-date';
import { SupplierProfile } from '../../components/supplier-profile/supplier-profile.component';
import { SupplierPopupComponent } from "src/app/components/supplier-profile/supplier-popup.component";

const routes: Routes = [{ path: '', component: SupplierProfile }];

@NgModule({
    imports: [
        RouterModule.forChild(routes),
        AppMatModule,
        SharedUtilityModule,
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
        AcMasterLibModule.forRoot({ Url: environment.libURL }),
        FromDateToDateModule
    ],
    declarations: [SupplierProfile, SupplierPopupComponent],
    entryComponents : [ SupplierPopupComponent ]
})

export class SupplierProfileModule {
    static forRoot(): ModuleWithProviders {
        return {
            ngModule: SupplierProfileModule
        }
    }
}