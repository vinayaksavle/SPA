import { Injectable } from '@angular/core';
import { webSocket, WebSocketSubject } from 'rxjs/webSocket';



@Injectable({  providedIn: 'root' })
export class WebSocketService {
  private URL:string  = "ws://127.0.0.1";
  private PORT:string= "5000";
  private subject : any;
  constructor() { }


  connect() {    
    
    this.subject = new WebSocketSubject(this.URL+ ":" + this.PORT);
    
    this.subject.subscribe(
      (msg) => console.log(msg),
      (err) => console.log(err),
      () => console.log("completed")
    );
    
    return this.subject;
  }

  send(message : string) {
    this.subject.next(message);
  }
}