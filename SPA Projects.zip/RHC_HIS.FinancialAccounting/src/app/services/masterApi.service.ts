import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ErrorPageComponent } from '../components/_layout/error-page/error-page.component';



@Injectable({ providedIn: 'root' })
export class MasterApiService {

  constructor(private http: HttpClient, public dialog: MatDialog) { }

  private prepareHeader(headers: HttpHeaders | null): object {
    headers = headers || new HttpHeaders();
    headers.set('center', localStorage.hasOwnProperty('Facility') ? localStorage.getItem('Facility') : '0');
    headers.set('userId', localStorage.hasOwnProperty('UserName') ? localStorage.getItem('UserName') : '');
    headers.set('Content-Type', 'application/json');
    return {
      headers: headers
    };
  }


  getHttpOptions() {
    return {
      headers: new HttpHeaders({
        'center': localStorage.hasOwnProperty('Facility') ? localStorage.getItem('Facility') : '0',
        'userId': localStorage.hasOwnProperty('UserName') ? localStorage.getItem('UserName') : ''
      })
    };
  }

  Get(url: string, headers?: HttpHeaders | null): Observable<any> {
    return this.http.get<any>(url, this.getHttpOptions()).pipe(catchError(this.handleError<any>(url)));
  }

  Post(url: string, body: any, header?: HttpHeaders | null): Observable<any> {
    return this.http.post<any>(url, body, this.getHttpOptions()).pipe(catchError(this.handleError<any>(url)));
  }

  AutoComplete(url: string, header?: HttpHeaders | null): Observable<any> {
    return this.http.get<any>(url, this.getHttpOptions()).pipe(catchError(this.handleError<any>(url)));
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      if (error.status != 200 || error.Data == null) {
        if (error.status == 0) {
          // error.error.Message = messageConstant.Common.ServerError;
          this.dialog.open(ErrorPageComponent, { data: { key: error } });
        }
        else {
          this.dialog.open(ErrorPageComponent, { data: { key: error } });
        }
      }

      // console.error(error);

      // console.log(`${operation} failed: ${error.message}`);

      return of(result as T);
    };
  }
}