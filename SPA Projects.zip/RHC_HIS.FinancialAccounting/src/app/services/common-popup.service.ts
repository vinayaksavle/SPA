import { Injectable } from '@angular/core';
// import { ChangeIPDCounterComponent } from 'projects/HIS-ADT/src/app/components/change-ipd-counter/change-ipd-counter.component';
import { isNullOrUndefined } from 'util';
import { DataTranferService } from './data-transfer.service';
import { CommonService } from './common.service';
import { MatDialog } from '@angular/material';
// import { ChangeOpdCounterComponent } from 'projects/HIS-OPD/src/app/components/change-opd-counter/change-opd-counter.component';


@Injectable({
    providedIn: 'root'
})

export class CommonPopupService {
}
// export class CommonPopupService {
//     IPDChangePermission: boolean;
//     OPDChangePermission: boolean;

//     constructor(public commonService: CommonService, public dataTransferService: DataTranferService
//         , private dialog: MatDialog) { }


//     // call change ipd component
//     // pass true for reload nad false for redirect
//     changeIPD(reload_redirect: string) {
//         // User Permissions
//         // this.OPDChangePermission = this.dataTransferService.checkAccessRights('023');
//         this.IPDChangePermission = true;
//         if (this.IPDChangePermission) {
//             const dialogRef = this.dialog.open(ChangeIPDCounterComponent, {
//                 width: "400px",
//                 disableClose: true
//             });

//             dialogRef.componentInstance.currentIPDCounter = this.dataTransferService.getObject('IPDCounterName');

//             dialogRef.afterClosed().subscribe(dialogResult => {

//                 if (!isNullOrUndefined(dialogResult)) {


//                     this.dataTransferService.setCookie('IPDCounterNo', dialogResult.CounterNo);
//                     this.dataTransferService.setCookie('IPDCounterName', dialogResult.Name);
//                     switch (reload_redirect) {
//                         case "R":
//                             window.location.reload();
//                             break;
//                         case "P":
//                             window.location.href = location.origin + '/#/patient/search';
//                             break;
//                         case "N":
//                             this.changeOPD("P");
//                             break;
//                     }

//                 }
//                 else {

//                     if (dialogResult === null) {
//                         this.commonService.openSnackBar('Invalid IPD Counter', "Ok");
//                         return;
//                     }
//                 }
//             });
//         }
//         else {
//             this.commonService.openSnackBar('Not Authorized User', "Ok");
//             return;

//         }
//     }


//     setAdmissionCounter(reload_redirect: string) {
//         let cookie = document.cookie;
//         if (isNullOrUndefined(cookie) || cookie.indexOf("IPDCounterNo") === -1) {
//             this.changeIPD(reload_redirect);
//         }
//         else {
//             if (reload_redirect == "N")
//                 this.changeOPD("P");
//             else
//                 window.location.href = location.origin + '/#/patient/search';
//         }
//     }



//     // call change opd component
//     changeOPD(reload_redirect: string) {
//         // User Permissions
//         this.OPDChangePermission = this.dataTransferService.checkAccessRights('023');
//         if (this.OPDChangePermission) {
//             const dialogRef = this.dialog.open(ChangeOpdCounterComponent, {
//                 width: "400px",
//                 disableClose: true
//             });


//             dialogRef.componentInstance.currentOPDCounter = this.dataTransferService.getObject('OPDCounterName');

//             dialogRef.afterClosed().subscribe(dialogResult => {
//                 if (!isNullOrUndefined(dialogResult)) {
//                     this.updateOPD(dialogResult, reload_redirect);
//                 }
//                 else {
//                     if (dialogResult === null) {
//                         this.commonService.openSnackBar('Invalid OPD Counter', "Ok");
//                         return;
//                     }
//                 }
//             });
//         }
//         else {
//             this.commonService.openSnackBar('Not Authorized User', "Ok");
//             return;

//         }
//     }

//     //Called on changing the current OPD
//     updateOPD(dialogResult: any, reload_redirect: string) {

//         switch (reload_redirect) {
//             case "R":
//                 this.commonService.confirmAction("Change", "Change OPD Counter ?").subscribe(response => {
//                     if (response) {
//                         this.setOPDValues(dialogResult);
//                         window.location.reload();
//                     }
//                 });
//                 break;
//             case "P":
//                 this.setOPDValues(dialogResult);
//                 window.location.href = location.origin + '/#/patient/search';
//                 break;
//             case "N":
//                 this.changeIPD("P");
//                 break;
//         }
//     }

//     setOPDValues(dialogResult: any) {
//         this.dataTransferService.setDefaultOpd(dialogResult.CounterNo);
//         this.dataTransferService.setValueInLocalStorage('OPDCounterName', dialogResult.Name);
//         this.dataTransferService.setValueInLocalStorage("OPDCounterDept", dialogResult.DeptCode);
//     }
// }
