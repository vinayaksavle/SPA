import { Injectable } from '@angular/core';
import { isNullOrUndefined } from 'util';

export class TransactionResponse {  
  Amount: string;
  TransactionNumber: string;
  BankName: string;
  CardNumber: string;
  CardType:string;
  Remark:string;
  Status: boolean;
}
@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  constructor() { }
  url : string = "ws://localhost:2012/echo";
  DoTransaction(data: string) : string  {
    if(!isNullOrUndefined(data)) {
      var ws = new WebSocket(this.url);      
      console.log("Connecting...");
      ws.onopen = function() {
        console.log("Data Sending...");
        ws.send(data);        
      }
      ws.onmessage = function(event) {
        console.log("Receiving...");
        if(!isNullOrUndefined(event) && !isNullOrUndefined(event.data)) {
          console.log(PaymentService.ParseResponse(event.data));
          return PaymentService.ParseResponse(event.data); 
        }
      }
      ws.onclose = function() {
        //ws.close();
      }
      window.onbeforeunload = function(event) {
        ws.close();
      }
    }
  return "";
  }
  static ParseResponse(msg : string) {
    let txnResponse:TransactionResponse = new TransactionResponse();
    let response = msg.split(",");
    console.log("ParseResponse");
    console.log(response);
    if(response.length > 0) {
      if(!isNullOrUndefined(response[2]) && response[2].trim().length > 0) {
        txnResponse.Remark =(!isNullOrUndefined(response[2])&&response[2]!=="")? response[2].replace(/"/g, "").trim() : "";
        txnResponse.TransactionNumber = (!isNullOrUndefined(response[0])&&response[0]!="")?response[0].replace(/"/g, "").trim() : "";
        txnResponse.CardNumber = (!isNullOrUndefined(response[3])&&response[3]!="")?response[3].replace(/"/g, "").trim() : "";
        txnResponse.CardType = (!isNullOrUndefined(response[6])&&response[6]!="")?response[6].replace(/"/g, "").trim() : "";
        txnResponse.BankName = (!isNullOrUndefined(response[12])&&response[12]!="")?response[12].replace(/"/g, "").trim() : "";
        if(response[2].replace(/"/g, "").trim() == "APPROVED")
          txnResponse.Status = true;
        else txnResponse.Status = false;
      }
    }
    else { // if no card shown to the machine
      txnResponse.Remark = response[11].replace(/"/g, "").trim();
      txnResponse.TransactionNumber = response[0].replace(/"/g, "").trim();
      txnResponse.Status = false;
    }
    return txnResponse;
  } 
}
