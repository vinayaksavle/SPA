import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ErrorPageComponent } from '../components/_layout/error-page/error-page.component';
import { environment } from 'src/environments/environment';


@Injectable({ providedIn: 'root' })
export class HttpService {

  smartCardUrl: string = environment.smartCardUrl;
  constructor(private http: HttpClient, public dialog: MatDialog) { }

  private prepareHeader(headers: HttpHeaders | null): object {
    headers = headers || new HttpHeaders();
    headers.set('center', localStorage.hasOwnProperty('Facility') ? localStorage.getItem('Facility') : '0');
    headers.set('userId', localStorage.hasOwnProperty('UserName') ? localStorage.getItem('UserName') : '');
    headers.set('Content-Type', 'application/json;  charset=utf-8');
    return {
      headers: headers
    };
  }


  getHttpOptions() {
    return {
      headers: new HttpHeaders({
        'center': localStorage.hasOwnProperty('Facility') ? localStorage.getItem('Facility') : '0',
        'userId': localStorage.hasOwnProperty('UserName') ? localStorage.getItem('UserName') : ''
      })
    };
  }

  Get(url: string, noUseParam?: boolean | null): Observable<any> {
    return this.http.get<any>(url, this.getHttpOptions()).pipe(catchError(this.handleError<any>(url)));
  }

  Post(url: string, body: any, noUseParam?: boolean | null): Observable<any> {
    return this.http.post<any>(url, body, this.getHttpOptions()).pipe(catchError(this.handleError<any>(url)));
  }

  Put(url: string, body: any, noUseParam?: boolean | null): Observable<any> {
    return this.http.put<any>(url, body, this.getHttpOptions()).pipe(catchError(this.handleError<any>(url)));
  }

  AutoComplete(url: string, noUseParam?: boolean | null): Observable<any> {
    return this.http.get<any>(url, this.getHttpOptions()).pipe(catchError(this.handleError<any>(url)));
  }

  

  openFile(filePath: string) {
    window.open(environment.domainURL + filePath);
  }

  GetSmartCard(url: string): Observable<any> {
    return this.http.get<any>(this.smartCardUrl + url).pipe(catchError(this.handleError<any>()));
  }
  GetPrinters(url: string): Observable<any> {
    return this.http.get<any>(this.smartCardUrl + url).pipe(catchError(this.handleError<any>()));
  }

  PostPrinter(url: string, body: any): Observable<any> {
    return this.http.post<any>((this.smartCardUrl) + url, body).pipe(catchError(this.handleError<any>(url)));
  }

  getJSON(url: string) {
    return this.http.get(url).pipe(catchError(this.handleError<any>(url)));
  }

  viewDocument(filePath: string, noUseParam?: boolean | null) {
    window.open(filePath);
  }

  GetLocalService(url: string): Observable<any> {
    return this.http.get<any>(url).pipe(catchError(this.handleError<any>()));
  }

  PostLocalService(url: string, body: any): Observable<any> {
    return this.http.post<any>(url, body).pipe(catchError(this.handleError<any>(url)));

  }

  private handleError<T>(operation = 'operation', result?: T) {

    return (error: any): Observable<T> => {

      if (error.status != 200 || error.Data == null) {
        if (error.status == 0) {
          // error.error.Message = messageConstant.Common.ServerError;
          this.dialog.open(ErrorPageComponent, { data: { key: error }, width: '650px' });
        }
        else {
          this.dialog.open(ErrorPageComponent, { data: { key: error }, width: '650px' });
        }
      }
      return of(result as T);
    };
  }
}