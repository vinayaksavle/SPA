import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { HttpService } from './http.service';
import { isNullOrUndefined } from 'util';
import { LoaderService } from './loader.service';


@Injectable({ providedIn: 'root' })
export class HelperService {
  titleList: any;
  constructor(private httpService: HttpService, private loader: LoaderService) { }

  // Export grid data to excel sheet.
  exportToExcel(url: string, searchObj: any) {
    this.httpService.Post(url, searchObj).subscribe((response: any) => {
      if (response && !isNullOrUndefined(response.Data) && response.Data.length > 0) {
        this.httpService.openFile(response.Data);
      }
      this.loader.spin.next(false);
    }, (error) => {
      this.loader.spin.next(false);
      console.error(error);
    });
  }

}
