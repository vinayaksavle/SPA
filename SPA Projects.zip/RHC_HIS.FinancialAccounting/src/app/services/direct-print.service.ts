import { Injectable } from '@angular/core';
import { Observable, Subject, Observer } from "rxjs";
import { map } from "rxjs/operators";
import { WebSocketService } from "./web-socket.service";


@Injectable({
  providedIn: 'root'
})
export class DirectPrintService {
  public data: Subject<any>;

  constructor(private wsService: WebSocketService) { }
  public connect() {
    this.data = <Subject<any>>this.wsService.connect().pipe(map((response: MessageEvent) => {
    }));
  }

  public close() {
    console.log("Dis-connecting ");

  }

  public print(data: any) {
    data.FilePath = window.location.origin + data.FilePath;
    console.log(data.FilePath);
    this.wsService.send(data);
  }

}
