import { MatSnackBar, MatDialog } from '@angular/material';
import { Injectable } from '@angular/core';
import { isNullOrUndefined } from 'util';
import { HttpService } from './http.service';
import { BehaviorSubject } from 'rxjs';
import { FormGroup } from '@angular/forms';
import { ConfirmDialogModel, ConfirmDialogComponent } from '../components/confirm-dialog/confirm-dialog.component';
import { DataTranferService } from './data-transfer.service';
import { InputConfirmDialogComponent, InputConfirmDialogModel } from '../components/input-confirm-dialog/input-confirm-dialog.component';
import { DeactivateDialogComponent, DeactivateDialogModel } from '../components/deactivate-modal/deactivate-modal.component';


interface ILabelReponse {
    LabelHTML: string,
    BarcodeBase64: string
}


@Injectable({ providedIn: 'root' })
export class CommonService {
    labelData: any = {};
    labelResponse: ILabelReponse;
    configurationData: any;
    IPDChangePermission: any;
    constructor(public httpService: HttpService, private snackBar: MatSnackBar, private dialog: MatDialog,
        private dataTransferService: DataTranferService) { }

    private demographicInfo = new BehaviorSubject<any>({});
    getDemographicForm = this.demographicInfo.asObservable();
    private regInfo = new BehaviorSubject<any>({});
    getRegInfoForm = this.regInfo.asObservable();
    private ipdInfoForm = new BehaviorSubject<any>({});
    getIpdInfoForm = this.ipdInfoForm.asObservable();
    private nextOfKinInfo = new BehaviorSubject<any>({});
    getNextOfKinForm = this.nextOfKinInfo.asObservable();

    setDemographicForm(form: string) {
        this.demographicInfo.next(form);
    }
    setRegInfoForm(form: string) {
        this.regInfo.next(form);
    }
    setIpdInfoForm(form: string) {
        this.ipdInfoForm.next(form);
    }
    setNextOfKinForm(form: string) {
        this.nextOfKinInfo.next(form);
    }

    // Used for get new patient type value
    private changedPatientType = new BehaviorSubject<any>({});
    getPatientType = this.changedPatientType.asObservable();

    // Used for set new patient type value from regForm
    setPatientType(val: string) {
        this.changedPatientType.next(val);
    }

    private billCategory = new BehaviorSubject<any>({});
    getBillCategory = this.billCategory.asObservable();
    setBillCategory(val) {
        this.billCategory.next(val);
    }

    // Used for get new Admission type value
    private changedAdmissionType = new BehaviorSubject<any>({});
    getAdmissionType = this.changedAdmissionType.asObservable();

    // Used for set new Admission type value from regForm
    setAdmissionType(val: string) {
        this.changedAdmissionType.next(val);
    }

    private changedGender = new BehaviorSubject<any>({});
    getGender = this.changedGender.asObservable();


    setGender(val: string) {
        this.changedGender.next(val);
    }

    private changeCaseType = new BehaviorSubject<any>({});
    getCaseType = this.changeCaseType.asObservable();

    setCaseType(val: any) {
        this.changeCaseType.next(val);
    }




    // To Set and Get Address formcontrols of demographic info.
    private presentAddressList = new BehaviorSubject<any>({});
    getPresentAddressList = this.presentAddressList.asObservable();

    setPresentAddressList(val: any) {
        this.presentAddressList.next(val);
    }

    // To get and set config data
    // tslint:disable-next-line: member-ordering
    private configData = new BehaviorSubject<any>({});
    // tslint:disable-next-line: member-ordering
    getConfigData = this.configData.asObservable();
    setConfigData(val: any) {
        this.configData.next(val);
    }

    // To get and set config data
    private patientData = new BehaviorSubject<any>({});
    getPatientData = this.patientData.asObservable();
    setPatientData(val: any) {
        this.patientData.next(val);
    }

    // To get and set file data
    // tslint:disable-next-line: member-ordering
    private filesList = new BehaviorSubject<any>({});
    // tslint:disable-next-line: member-ordering
    filesData = this.filesList.asObservable();
    setFilesData(val: any) {
        this.filesList.next(val);
    }

    // tslint:disable-next-line: member-ordering
    private documents = new BehaviorSubject<any>({});
    documentData = this.documents.asObservable();
    setDocuments(val: any) {
        this.documents.next(val);
    }

    encodeValue(value: string): string {
        return encodeURIComponent(value);
    }

    decodeValue(value: string): string {
        return decodeURIComponent(value);
    }

    getISODate(date): string {
        if (date) {
            date = new Date(Number(date.year), Number(date.month - 1), Number(date.day)).toISOString();
        }
        return date;
    }

    convertAge(dateString: any): any {
        var age = "0";
        if (dateString && dateString.trim().length == 8) {
            var today = new Date();
            let dd = (dateString.substring(6, 8));
            let mm = (dateString.substring(4, 6));
            let yyyy = (dateString.substring(0, 4));


            var birthDate = new Date(yyyy, mm, dd);
            var year = today.getFullYear() - birthDate.getFullYear();
            var month = today.getMonth() - birthDate.getMonth();
            var day = today.getDate() - birthDate.getDate();
            if (month < 0 || (month === 0 && today.getDate() < birthDate.getDate())) {
                year--;
            }


            if (year == 0 && month === 0) {
                age = day + " days ";
            }
            else if (year == 0 && month <= 6) {
                age = month + " months " + day + " days ";
            }
            else if (year == 0 && month > 6) {
                age = month + " months ";
            }
            else if (year >= 1) {
                age = year + " years";
            }


        }

        return age;
    }

    getISODateFromString(date: string): string {
        let iSODateString;
        let billDate;
        if (date && date.length == 8) {
            let _year = date.substring(0, 4);
            let _month = date.substring(4, 6);
            let _day = date.substring(6, 8);
            billDate = { year: _year, month: _month, day: _day };
            iSODateString = this.getISODate(billDate);
        }
        else {
            iSODateString = null;
        }
        return iSODateString;
    }

    getDateFromString(date: string): string {

        let billDate;
        if (date && date.length == 8) {
            let _year = date.substring(0, 4);
            let _month = date.substring(4, 6);
            let _day = date.substring(6, 8);
            billDate = _day + "/" + _month + "/" + _year;
            return billDate;
        }
        else {
            billDate = null;
        }
        return billDate;
    }

    noData() {
        return "No Record Found";
    }


    /**
     * Valiate Date formate at time of manually enter date
     * @param value
     */
    maskDate(value) {
        if (value == 'from') { var input = document.querySelectorAll('.js-from-date')[0]; }
        else { var input = document.querySelectorAll('.js-to-date')[0]; }
        var dateInputMask = function dateInputMask(elm) {
            elm.addEventListener('keypress', function (e) {
                if (e.keyCode < 47 || e.keyCode > 57) { e.preventDefault(); }
                var len = elm.value.length;
                if (len !== 1 || len !== 3) { if (e.keyCode == 47) { e.preventDefault(); } }
                if (len === 2) { elm.value += '/'; }
                if (len === 5) { elm.value += '/'; }
            });
        }; dateInputMask(input);
    }

    validateDate(value) {
        let today = { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() };
        if (value == 'from') { var input = document.querySelectorAll('.js-from-date')[0]; }
        else { var input = document.querySelectorAll('.js-to-date')[0]; }
        var dateInputMask = function dateInputMask(elm) {
            elm.addEventListener('keypress', function (e) {
                if (e.keyCode < 47 || e.keyCode > 57) { e.preventDefault(); }
                var len = elm.value.length;
                if (len !== 1 || len !== 3) { if (e.keyCode == 47) { e.preventDefault(); } }
                if (len === 2) {
                    if (elm.value > 31) { elm.value = '01'; }
                    elm.value += '/';
                }
                if (len === 5) {
                    if (Number(elm.value.slice(3, 5)) > 12) {
                        elm.value = elm.value.slice(0, -2);
                        elm.value += '01';
                    }
                    elm.value += '/';
                }
            });
        }; dateInputMask(input);
    }

    fromToDateValidation(fromDate, toDate) {
        if (!isNullOrUndefined(fromDate) && !isNullOrUndefined(toDate)) {
            let from = new Date(Number(fromDate.year), Number(fromDate.month - 1), Number(fromDate.day)).toISOString();
            let to = new Date(Number(toDate.year), Number(toDate.month - 1), Number(toDate.day)).toISOString();
            if (from > to) {
                return false;
            }
        }
    }

    // returns the current date in yyyymmdd format
    FormatDate(currentDate: Date) {
        var date = "";
        if (!isNullOrUndefined(currentDate)) {
            var year = currentDate.getFullYear().toString();

            var month = (currentDate.getMonth() + 1).toString();
            if (month.length == 1) {
                month = "0" + month;
            }

            var day = currentDate.getDate().toString();
            if (day.length == 1) {
                day = "0" + day;
            }
            date = year + month + day;
        }
        return date;
    }



    //checks whether string value is null or blank
    isValidStringValue(value: string) {
        var valid: boolean = true;

        if (isNullOrUndefined(value)) {
            valid = false;
        }

        if (typeof value === "string") {
            if (value.trim() === "" || value === "undefined") {
                valid = false;
            }
        }

        return valid;
    }
    //checks whether string value is null or blank
    isValidStringForAddress(value: string) {
        var valid: boolean = true;
        if (isNullOrUndefined(value) || value === "null" || value === "undefined") {
            valid = false;
        }

        return valid;
    }


    //compares whether value1 is greater than value2
    compareValues(value1: number, value2: number) {
        var valid: boolean = true;
        if (value1 > value2) {
            valid = false;
        }
        return valid;
    }

    // applies and removes field focus
    // setFieldFocus(fieldId: string) {
    //     setTimeout(function () {
    //         $('#' + fieldId).focus();
    //     }, 500)
    // }


    // close Modal popup
    // closeModal(modalId: string) {
    //     $('#' + modalId).modal('hide');
    // }


    // match regex
    matchRegex(value: string, regexString: string) {
        console.log(String(value).match("^\-?\d*\.?[0-9]{0,2}$"));
    }

    setFieldFocus(id: string) {
        setTimeout(() => {
            document.getElementById(id).focus();
        }, 100);

    }

    toggleCloseBtn(f: any, componentName: string, ...otherComponentList: any) {
        let component = f[componentName];
        if (!isNullOrUndefined(component.value) && component.value.length > 0) {
            component.setValue('');
            for (let otherComponent of otherComponentList) {
                if (f[otherComponent])
                    f[otherComponent].setValue('');
            }
        }
        else return;
    }

    StringFormat = (str: string, ...args: string[]) =>
        str.replace(/{(\d+)}/g, (match, index) => args[index] || '')

    // LABEL PRINTING
    printLabel(rowDetails) {
        this.labelData = {
            PID: rowDetails.PID,
            RegistrationNumber: rowDetails.RegistrationNumber,
            PatientName: rowDetails.Name,
            PatientCategory: rowDetails.PatientCategoryName,
            DOB: rowDetails.DOB,
            UHID: "",
            Gender: rowDetails.Gender,
            DoctorName: rowDetails.DoctorName,
            RegDate: rowDetails.RegDate,
            RegTime: rowDetails.RegTime
        };

        if (rowDetails.UHID == "" || isNullOrUndefined(rowDetails.UHID)) {
            this.labelData.UHID = rowDetails.PID;
        }
        else {
            this.labelData.UHID = rowDetails.UHID;
        }

        this.httpService.Post('CentralPatient/PrintLabel', this.labelData).subscribe(Response => {

            if (Response.Status === 200) {
                var i = 0

                let newWindow = window.open('', '_blank', 'top=4,left=3,height=100%,width=auto');
                newWindow.document.open();
                let html = "";
                Response.Data.imgList.forEach(function (img: string) {
                    html = '<html><head><title></title>' +
                        '<link rel="stylesheet" href="css/mycss.css" type="text/css" />' +
                        '</head><body onload="window.focus(); window.print(); window.close()"><img src="data:image/jpeg;base64,' + img + '" id="fid' + [i] + '" style="height:80px;margin-top:10px;margin-left:23px"/></body></html>';
                    newWindow.document.write(html);

                });
                newWindow.document.close();
            }
        });

    }


    // To Set and Get DropDown of PatientType. dadhasjdh
    private data = new BehaviorSubject<any>({});
    getData = this.data.asObservable();

    setData(val: string) {
        this.data.next(val);
    }

    // Get the required UI static values from OPD-Client.config.json
    getConfigurationData() {
        // this.httpService.getJSON(urlConstant.newReservationAccount.GetADTConfig).subscribe(Response => {
        //     this.configurationData = Response;
        //     this.setConfigData(this.configurationData);
        // });
        return this.configurationData;
    }

    // Get the required UI static values from OPD-Client.config.json
    getHCConfigurationData() {
        this.httpService.getJSON('assets/HealthCheckupClientConfig.json').subscribe(Response => {
            this.configurationData = Response;
            this.setConfigData(this.configurationData);
        });
        return this.configurationData;
    }

    getControlDescription(controlName) {
        if (this.configurationData.controlList) {
            let controlDesc: any;
            controlDesc = this.configurationData.controlList[controlName];
            if (controlDesc) {
                return controlDesc;
            }
        }
        return controlName;
    }

    showErrorMessage(isInvalid, controlName, addess = null) {
        this.getConfigData.subscribe(response => {
            this.configurationData = response;
        });
        if (!isNullOrUndefined(this.configurationData)) {
            if (isInvalid) {
                this.openSnackBar(
                    this.StringFormat(
                        this.configurationData.ValidationMessage.InvalidValue,
                        !isNullOrUndefined(addess) ? addess + this.getControlDescription(controlName) : this.getControlDescription(controlName)
                    ),
                    'Ok'
                );
                //  this.loaderService.spin.next(false);
                // TODO : focus
                // (<any>controlName).nativeElement.focus();
                return false;
            }
        }
    }

    showMaxlengthMessage(isInvalid, controlName, length, addess = null) {
        this.getConfigData.subscribe(response => {
            this.configurationData = response;
        });
        if (!isNullOrUndefined(this.configurationData)) {
            if (isInvalid) {
                this.openSnackBar(
                    this.StringFormat(
                        this.configurationData.ValidationMessage.MaxLength,
                        !isNullOrUndefined(addess) ? addess + this.getControlDescription(controlName) : this.getControlDescription(controlName)
                        , length
                    ),
                    'Ok'
                );
                //  this.loaderService.spin.next(false);
                // TODO : focus
                // (<any>controlName).nativeElement.focus();
                return false;
            }
        }
    }


    // opens snack bar
    openSnackBar(message: string, action: string) {
        this.snackBar.open(message, action, {
            duration: 5000,
            verticalPosition: 'top'
        });
    }


    PrintLabel(labelData: ILabelReponse) {
        let newWindow = window.open('', '_blank', 'top=4,left=3,height=100%,width=auto');
        newWindow.document.open();
        let html = labelData.LabelHTML;
        if (this.isValidStringValue(labelData.BarcodeBase64)) {
            html = html.replace(/ReplaceWithBase64String/g, labelData.BarcodeBase64)

        }
        newWindow.document.write(html);
        newWindow.document.close();
    }

    private checked = new BehaviorSubject<any>({});
    getChecked = this.checked.asObservable();

    setChecked(form: boolean) {
        this.checked.next(form);
    }


    //Newly Added Function for UpperCase Issue.
    //Date:- 11/11/2019
    //Author:-Bhushan T
    convertToUpper(val: string): string {
        if (!isNullOrUndefined(val)) {
            return val.toUpperCase();
        }
        else {
            return val;
        }

    }


    // Common method for form confirm dialog box
    confirmAction(actionName: string, actionDescription: string) {
        const dialogData = new ConfirmDialogModel(
            actionName,
            actionDescription,
            'Yes',
            'No'
        );

        const dialogRef = this.dialog.open(ConfirmDialogComponent, {
            width: '400px',
            data: dialogData,
            disableClose: false
        });
        return dialogRef.afterClosed();
    }

    // Common method for input remarks dialog box
    inputConfirmAction(actionName: string, actionDescription: string, remarks?: string) {

        const dialogData = new InputConfirmDialogModel(
            actionName,
            actionDescription,
            remarks,
            'Deactivate',
            'Close'
        );

        const dialogRef = this.dialog.open(InputConfirmDialogComponent, {
            width: '400px',
            data: dialogData,
            disableClose: false
        });

        // dialogRef.afterClosed().subscribe(result => {
        //     console.log('Result ' + result);
        //     this.remarks = result;
        // });
        return dialogRef.afterClosed();
    }

    // Common Deactivate dialog modal. Remarks are optional can pass default remarks value
    deactivateAction(actionName: string, actionDescription: string, remarks?: string, deactivateActionLabel:string='Deactivate') {
        const dialogData = new DeactivateDialogModel(
            actionName,
            actionDescription,
            remarks,
            deactivateActionLabel,
            'Close',
            
        );

        const dialogRef = this.dialog.open(DeactivateDialogComponent, {
            width: '400px',
            data: dialogData,
            disableClose: false
        });

        return dialogRef.afterClosed();
    }

    // Common method for PROMPT
    displayPromptMessage(actionName: string, actionDescription: string) {
        const dialogData = new ConfirmDialogModel(
            actionName,
            actionDescription,
            'Close'
        );

        const dialogRef = this.dialog.open(ConfirmDialogComponent, {
            width: '400px',
            data: dialogData,
            disableClose: false
        });
        return dialogRef.afterClosed();
    }


    // Converts JS date format to yyyymmdd
    convertDateToString(date: any = new Date()) {
        if (isNullOrUndefined(date._isAMomentObject)) {

            let month = date.getMonth() + 1;
            let day = date.getDate();

            return date.getFullYear() + "" + (month < 10 ? "0" + month : month) + "" + (day < 10 ? "0" + day : day);
        }
        else {

            let month = date._i.month + 1;
            let day = date._i.date;

            return date._i.year + "" + (month < 10 ? "0" + month : month) + "" + (day < 10 ? "0" + day : day);
        }
    }

    //captitalize first character of string and returns string with it
    capitalizeFirstLetter(text: string) {
        return text.charAt(0).toUpperCase() + text.slice(1);
    }


    convertStringToDate(date: string) {
        let _year = parseInt(date.substring(0, 4));
        let _month = parseInt(date.substring(4, 6)) - 1;
        let _day = parseInt(date.substring(6, 8));

        return new Date(_year, _month, _day);
    }


    convertTo24HrFormat(time: string) {
        if (time.length === 5) {
            time = time + ":00";
        }
        if (time.length === 8 && time.indexOf('m') === time.length - 1
            && time.indexOf(':') === 2) {
            if (time.indexOf('am') > -1) {
                return time.replace(" am", ":00");
            }
            else if (time.indexOf('pm') > -1) {
                time = time.replace(" pm", ":00");
                let splittedTime = time.split(':');
                let hour = splittedTime[0];
                if (hour === "12") {
                    return time;
                }
                let updatedHour = (parseInt(splittedTime[0]) + 12).toString();
                return updatedHour + ":" + splittedTime[1] + ":" + splittedTime[2];
            }
            else {
                return time;
            }
        }
        else
            return time;
    }


    getCurrentTime() {
        let currentDate = new Date();
        let currentHours = currentDate.getHours();
        let currentMinutes = currentDate.getMinutes();
        let currentSecs = currentDate.getSeconds();
        return (currentHours < 10 ? ('0' + currentHours) : currentHours)
            + '' + (currentMinutes < 10 ? ('0' + currentMinutes) : currentMinutes)
            + '' + (currentSecs < 10 ? ('0' + currentSecs) : currentSecs);
    }


    // common fucntion for formatting amount
    formatAmount(amount: string) {
        let parsedValue = parseInt(amount);
        if (!isNaN(parsedValue))
            return parsedValue.toFixed(2);
        else return "0.00"
    }

    // common fucntion for formatting amount
    formatDecimalAmount(amount: string) {
        let parsedValue = parseFloat(amount);
        if (!isNaN(parsedValue))
            return parsedValue.toFixed(2);
        else return "0.00"
    }
 
  
}
