import { Injectable } from '@angular/core';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/fromPromise';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import { DataTranferService } from '../services/data-transfer.service';

import { isNullOrUndefined } from 'util';
import { HttpService } from './http.service';
import { DirectPrintService } from './direct-print.service';
declare var print: any;

@Injectable({ providedIn: 'root' })
export class PrinterService {
    panGstDetails: any;
    multiplePrints: boolean;
    data: string;
    multiplePrint: boolean;
    toastr: any;
    constructor(public dataTransferService: DataTranferService, private directPrintService: DirectPrintService) { }

    // call the web socket service and pass the data load
    callWebSocketService(data: any) {

        this.directPrintService.connect();
        this.directPrintService.print(data);

    }


}
