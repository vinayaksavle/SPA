import { BehaviorSubject } from 'rxjs';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import 'rxjs/add/operator/toPromise';
import { isNullOrUndefined } from 'util';
import { ErrorPageComponent } from '../components/_layout/error-page/error-page.component';
import { MatDialog } from '@angular/material';

@Injectable({ providedIn: 'root' })
export class DataTranferService {

    constructor(private router: Router, public dialog: MatDialog) { }

    public LoginKey = 'isUserLogin';
    public OpdKey = 'Ipd';

    public AccessRights: Array<string> = [];

    private formData = new BehaviorSubject<any>([]);
    cast_formData = this.formData.asObservable();

    public userType = 'userType';
    public doctCode = 'doctCode';

    private _islogin = new BehaviorSubject<boolean>(false);
    islogin = this._islogin.asObservable();


    private _userName = new BehaviorSubject<string>('');
    userName = this._userName.asObservable();


    private _permission = new BehaviorSubject<any>({});
    permission = this._permission.asObservable();

    getObject(key: string) {
        return localStorage.getItem(key);
    }

    setObject(key: string, value: any) {
        localStorage.setItem(key, value);
    }

    Logout() {
        this.setlogin(false);

    }

    encodeValue(value: string): string {
        return encodeURIComponent(value);
    }

    decodeValue(value: string): string {
        return decodeURIComponent(value);
    }
    // returns the current date in yyyymmdd format
    FormatDate(currentDate: Date) {
        let date = '';
        if (!isNullOrUndefined(currentDate)) {
            let year = currentDate.getFullYear().toString();

            let month = (currentDate.getMonth() + 1).toString();
            if (month.length == 1) {
                month = '0' + month;
            }

            let day = currentDate.getDate().toString();
            if (day.length == 1) {
                day = '0' + day;
            }
            date = year + month + day;
        }
        return date;
    }

    errorPage() {
        const dialogRef = this.dialog.open(ErrorPageComponent, {
            data: {
                key: null
            }
        });
        dialogRef.afterClosed().subscribe(dialogResult => {
            console.log('Close Popup');
        });
        // this.router.navigate(['error-page']);
    }

    setLoginKeyExternally(value) {
        this._islogin.next(value);
    }

    setlogin(value) {
        localStorage.setItem(this.LoginKey, value);
        this._islogin.next(value);
        localStorage.removeItem('Permission');
        localStorage.removeItem('UserName');
        localStorage.removeItem('Facility');
        localStorage.removeItem('Ipd');
        window.location.href = location.origin + '/#/login';
        return false;
    }

    setUserName(value: string) {
        localStorage.setItem('UserName', value);
        this._userName.next(value);
    }

    GetUserName(): string {
        return localStorage.getItem('UserName');
    }

    setPermission(value: any) {
        localStorage.setItem('Permission', JSON.stringify(value));
        this._permission.next(value);
    }

    setFacility(value: string) {
        localStorage.setItem('Facility', value);
    }

    setDefaultIpd(value) {
        localStorage.setItem('Ipd', value);
    }

    setUserGroup(value: any[]) {
        localStorage.setItem('moduleId', JSON.stringify(value));
    }

    GetUserGroup() {
        return JSON.parse(localStorage.getItem('moduleId'));
    }

    setValueInLocalStorage(key: string, value: string) {
        localStorage.setItem(key, value);
    }


    checkAccessRights(moduleid: string): boolean {
        const AccessRights = JSON.parse(localStorage.getItem('Permission'));
        if (AccessRights) {
            const index = AccessRights.indexOf(moduleid);
            if (index == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    getDayOfWeek(isoDate: string): string {
        let d = new Date(isoDate);
        let weekday = new Array(7);
        weekday[0] = 'Sunday';
        weekday[1] = 'Monday';
        weekday[2] = 'Tuesday';
        weekday[3] = 'Wednesday';
        weekday[4] = 'Thursday';
        weekday[5] = 'Friday';
        weekday[6] = 'Saturday';

        let day = weekday[d.getDay()];
        return day;
    }

    setDefaultOpd(value) {
        localStorage.setItem('Opd', value);
    }

    checkUserSession() {
        let result: boolean = false;
        let facilty = localStorage.getItem('Facility');
        let islogin = localStorage.getItem('isUserLogin')
        if (islogin == 'true' && !isNullOrUndefined(facilty)) {
            //do something
        }
        else {
            this.Logout();
            return;
        }
    }

    setCookie(name: string, value: string) {
        document.cookie = `${name} = ${value}`;
    }

    getCookieValue(propertyName: string) {
        let cookies = document.cookie.split(";");
        var cookieValue = cookies.filter(c => c.indexOf(propertyName));
        if (!isNullOrUndefined(cookieValue)) return cookieValue[0].split("=")[1].trim();
        else return "";
    }
}
