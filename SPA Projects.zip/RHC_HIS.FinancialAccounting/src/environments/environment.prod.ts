 
 const applicationDomainURL = 'http://128.9.8.26:97';


const applicationAPIURL = applicationDomainURL + '/api/';
export const environment = {
    production: true,
    domainURL: applicationDomainURL,
    apiURL: applicationAPIURL,
    libURL: applicationAPIURL,
    smartCardUrl: applicationAPIURL,
};

